package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WireTest {
    private fun pts() = List(33) { i -> BodyPoint(i / 40f - 0.1f, 1f - i / 35f, (i % 11) / 10f) }

    @Test fun roundTripKeepsEverything() {
        val src = pts()
        val bytes = Wire.encodePose(src, 480, 640, lightingOk = true, mirrored = true, timeMs = 123_456_789_012L)
        val d = Wire.decodePose(bytes)!!
        assertEquals(480, d.width)
        assertEquals(640, d.height)
        assertTrue(d.lightingOk)
        assertTrue(d.mirrored)
        assertEquals(123_456_789_012L, d.timeMs)
        val out = d.points!!
        assertEquals(33, out.size)
        for (i in 0 until 33) {
            assertTrue("x$i", kotlin.math.abs(out[i].x - src[i].x) < 0.001f)
            assertTrue("y$i", kotlin.math.abs(out[i].y - src[i].y) < 0.001f)
            assertTrue("v$i", kotlin.math.abs(out[i].v - src[i].v) < 0.01f)
        }
    }

    @Test fun noBodyIsSentAsEmptyFrame() {
        val d = Wire.decodePose(Wire.encodePose(null, 480, 640, lightingOk = false, mirrored = false, timeMs = 5L))!!
        assertTrue(d.points == null)
        assertTrue(!d.lightingOk)
        assertTrue(!d.mirrored)
    }

    @Test fun messageIsSmall() {
        assertTrue(Wire.encodePose(pts(), 480, 640, true, false, 1L).size < 200)
    }

    @Test fun garbageIsRejected() {
        assertTrue(Wire.decodePose(ByteArray(0)) == null)
        assertTrue(Wire.decodePose(ByteArray(40) { 7 }) == null)
        val ok = Wire.encodePose(pts(), 480, 640, true, false, 1L)
        assertTrue(Wire.decodePose(ok.copyOf(50)) == null) // truncated
    }

    @Test fun landmarksSlightlyOutsideTheFrameSurvive() {
        val src = List(33) { BodyPoint(-0.2f, 1.3f, 1f) }
        val out = Wire.decodePose(Wire.encodePose(src, 480, 640, true, false, 1L))!!.points!!
        assertTrue(kotlin.math.abs(out[0].x + 0.2f) < 0.001f)
        assertTrue(kotlin.math.abs(out[0].y - 1.3f) < 0.001f)
    }
}
