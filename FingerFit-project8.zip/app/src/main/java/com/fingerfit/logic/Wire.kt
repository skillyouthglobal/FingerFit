package com.fingerfit.logic

import java.nio.ByteBuffer
import java.nio.ByteOrder

class DecodedPose(
    val points: List<BodyPoint>?,
    val width: Int,
    val height: Int,
    val lightingOk: Boolean,
    val mirrored: Boolean,
    val timeMs: Long,
)

/**
 * Compact binary format used to send body landmarks from the camera phone to the
 * display phone (about 180 bytes per frame, so it works even over Bluetooth).
 * No video is ever sent.
 */
object Wire {
    private const val TYPE_POSE: Byte = 1
    private const val HEADER = 14 // type 1 + flags 1 + width 2 + height 2 + time 8
    private const val POINT = 5 // x 2 + y 2 + visibility 1
    private const val COUNT = 33
    private const val SCALE = 16384f

    fun encodePose(
        points: List<BodyPoint>?,
        width: Int,
        height: Int,
        lightingOk: Boolean,
        mirrored: Boolean,
        timeMs: Long,
    ): ByteArray {
        val pts = if (points != null && points.size == COUNT) points else null
        val buf = ByteBuffer.allocate(HEADER + if (pts != null) COUNT * POINT else 0).order(ByteOrder.BIG_ENDIAN)
        var flags = 0
        if (lightingOk) flags = flags or 1
        if (mirrored) flags = flags or 2
        if (pts != null) flags = flags or 4
        buf.put(TYPE_POSE)
        buf.put(flags.toByte())
        buf.putShort(width.coerceIn(0, 32767).toShort())
        buf.putShort(height.coerceIn(0, 32767).toShort())
        buf.putLong(timeMs)
        if (pts != null) {
            for (p in pts) {
                buf.putShort((p.x * SCALE).toInt().coerceIn(-32768, 32767).toShort())
                buf.putShort((p.y * SCALE).toInt().coerceIn(-32768, 32767).toShort())
                buf.put((p.v * 255f).toInt().coerceIn(0, 255).toByte())
            }
        }
        return buf.array()
    }

    /** Returns null for anything that is not a complete, valid pose message. */
    fun decodePose(b: ByteArray): DecodedPose? {
        if (b.size < HEADER || b[0] != TYPE_POSE) return null
        val buf = ByteBuffer.wrap(b).order(ByteOrder.BIG_ENDIAN)
        buf.get()
        val flags = buf.get().toInt()
        val w = buf.short.toInt()
        val h = buf.short.toInt()
        val t = buf.long
        val lighting = (flags and 1) != 0
        val mirrored = (flags and 2) != 0
        if ((flags and 4) == 0) return DecodedPose(null, w, h, lighting, mirrored, t)
        if (b.size < HEADER + COUNT * POINT) return null
        val pts = List(COUNT) {
            val x = buf.short / SCALE
            val y = buf.short / SCALE
            val v = (buf.get().toInt() and 255) / 255f
            BodyPoint(x, y, v)
        }
        return DecodedPose(pts, w, h, lighting, mirrored, t)
    }
}
