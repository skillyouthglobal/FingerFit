package com.fingerfit

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fingerfit.link.LinkState
import com.fingerfit.link.LinkUi
import com.fingerfit.link.NearbyLink
import com.fingerfit.link.Peer
import com.fingerfit.link.WebCamServer
import com.fingerfit.link.WebUi
import com.fingerfit.logic.Wire
import com.fingerfit.vision.PoseFrame
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Two-phone mode: owns the Nearby link, sends frames (camera phone) or receives them (main phone). */
class LinkViewModel(app: Application) : AndroidViewModel(app) {

    private val link = NearbyLink(app) { bytes -> onBytes(bytes) }
    val ui: StateFlow<LinkUi> = link.ui

    private val web = WebCamServer(app) { f -> onWebFrame(f) }
    /** Browser-camera mode (the other phone needs no app). */
    val webUi: StateFlow<WebUi> = web.ui

    private val _streamOk = MutableStateFlow(false)
    /** True while body data keeps arriving from the camera phone. */
    val streamOk: StateFlow<Boolean> = _streamOk.asStateFlow()

    @Volatile private var sink: ((PoseFrame) -> Unit)? = null
    @Volatile private var lastFrameAt = 0L
    @Volatile private var lastSentAt = 0L

    init {
        viewModelScope.launch {
            while (true) {
                val ok = (link.ui.value.state == LinkState.CONNECTED || web.ui.value.running) &&
                    SystemClock.uptimeMillis() - lastFrameAt < 2000
                if (_streamOk.value != ok) _streamOk.value = ok
                delay(500)
            }
        }
    }

    fun setSink(s: ((PoseFrame) -> Unit)?) {
        sink = s
    }

    fun startDisplay() = link.startDisplay()
    fun startCamera() = link.startCamera()
    fun connect(peer: Peer) = link.connect(peer)
    fun accept() = link.accept()
    fun reject() = link.reject()
    fun startWeb() {
        link.stop()
        web.start()
    }

    fun refreshWeb() = web.refresh()

    fun stop() {
        link.stop()
        web.stop()
        lastFrameAt = 0L
    }

    fun isConnected(): Boolean = link.isConnected()

    /** Camera phone: send one analysed frame (about 12 per second at most). */
    fun sendPose(f: PoseFrame?) {
        if (f == null || !link.isConnected()) return
        val now = SystemClock.uptimeMillis()
        if (now - lastSentAt < MIN_SEND_GAP_MS) return
        lastSentAt = now
        link.send(Wire.encodePose(f.points, f.width, f.height, f.lightingOk, f.mirrored, f.timeMs))
    }

    private fun onBytes(bytes: ByteArray) {
        val d = Wire.decodePose(bytes) ?: return
        lastFrameAt = SystemClock.uptimeMillis()
        sink?.invoke(PoseFrame(d.points, d.width, d.height, d.lightingOk, d.mirrored, d.timeMs))
    }

    private fun onWebFrame(f: PoseFrame) {
        lastFrameAt = SystemClock.uptimeMillis()
        sink?.invoke(f)
    }

    override fun onCleared() {
        web.stop()
        link.release()
    }

    private companion object {
        const val MIN_SEND_GAP_MS = 70L
    }
}
