package com.fingerfit.link

import android.Manifest
import android.content.Context
import android.os.Build
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class LinkRole { NONE, DISPLAY, CAMERA }

enum class LinkState { IDLE, WAITING, SEARCHING, CONNECTING, CONNECTED }

class Peer(val id: String, val name: String)

data class LinkUi(
    val role: LinkRole = LinkRole.NONE,
    val state: LinkState = LinkState.IDLE,
    val peers: List<Peer> = emptyList(),
    val message: String = "",
    /** Pairing code shown on both phones while connecting. */
    val code: String? = null,
    /** Name of the phone that is asking to connect, or that we are connected to. */
    val peerName: String? = null,
    /** On the display phone: a camera phone is waiting for the user to accept. */
    val needsAccept: Boolean = false,
)

object LinkPermissions {
    /** The runtime permissions Nearby needs on this Android version. */
    fun nearby(): List<String> = when {
        Build.VERSION.SDK_INT >= 33 -> listOf(
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.NEARBY_WIFI_DEVICES,
        )
        Build.VERSION.SDK_INT >= 31 -> listOf(
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.ACCESS_FINE_LOCATION,
        )
        else -> listOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }
}

/**
 * Offline phone-to-phone link built on Google Nearby Connections. Nearby picks the
 * fastest medium available on its own: the same Wi-Fi, a phone hotspot, Wi-Fi Direct,
 * Bluetooth or BLE. No internet is needed. Only small body-landmark messages are sent.
 */
class NearbyLink(context: Context, private val onData: (ByteArray) -> Unit) {

    private val client: ConnectionsClient = Nearby.getConnectionsClient(context.applicationContext)
    private val deviceName: String = (Build.MODEL ?: "Phone").take(30)

    private val _ui = MutableStateFlow(LinkUi())
    val ui: StateFlow<LinkUi> = _ui.asStateFlow()

    @Volatile private var endpoint: String? = null
    private var pendingId: String? = null

    fun isConnected(): Boolean = endpoint != null

    // ---- start / stop ------------------------------------------------------

    /** The phone that shows the workout waits for a camera phone. */
    fun startDisplay() {
        resetNearby()
        _ui.value = LinkUi(role = LinkRole.DISPLAY, state = LinkState.WAITING, message = "Waiting for the camera phone…")
        advertise()
    }

    /** The phone that watches the exercise looks for the display phone. */
    fun startCamera() {
        resetNearby()
        _ui.value = LinkUi(role = LinkRole.CAMERA, state = LinkState.SEARCHING, message = "Looking for the main phone…")
        discover()
    }

    fun stop() {
        resetNearby()
        _ui.value = LinkUi()
    }

    private fun resetNearby() {
        try {
            client.stopAdvertising()
            client.stopDiscovery()
            client.stopAllEndpoints()
        } catch (e: Exception) {
        }
        endpoint = null
        pendingId = null
    }

    private fun advertise() {
        try {
            val options = AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
            client.startAdvertising(deviceName, SERVICE_ID, lifecycle, options)
                .addOnFailureListener { fail("Could not start. Turn on Bluetooth and Wi-Fi, then try again. (${it.localizedMessage ?: "error"})") }
        } catch (e: Exception) {
            fail("Could not start (${e.localizedMessage ?: "error"}).")
        }
    }

    private fun discover() {
        try {
            val options = DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
            client.startDiscovery(SERVICE_ID, discovery, options)
                .addOnFailureListener { fail("Could not search. Turn on Bluetooth and Wi-Fi, then try again. (${it.localizedMessage ?: "error"})") }
        } catch (e: Exception) {
            fail("Could not search (${e.localizedMessage ?: "error"}).")
        }
    }

    private fun fail(message: String) {
        _ui.update { it.copy(message = message) }
    }

    // ---- connecting --------------------------------------------------------

    /** Camera phone: ask the chosen main phone to connect. */
    fun connect(peer: Peer) {
        if (_ui.value.role != LinkRole.CAMERA) return
        _ui.update { it.copy(state = LinkState.CONNECTING, peerName = peer.name, message = "Connecting to ${peer.name}…") }
        try {
            client.requestConnection(deviceName, peer.id, lifecycle)
                .addOnFailureListener {
                    _ui.update { u ->
                        u.copy(state = LinkState.SEARCHING, message = "Could not connect (${it.localizedMessage ?: "error"}). Try again.")
                    }
                }
        } catch (e: Exception) {
            _ui.update { it.copy(state = LinkState.SEARCHING, message = "Could not connect.") }
        }
    }

    /** Display phone: the user confirmed the code. */
    fun accept() {
        val id = pendingId ?: return
        _ui.update { it.copy(needsAccept = false, message = "Connecting…") }
        try {
            client.acceptConnection(id, payloads)
        } catch (e: Exception) {
        }
    }

    fun reject() {
        val id = pendingId ?: return
        pendingId = null
        _ui.update { it.copy(needsAccept = false, state = LinkState.WAITING, code = null, peerName = null, message = "Waiting for the camera phone…") }
        try {
            client.rejectConnection(id)
        } catch (e: Exception) {
        }
    }

    fun send(bytes: ByteArray) {
        val id = endpoint ?: return
        try {
            client.sendPayload(id, Payload.fromBytes(bytes))
        } catch (e: Exception) {
        }
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            val role = _ui.value.role
            if (endpoint != null || (pendingId != null && pendingId != id)) {
                try { client.rejectConnection(id) } catch (e: Exception) {}
                return
            }
            pendingId = id
            val code = info.authenticationDigits
            if (role == LinkRole.CAMERA) {
                // The user already chose this phone, so accept; the code is shown for checking.
                _ui.update { it.copy(state = LinkState.CONNECTING, code = code, peerName = info.endpointName, message = "Connecting to ${info.endpointName}…") }
                try { client.acceptConnection(id, payloads) } catch (e: Exception) {}
            } else {
                _ui.update {
                    it.copy(state = LinkState.CONNECTING, code = code, peerName = info.endpointName, needsAccept = true,
                        message = "${info.endpointName} wants to connect")
                }
            }
        }

        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                endpoint = id
                pendingId = null
                try {
                    client.stopAdvertising()
                    client.stopDiscovery()
                } catch (e: Exception) {
                }
                _ui.update { it.copy(state = LinkState.CONNECTED, needsAccept = false, peers = emptyList(), message = "Connected") }
            } else {
                pendingId = null
                backToSearching("The connection was not completed. Try again.")
            }
        }

        override fun onDisconnected(id: String) {
            if (id != endpoint && id != pendingId) return
            endpoint = null
            pendingId = null
            backToSearching("The other phone disconnected.")
        }
    }

    private fun backToSearching(message: String) {
        val role = _ui.value.role
        if (role == LinkRole.NONE) return
        _ui.update {
            it.copy(
                state = if (role == LinkRole.DISPLAY) LinkState.WAITING else LinkState.SEARCHING,
                needsAccept = false, code = null, peerName = null, peers = emptyList(), message = message,
            )
        }
        try {
            client.stopAllEndpoints()
            client.stopAdvertising()
            client.stopDiscovery()
        } catch (e: Exception) {
        }
        if (role == LinkRole.DISPLAY) advertise() else discover()
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            _ui.update { u -> u.copy(peers = u.peers.filter { it.id != id } + Peer(id, info.endpointName)) }
        }

        override fun onEndpointLost(id: String) {
            _ui.update { u -> u.copy(peers = u.peers.filter { it.id != id }) }
        }
    }

    private val payloads = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {
            val b = payload.asBytes() ?: return
            try {
                onData(b)
            } catch (e: Exception) {
            }
        }

        override fun onPayloadTransferUpdate(id: String, update: PayloadTransferUpdate) {}
    }

    fun release() {
        resetNearby()
    }

    private companion object {
        const val SERVICE_ID = "com.fingerfit.kinetro.link"
    }
}
