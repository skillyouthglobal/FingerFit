package com.fingerfit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.data.Repo
import com.fingerfit.logic.ExerciseType
import com.fingerfit.ui.BodyListScreen
import com.fingerfit.ui.ExerciseScreen
import com.fingerfit.ui.FingerFitTheme
import com.fingerfit.ui.HomeScreen
import com.fingerfit.ui.InboxScreen
import com.fingerfit.ui.LinkScreen
import com.fingerfit.ui.SettingsScreen
import com.fingerfit.ui.SleepScreen
import com.fingerfit.ui.WalkScreen
import com.fingerfit.ui.WorkoutScreen

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    private val workoutVm: WorkoutViewModel by viewModels()
    private val linkVm: LinkViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(this)
        Notify.ensureChannels(this)
        val s = vm.settings.value
        Reminders.scheduleSleep(this, s.sleepReminder, s.sleepHour, s.sleepMinute)
        enableEdgeToEdge()
        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            FingerFitTheme(settings.theme) { FingerFitApp(vm, workoutVm, linkVm) }
        }
    }
}

private const val HOME = "home"
private const val EXERCISE = "exercise"
private const val SETTINGS = "settings"
private const val BODY = "body"
private const val WORKOUT = "workout"
private const val WALK = "walk"
private const val SLEEP = "sleep"
private const val INBOX = "inbox"
private const val LINK = "link"

@Composable
private fun FingerFitApp(vm: AppViewModel, workoutVm: WorkoutViewModel, linkVm: LinkViewModel) {
    var screen by rememberSaveable { mutableStateOf(HOME) }
    val goHome = { screen = HOME }
    when (screen) {
        EXERCISE -> ExerciseScreen(vm, onExit = goHome)
        SETTINGS -> SettingsScreen(vm, onBack = goHome)
        BODY -> BodyListScreen(
            onBack = goHome,
            onPick = { type: ExerciseType ->
                workoutVm.select(type)
                screen = WORKOUT
            },
        )
        WORKOUT -> WorkoutScreen(workoutVm, vm, onExit = { screen = BODY })
        WALK -> WalkScreen(vm, onBack = goHome)
        SLEEP -> SleepScreen(vm, onBack = goHome)
        INBOX -> InboxScreen(onBack = goHome)
        LINK -> LinkScreen(linkVm, workoutVm, vm, onBack = goHome)
        else -> HomeScreen(
            vm,
            onStart = { vm.prepareSession(); screen = EXERCISE },
            onSettings = { screen = SETTINGS },
            onBody = { screen = BODY },
            onWalk = { screen = WALK },
            onSleep = { screen = SLEEP },
            onInbox = { screen = INBOX },
            onLink = { screen = LINK },
        )
    }
}
