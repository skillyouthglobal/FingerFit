package com.fingerfit.logic

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Why the camera picture is not good enough yet for the exercise. */
enum class FrameIssue {
    NO_BODY, DARK, HEAD_CUT, FEET_CUT, UPPER_ONLY, SIDE_CUT, LOW_VISIBILITY, TOO_FAR, TILTED, TURN_SIDE, FACE_FRONT,
}

/**
 * Looks at the body points of one picture and finds what is wrong with the set-up, the way a coach standing
 * beside the camera would: half the body missing, feet cut off, too far, wrong side to the camera, tilted camera, too dark.
 * Returns null when everything needed for the exercise is in view.
 */
object Framing {
    private const val EDGE = 0.03f
    private const val SEEN = 0.5f

    fun needsFront(t: ExerciseType) = t == ExerciseType.JUMPING_JACKS || t == ExerciseType.HIGH_KNEES
    fun isLying(t: ExerciseType) =
        t == ExerciseType.PUSH_UPS || t == ExerciseType.CRUNCHES || t == ExerciseType.GLUTE_BRIDGES || t == ExerciseType.PLANK ||
            t == ExerciseType.INCLINE_PUSHUPS || t == ExerciseType.DECLINE_PUSHUPS || t == ExerciseType.LEG_RAISE

    private fun seen(p: BodyPoint) = p.v >= SEEN && p.x > EDGE / 2 && p.x < 1f - EDGE / 2 && p.y > EDGE / 2 && p.y < 1f - EDGE / 2

    private class Group(val ids: IntArray)

    /** Which way the missing joints went out of the picture: 'b' bottom, 't' top, 'l' left, 'r' right, 'i' still inside (just not clear). */
    private fun where(pts: List<BodyPoint>, g: Group): Char {
        var sx = 0f
        var sy = 0f
        for (i in g.ids) { sx += pts[i].x; sy += pts[i].y }
        val x = sx / g.ids.size
        val y = sy / g.ids.size
        return when {
            y > 1f - EDGE -> 'b'
            y < EDGE -> 't'
            x < EDGE -> 'l'
            x > 1f - EDGE -> 'r'
            else -> 'i'
        }
    }

    fun check(t: ExerciseType, pts: List<BodyPoint>?, w: Float, h: Float, lightOk: Boolean): FrameIssue? {
        if (!lightOk) return FrameIssue.DARK
        if (pts == null || pts.size < 33 || w <= 0f || h <= 0f) return FrameIssue.NO_BODY

        val shoulders = Group(intArrayOf(Joint.L_SH, Joint.R_SH))
        val hips = Group(intArrayOf(Joint.L_HIP, Joint.R_HIP))
        val knees = Group(intArrayOf(Joint.L_KN, Joint.R_KN))
        val ankles = Group(intArrayOf(Joint.L_AN, Joint.R_AN))
        val feet = Group(intArrayOf(Joint.L_HEEL, Joint.R_HEEL, Joint.L_FOOT, Joint.R_FOOT))
        val head = Group(intArrayOf(Joint.NOSE))

        fun has(g: Group) = g.ids.any { seen(pts[it]) }
        val hasSh = has(shoulders)
        val hasHip = has(hips)
        val hasKn = has(knees)
        val hasAn = has(ankles)
        val hasFeet = has(feet)
        val hasHead = has(head)

        // 1) something needed is missing: find out how
        val kneesGone = !hasKn && !hasAn
        if (kneesGone && (hasSh || hasHip)) {
            val d = where(pts, knees)
            if (d == 'l' || d == 'r') return FrameIssue.SIDE_CUT
            return FrameIssue.UPPER_ONLY
        }
        if (!hasSh && !hasHip) {
            // only legs, or nothing reliable
            val d = where(pts, shoulders)
            return if (d == 't') FrameIssue.HEAD_CUT else if (d == 'l' || d == 'r') FrameIssue.SIDE_CUT else FrameIssue.LOW_VISIBILITY
        }
        if (!hasAn || (t == ExerciseType.CALF_RAISES && !hasFeet)) {
            val d = where(pts, if (!hasAn) ankles else feet)
            return when (d) {
                'b' -> FrameIssue.FEET_CUT
                'l', 'r' -> FrameIssue.SIDE_CUT
                else -> FrameIssue.LOW_VISIBILITY
            }
        }
        if (!hasHead) {
            // the head only matters when it has gone out of the picture; a nose that is just unclear is ignored
            val d = where(pts, head)
            if (d == 't') return FrameIssue.HEAD_CUT
            if (d == 'l' || d == 'r') return FrameIssue.SIDE_CUT
        }
        if (!hasSh || !hasHip || !hasKn) return FrameIssue.LOW_VISIBILITY

        // 2) everything is there: is the person big enough, upright, and turned the right way?
        var minX = 1f; var maxX = 0f; var minY = 1f; var maxY = 0f
        for (i in intArrayOf(Joint.NOSE, Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP, Joint.L_KN, Joint.R_KN, Joint.L_AN, Joint.R_AN)) {
            if (!seen(pts[i])) continue
            minX = min(minX, pts[i].x); maxX = max(maxX, pts[i].x)
            minY = min(minY, pts[i].y); maxY = max(maxY, pts[i].y)
        }
        if (max(maxY - minY, maxX - minX) < 0.38f) return FrameIssue.TOO_FAR

        fun mid(a: Int, b: Int, useX: Boolean): Float {
            val pa = pts[a]; val pb = pts[b]
            val xa = if (useX) pa.x * w else pa.y * h
            val xb = if (useX) pb.x * w else pb.y * h
            return when {
                seen(pa) && seen(pb) -> (xa + xb) / 2f
                seen(pa) -> xa
                else -> xb
            }
        }
        val shX = mid(Joint.L_SH, Joint.R_SH, true); val shY = mid(Joint.L_SH, Joint.R_SH, false)
        val hpX = mid(Joint.L_HIP, Joint.R_HIP, true); val hpY = mid(Joint.L_HIP, Joint.R_HIP, false)
        val dx = abs(hpX - shX)
        val dy = abs(hpY - shY)
        if (!isLying(t) && dx > 1.3f * dy && dx > 0.08f * w) return FrameIssue.TILTED

        val torso = hypot(hpX - shX, hpY - shY)
        if (torso > 0.1f * min(w, h) && seen(pts[Joint.L_SH]) && seen(pts[Joint.R_SH])) {
            val shoulderWidth = hypot((pts[Joint.L_SH].x - pts[Joint.R_SH].x) * w, (pts[Joint.L_SH].y - pts[Joint.R_SH].y) * h)
            val ratio = shoulderWidth / torso
            if (needsFront(t) && ratio < 0.3f) return FrameIssue.FACE_FRONT
            if (isLying(t) && ratio > 0.6f) return FrameIssue.TURN_SIDE
        }
        return null
    }

    /** A short line for the screen (English; the app translates it). */
    fun screenText(issue: FrameIssue?): String = when (issue) {
        null -> "Perfect. Your whole body is in view. Press Start when ready."
        FrameIssue.NO_BODY -> "Stand in front of the camera."
        FrameIssue.DARK -> "Too dark. Move to a brighter place."
        FrameIssue.HEAD_CUT -> "Your head is out of view. Step back a little."
        FrameIssue.FEET_CUT -> "Your feet are out of view. Step back a little."
        FrameIssue.UPPER_ONLY -> "Only your upper body is visible. Step back so your whole body fits."
        FrameIssue.SIDE_CUT -> "You are at the edge of the picture. Move to the middle."
        FrameIssue.LOW_VISIBILITY -> "I can't see you clearly. Check the light and that nothing blocks you."
        FrameIssue.TOO_FAR -> "A little closer to the camera, please."
        FrameIssue.TILTED -> "The picture looks tilted. Hold the camera upright."
        FrameIssue.TURN_SIDE -> "Turn sideways to the camera."
        FrameIssue.FACE_FRONT -> "Face the camera."
    }
}

/**
 * Says what is wrong with the set-up, calmly and at the right time: waits a moment before speaking (people are still
 * moving into place), does not repeat itself, gives up after a few tries, and says well done once it is fixed.
 */
class FramingCoach(private val bn: Boolean, name: String, private val rnd: kotlin.random.Random = kotlin.random.Random.Default) {
    private val nm = name.trim().substringBefore(' ')
    private var cur: FrameIssue? = null
    private var curSince = 0L
    private var lastSpoke = -100_000L
    private var lastSpokeIssue: FrameIssue? = null
    private var tries = 0
    private var warned = false
    private var readySaid = false
    private var idx = 0

    fun reset() {
        cur = null; curSince = 0L; lastSpoke = -100_000L; lastSpokeIssue = null; tries = 0; warned = false; readySaid = false
    }

    private fun fill(s: String): String {
        val r = if (nm.isEmpty()) s.replace("{n}, ", "").replace(", {n}", "").replace("{n}", "") else s.replace("{n}", nm)
        return r.trim()
    }

    /**
     * Called for every picture. [idle] = before the exercise has started (also says when everything is ready).
     * [skipNoBody] = leave "I can't see you" to the other coach while exercising.
     */
    fun update(issue: FrameIssue?, nowMs: Long, idle: Boolean, skipNoBody: Boolean = false): Say? {
        if (issue != cur) { cur = issue; curSince = nowMs }
        val held = nowMs - curSince
        if (issue == null) {
            if (warned && held >= 1200) {
                warned = false; tries = 0; lastSpokeIssue = null
                readySaid = idle
                return Say(fill(if (bn) pick(listOf("ঠিক আছে {n}, এবার আপনাকে পুরোটা দেখা যাচ্ছে।", "এই তো {n}, এখন ঠিক আছে।")) else pick(listOf("That's it, {n}. I can see you fully now.", "Perfect, {n}. All good now."))), false)
            }
            if (idle && !readySaid && held >= 1500) {
                readySaid = true
                return Say(fill(if (bn) pick(listOf("দারুণ {n}, আপনাকে পুরোটা দেখা যাচ্ছে। এবার শুরু করুন।", "{n}, সব ঠিক আছে। প্রস্তুত হলে শুরু করুন।")) else pick(listOf("Great, {n}, I can see all of you. Press Start when you're ready.", "All set, {n}. Start whenever you're ready."))), false)
            }
            return null
        }
        if (skipNoBody && issue == FrameIssue.NO_BODY) return null
        val wait = if (issue == FrameIssue.NO_BODY) 3000L else 1800L
        if (held < wait) return null
        val gap = if (issue == lastSpokeIssue) 14_000L else 7_000L
        if (nowMs - lastSpoke < gap) return null
        if (issue == lastSpokeIssue && tries >= 3) return null // do not nag
        tries = if (issue == lastSpokeIssue) tries + 1 else 1
        lastSpoke = nowMs; lastSpokeIssue = issue; warned = true; readySaid = false
        return Say(fill(voice(issue)), false)
    }

    private fun pick(l: List<String>): String { idx = (idx + 1 + rnd.nextInt(l.size)) % l.size; return l[idx] }

    fun voice(i: FrameIssue): String = if (bn) when (i) {
        FrameIssue.NO_BODY -> pick(listOf("{n}, আপনাকে দেখতে পাচ্ছি না। ক্যামেরার সামনে এসে দাঁড়ান।", "কাউকে দেখা যাচ্ছে না। {n}, ক্যামেরার সামনে আসুন।"))
        FrameIssue.DARK -> pick(listOf("{n}, আলো খুব কম। একটু আলো আছে এমন জায়গায় যান।", "জায়গাটা অন্ধকার, {n}। আলো জ্বালিয়ে নিন।"))
        FrameIssue.HEAD_CUT -> pick(listOf("{n}, আপনার মাথা ছবির বাইরে চলে গেছে। একটু পেছনে সরুন।", "মাথা কেটে যাচ্ছে, {n}। ক্যামেরা থেকে একটু দূরে যান।"))
        FrameIssue.FEET_CUT -> pick(listOf("{n}, আপনার পা দেখা যাচ্ছে না। একটু পেছনে সরুন, তাহলে পা পর্যন্ত ছবিতে আসবে।", "পা কেটে যাচ্ছে, {n}। ক্যামেরা থেকে আরেকটু দূরে দাঁড়ান।"))
        FrameIssue.UPPER_ONLY -> pick(listOf("{n}, শুধু শরীরের ওপরের অংশ দেখা যাচ্ছে। এই ব্যায়ামে পুরো শরীর লাগবে, একটু পেছনে সরে যান।", "{n}, অর্ধেক শরীর দেখা যাচ্ছে। মাথা থেকে পা পর্যন্ত ছবিতে আনতে পেছনে সরুন।"))
        FrameIssue.SIDE_CUT -> pick(listOf("{n}, আপনি ছবির এক পাশে সরে গেছেন, শরীর কেটে যাচ্ছে। ছবির মাঝখানে আসুন।", "শরীর ছবির কিনারায়, {n}। একটু মাঝখানে আসুন।"))
        FrameIssue.LOW_VISIBILITY -> pick(listOf("{n}, আপনাকে ঠিকমতো স্পষ্ট দেখতে পাচ্ছি না। আলো ঠিক আছে কি না দেখুন, আর কিছু যেন শরীর ঢেকে না রাখে।", "ছবি পরিষ্কার নয়, {n}। একটু বেশি আলোতে এসে দাঁড়ান।"))
        FrameIssue.TOO_FAR -> pick(listOf("{n}, আপনি একটু বেশি দূরে আছেন। ক্যামেরার একটু কাছে আসুন, যাতে ঠিকমতো গুনতে পারি।", "একটু কাছে আসুন, {n}, তাহলে আরও নির্ভুল গুনতে পারব।"))
        FrameIssue.TILTED -> pick(listOf("{n}, ছবিটা কাত হয়ে আছে মনে হচ্ছে। ফোন বা ক্যামেরা সোজা করে ধরুন। দরকার হলে ছবি ঘোরান বোতাম চাপুন।", "ক্যামেরা কাত হয়ে আছে, {n}। সোজা করে নিন।"))
        FrameIssue.TURN_SIDE -> pick(listOf("{n}, এই ব্যায়ামে ক্যামেরার দিকে পাশ ফিরে দাঁড়াতে হবে। একটু ঘুরে যান।", "পাশ ফিরে দাঁড়ান, {n}, যাতে ক্যামেরা পাশ থেকে দেখতে পায়।"))
        FrameIssue.FACE_FRONT -> pick(listOf("{n}, এই ব্যায়ামে ক্যামেরার দিকে মুখ করে দাঁড়ান।", "ক্যামেরার দিকে ঘুরে দাঁড়ান, {n}, যাতে সামনে থেকে দেখা যায়।"))
    } else when (i) {
        FrameIssue.NO_BODY -> pick(listOf("{n}, I can't see you. Step in front of the camera.", "I can't see anyone, {n}. Come in front of the camera."))
        FrameIssue.DARK -> pick(listOf("{n}, it's too dark. Move to a brighter spot.", "It's quite dark here, {n}. Turn on a light."))
        FrameIssue.HEAD_CUT -> pick(listOf("{n}, your head is out of the picture. Step back a little.", "Your head is cut off, {n}. Move a bit further from the camera."))
        FrameIssue.FEET_CUT -> pick(listOf("{n}, I can't see your feet. Step back a little so they fit in the picture.", "Your feet are cut off, {n}. Stand a bit further from the camera."))
        FrameIssue.UPPER_ONLY -> pick(listOf("{n}, I can only see your upper body. This exercise needs your whole body, so step back.", "I can see just half of you, {n}. Step back until you're in from head to toe."))
        FrameIssue.SIDE_CUT -> pick(listOf("{n}, you've drifted to the edge of the picture and you're getting cut off. Move to the middle.", "You're at the edge, {n}. Come a little more to the centre."))
        FrameIssue.LOW_VISIBILITY -> pick(listOf("{n}, I can't see you clearly. Check the light and that nothing is blocking you.", "The picture isn't clear, {n}. Try a brighter spot."))
        FrameIssue.TOO_FAR -> pick(listOf("{n}, you're a little too far. Come closer so I can count accurately.", "A bit closer, {n}, and I'll count more accurately."))
        FrameIssue.TILTED -> pick(listOf("{n}, the picture looks tilted. Hold the phone or camera upright. You can also press Rotate picture.", "The camera looks tilted, {n}. Straighten it up."))
        FrameIssue.TURN_SIDE -> pick(listOf("{n}, this exercise needs you sideways to the camera. Turn a little.", "Turn sideways, {n}, so the camera sees you from the side."))
        FrameIssue.FACE_FRONT -> pick(listOf("{n}, face the camera for this exercise.", "Turn to face the camera, {n}, so it sees you from the front."))
    }
}
