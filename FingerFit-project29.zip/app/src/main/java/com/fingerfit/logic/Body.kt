package com.fingerfit.logic

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.hypot

/** One of the 33 MediaPipe pose landmarks (x,y normalised 0..1) with its visibility score. */
class BodyPoint(val x: Float, val y: Float, val v: Float)

/** MediaPipe pose landmark indices used by the app. */
object Joint {
    const val NOSE = 0
    const val L_SH = 11
    const val R_SH = 12
    const val L_EL = 13
    const val R_EL = 14
    const val L_WR = 15
    const val R_WR = 16
    const val L_HIP = 23
    const val R_HIP = 24
    const val L_KN = 25
    const val R_KN = 26
    const val L_AN = 27
    const val R_AN = 28
    const val L_HEEL = 29
    const val R_HEEL = 30
    const val L_FOOT = 31
    const val R_FOOT = 32
}

enum class ExerciseType(
    val emoji: String,
    val title: String,
    val benefit: String,
    val setup: String,
    val unit: String,
    val defaultTarget: Int,
    val step: Int,
    val startCue: String,
    val peakCue: String,
    val backCue: String,
) {
    JUMPING_JACKS(
        "🤸", "Jumping Jacks",
        "Boosts heart fitness and endurance, improves arm-leg coordination.",
        "Face the camera with your whole body in view.",
        "reps", 20, 5,
        "Stand with feet together, arms down", "Jump: arms up, feet apart", "Jump back to the start",
    ),
    SQUATS(
        "🏋️", "Bodyweight Squats",
        "Strengthens thighs and glutes, makes sitting and standing easier.",
        "Stand sideways to the camera, whole body in view.",
        "reps", 15, 5,
        "Stand tall", "Squat down", "Stand back up",
    ),
    PUSH_UPS(
        "💪", "Push-ups",
        "Strengthens chest, shoulders and arms, builds core stability.",
        "Put the phone on the floor beside you (side view), whole body in view.",
        "reps", 10, 2,
        "Arms straight, body in one line", "Lower your chest", "Push back up",
    ),
    LUNGES(
        "🦵", "Alternating Lunges",
        "Strengthens legs and glutes, improves balance and control.",
        "Stand sideways to the camera, whole body in view.",
        "reps", 12, 2,
        "Stand tall", "Step into a lunge", "Return to standing",
    ),
    HIGH_KNEES(
        "🏃", "High Knees",
        "Boosts heart fitness and endurance, improves speed and coordination.",
        "Face the camera with your whole body in view.",
        "reps", 40, 10,
        "Stand ready", "Lift your knees", "Keep alternating knees",
    ),
    CRUNCHES(
        "🧘", "Abdominal Crunches",
        "Strengthens the abdominal muscles and core stability.",
        "Lie on your back with the camera at your side, whole body in view.",
        "reps", 15, 5,
        "Lie flat, knees bent", "Curl your shoulders up", "Lower back down",
    ),
    GLUTE_BRIDGES(
        "🍑", "Glute Bridges",
        "Strengthens glutes and hamstrings, improves hip control.",
        "Lie on your back with the camera at your side, whole body in view.",
        "reps", 12, 2,
        "Lie flat, knees bent", "Lift your hips", "Lower your hips",
    ),
    PLANK(
        "🧱", "Plank",
        "Strengthens abs and core, builds muscular endurance.",
        "Put the phone on the floor beside you (side view), whole body in view.",
        "sec", 30, 10,
        "Get into plank position", "", "",
    ),
    SIT_TO_STAND(
        "💺", "Sit-to-Stand",
        "Builds leg and hip strength for standing up and climbing stairs, and supports balance and independence.",
        "Put a sturdy chair against a wall. Sit sideways to the camera, whole body in view.",
        "reps", 10, 2,
        "Sit on the chair", "Stand up fully", "Sit back down",
    ),
    CALF_RAISES(
        "👟", "Calf Raises",
        "Strengthens the calves and ankles, and improves balance and walking.",
        "Stand sideways to the camera, whole body and both feet in view.",
        "reps", 15, 5,
        "Stand flat on your feet", "Rise onto your toes", "Lower your heels",
    ),
    SIDE_LEG_RAISES(
        "🕺", "Side Leg Raises",
        "Strengthens the hips and outer thighs, and improves balance and stability.",
        "Face the camera, 2 to 3 metres away, whole body in view. Hold a chair if you need balance.",
        "reps", 20, 4,
        "Stand tall", "Lift one leg out to the side", "Lower it and switch",
    ),
    INCLINE_PUSHUPS(
        "💪", "Incline Push-ups",
        "Builds the chest, shoulders and arms with less load than floor push-ups. A good first step for beginners.",
        "Put your hands on a sturdy table or bench. Stand sideways to the camera, 2 to 3 metres away, whole body in view.",
        "reps", 10, 2,
        "Arms straight, body in one line", "Lower your chest to the bench", "Push back up",
    ),
    DECLINE_PUSHUPS(
        "🦾", "Decline Push-ups",
        "Works the upper chest and shoulders harder than floor push-ups and builds upper-body strength.",
        "Put your feet on a sturdy bench and your hands on the floor. Phone on the floor beside you (side view), whole body in view.",
        "reps", 8, 2,
        "Arms straight, body in one line", "Lower your chest toward the floor", "Push back up",
    ),
    BICEPS_CURL(
        "💪", "Biceps Curls",
        "Strengthens the front of the arms and makes carrying and lifting easier.",
        "Hold a water bottle or light weight in each hand. Face the camera, 2 to 3 metres away, whole body in view.",
        "reps", 12, 2,
        "Arms down by your sides", "Curl your hands up to your shoulders", "Lower slowly",
    ),
    TRICEPS_EXTENSION(
        "🙆", "Overhead Triceps Extension",
        "Strengthens the back of the arms and the ability to straighten the elbow.",
        "Hold one light weight with both hands overhead. Stand sideways to the camera, 2 to 3 metres away, whole body in view.",
        "reps", 10, 2,
        "Arms straight overhead", "Bend your elbows, lower behind your head", "Straighten your arms up",
    ),
    FRONT_RAISE(
        "🙋", "Front Arm Raises",
        "Builds shoulder strength and makes lifting the arms forward easier.",
        "Stand sideways to the camera, 2 to 3 metres away, whole body in view.",
        "reps", 12, 2,
        "Arms down in front", "Raise your arms to shoulder height", "Lower slowly",
    ),
    LATERAL_RAISE(
        "🙌", "Lateral Arm Raises",
        "Strengthens the sides of the shoulders and improves shoulder shape and control.",
        "Hold a light weight in each hand. Face the camera, 2 to 3 metres away, whole body in view.",
        "reps", 12, 2,
        "Arms down by your sides", "Raise your arms out to shoulder height", "Lower slowly",
    ),
    BUTT_KICKS(
        "🏃", "Heel-to-Butt Kicks",
        "Raises your heart rate, builds leg speed and warms up the back of the thighs.",
        "Face the camera or stand sideways, 2 to 3 metres away, whole body in view.",
        "reps", 30, 5,
        "Jog on the spot", "Kick one heel up toward your glutes", "Switch legs",
    ),
    GOOD_MORNING(
        "🌅", "Good Mornings",
        "Teaches the hip-hinge movement and strengthens the back of the thighs and hips.",
        "Stand sideways to the camera, 2 to 3 metres away, whole body in view.",
        "reps", 12, 2,
        "Stand tall, hands on your chest", "Hinge forward from the hips, back straight", "Stand back up",
    ),
    LEG_RAISE(
        "🦵", "Lying Leg Raises",
        "Strengthens the tummy muscles and improves core control.",
        "Lie on your back on a mat. Put the phone on the floor beside your hips (side view), 2 to 3 metres away, whole body in view.",
        "reps", 10, 2,
        "Legs straight on the floor", "Lift both legs up", "Lower with control",
    );

    val isHold: Boolean get() = this == PLANK
    val isSided: Boolean get() = this == LUNGES || this == HIGH_KNEES || this == SIDE_LEG_RAISES || this == BUTT_KICKS

    /** Each leg is counted on its own (left and right separately). */
    val isTwoLeg: Boolean get() = this == HIGH_KNEES || this == SIDE_LEG_RAISES || this == BUTT_KICKS
}

/** Pixel-space geometry helper over the 33 landmarks. */
class Geo(private val p: List<BodyPoint>, private val w: Float, private val h: Float) {
    fun x(i: Int) = p[i].x * w
    fun y(i: Int) = p[i].y * h
    fun dist(a: Int, b: Int) = hypot(x(a) - x(b), y(a) - y(b))
    fun midX(a: Int, b: Int) = (x(a) + x(b)) / 2f
    fun midY(a: Int, b: Int) = (y(a) + y(b)) / 2f

    /** All listed joints are visible and inside the frame. */
    fun ok(vararg ids: Int) = ids.all {
        val q = p[it]
        q.v >= MIN_VIS && q.x > -0.02f && q.x < 1.02f && q.y > -0.02f && q.y < 1.02f
    }

    fun minVis(vararg ids: Int) = ids.minOf { p[it].v }

    /** Angle in degrees at joint [b] between [a] and [c]. */
    fun angle(a: Int, b: Int, c: Int): Float {
        val ax = x(a) - x(b)
        val ay = y(a) - y(b)
        val cx = x(c) - x(b)
        val cy = y(c) - y(b)
        val d = hypot(ax, ay) * hypot(cx, cy)
        if (d < 1e-3f) return 0f
        val cos = ((ax * cx + ay * cy) / d).coerceIn(-1f, 1f)
        return Math.toDegrees(acos(cos).toDouble()).toFloat()
    }

    /** 1 = the line a-b is horizontal in the image, 0 = vertical. */
    /** Hip position against the straight line shoulder -> ankle (+ = below the line). */
    fun hipSag(sh: Int, hip: Int, an: Int): Float {
        val len = dist(sh, an)
        val dx = x(an) - x(sh)
        if (len < 10f || abs(dx) < 10f) return 0f
        val t = (x(hip) - x(sh)) / dx
        val lineY = y(sh) + t * (y(an) - y(sh))
        return (y(hip) - lineY) / len
    }

    /** Angle in degrees between the line a -> b and straight down (0 = hanging straight, 90 = level with a). */
    fun tiltFromVertical(a: Int, b: Int): Float {
        val dxp = abs(x(b) - x(a))
        val dyp = y(b) - y(a)
        return Math.toDegrees(atan2(dxp.toDouble(), dyp.toDouble())).toFloat()
    }

    fun horizontalness(a: Int, b: Int): Float {
        val d = dist(a, b)
        return if (d < 1e-3f) 0f else abs(x(a) - x(b)) / d
    }

    companion object {
        const val MIN_VIS = 0.5f
    }
}

/**
 * What one frame says about the exercise. Pose.OPEN = START position of the
 * exercise, Pose.CLOSED = PEAK position (so one repetition = start -> peak -> start).
 */
class BodyRead(
    val valid: Boolean,
    val pose: Pose = Pose.UNKNOWN,
    val poseL: Pose = Pose.UNKNOWN,
    val poseR: Pose = Pose.UNKNOWN,
    val frontLeft: Boolean? = null,
    val good: Boolean = false,
    val hint: String? = null,
    /** Squat: knee angle. Push-up: elbow angle. (Smaller = deeper.) */
    val depth: Float = 180f,
    /** Hip height against the shoulder-ankle line as a share of body length: + = hips sag, - = hips too high. */
    val sag: Float = 0f,
    /** How far the movement went: jumping jack = hands above shoulders (share of torso), crunch = shoulder lift, bridge = hip angle. */
    val reach: Float = 0f,
    /** High knees: knee drop below the hip as a share of torso (small = high knee). */
    val ratioL: Float = 1f,
    val ratioR: Float = 1f,
    /** Side leg raise: how far each leg is lifted away from straight down, in degrees. */
    val tiltL: Float = 0f,
    val tiltR: Float = 0f,
)

object BodyClassifier {
    private const val IN_VIEW = "Step back so your whole body is in view."

    fun read(type: ExerciseType, pts: List<BodyPoint>, w: Float, h: Float): BodyRead {
        if (pts.size < 33 || w <= 0f || h <= 0f) return BodyRead(false, hint = IN_VIEW)
        val g = Geo(pts, w, h)
        return when (type) {
            ExerciseType.SQUATS -> squat(g)
            ExerciseType.PUSH_UPS -> pushUp(g)
            ExerciseType.JUMPING_JACKS -> jumpingJack(g)
            ExerciseType.HIGH_KNEES -> highKnees(g)
            ExerciseType.LUNGES -> lunge(g)
            ExerciseType.CRUNCHES -> crunch(g)
            ExerciseType.GLUTE_BRIDGES -> bridge(g)
            ExerciseType.PLANK -> plank(g)
            ExerciseType.SIT_TO_STAND -> sitToStand(g)
            ExerciseType.CALF_RAISES -> calfRaise(g)
            ExerciseType.SIDE_LEG_RAISES -> sideLeg(g)
            ExerciseType.INCLINE_PUSHUPS, ExerciseType.DECLINE_PUSHUPS -> pushUp(g)
            ExerciseType.BICEPS_CURL -> curl(g)
            ExerciseType.TRICEPS_EXTENSION -> tricepsExt(g)
            ExerciseType.FRONT_RAISE, ExerciseType.LATERAL_RAISE -> armRaise(g)
            ExerciseType.BUTT_KICKS -> buttKicks(g)
            ExerciseType.GOOD_MORNING -> goodMorning(g)
            ExerciseType.LEG_RAISE -> legRaise(g)
        }
    }

    private fun invalid(hint: String) = BodyRead(false, hint = hint)

    private fun curl(g: Geo): BodyRead {
        val hint = "Stand facing the camera with your whole body in view."
        val s = bestSide(g, Joint.L_SH, Joint.L_EL, Joint.L_WR, Joint.R_SH, Joint.R_EL, Joint.R_WR) ?: return invalid(hint)
        val a = g.angle(s[0], s[1], s[2])
        val pose = when {
            a >= 150f -> Pose.OPEN
            a <= 60f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a)
    }

    private fun tricepsExt(g: Geo): BodyRead {
        val hint = "Hold the weight overhead, side view, whole body in view."
        val s = bestSide(g, Joint.L_SH, Joint.L_EL, Joint.L_WR, Joint.R_SH, Joint.R_EL, Joint.R_WR) ?: return invalid(hint)
        val ref = g.dist(s[0], s[1])
        if (ref < 10f) return invalid(hint)
        val a = g.angle(s[0], s[1], s[2])
        val wristUp = g.y(s[2]) < g.y(s[0]) - 0.5f * ref
        val elbowUp = g.y(s[1]) < g.y(s[0]) - 0.3f * ref
        val pose = when {
            a >= 150f && wristUp && elbowUp -> Pose.OPEN
            a <= 90f && elbowUp -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a)
    }

    /** Front and lateral arm raises: how high the hands are against the shoulders, as a share of the torso. */
    private fun armRaise(g: Geo): BodyRead {
        val hint = "Stand with your whole body and both arms in view."
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP)) return invalid(hint)
        val torso = g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_SH, Joint.R_SH)
        if (torso < 10f) return invalid(hint)
        val lOk = g.ok(Joint.L_WR)
        val rOk = g.ok(Joint.R_WR)
        if (!lOk && !rOk) return invalid(hint)
        var sum = 0f
        var n = 0
        if (lOk) { sum += (g.y(Joint.L_SH) - g.y(Joint.L_WR)) / torso; n++ }
        if (rOk) { sum += (g.y(Joint.R_SH) - g.y(Joint.R_WR)) / torso; n++ }
        val reach = sum / n
        val pose = when {
            reach >= -0.15f -> Pose.CLOSED
            reach <= -0.55f -> Pose.OPEN
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, reach = reach)
    }

    private fun buttKicks(g: Geo): BodyRead {
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP, Joint.L_KN, Joint.R_KN, Joint.L_AN, Joint.R_AN)) return invalid(IN_VIEW)
        val torso = g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_SH, Joint.R_SH)
        if (torso < 10f) return invalid("Stand upright, whole body in view.")
        fun ratio(knee: Int, ankle: Int) = (g.y(ankle) - g.y(knee)) / torso
        fun leg(knee: Int, ankle: Int): Pose {
            val r = ratio(knee, ankle)
            return when {
                r <= 0.2f -> Pose.CLOSED // heel kicked up to knee height or higher
                r >= 0.55f -> Pose.OPEN
                else -> Pose.UNKNOWN
            }
        }
        return BodyRead(
            true,
            poseL = leg(Joint.L_KN, Joint.L_AN), poseR = leg(Joint.R_KN, Joint.R_AN),
            ratioL = ratio(Joint.L_KN, Joint.L_AN), ratioR = ratio(Joint.R_KN, Joint.R_AN),
        )
    }

    private fun goodMorning(g: Geo): BodyRead {
        val hint = "Stand sideways to the camera, whole body in view."
        val s = bestSide(g, Joint.L_SH, Joint.L_HIP, Joint.L_KN, Joint.R_SH, Joint.R_HIP, Joint.R_KN) ?: return invalid(hint)
        val a = g.angle(s[0], s[1], s[2])
        val pose = when {
            a >= 165f -> Pose.OPEN
            a <= 135f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a)
    }

    private fun legRaise(g: Geo): BodyRead {
        val hint = "Lie on your back, side view, with your feet in the picture."
        val s = bestSide(g, Joint.L_SH, Joint.L_HIP, Joint.L_AN, Joint.R_SH, Joint.R_HIP, Joint.R_AN) ?: return invalid(hint)
        if (g.horizontalness(s[0], s[1]) < 0.7f) return invalid(hint)
        val a = g.angle(s[0], s[1], s[2])
        val pose = when {
            a >= 155f -> Pose.OPEN
            a <= 115f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a)
    }

    /** The left or right triple of joints that is fully visible (best visibility wins). */
    private fun bestSide(g: Geo, l1: Int, l2: Int, l3: Int, r1: Int, r2: Int, r3: Int): IntArray? {
        val lOk = g.ok(l1, l2, l3)
        val rOk = g.ok(r1, r2, r3)
        return when {
            lOk && rOk ->
                if (g.minVis(l1, l2, l3) >= g.minVis(r1, r2, r3)) intArrayOf(l1, l2, l3) else intArrayOf(r1, r2, r3)
            lOk -> intArrayOf(l1, l2, l3)
            rOk -> intArrayOf(r1, r2, r3)
            else -> null
        }
    }

    private fun squat(g: Geo): BodyRead {
        val s = bestSide(g, Joint.L_HIP, Joint.L_KN, Joint.L_AN, Joint.R_HIP, Joint.R_KN, Joint.R_AN)
            ?: return invalid(IN_VIEW)
        val a = g.angle(s[0], s[1], s[2])
        val pose = when {
            a >= 155f -> Pose.OPEN
            a <= 120f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a)
    }

    private fun pushUp(g: Geo): BodyRead {
        val hint = "Get into push-up position, side view."
        val s = bestSide(g, Joint.L_SH, Joint.L_EL, Joint.L_WR, Joint.R_SH, Joint.R_EL, Joint.R_WR)
            ?: return invalid(hint)
        val hip = s[0] + 12 // shoulder index + 12 = hip index on the same side
        if (!g.ok(hip) || g.horizontalness(s[0], hip) < 0.77f) return invalid(hint)
        val a = g.angle(s[0], s[1], s[2])
        val pose = when {
            a >= 150f -> Pose.OPEN
            a <= 110f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        val ankle = if (g.ok(hip + 4)) hip + 4 else -1 // same side ankle
        val sag = if (ankle >= 0) g.hipSag(s[0], hip, ankle) else 0f
        return BodyRead(true, pose, depth = a, sag = sag)
    }

    private fun jumpingJack(g: Geo): BodyRead {
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP, Joint.L_WR, Joint.R_WR, Joint.L_AN, Joint.R_AN)) {
            return invalid(IN_VIEW)
        }
        val sw = abs(g.x(Joint.L_SH) - g.x(Joint.R_SH))
        val torso = g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_SH, Joint.R_SH)
        if (sw < 10f || torso < 10f) return invalid("Face the camera, standing upright.")
        val ankles = abs(g.x(Joint.L_AN) - g.x(Joint.R_AN)) / sw
        val up = g.y(Joint.L_WR) < g.y(Joint.L_SH) && g.y(Joint.R_WR) < g.y(Joint.R_SH)
        val down = g.y(Joint.L_WR) > g.y(Joint.L_SH) + 0.4f * torso &&
            g.y(Joint.R_WR) > g.y(Joint.R_SH) + 0.4f * torso
        val pose = when {
            up && ankles >= 1.5f -> Pose.CLOSED
            down && ankles <= 1.0f -> Pose.OPEN
            else -> Pose.UNKNOWN
        }
        val reach = minOf(
            (g.y(Joint.L_SH) - g.y(Joint.L_WR)) / torso,
            (g.y(Joint.R_SH) - g.y(Joint.R_WR)) / torso,
        )
        return BodyRead(true, pose, reach = reach)
    }

    private fun highKnees(g: Geo): BodyRead {
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP, Joint.L_KN, Joint.R_KN)) return invalid(IN_VIEW)
        val torso = g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_SH, Joint.R_SH)
        if (torso < 10f) return invalid("Face the camera, standing upright.")
        fun ratio(hip: Int, knee: Int) = (g.y(knee) - g.y(hip)) / torso
        fun leg(hip: Int, knee: Int): Pose {
            val r = ratio(hip, knee)
            return when {
                r <= 0.25f -> Pose.CLOSED // knee lifted to hip level
                r >= 0.5f -> Pose.OPEN
                else -> Pose.UNKNOWN
            }
        }
        return BodyRead(
            true,
            poseL = leg(Joint.L_HIP, Joint.L_KN), poseR = leg(Joint.R_HIP, Joint.R_KN),
            ratioL = ratio(Joint.L_HIP, Joint.L_KN), ratioR = ratio(Joint.R_HIP, Joint.R_KN),
        )
    }

    private fun lunge(g: Geo): BodyRead {
        val hint = "Stand sideways to the camera, whole body in view."
        if (!g.ok(Joint.NOSE, Joint.L_HIP, Joint.R_HIP, Joint.L_KN, Joint.R_KN, Joint.L_AN, Joint.R_AN)) return invalid(hint)
        val hipX = g.midX(Joint.L_HIP, Joint.R_HIP)
        if (abs(g.x(Joint.NOSE) - hipX) < 8f) return invalid(hint)
        val facing = if (g.x(Joint.NOSE) >= hipX) 1f else -1f
        val kL = g.angle(Joint.L_HIP, Joint.L_KN, Joint.L_AN)
        val kR = g.angle(Joint.R_HIP, Joint.R_KN, Joint.R_AN)
        val frontLeft = (g.x(Joint.L_AN) - hipX) * facing >= (g.x(Joint.R_AN) - hipX) * facing
        val front = if (frontLeft) kL else kR
        val pose = when {
            kL >= 155f && kR >= 155f -> Pose.OPEN
            front <= 110f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, frontLeft = frontLeft, depth = front)
    }

    private fun crunch(g: Geo): BodyRead {
        val hint = "Lie on your back with the camera at your side."
        val s = bestSide(g, Joint.L_SH, Joint.L_HIP, Joint.L_KN, Joint.R_SH, Joint.R_HIP, Joint.R_KN)
            ?: return invalid(hint)
        val len = g.dist(s[0], s[1])
        if (len < 10f || g.horizontalness(s[0], s[1]) < 0.5f) return invalid(hint)
        val lift = (g.y(s[1]) - g.y(s[0])) / len // shoulders rising above the hips
        val pose = when {
            lift <= 0.15f -> Pose.OPEN
            lift >= 0.33f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, reach = lift)
    }

    private fun bridge(g: Geo): BodyRead {
        val hint = "Lie on your back with the camera at your side."
        val s = bestSide(g, Joint.L_SH, Joint.L_HIP, Joint.L_KN, Joint.R_SH, Joint.R_HIP, Joint.R_KN)
            ?: return invalid(hint)
        if (g.horizontalness(s[0], s[1]) < 0.6f) return invalid(hint)
        val a = g.angle(s[0], s[1], s[2]) // shoulder-hip-knee: ~120-150 flat, ~175 at the top
        val pose = when {
            a <= 150f -> Pose.OPEN
            a >= 163f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, reach = a)
    }

    /** True when the person faces the camera (wide shoulders in the picture), so the knee angle cannot be read. */
    private fun facingCamera(g: Geo): Boolean {
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP)) return false
        val torso = g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_SH, Joint.R_SH)
        if (torso < 10f) return false
        return abs(g.x(Joint.L_SH) - g.x(Joint.R_SH)) > 0.6f * torso
    }

    private fun sitToStand(g: Geo): BodyRead {
        val hint = "Sit sideways to the camera, whole body in view."
        val s = bestSide(g, Joint.L_HIP, Joint.L_KN, Joint.L_AN, Joint.R_HIP, Joint.R_KN, Joint.R_AN)
            ?: return invalid(hint)
        if (facingCamera(g)) return invalid(hint)
        val a = g.angle(s[0], s[1], s[2]) // knee angle: about 90 seated, about 170 standing
        // START = seated, PEAK = standing, so one repetition = stand up and sit back down
        val pose = when {
            a <= 112f -> Pose.OPEN
            a >= 160f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a, reach = a)
    }

    private fun calfRaise(g: Geo): BodyRead {
        val hint = "Stand sideways to the camera, with your whole body and feet in view."
        val l = intArrayOf(Joint.L_HIP, Joint.L_KN, Joint.L_AN, Joint.L_HEEL, Joint.L_FOOT)
        val r = intArrayOf(Joint.R_HIP, Joint.R_KN, Joint.R_AN, Joint.R_HEEL, Joint.R_FOOT)
        val lOk = g.ok(*l)
        val rOk = g.ok(*r)
        val s = when {
            lOk && rOk -> if (g.minVis(*l) >= g.minVis(*r)) l else r
            lOk -> l
            rOk -> r
            else -> return invalid(hint)
        }
        if (facingCamera(g)) return invalid(hint)
        val run = abs(g.x(s[4]) - g.x(s[3]))
        if (run < 4f) return invalid(hint)
        val rise = g.y(s[4]) - g.y(s[3]) // positive when the heel is higher than the toes
        val pitch = Math.toDegrees(atan2(rise.toDouble(), run.toDouble())).toFloat() // foot tilt: about 0 flat, 20 to 30 raised
        val pose = when {
            pitch <= 9f -> Pose.OPEN
            pitch >= 18f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = g.angle(s[0], s[1], s[2]), reach = pitch)
    }

    private fun sideLeg(g: Geo): BodyRead {
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP, Joint.L_KN, Joint.R_KN, Joint.L_AN, Joint.R_AN)) return invalid(IN_VIEW)
        val torso = g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_SH, Joint.R_SH)
        if (torso < 10f) return invalid("Face the camera, standing upright.")
        if (abs(g.x(Joint.L_SH) - g.x(Joint.R_SH)) < 0.35f * torso) return invalid("Face the camera, standing upright.")
        fun leg(t: Float) = when {
            t <= 11f -> Pose.OPEN
            t >= 26f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        val tL = g.tiltFromVertical(Joint.L_HIP, Joint.L_AN)
        val tR = g.tiltFromVertical(Joint.R_HIP, Joint.R_AN)
        val lean = abs(g.midX(Joint.L_SH, Joint.R_SH) - g.midX(Joint.L_HIP, Joint.R_HIP)) / torso
        return BodyRead(true, poseL = leg(tL), poseR = leg(tR), tiltL = tL, tiltR = tR, reach = lean)
    }

    private fun plank(g: Geo): BodyRead {
        val hint = "Get into plank position, side view."
        val s = bestSide(g, Joint.L_SH, Joint.L_HIP, Joint.L_AN, Joint.R_SH, Joint.R_HIP, Joint.R_AN)
            ?: return invalid(hint)
        val straight = g.angle(s[0], s[1], s[2]) >= 155f
        val flat = g.horizontalness(s[0], s[2]) >= 0.8f
        if (!flat) return invalid(hint)
        return BodyRead(true, good = straight, hint = if (straight) null else "Keep your body in a straight line.", sag = g.hipSag(s[0], s[1], s[2]))
    }
}

/** Turns a stream of pose frames into repetitions (or hold time for the plank). */
class ExerciseEngine(val type: ExerciseType) {

    class Out(
        val detected: Boolean,
        val reliable: Boolean,
        val repDone: Boolean,
        val pose: Pose,
        val phase: RepCounter.Phase,
        val hint: String?,
        /** A form fix to say aloud (found while doing the repetition / while holding). */
        val form: FormTip? = null,
    )

    var leftReps = 0
        private set
    var rightReps = 0
        private set
    var holdMs = 0L
        private set

    private val counter = RepCounter(cfg(type))
    private val counterL = RepCounter(cfg(type))
    private val counterR = RepCounter(cfg(type))
    private var bottomFrontLeft: Boolean? = null

    // plank state
    private var lastT = -1L
    private var goodStreak = 0
    private var lastGoodT = 0L
    private var holding = false

    /** Repetitions, or whole seconds held for the plank. */
    val reps: Int
        get() = when {
            type.isHold -> (holdMs / 1000).toInt()
            type.isTwoLeg -> counterL.count + counterR.count
            else -> counter.count
        }

    fun update(pts: List<BodyPoint>?, w: Float, h: Float, t: Long, mirrored: Boolean): Out {
        if (pts == null) {
            lose(t)
            return Out(false, false, false, Pose.UNKNOWN, phase(), "Step back so your whole body is in view.")
        }
        val r = BodyClassifier.read(type, pts, w, h)
        if (!r.valid) {
            lose(t)
            return Out(true, false, false, Pose.UNKNOWN, phase(), r.hint)
        }
        return when {
            type.isHold -> plank(r, t)
            type == ExerciseType.HIGH_KNEES -> knees(r, t, mirrored)
            type == ExerciseType.SIDE_LEG_RAISES -> sideLegs(r, t, mirrored)
            type == ExerciseType.BUTT_KICKS -> kicks(r, t, mirrored)
            else -> single(r, t, mirrored)
        }
    }

    // form tracking for the repetition in progress
    private var repMinDepth = 180f
    private var repMaxSag = 0f
    private var repMinSag = 0f

    private var repMaxReach = -9f
    private var attemptMax = 0f // best reach of a crunch / bridge that has not (yet) counted

    private fun formOfRep(): FormTip? {
        val tip = when (type) {
            ExerciseType.LUNGES -> if (repMinDepth > LUNGE_DEEP) FormTip.LUNGE_SHALLOW else null
            ExerciseType.JUMPING_JACKS -> if (repMaxReach < ARMS_HIGH) FormTip.ARMS_LOW else null
            ExerciseType.PUSH_UPS, ExerciseType.INCLINE_PUSHUPS, ExerciseType.DECLINE_PUSHUPS -> when {
                repMaxSag > SAG_LIMIT -> FormTip.HIPS_SAG
                repMinSag < -SAG_LIMIT -> FormTip.HIPS_HIGH
                repMinDepth > PUSHUP_DEEP -> FormTip.PUSHUP_SHALLOW
                else -> null
            }
            ExerciseType.SQUATS -> if (repMinDepth > SQUAT_DEEP) FormTip.SQUAT_SHALLOW else null
            ExerciseType.CALF_RAISES -> if (repMinDepth < KNEES_BENT) FormTip.KNEES_BENT else null
            ExerciseType.BICEPS_CURL -> if (repMinDepth > CURL_DEEP) FormTip.CURL_SHALLOW else null
            ExerciseType.FRONT_RAISE, ExerciseType.LATERAL_RAISE -> if (repMaxReach < RAISE_HIGH) FormTip.RAISE_LOW else null
            ExerciseType.GOOD_MORNING -> if (repMinDepth > HINGE_DEEP) FormTip.HINGE_SHALLOW else null
            ExerciseType.LEG_RAISE -> if (repMinDepth > LEGRAISE_DEEP) FormTip.LEGRAISE_LOW else null
            else -> null
        }
        repMinDepth = 180f; repMaxSag = 0f; repMinSag = 0f; repMaxReach = -9f
        return tip
    }

    private fun single(r: BodyRead, t: Long, mirrored: Boolean): Out {
        if (r.pose != Pose.OPEN) {
            if (r.depth < repMinDepth) repMinDepth = r.depth
            if (r.sag > repMaxSag) repMaxSag = r.sag
            if (r.sag < repMinSag) repMinSag = r.sag
            if (r.reach > repMaxReach) repMaxReach = r.reach
            if (r.reach > attemptMax) attemptMax = r.reach
        }
        val e = counter.update(Observation(t, true, true, r.pose))
        if (e == RepCounter.Event.CLOSED_CONFIRMED) bottomFrontLeft = r.frontLeft
        val done = e == RepCounter.Event.REP_COMPLETED
        if (done && type == ExerciseType.LUNGES) {
            val indexLeft = bottomFrontLeft
            if (indexLeft != null) {
                if (indexLeft != mirrored) leftReps++ else rightReps++
            }
        }
        var tip = if (done) formOfRep() else null
        if (done) attemptMax = 0f
        if (!done && counter.phase == RepCounter.Phase.WAIT_CLOSE) {
            repMinDepth = 180f; repMaxSag = 0f; repMinSag = 0f; repMaxReach = -9f
            // back at the start without reaching the top: tell the person to go further
            if (r.pose == Pose.OPEN) {
                if (type == ExerciseType.CRUNCHES && attemptMax >= CRUNCH_TRY) tip = FormTip.CRUNCH_SHALLOW
                if (type == ExerciseType.GLUTE_BRIDGES && attemptMax >= BRIDGE_TRY) tip = FormTip.BRIDGE_LOW
                if (type == ExerciseType.SIT_TO_STAND && attemptMax >= STAND_TRY) tip = FormTip.STAND_SHORT
                if (type == ExerciseType.CALF_RAISES && attemptMax >= CALF_TRY) tip = FormTip.CALF_LOW
                attemptMax = 0f
            }
        }
        return Out(true, true, done, r.pose, counter.phase, null, tip)
    }

    /** Heel-to-butt kicks: each leg is counted on its own, like high knees but without a height tip. */
    private fun kicks(r: BodyRead, t: Long, mirrored: Boolean): Out {
        val eL = counterL.update(Observation(t, true, true, r.poseL))
        val eR = counterR.update(Observation(t, true, true, r.poseR))
        var done = false
        if (eL == RepCounter.Event.REP_COMPLETED) {
            done = true
            if (true != mirrored) leftReps++ else rightReps++
        }
        if (eR == RepCounter.Event.REP_COMPLETED) {
            done = true
            if (false != mirrored) leftReps++ else rightReps++
        }
        return Out(true, true, done, Pose.UNKNOWN, phase(), null, null)
    }

    private var kneeMinL = 9f
    private var kneeMinR = 9f

    private fun knees(r: BodyRead, t: Long, mirrored: Boolean): Out {
        var tip: FormTip? = null
        if (r.ratioL < kneeMinL) kneeMinL = r.ratioL
        if (r.ratioR < kneeMinR) kneeMinR = r.ratioR
        if (r.poseL == Pose.OPEN) { if (kneeMinL > KNEE_HIP && kneeMinL < KNEE_TRY) tip = FormTip.KNEES_LOW; kneeMinL = 9f }
        if (r.poseR == Pose.OPEN) { if (kneeMinR > KNEE_HIP && kneeMinR < KNEE_TRY) tip = FormTip.KNEES_LOW; kneeMinR = 9f }
        val eL = counterL.update(Observation(t, true, true, r.poseL))
        val eR = counterR.update(Observation(t, true, true, r.poseR))
        var done = false
        if (eL == RepCounter.Event.REP_COMPLETED) {
            done = true
            if (true != mirrored) leftReps++ else rightReps++ // model-left leg
        }
        if (eR == RepCounter.Event.REP_COMPLETED) {
            done = true
            if (false != mirrored) leftReps++ else rightReps++ // model-right leg
        }
        return Out(true, true, done, Pose.UNKNOWN, phase(), null, tip)
    }

    private var tiltMaxL = 0f
    private var tiltMaxR = 0f
    private var leanMax = 0f

    private fun sideLegs(r: BodyRead, t: Long, mirrored: Boolean): Out {
        var tip: FormTip? = null
        if (r.tiltL > tiltMaxL) tiltMaxL = r.tiltL
        if (r.tiltR > tiltMaxR) tiltMaxR = r.tiltR
        if (r.poseL != Pose.OPEN || r.poseR != Pose.OPEN) {
            if (r.reach > leanMax) leanMax = r.reach
        } else {
            leanMax = 0f
        }
        // a leg went up but not high enough to count, and is now back down
        if (r.poseL == Pose.OPEN) { if (tiltMaxL > LEG_TRY && tiltMaxL < LEG_UP) tip = FormTip.LEG_LOW; tiltMaxL = 0f }
        if (r.poseR == Pose.OPEN) { if (tiltMaxR > LEG_TRY && tiltMaxR < LEG_UP) tip = FormTip.LEG_LOW; tiltMaxR = 0f }
        val eL = counterL.update(Observation(t, true, true, r.poseL))
        val eR = counterR.update(Observation(t, true, true, r.poseR))
        var done = false
        if (eL == RepCounter.Event.REP_COMPLETED) {
            done = true
            if (true != mirrored) leftReps++ else rightReps++ // model-left leg
        }
        if (eR == RepCounter.Event.REP_COMPLETED) {
            done = true
            if (false != mirrored) leftReps++ else rightReps++ // model-right leg
        }
        if (done) {
            if (tip == null && leanMax > LEAN_LIMIT) tip = FormTip.LEANING
            leanMax = 0f
        }
        return Out(true, true, done, Pose.UNKNOWN, phase(), null, tip)
    }

    private fun plank(r: BodyRead, t: Long): Out {
        val dt = if (lastT >= 0) (t - lastT).coerceIn(0L, 250L) else 0L
        lastT = t
        if (r.good) {
            goodStreak++
            lastGoodT = t
            if (goodStreak >= 3) holding = true
        } else {
            goodStreak = 0
            if (t - lastGoodT > 600) holding = false
        }
        if (holding) holdMs += dt
        val tip = if (r.good) null else when {
            r.sag > PLANK_SAG -> FormTip.HIPS_SAG
            r.sag < -PLANK_SAG -> FormTip.HIPS_HIGH
            else -> null
        }
        return Out(true, true, false, Pose.UNKNOWN, phase(), if (holding) null else r.hint, tip)
    }

    private fun lose(t: Long) {
        attemptMax = 0f; kneeMinL = 9f; kneeMinR = 9f; tiltMaxL = 0f; tiltMaxR = 0f; leanMax = 0f
        if (type.isHold) {
            lastT = t
            goodStreak = 0
            if (t - lastGoodT > 600) holding = false
            return
        }
        val o = Observation(t, false, false, Pose.UNKNOWN)
        if (type.isTwoLeg) {
            counterL.update(o)
            counterR.update(o)
        } else {
            counter.update(o)
        }
    }

    private fun phase(): RepCounter.Phase {
        if (!type.isTwoLeg) return counter.phase
        val a = counterL.phase
        val b = counterR.phase
        return when {
            a == RepCounter.Phase.WAIT_CLOSE || b == RepCounter.Phase.WAIT_CLOSE -> RepCounter.Phase.WAIT_CLOSE
            a == RepCounter.Phase.WAIT_REOPEN || b == RepCounter.Phase.WAIT_REOPEN -> RepCounter.Phase.WAIT_REOPEN
            a == RepCounter.Phase.NO_HAND && b == RepCounter.Phase.NO_HAND -> RepCounter.Phase.NO_HAND
            else -> RepCounter.Phase.WAIT_OPEN
        }
    }

    /** Forget the movement in progress but keep the totals (used on pause / resume). */
    fun restartCycle() {
        counter.resetCycle()
        counterL.resetCycle()
        counterR.resetCycle()
        holding = false
        goodStreak = 0
        lastT = -1L
        attemptMax = 0f; kneeMinL = 9f; kneeMinR = 9f; tiltMaxL = 0f; tiltMaxR = 0f; leanMax = 0f
    }

    val isHolding: Boolean get() = holding

    private companion object {
        const val SAG_LIMIT = 0.08f
        const val PLANK_SAG = 0.05f
        const val SQUAT_DEEP = 105f
        const val PUSHUP_DEEP = 95f
        const val LUNGE_DEEP = 100f   // front knee angle: at or below = deep enough
        const val ARMS_HIGH = 0.6f    // jumping jack: hands at least this far above the shoulders (head height)
        const val CRUNCH_TRY = 0.22f  // shoulder lift that shows a real attempt (counts at 0.33)
        const val BRIDGE_TRY = 156f   // hip angle that shows a real attempt (counts at 163)
        const val KNEE_HIP = 0.25f    // knee at hip level (counts)
        const val KNEE_TRY = 0.42f    // knee lifted well past half way but not to the hip
        const val STAND_TRY = 140f    // knee angle that shows a real try at standing up (counts at 160)
        const val CALF_TRY = 14f      // foot tilt that shows a real try at rising (counts at 18)
        const val KNEES_BENT = 150f   // calf raise: knee angle below this = knees bent too much
        const val LEG_TRY = 17f       // side leg raise: leg tilt that shows a real try (counts at 26)
        const val LEG_UP = 26f
        const val CURL_DEEP = 75f      // biceps curl: elbow angle at or below = curled high enough
        const val RAISE_HIGH = -0.05f  // arm raise: hands at least this near the shoulder line (share of torso)
        const val HINGE_DEEP = 140f    // good morning: hip angle at or below = bent far enough
        const val LEGRAISE_DEEP = 105f // leg raise: hip angle at or below = legs high enough
        const val LEAN_LIMIT = 0.22f  // side leg raise: body leaning sideways more than this share of the torso

        fun cfg(t: ExerciseType) = when (t) {
            // One confirming frame is enough: a Wi-Fi camera gives only 6 to 10 pictures a second, so a
            // quick repetition may show its lowest point in a single picture. The wide gap between the
            // START and PEAK angles already keeps noise from counting.
            ExerciseType.JUMPING_JACKS -> RepCounter.Config(1, 0, 1000, 300)
            ExerciseType.HIGH_KNEES, ExerciseType.BUTT_KICKS -> RepCounter.Config(1, 0, 1000, 200)
            else -> RepCounter.Config(1, 0, 1500, 400)
        }
    }
}
