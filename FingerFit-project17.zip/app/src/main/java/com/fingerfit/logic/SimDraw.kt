package com.fingerfit.logic

/** Colour roles; the screen maps them to real colours. */
enum class PCol { SKIN, SHIRT, SHORTS, SHOE, HAIR, EYE, GLOW, GHOST }

/**
 * One filled shape. kind 0 = tapered limb from pts[0..1] to pts[2..3] with radii ra -> rb,
 * kind 1 = dot at pts[0..1] with radius ra, kind 2 = polygon through all pts.
 */
class Prim(val kind: Int, val pts: FloatArray, val ra: Float, val rb: Float, val col: PCol, val far: Boolean)

/** Turns a skeleton pose into a drawn person (skin, shirt, shorts, shoes, hair, face, muscle glow). */
object SimDraw {
    private fun mid(a: SimPt, b: SimPt, f: Float) = SimPt(a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f)
    private fun cap(out: MutableList<Prim>, a: SimPt, b: SimPt, ra: Float, rb: Float, c: PCol, far: Boolean) {
        out += Prim(0, floatArrayOf(a.x, a.y, b.x, b.y), ra, rb, c, far)
    }
    private fun dot(out: MutableList<Prim>, a: SimPt, r: Float, c: PCol, far: Boolean = false) {
        out += Prim(1, floatArrayOf(a.x, a.y), r, r, c, far)
    }

    /** [ghost] = flat single-colour silhouette (the position to reach). [glow] = muscle highlight pulse on/off. */
    fun build(f: SimFigure, spec: SimSpec, ghost: Boolean, glow: Boolean): List<Prim> {
        val out = ArrayList<Prim>(40)
        val front = spec.view == SimView.FRONT
        fun c(x: PCol) = if (ghost) PCol.GHOST else x

        fun arm(s: SimPt, e: SimPt, w: SimPt, far: Boolean) {
            cap(out, s, e, 0.036f, 0.030f, c(PCol.SHIRT), far)
            cap(out, e, w, 0.027f, 0.020f, c(PCol.SKIN), far)
            dot(out, w, 0.025f, c(PCol.SKIN), far)
        }
        fun leg(h: SimPt, k: SimPt, a: SimPt, t: SimPt, far: Boolean) {
            val hem = mid(h, k, 0.62f)
            cap(out, h, hem, 0.056f, 0.047f, c(PCol.SHORTS), far)
            cap(out, hem, k, 0.037f, 0.034f, c(PCol.SKIN), far)
            cap(out, k, a, 0.034f, 0.023f, c(PCol.SKIN), far)
            cap(out, a, t, 0.031f, 0.024f, c(PCol.SHOE), far)
        }
        // far side first
        arm(f.shoulderFar, f.elbowFar, f.wristFar, true)
        leg(f.hipFar, f.kneeFar, f.ankleFar, f.toeFar, true)
        // torso
        if (front) {
            dot(out, f.shoulderNear, 0.04f, c(PCol.SHIRT)); dot(out, f.shoulderFar, 0.04f, c(PCol.SHIRT))
            out += Prim(2, floatArrayOf(f.shoulderNear.x, f.shoulderNear.y, f.shoulderFar.x, f.shoulderFar.y, f.hipFar.x, f.hipFar.y, f.hipNear.x, f.hipNear.y), 0f, 0f, c(PCol.SHIRT), false)
            dot(out, f.hipNear, 0.046f, c(PCol.SHORTS)); dot(out, f.hipFar, 0.046f, c(PCol.SHORTS))
            out += Prim(2, floatArrayOf(f.hipNear.x, f.hipNear.y, f.hipFar.x, f.hipFar.y, f.hipFar.x, f.hipFar.y - 0.0f, f.hipNear.x, f.hipNear.y), 0f, 0f, c(PCol.SHORTS), false)
        } else {
            val waist = mid(f.hip, f.neck, 0.42f); val chest = mid(f.hip, f.neck, 0.86f)
            cap(out, f.hip, waist, 0.072f, 0.066f, c(PCol.SHORTS), false)
            cap(out, waist, chest, 0.068f, 0.074f, c(PCol.SHIRT), false)
            cap(out, chest, f.neck, 0.074f, 0.045f, c(PCol.SHIRT), false)
        }
        leg(if (front) f.hipNear else f.hip, f.kneeNear, f.ankleNear, f.toeNear, false)
        arm(f.shoulderNear, f.elbowNear, f.wristNear, false)
        // neck and head
        val hx = f.head.x - f.neck.x; val hy = f.head.y - f.neck.y
        val hl = kotlin.math.sqrt(hx * hx + hy * hy).coerceAtLeast(1e-4f)
        val ux = hx / hl; val uy = hy / hl                 // up along the head
        val fx = if (front) 0f else uy; val fy = if (front) 0f else -ux // face direction (clockwise from up)
        cap(out, f.neck, mid(f.neck, f.head, 0.55f), 0.026f, 0.024f, c(PCol.SKIN), false)
        val r = SimMath.HEAD_R
        // hair sits behind and above the face
        dot(out, SimPt(f.head.x - fx * r * 0.22f + ux * r * 0.12f, f.head.y - fy * r * 0.22f + uy * r * 0.12f), r * 1.04f, c(PCol.HAIR))
        dot(out, SimPt(f.head.x + fx * r * 0.10f - ux * r * 0.04f, f.head.y + fy * r * 0.10f - uy * r * 0.04f), r * 0.9f, c(PCol.SKIN))
        if (!ghost) {
            if (front) {
                dot(out, SimPt(f.head.x - r * 0.32f, f.head.y + r * 0.02f), r * 0.1f, PCol.EYE)
                dot(out, SimPt(f.head.x + r * 0.32f, f.head.y + r * 0.02f), r * 0.1f, PCol.EYE)
            } else {
                dot(out, SimPt(f.head.x + fx * r * 0.52f + ux * r * 0.08f, f.head.y + fy * r * 0.52f + uy * r * 0.08f), r * 0.11f, PCol.EYE)
            }
        }
        // muscle highlight
        if (glow && !ghost) {
            if (spec.hotLegs) {
                cap(out, if (front) f.hipNear else f.hip, f.kneeNear, 0.07f, 0.05f, PCol.GLOW, false)
                cap(out, f.kneeNear, f.ankleNear, 0.045f, 0.032f, PCol.GLOW, false)
                if (front) cap(out, f.hipFar, f.kneeFar, 0.07f, 0.05f, PCol.GLOW, true)
            }
            if (spec.hotArms) {
                cap(out, f.shoulderNear, f.elbowNear, 0.045f, 0.04f, PCol.GLOW, false)
                cap(out, f.elbowNear, f.wristNear, 0.036f, 0.03f, PCol.GLOW, false)
                if (front) { cap(out, f.shoulderFar, f.elbowFar, 0.045f, 0.04f, PCol.GLOW, true); cap(out, f.elbowFar, f.wristFar, 0.036f, 0.03f, PCol.GLOW, true) }
            }
            if (spec.hotCore) cap(out, mid(f.hip, f.neck, 0.1f), mid(f.hip, f.neck, 0.78f), 0.075f, 0.082f, PCol.GLOW, false)
        }
        return out
    }
}
