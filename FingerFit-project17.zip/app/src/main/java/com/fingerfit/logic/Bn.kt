package com.fingerfit.logic

/**
 * Tiny offline translation layer (English -> Bengali).
 * Every English string shown in the app is looked up here at display time.
 * Strings with numbers/names inside are written in BnData as "{0}", "{1}" ... patterns.
 * If a string is unknown it is simply shown in English (never crashes).
 */
object Bn {
    @Volatile var bn: Boolean = false

    private val exact: HashMap<String, String> = HashMap()
    private class Pat(val re: Regex, val out: String, val weight: Int)
    private val pats: ArrayList<Pat> = ArrayList()
    private val cache = HashMap<String, String>()
    private var ready = false

    private val PH = Regex("\\{(\\d)\\}")
    private val digitsOnly = Regex("^[0-9:.,%/+\\-\\s]*$")
    private val ipLike = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")

    @Synchronized
    private fun init() {
        if (ready) return
        val p = BnData.P
        var i = 0
        while (i + 1 < p.size) {
            val k = p[i]; val v = p[i + 1]; i += 2
            if (exact.containsKey(k)) continue
            exact[k] = v
            if (PH.containsMatchIn(k)) {
                val sb = StringBuilder("^")
                var last = 0
                var lit = 0
                for (m in PH.findAll(k)) {
                    val part = k.substring(last, m.range.first)
                    lit += part.length
                    sb.append(Regex.escape(part)).append("(.+?)")
                    last = m.range.last + 1
                }
                val tail = k.substring(last)
                lit += tail.length
                sb.append(Regex.escape(tail)).append("$")
                pats.add(Pat(Regex(sb.toString(), RegexOption.DOT_MATCHES_ALL), v, lit))
            }
        }
        pats.sortByDescending { it.weight }
        ready = true
    }

    fun digits(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) sb.append(if (c in '0'..'9') ('\u09E6' + (c - '0')) else c)
        return sb.toString()
    }

    /** Translate [s] to the current language. */
    fun t(s: String): String = if (bn) toBn(s) else s

    fun toBn(s: String): String {
        if (s.isEmpty()) return s
        synchronized(cache) { cache[s]?.let { return it } }
        val r = compute(s)
        synchronized(cache) { if (cache.size > 2000) cache.clear(); cache[s] = r }
        return r
    }

    private fun compute(s: String): String {
        init()
        exact[s]?.let { return digits(it) }
        if (digitsOnly.matches(s)) return if (ipLike.matches(s.trim())) s else digits(s)
        for (p in pats) {
            val m = p.re.matchEntire(s) ?: continue
            var out = p.out
            for (g in 1 until m.groupValues.size) {
                out = out.replace("{" + (g - 1) + "}", toBn(m.groupValues[g]))
            }
            return digits(out)
        }
        // Time-of-day like "07:30 AM"
        if (s.endsWith(" AM") || s.endsWith(" PM")) {
            val pm = s.endsWith(" PM")
            return digits(s.dropLast(3)) + (if (pm) " PM" else " AM").let { if (pm) " অপরাহ্ণ" else " পূর্বাহ্ণ" }
        }
        return s
    }
}
