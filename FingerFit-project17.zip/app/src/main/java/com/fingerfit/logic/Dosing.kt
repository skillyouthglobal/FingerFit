package com.fingerfit.logic

import kotlin.math.roundToInt

/** How much of an exercise suits an age group, following the WHO physical-activity age bands. */
class Dose(val band: AgeBand, val sets: Int, val perSet: Int, val unit: String, val restSec: Int, val extra: String?)

enum class AgeBand(val who: String) {
    CHILD("Children 5 to 12: WHO recommends an average of at least 60 minutes of moderate to vigorous activity every day, including muscle and bone strengthening on at least 3 days a week. Keep it playful and exercise with an adult nearby."),
    TEEN("Teenagers 13 to 17: WHO recommends an average of at least 60 minutes of moderate to vigorous activity every day, including muscle and bone strengthening on at least 3 days a week."),
    ADULT("Adults 18 to 64: WHO recommends 150 to 300 minutes of moderate activity every week, plus muscle strengthening on at least 2 days a week."),
    SENIOR("Adults 65 and over: WHO recommends the same as adults, plus balance and strength training on at least 3 days a week. Keep a chair or wall within reach and move gently."),
}

object Dosing {
    fun band(age: Int): AgeBand = when {
        age < 13 -> AgeBand.CHILD
        age < 18 -> AgeBand.TEEN
        age < 65 -> AgeBand.ADULT
        else -> AgeBand.SENIOR
    }

    fun forType(type: ExerciseType, age: Int, lowImpact: Boolean): Dose {
        val b = band(age)
        var factor = when (b) { AgeBand.CHILD -> 0.5f; AgeBand.TEEN -> 0.8f; AgeBand.ADULT -> 1f; AgeBand.SENIOR -> 0.6f }
        if (lowImpact && b == AgeBand.ADULT) factor = 0.8f
        val sets = when (b) { AgeBand.CHILD -> 1; AgeBand.TEEN -> 2; AgeBand.ADULT -> if (lowImpact) 2 else 3; AgeBand.SENIOR -> 2 }
        val rest = when (b) { AgeBand.SENIOR -> 90; AgeBand.ADULT -> 45; else -> 60 }
        val per = ((type.defaultTarget * factor / type.step).roundToInt() * type.step).coerceAtLeast(type.step)
        val jumpy = type == ExerciseType.JUMPING_JACKS || type == ExerciseType.HIGH_KNEES
        val extra = if (jumpy && (b == AgeBand.SENIOR || lowImpact)) "Take it gentle: skip the jumps and do a low-impact step version." else null
        return Dose(b, sets, per, type.unit, rest, extra)
    }
}
