package com.fingerfit.logic

/** Pure helpers for Wi-Fi / IP cameras (no Android needed, so they can be tested). */
object IpCams {

    /** Ports a camera usually answers on. 554 and 8554 are RTSP, the others are web ports. */
    val webPorts = listOf(8080, 80, 8081, 8000)
    val rtspPorts = listOf(554, 8554)

    /** Addresses that give a live picture (MJPEG), in the order they are tried. */
    val streamPaths = listOf(
        "/video", "/videostream.cgi", "/mjpeg", "/video.mjpg", "/mjpg/video.mjpg",
        "/axis-cgi/mjpg/video.cgi", "/cgi-bin/mjpg/video.cgi",
    )

    /** Addresses that give one still picture each time they are opened. */
    val snapshotPaths = listOf(
        "/shot.jpg", "/snapshot.jpg", "/snap.jpg", "/image.jpg", "/cgi-bin/snapshot.cgi", "/image/jpeg.cgi", "/capture",
    )

    private val hostRegex = Regex("^[A-Za-z0-9.-]+$")

    /** Turns what the user typed into a full address (http, https or rtsp), or null if it cannot be one. */
    fun normalizeUrl(input: String): String? {
        val t = input.trim()
        if (t.isEmpty() || t.any { it.isWhitespace() }) return null
        val full = if (t.contains("://")) t else "http://$t"
        val scheme = full.substringBefore("://").lowercase()
        if (scheme != "http" && scheme != "https" && scheme != "rtsp") return null
        val rest = full.substringAfter("://")
        val authority = rest.substringBefore('/').substringBefore('?')
        val hostPort = authority.substringAfterLast('@')
        val host = hostPort.substringBefore(':')
        if (host.isEmpty() || !hostRegex.matches(host)) return null
        if (hostPort.contains(':')) {
            val port = hostPort.substringAfter(':').toIntOrNull() ?: return null
            if (port !in 1..65535) return null
        }
        return "$scheme://$rest"
    }

    fun isRtsp(url: String): Boolean = url.startsWith("rtsp://", ignoreCase = true)

    private fun dotted(a: Long): String =
        "${(a shr 24) and 255L}.${(a shr 16) and 255L}.${(a shr 8) and 255L}.${a and 255L}"

    /**
     * Every other address on the phone's own network. Networks bigger than a /24 are cut down to the
     * /24 around the phone, so a scan stays quick.
     */
    fun subnetHosts(ip: String, prefix: Int): List<String> {
        val p = ip.split('.').map { it.toIntOrNull() ?: return emptyList() }
        if (p.size != 4 || p.any { it !in 0..255 }) return emptyList()
        val self = (p[0].toLong() shl 24) or (p[1].toLong() shl 16) or (p[2].toLong() shl 8) or p[3].toLong()
        val pre = if (prefix >= 24) prefix.coerceAtMost(30) else 24
        val mask = (0xFFFFFFFFL shl (32 - pre)) and 0xFFFFFFFFL
        val net = self and mask
        val broadcast = net or (mask.inv() and 0xFFFFFFFFL)
        val out = ArrayList<String>()
        var a = net + 1
        while (a < broadcast) {
            if (a != self) out.add(dotted(a))
            a++
        }
        return out
    }
}

/**
 * Cuts a Motion-JPEG byte stream into single JPEG pictures. Each picture starts with FF D8 and ends
 * with FF D9; whatever is between pictures (headers, boundaries) is thrown away.
 */
class JpegSplitter(private val maxFrame: Int = 3_000_000) {
    private var buf = ByteArray(65536)
    private var len = 0

    fun feed(data: ByteArray, n: Int): List<ByteArray> {
        if (n <= 0) return emptyList()
        if (len + n > buf.size) buf = buf.copyOf(maxOf(buf.size * 2, len + n))
        System.arraycopy(data, 0, buf, len, n)
        len += n
        val out = ArrayList<ByteArray>()
        while (true) {
            val s = find(0xD8, 0)
            if (s < 0) {
                // Keep a lone FF at the end: its partner may arrive in the next chunk.
                if (len > 0 && buf[len - 1] == 0xFF.toByte()) {
                    buf[0] = buf[len - 1]
                    len = 1
                } else {
                    len = 0
                }
                break
            }
            val e = find(0xD9, s + 2)
            if (e < 0) {
                if (s > 0) shift(s)
                if (len > maxFrame) len = 0
                break
            }
            out.add(buf.copyOfRange(s, e + 2))
            shift(e + 2)
        }
        return out
    }

    /** Index of the FF byte that is followed by [second], searching from [from]; -1 if none. */
    private fun find(second: Int, from: Int): Int {
        var i = from
        while (i + 1 < len) {
            if (buf[i] == 0xFF.toByte() && buf[i + 1] == second.toByte()) return i
            i++
        }
        return -1
    }

    private fun shift(k: Int) {
        System.arraycopy(buf, k, buf, 0, len - k)
        len -= k
    }
}
