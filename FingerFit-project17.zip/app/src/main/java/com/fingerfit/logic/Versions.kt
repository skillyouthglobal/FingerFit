package com.fingerfit.logic

/** Release tags look like v1.0.17. The last number is the GitHub build number = the app's versionCode. */
object Versions {
    private val TAG = Regex("""^v?(\d+)\.(\d+)\.(\d+)$""")

    fun codeFromTag(tag: String?): Int? {
        val m = TAG.matchEntire(tag?.trim() ?: return null) ?: return null
        return m.groupValues[3].toIntOrNull()
    }

    fun isNewer(latest: Int?, installed: Int): Boolean = latest != null && latest > installed
}
