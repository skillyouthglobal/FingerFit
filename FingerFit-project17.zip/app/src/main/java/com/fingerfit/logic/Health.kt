package com.fingerfit.logic

import java.time.DateTimeException
import java.time.LocalDate
import java.time.Period

enum class Gender(val label: String) { MALE("Male"), FEMALE("Female"), OTHER("Other") }

enum class Goal(val label: String) {
    LOSE("Lose weight"),
    MAINTAIN("Stay fit"),
    GAIN("Build muscle / gain weight"),
}

/** Simple, offline health calculations used by the profile. */
object Health {

    fun age(birth: LocalDate, today: LocalDate): Int = Period.between(birth, today).years.coerceAtLeast(0)

    fun bmi(weightKg: Float, heightCm: Float): Float {
        if (heightCm <= 0f) return 0f
        val m = heightCm / 100f
        return weightKg / (m * m)
    }

    /** WHO Asia-Pacific cut-offs, which suit South Asian (Bangladeshi) bodies better than the global ones. */
    fun bmiCategory(bmi: Float): String = when {
        bmi <= 0f -> "-"
        bmi < 18.5f -> "Underweight"
        bmi < 23f -> "Healthy weight"
        bmi < 27.5f -> "Overweight"
        else -> "Obese"
    }

    /** Healthy weight range (kg) for the height, using BMI 18.5 to 22.9. */
    fun healthyRangeKg(heightCm: Float): Pair<Float, Float> {
        val m = heightCm / 100f
        return Pair(18.5f * m * m, 22.9f * m * m)
    }

    fun cmFromFeetInches(feet: Int, inches: Int): Float = (feet * 12 + inches) * 2.54f

    fun feetInchesFromCm(cm: Float): Pair<Int, Int> {
        val total = Math.round(cm / 2.54f)
        return Pair(total / 12, total % 12)
    }

    /** Null when the date does not exist, is in the future, or is unrealistically old. */
    fun parseDate(day: Int, month: Int, year: Int, today: LocalDate): LocalDate? = try {
        val d = LocalDate.of(year, month, day)
        if (d.isAfter(today) || year < 1900) null else d
    } catch (e: DateTimeException) {
        null
    }
}
