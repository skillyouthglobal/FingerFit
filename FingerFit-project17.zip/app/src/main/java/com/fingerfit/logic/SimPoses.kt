package com.fingerfit.logic

/** Generated joint-angle poses (degrees). Solved so hands/feet stay planted. */
internal object SimPoses {
    val JJ_A = SimPose(t = 180f, h = 180f, a1 = 8f, a2 = 6f, b1 = 8f, b2 = 6f, l1 = 4f, l2 = 4f, r1 = 4f, r2 = 4f, lf = 80f, rf = 80f, lift = 0f)
    val JJ_B = SimPose(t = 180f, h = 180f, a1 = 150f, a2 = 168f, b1 = 150f, b2 = 168f, l1 = 20f, l2 = 20f, r1 = 20f, r2 = 20f, lf = 70f, rf = 70f, lift = 0.05f)
    val SQ_A = SimPose(t = 180f, h = 180f, a1 = 12f, a2 = 10f, b1 = 12f, b2 = 10f, l1 = 0f, l2 = 0f, r1 = 0f, r2 = 0f, lf = 90f, rf = 90f, lift = 0f)
    val SQ_B = SimPose(t = 148f, h = 166f, a1 = 88f, a2 = 88f, b1 = 88f, b2 = 88f, l1 = 76f, l2 = -26f, r1 = 76f, r2 = -26f, lf = 90f, rf = 90f, lift = 0f)
    val PU_A = SimPose(t = 108.81f, h = 108.81f, a1 = 2f, a2 = 2f, b1 = 2f, b2 = 2f, l1 = 288.81f, l2 = 288.81f, r1 = 288.81f, r2 = 288.81f, lf = 25f, rf = 25f, lift = 0f)
    val PU_B = SimPose(t = 95.46f, h = 95.46f, a1 = -68f, a2 = 55.28f, b1 = -68f, b2 = 55.28f, l1 = 275.46f, l2 = 275.46f, r1 = 275.46f, r2 = 275.46f, lf = 25f, rf = 25f, lift = 0f)
    val PL_A = SimPose(t = 96.59f, h = 96.59f, a1 = 0f, a2 = 90f, b1 = 0f, b2 = 90f, l1 = 276.59f, l2 = 276.59f, r1 = 276.59f, r2 = 276.59f, lf = 25f, rf = 25f, lift = 0f)
    val PL_B = SimPose(t = 98.09f, h = 98.09f, a1 = 0f, a2 = 90f, b1 = 0f, b2 = 90f, l1 = 278.09f, l2 = 278.09f, r1 = 278.09f, r2 = 278.09f, lf = 25f, rf = 25f, lift = 0f)
    val LU_L = SimPose(t = 180f, h = 180f, a1 = 6f, a2 = 22f, b1 = 6f, b2 = 22f, l1 = 82f, l2 = -4f, r1 = -24f, r2 = -97.53f, lf = 90f, rf = 35f, lift = 0f)
    val LU_STAND = SimPose(t = 180f, h = 180f, a1 = 6f, a2 = 22f, b1 = 6f, b2 = 22f, l1 = 2f, l2 = 2f, r1 = 2f, r2 = 2f, lf = 90f, rf = 90f, lift = 0f)
    val LU_R = SimPose(t = 180f, h = 180f, a1 = 6f, a2 = 22f, b1 = 6f, b2 = 22f, l1 = -24f, l2 = -97.53f, r1 = 82f, r2 = -4f, lf = 35f, rf = 90f, lift = 0f)
    val HK_UP = SimPose(t = 178f, h = 178f, a1 = -55f, a2 = -8f, b1 = 68f, b2 = 125f, l1 = 96f, l2 = -8f, r1 = -2f, r2 = 0f, lf = 70f, rf = 90f, lift = 0f)
    val HK_MID = SimPose(t = 180f, h = 180f, a1 = -20f, a2 = 60f, b1 = 20f, b2 = 70f, l1 = 10f, l2 = -5f, r1 = -4f, r2 = -4f, lf = 90f, rf = 90f, lift = 0f)
    val HK_UP2 = SimPose(t = 178f, h = 178f, a1 = 68f, a2 = 125f, b1 = -55f, b2 = -8f, l1 = -2f, l2 = 0f, r1 = 96f, r2 = -8f, lf = 90f, rf = 70f, lift = 0f)
    val CR_A = SimPose(t = -90f, h = -90f, a1 = -140f, a2 = -50f, b1 = -140f, b2 = -50f, l1 = 125f, l2 = 37.42f, r1 = 125f, r2 = 37.42f, lf = 90f, rf = 90f, lift = 0f)
    val CR_B = SimPose(t = -128f, h = -140f, a1 = -140f, a2 = -52f, b1 = -140f, b2 = -52f, l1 = 125f, l2 = 37.42f, r1 = 125f, r2 = 37.42f, lf = 90f, rf = 90f, lift = 0f)
    val GB_A = SimPose(t = -90f, h = -90f, a1 = 90f, a2 = 90f, b1 = 90f, b2 = 90f, l1 = 125f, l2 = 37.42f, r1 = 125f, r2 = 37.42f, lf = 90f, rf = 90f, lift = 0f)
    val GB_B = SimPose(t = -69.48f, h = -69.48f, a1 = 90f, a2 = 90f, b1 = 90f, b2 = 90f, l1 = 110.52f, l2 = 34.61f, r1 = 110.52f, r2 = 34.61f, lf = 90f, rf = 90f, lift = 0f)
}
