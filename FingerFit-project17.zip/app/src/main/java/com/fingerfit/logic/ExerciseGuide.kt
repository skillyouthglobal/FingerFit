package com.fingerfit.logic

/** Plain-language instructions shown before each workout. */
class Guide(
    val steps: List<String>,
    val benefits: List<String>,
    val camera: String,
    val counting: String,
    val safety: String,
)

object Guides {
    fun of(type: ExerciseType): Guide = when (type) {
        ExerciseType.JUMPING_JACKS -> Guide(
            steps = listOf(
                "Stand straight with feet together and arms down by your sides.",
                "Jump and spread your feet wider than your shoulders while raising both arms overhead.",
                "Jump again, bringing your feet together and arms back down.",
                "Keep a steady rhythm and breathe normally.",
            ),
            benefits = listOf(
                "Raises your heart rate quickly: good warm-up and cardio",
                "Burns calories and improves stamina",
                "Improves coordination between arms and legs",
                "Needs no equipment and little space",
            ),
            camera = "Face the camera, 2 to 3 metres away. Your whole body, from head to feet, must be inside the picture. Raise your arms fully so the camera can see them.",
            counting = "One repetition is counted when your arms go up and feet spread, then you return to the start position.",
            safety = "Land softly on the balls of your feet. Skip this one if you have knee, ankle or back pain.",
        )
        ExerciseType.SQUATS -> Guide(
            steps = listOf(
                "Stand with feet shoulder-width apart, toes slightly outward.",
                "Push your hips back and bend your knees as if sitting on a chair.",
                "Go down until your thighs are about parallel to the floor, chest up, back straight.",
                "Push through your heels to stand up fully.",
            ),
            benefits = listOf(
                "Strengthens thighs, glutes and core",
                "Makes everyday movements like standing up and climbing stairs easier",
                "Supports healthy bones and joints",
                "Burns many calories because large muscles work together",
            ),
            camera = "Stand SIDEWAYS to the camera, 2 to 3 metres away, phone at about hip height. Keep your whole body in view.",
            counting = "A repetition is counted when your knees bend deeply enough and you stand back up.",
            safety = "Keep your knees in line with your toes and your heels on the floor. Stop if you feel sharp knee pain.",
        )
        ExerciseType.PUSH_UPS -> Guide(
            steps = listOf(
                "Place your hands slightly wider than your shoulders. Body in one straight line from head to heels.",
                "Lower your chest toward the floor by bending your elbows.",
                "Stop just above the floor, then push back up until your arms are straight.",
                "If this is too hard, do it with your knees on the floor.",
            ),
            benefits = listOf(
                "Builds chest, shoulder and arm strength",
                "Strengthens your core",
                "Improves upper-body endurance",
                "Needs no equipment",
            ),
            camera = "Put the phone on the floor beside you (SIDE view), about 1.5 to 2 metres away, so your whole body from head to feet is visible.",
            counting = "A repetition is counted when your elbows bend as your chest goes down and you push back up. Standing up will not count.",
            safety = "Do not let your hips sag or rise. Stop if you feel wrist or shoulder pain.",
        )
        ExerciseType.LUNGES -> Guide(
            steps = listOf(
                "Stand tall with feet hip-width apart.",
                "Step one foot forward and lower your hips until both knees bend to about 90 degrees.",
                "Push through the front foot to return to standing.",
                "Repeat with the other leg, alternating sides.",
            ),
            benefits = listOf(
                "Strengthens thighs and glutes",
                "Improves balance and leg control",
                "Works each leg separately to even out strength",
                "Good for walking and running ability",
            ),
            camera = "Stand SIDEWAYS to the camera, 2 to 3 metres away, whole body in view.",
            counting = "Each step into a lunge counts once. Kinetro shows left and right separately.",
            safety = "Keep the front knee above the ankle, not past your toes. Hold a wall for balance if needed.",
        )
        ExerciseType.HIGH_KNEES -> Guide(
            steps = listOf(
                "Stand tall with feet hip-width apart.",
                "Run in place, lifting each knee up toward hip height.",
                "Swing your arms naturally and stay on the balls of your feet.",
                "Keep a quick, steady pace.",
            ),
            benefits = listOf(
                "Strong cardio workout that burns calories",
                "Improves speed, coordination and leg strength",
                "Works the core and hip flexors",
                "Great as a warm-up",
            ),
            camera = "Face the camera, 2 to 3 metres away, whole body from head to feet in view.",
            counting = "Each knee lifted to hip height counts once. Kinetro shows left and right separately.",
            safety = "Land softly and keep your chest up. Slow down if you feel dizzy or short of breath.",
        )
        ExerciseType.CRUNCHES -> Guide(
            steps = listOf(
                "Lie on your back with knees bent and feet flat on the floor.",
                "Place your hands lightly behind your head or cross them on your chest.",
                "Curl your shoulders up off the floor by tightening your stomach muscles.",
                "Lower back down slowly. Do not pull on your neck.",
            ),
            benefits = listOf(
                "Strengthens the abdominal muscles",
                "Improves core stability and posture",
                "Supports your lower back",
                "Needs only a mat or soft floor",
            ),
            camera = "Lie down with the phone on the floor at your SIDE, 1.5 to 2 metres away, so your whole body is in view.",
            counting = "A repetition is counted when your shoulders lift toward your knees and you lower back down.",
            safety = "Move slowly and keep your neck relaxed. Stop if your back or neck hurts.",
        )
        ExerciseType.GLUTE_BRIDGES -> Guide(
            steps = listOf(
                "Lie on your back with knees bent and feet flat, hip-width apart.",
                "Press through your heels and lift your hips until shoulders, hips and knees form a straight line.",
                "Squeeze your glutes at the top for a moment.",
                "Lower your hips slowly to the floor.",
            ),
            benefits = listOf(
                "Strengthens glutes and hamstrings",
                "Improves hip control and stability",
                "Helps reduce lower-back stiffness from sitting",
                "Gentle and suitable for beginners",
            ),
            camera = "Lie down with the phone on the floor at your SIDE, 1.5 to 2 metres away, whole body in view.",
            counting = "A repetition is counted when your hips rise high enough and come back down.",
            safety = "Do not arch your lower back too much. Stop if you feel pain in your back.",
        )
        ExerciseType.PLANK -> Guide(
            steps = listOf(
                "Rest on your forearms and toes, elbows under your shoulders.",
                "Keep your body in one straight line from head to heels.",
                "Tighten your stomach and glutes. Look at the floor.",
                "Hold the position and breathe normally.",
            ),
            benefits = listOf(
                "Strengthens abs, back and shoulders",
                "Builds muscular endurance",
                "Improves posture and balance",
                "No movement, so it is easy on the joints",
            ),
            camera = "Put the phone on the floor beside you (SIDE view), 1.5 to 2 metres away, so your whole body is in view.",
            counting = "Time is counted only while your body stays in a straight plank line. The timer pauses if your hips sag or rise.",
            safety = "Stop when your form breaks down. Do not hold your breath.",
        )
    }
}
