package com.fingerfit

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fingerfit.link.IpCamera
import com.fingerfit.link.IpUi
import com.fingerfit.link.LinkRole
import com.fingerfit.link.LinkService
import com.fingerfit.link.LinkState
import com.fingerfit.link.LinkUi
import com.fingerfit.link.NearbyLink
import com.fingerfit.link.Peer
import com.fingerfit.link.WebCamServer
import com.fingerfit.link.WebUi
import com.fingerfit.logic.Wire
import com.fingerfit.vision.PoseFrame
import com.fingerfit.vision.PoseTracker
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

/**
 * Two-phone mode. The link stays alive until the user taps Disconnect (or the app is closed
 * completely); leaving the screen or the app does not drop it.
 */
class LinkViewModel(private val app: Application) : AndroidViewModel(app) {

    private val link = NearbyLink(app) { bytes -> onBytes(bytes) }
    val ui: StateFlow<LinkUi> = link.ui

    private val web = WebCamServer(app, { f -> onWebFrame(f) }, { jpeg -> showPreview(jpeg) })
    /** Browser-camera mode (the other phone needs no app). */
    val webUi: StateFlow<WebUi> = web.ui

    private val ip = IpCamera { jpeg -> onIpJpeg(jpeg) }
    /** Wi-Fi / IP camera mode. */
    val ipUi: StateFlow<IpUi> = ip.ui
    private var ipTracker: PoseTracker? = null

    private val _streamOk = MutableStateFlow(false)
    /** True while body data keeps arriving from the camera phone. */
    val streamOk: StateFlow<Boolean> = _streamOk.asStateFlow()

    private val _preview = MutableStateFlow<Bitmap?>(null)
    /** Latest small picture from the camera phone (shown behind the skeleton). */
    val preview: StateFlow<Bitmap?> = _preview.asStateFlow()

    private val _fps = MutableStateFlow(0)
    /** Pictures per second arriving from the camera (shown so you can judge how smooth it is). */
    val fps: StateFlow<Int> = _fps.asStateFlow()
    private var fpsCount = 0
    private var fpsStart = 0L

    private fun tickFps(now: Long) {
        if (fpsStart == 0L) fpsStart = now
        fpsCount++
        if (now - fpsStart >= 1000) {
            _fps.value = (fpsCount * 1000L / (now - fpsStart)).toInt()
            fpsCount = 0
            fpsStart = now
        }
    }

    private val _useRemote = MutableStateFlow(true)
    /** The workout screen uses the other phone's camera while this is true and a phone is linked. */
    val useRemote: StateFlow<Boolean> = _useRemote.asStateFlow()

    @Volatile private var sink: ((PoseFrame) -> Unit)? = null
    @Volatile private var lastFrameAt = 0L
    @Volatile private var lastSentAt = 0L
    @Volatile private var lastPreviewSentAt = 0L
    @Volatile private var lastPreviewShownAt = 0L
    private var wasAvailable = false
    private var serviceOn = false

    init {
        viewModelScope.launch {
            while (true) {
                val l = link.ui.value
                val webOn = web.ui.value.running
                val ipOn = ip.ui.value.running
                val linked = l.state == LinkState.CONNECTED || webOn || ipOn
                val ok = linked && SystemClock.uptimeMillis() - lastFrameAt < 2000
                if (_streamOk.value != ok) _streamOk.value = ok
                if (!ok && _fps.value != 0) _fps.value = 0
                if (!ok && _preview.value != null) _preview.value = null

                // A newly linked phone becomes the camera automatically.
                val available = (l.state == LinkState.CONNECTED && l.role == LinkRole.DISPLAY) || webOn || ipOn
                if (available && !wasAvailable) _useRemote.value = true
                wasAvailable = available

                // Keep the link alive in the background while linked.
                if (linked != serviceOn) {
                    serviceOn = linked
                    try {
                        val i = Intent(app, LinkService::class.java)
                        if (linked) ContextCompat.startForegroundService(app, i) else app.stopService(i)
                    } catch (e: Exception) {
                    }
                }
                delay(500)
            }
        }
    }

    fun setSink(s: ((PoseFrame) -> Unit)?) {
        sink = s
    }

    fun setUseRemote(v: Boolean) {
        _useRemote.value = v
    }

    fun startDisplay() {
        web.stop()
        ip.stop()
        link.startDisplay()
    }

    fun startCamera() {
        web.stop()
        ip.stop()
        link.startCamera()
    }

    fun connect(peer: Peer) = link.connect(peer)
    fun accept() = link.accept()
    fun reject() = link.reject()

    fun scanIp() = ip.scan()
    fun stopScanIp() = ip.stopScan()

    /** Use a Wi-Fi / IP camera (a picture address such as http://192.168.0.5:8080/video). */
    fun startIp(url: String, label: String) {
        link.stop()
        web.stop()
        ip.connect(url, label)
    }

    fun startWeb() {
        link.stop()
        ip.stop()
        web.start()
    }

    fun refreshWeb() = web.refresh()

    /** Disconnect everything. */
    fun stop() {
        link.stop()
        web.stop()
        ip.stop()
        lastFrameAt = 0L
        _preview.value = null
    }

    fun isConnected(): Boolean = link.isConnected()

    /** Camera phone: send one analysed frame (about 14 per second at most). */
    fun sendPose(f: PoseFrame?) {
        if (f == null || !link.isConnected()) return
        val now = SystemClock.uptimeMillis()
        if (now - lastSentAt < MIN_SEND_GAP_MS) return
        lastSentAt = now
        link.send(Wire.encodePose(f.points, f.width, f.height, f.lightingOk, f.mirrored, f.timeMs))
    }

    /** Camera phone: send a small picture (about 6 per second) so the main phone can show the view. */
    fun sendPicture(upright: Bitmap) {
        if (!link.isConnected()) return
        val now = SystemClock.uptimeMillis()
        if (now - lastPreviewSentAt < PREVIEW_GAP_MS) return
        lastPreviewSentAt = now
        val k = PREVIEW_SIDE.toFloat() / maxOf(upright.width, upright.height)
        val small = if (k < 1f) {
            Bitmap.createScaledBitmap(upright, (upright.width * k).toInt().coerceAtLeast(1), (upright.height * k).toInt().coerceAtLeast(1), true)
        } else upright
        val os = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 55, os)
        if (small !== upright) small.recycle()
        val msg = Wire.encodePreview(os.toByteArray()) ?: return
        link.send(msg)
    }

    private fun onBytes(bytes: ByteArray) {
        if (Wire.isPreview(bytes)) {
            Wire.previewBytes(bytes)?.let { showPreview(it) }
            return
        }
        val d = Wire.decodePose(bytes) ?: return
        lastFrameAt = SystemClock.uptimeMillis()
        tickFps(lastFrameAt)
        sink?.invoke(PoseFrame(d.points, d.width, d.height, d.lightingOk, d.mirrored, d.timeMs))
    }

    private fun showPreview(jpeg: ByteArray) {
        val now = SystemClock.uptimeMillis()
        if (now - lastPreviewShownAt < 60) return
        lastPreviewShownAt = now
        try {
            val bmp = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return
            _preview.value = bmp
        } catch (e: Exception) {
        }
    }

    /** Wi-Fi camera: find the body in one picture and pass it on like any other camera. */
    private fun onIpJpeg(jpeg: ByteArray) {
        val raw = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return
        val k = IP_SIDE.toFloat() / maxOf(raw.width, raw.height)
        val bmp = if (k < 1f) {
            Bitmap.createScaledBitmap(raw, (raw.width * k).toInt().coerceAtLeast(1), (raw.height * k).toInt().coerceAtLeast(1), true)
        } else raw
        if (bmp !== raw) raw.recycle()
        try {
            val tracker = ipTracker ?: PoseTracker(app).also { ipTracker = it }
            val now = SystemClock.uptimeMillis()
            val points = tracker.detect(bmp, now)
            _preview.value = bmp
            lastFrameAt = now
            tickFps(now)
            sink?.invoke(PoseFrame(points, bmp.width, bmp.height, brightEnough(bmp), false, now))
        } catch (e: Exception) {
        }
    }

    private fun brightEnough(b: Bitmap): Boolean {
        val n = 10
        var sum = 0f
        for (iy in 0 until n) for (ix in 0 until n) {
            val p = b.getPixel(((ix + 0.5f) * b.width / n).toInt(), ((iy + 0.5f) * b.height / n).toInt())
            sum += 0.299f * android.graphics.Color.red(p) + 0.587f * android.graphics.Color.green(p) + 0.114f * android.graphics.Color.blue(p)
        }
        return sum / (n * n) >= 40f
    }

    private fun onWebFrame(f: PoseFrame) {
        lastFrameAt = SystemClock.uptimeMillis()
        tickFps(lastFrameAt)
        sink?.invoke(f)
    }

    override fun onCleared() {
        web.stop()
        ip.stop()
        ip.release()
        try {
            ipTracker?.close()
        } catch (e: Exception) {
        }
        link.release()
        try {
            app.stopService(Intent(app, LinkService::class.java))
        } catch (e: Exception) {
        }
    }

    private companion object {
        const val MIN_SEND_GAP_MS = 70L
        const val PREVIEW_GAP_MS = 160L
        const val PREVIEW_SIDE = 256
        const val IP_SIDE = 640
    }
}
