package com.fingerfit.link

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.os.SystemClock
import com.fingerfit.vision.PoseFrame
import com.fingerfit.vision.PoseTracker
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.ByteArrayOutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.KeyStore
import java.security.cert.X509Certificate
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import kotlin.concurrent.thread

data class WebUi(
    val running: Boolean = false,
    /** Addresses the other phone can open, e.g. https://192.168.43.1:8443 */
    val urls: List<String> = emptyList(),
    val error: String? = null,
    /** True while the server is being started and tested. */
    val checking: Boolean = false,
)

/**
 * "Browser camera" mode: this phone runs a tiny web page on the local Wi-Fi / hotspot.
 * Any phone with a browser (no app needed) opens it, and its camera pictures are sent here,
 * analysed on this phone and thrown away. Nothing leaves the local network; no internet needed.
 */
class WebCamServer(
    private val context: Context,
    private val onFrame: (PoseFrame) -> Unit,
    /** A JPEG picture of what the other phone's camera sees (already mirrored like the skeleton). */
    private val onPreview: (ByteArray) -> Unit,
) {

    private val _ui = MutableStateFlow(WebUi())
    val ui: StateFlow<WebUi> = _ui.asStateFlow()

    private var server: Server? = null
    private var landing: Landing? = null
    @Volatile private var generation = 0
    private var tracker: PoseTracker? = null

    fun start() {
        val gen = synchronized(this) {
            stopInternal()
            ++generation
        }
        _ui.value = WebUi(running = true, urls = localAddresses().map { "http://$it:$HTTP_PORT" }, checking = true)
        thread(name = "kinetro-web-start") { startBlocking(gen) }
    }

    private fun startBlocking(gen: Int) {
        var problem: String? = null
        try {
            val t = PoseTracker(context.applicationContext)
            synchronized(this) {
                if (gen != generation) {
                    t.close()
                    return
                }
                tracker = t
            }
        } catch (e: Throwable) {
            fail(gen, "The body-tracking model could not be loaded (${e.localizedMessage ?: "error"}).")
            return
        }

        val factory = try {
            sslFactory()
        } catch (e: Throwable) {
            fail(gen, "Security certificate problem (${e.localizedMessage ?: "error"}).")
            return
        }

        var ok = false
        for (protocols in listOf<Array<String>?>(arrayOf("TLSv1.2"), null)) {
            val srv = Server()
            try {
                srv.makeSecure(factory, protocols)
                srv.start(NanoHTTPD.SOCKET_READ_TIMEOUT, true)
                val err = selfTest()
                if (err == null) {
                    synchronized(this) {
                        if (gen != generation) {
                            srv.stop()
                            return
                        }
                        server = srv
                    }
                    ok = true
                    break
                }
                problem = err
                srv.stop()
            } catch (e: Throwable) {
                problem = "${e.javaClass.simpleName}: ${e.localizedMessage ?: ""}"
                try {
                    srv.stop()
                } catch (x: Exception) {
                }
            }
        }
        if (!ok) {
            fail(gen, "The camera page could not start. ${problem ?: ""}".trim())
            return
        }

        try {
            val l = Landing()
            l.start(NanoHTTPD.SOCKET_READ_TIMEOUT, true)
            synchronized(this) {
                if (gen != generation) {
                    l.stop()
                    return
                }
                landing = l
            }
        } catch (e: Throwable) {
            // The short link is a convenience; the https link still works.
        }
        synchronized(this) { if (gen == generation) publishAddresses() }
    }

    private fun fail(gen: Int, message: String) {
        synchronized(this) {
            if (gen != generation) return
            stopInternal()
            _ui.value = WebUi(error = message)
        }
    }

    /** Opens a TLS connection to ourselves to make sure browsers will be able to connect too. */
    private fun selfTest(): String? = try {
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(null, arrayOf<TrustManager>(trustAll), null)
        val sock = ctx.socketFactory.createSocket("127.0.0.1", PORT) as SSLSocket
        sock.soTimeout = 5000
        sock.use { it.startHandshake() }
        null
    } catch (e: Throwable) {
        "${e.javaClass.simpleName}: ${e.localizedMessage ?: ""}"
    }

    /** Look for the Wi-Fi / hotspot address again (after turning the hotspot on, for example). */
    @Synchronized
    fun refresh() {
        if (server != null) publishAddresses()
    }

    @Synchronized
    fun stop() {
        generation++
        stopInternal()
        _ui.value = WebUi()
    }

    private fun stopInternal() {
        try {
            server?.stop()
        } catch (e: Exception) {
        }
        server = null
        try {
            landing?.stop()
        } catch (e: Exception) {
        }
        landing = null
        try {
            tracker?.close()
        } catch (e: Exception) {
        }
        tracker = null
    }

    private fun publishAddresses() {
        val urls = localAddresses().map { "http://$it:$HTTP_PORT" }
        _ui.value = WebUi(
            running = true,
            urls = urls,
            error = if (urls.isEmpty()) {
                "No Wi-Fi or hotspot found. Connect to a Wi-Fi network, or turn on this phone's hotspot, then tap \"Refresh address\"."
            } else null,
        )
    }

    private fun sslFactory(): javax.net.ssl.SSLServerSocketFactory {
        val ks = KeyStore.getInstance("PKCS12")
        context.assets.open(KEYSTORE_ASSET).use { ks.load(it, KEYSTORE_PASSWORD) }
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, KEYSTORE_PASSWORD)
        return NanoHTTPD.makeSSLSocketFactory(ks, kmf)
    }

    private inner class Server : NanoHTTPD(PORT) {
        override fun serve(session: IHTTPSession): Response {
            return try {
                val uri = session.uri ?: "/"
                when {
                    session.method == Method.POST && uri == "/frame" -> handleFrame(session)
                    uri == "/" || uri == "/index.html" ->
                        NanoHTTPD.newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", PAGE)
                    else -> NanoHTTPD.newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
                }
            } catch (e: Throwable) {
                NanoHTTPD.newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "error")
            }
        }
    }

    /** Plain-http entry page: easy to type or scan, then sends the browser on to the camera page. */
    private inner class Landing : NanoHTTPD(HTTP_PORT) {
        override fun serve(session: IHTTPSession): Response =
            NanoHTTPD.newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", LANDING)
    }

    private fun bad(): Response =
        NanoHTTPD.newFixedLengthResponse(Response.Status.BAD_REQUEST, "text/plain", "bad")

    private fun handleFrame(session: IHTTPSession): Response {
        val len = session.headers["content-length"]?.toIntOrNull() ?: return bad()
        if (len <= 0 || len > MAX_FRAME_BYTES) return bad()
        val buf = ByteArray(len)
        var off = 0
        val input = session.inputStream
        while (off < len) {
            val n = input.read(buf, off, len - off)
            if (n < 0) break
            off += n
        }
        if (off < len) return bad()

        val mirror = session.headers["x-mirror"] == "1"
        val raw = BitmapFactory.decodeByteArray(buf, 0, len) ?: return bad()
        val bmp = if (mirror) {
            Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, Matrix().apply { postScale(-1f, 1f) }, true)
        } else raw
        try {
            val t = tracker ?: return bad()
            val now = SystemClock.uptimeMillis()
            val lightingOk = meanLuma(bmp) >= MIN_LUMA
            val points = t.detect(bmp, now)
            onFrame(PoseFrame(points, bmp.width, bmp.height, lightingOk, mirror, now))
            try {
                onPreview(if (!mirror) buf else toJpeg(bmp))
            } catch (e: Exception) {
            }
        } finally {
            if (bmp !== raw) bmp.recycle()
            raw.recycle()
        }
        return NanoHTTPD.newFixedLengthResponse(Response.Status.OK, "text/plain", "ok")
    }

    private fun toJpeg(b: Bitmap): ByteArray {
        val os = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 60, os)
        return os.toByteArray()
    }

    private fun meanLuma(b: Bitmap): Float {
        val n = 12
        var sum = 0f
        for (iy in 0 until n) for (ix in 0 until n) {
            val p = b.getPixel(((ix + 0.5f) * b.width / n).toInt(), ((iy + 0.5f) * b.height / n).toInt())
            sum += 0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p)
        }
        return sum / (n * n)
    }

    private fun localAddresses(): List<String> {
        val found = mutableListOf<Pair<Int, String>>()
        try {
            val list = NetworkInterface.getNetworkInterfaces() ?: return emptyList()
            for (ni in list) {
                if (!ni.isUp || ni.isLoopback) continue
                val name = ni.name.lowercase()
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && !a.isLoopbackAddress && a.isSiteLocalAddress) {
                        val rank = when {
                            name.startsWith("ap") || name.startsWith("swlan") || name.startsWith("softap") -> 0
                            name.startsWith("wlan") -> 1
                            else -> 2
                        }
                        found += rank to (a.hostAddress ?: continue)
                    }
                }
            }
        } catch (e: Exception) {
        }
        return found.sortedBy { it.first }.map { it.second }.distinct()
    }

    companion object {
        const val PORT = 8443
        const val HTTP_PORT = 8080
        private const val MAX_FRAME_BYTES = 2_000_000
        private const val MIN_LUMA = 40f
        private const val KEYSTORE_ASSET = "kinetro_local.p12"
        private val KEYSTORE_PASSWORD = "kinetro-local".toCharArray()

        private val LANDING = """
<!doctype html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Kinetro Camera</title>
<style>
body{margin:0;padding:20px;background:#0A1330;color:#EDEFFF;font-family:sans-serif;text-align:center}
a{display:inline-block;margin:18px 0;padding:16px 26px;border-radius:14px;background:#2EE6B0;color:#04122A;font-weight:bold;font-size:19px;text-decoration:none}
p{color:#A9B8E0;font-size:15px;line-height:1.5}
</style></head><body>
<h2>Kinetro Camera</h2>
<p>Opening the camera page...</p>
<a id="a" href="#">Open camera page</a>
<p>If the browser says <b>Not secure</b> or <b>Your connection is not private</b>, tap <b>Advanced</b> and then <b>Continue</b> (or <b>Proceed</b>). This is normal: the link is on your own phone and nothing goes to the internet. The browser needs this step before it lets the camera start.</p>
<script>
var u='https://'+location.hostname+':8443/';
document.getElementById('a').href=u;
setTimeout(function(){location.href=u;},2500);
</script></body></html>
"""

        /** The page the other phone's browser shows. */
        private val PAGE = """
<!doctype html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Kinetro Camera</title>
<style>
body{margin:0;padding:12px;background:#0A1330;color:#EDEFFF;font-family:sans-serif;text-align:center}
video{width:100%;max-height:62vh;background:#000;border-radius:16px}
button{font-size:18px;padding:14px 22px;margin:8px 4px;border:0;border-radius:14px;background:#2EE6B0;color:#04122A;font-weight:bold}
button.o{background:#1C2A5C;color:#EDEFFF}
#s{min-height:44px;font-size:15px;color:#A9B8E0}
</style></head><body>
<h2>Kinetro Camera</h2>
<video id="v" playsinline muted autoplay></video>
<canvas id="c" style="display:none"></canvas>
<p id="s">Tap "Start camera", then allow the camera.</p>
<button id="go">Start camera</button>
<button id="flip" class="o">Switch camera</button>
<p style="font-size:13px;color:#A9B8E0">Prop this phone up so your whole body is in view. Keep this page open. Pictures are only analysed on the main phone and are never saved.</p>
<script>
var v=document.getElementById('v'),c=document.getElementById('c'),s=document.getElementById('s');
var front=false,stream=null,running=false;
function say(t){s.textContent=t;}
function sleep(ms){return new Promise(function(r){setTimeout(r,ms);});}
async function openCam(){
  if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){
    throw new Error('This browser blocked the camera. Open the link again and choose Advanced > Continue.');
  }
  if(stream){stream.getTracks().forEach(function(t){t.stop();});}
  stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:front?'user':'environment',width:{ideal:640},height:{ideal:480}},audio:false});
  v.srcObject=stream;
  await v.play();
}
async function loop(){
  running=true;
  while(true){
    try{
      var w=v.videoWidth,h=v.videoHeight;
      if(w&&h){
        var k=Math.min(1,480/Math.max(w,h));
        c.width=Math.round(w*k);c.height=Math.round(h*k);
        c.getContext('2d').drawImage(v,0,0,c.width,c.height);
        var blob=await new Promise(function(r){c.toBlob(r,'image/jpeg',0.7);});
        var res=await fetch('/frame',{method:'POST',headers:{'X-Mirror':front?'1':'0'},body:blob});
        if(!res.ok){throw new Error('bad');}
        say('● Sending to the main phone');
      }
    }catch(e){
      say('Connection lost. Trying again...');
      await sleep(1000);
    }
    await sleep(25);
  }
}
document.getElementById('go').onclick=async function(){
  try{
    await openCam();
    try{if(navigator.wakeLock){navigator.wakeLock.request('screen');}}catch(e){}
    document.getElementById('go').style.display='none';
    if(!running){loop();}
  }catch(e){say(e.message||'The camera could not start.');}
};
document.getElementById('flip').onclick=async function(){
  front=!front;
  try{await openCam();}catch(e){say(e.message||'The camera could not switch.');}
};
</script></body></html>
"""
    }
}
