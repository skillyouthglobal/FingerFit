package com.fingerfit.link

import android.util.Base64
import com.fingerfit.logic.IpCams
import com.fingerfit.logic.JpegSplitter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.IOException
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLDecoder
import java.net.HttpURLConnection
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/** One camera found on the Wi-Fi. [url] is the address to open; [rtspOnly] cameras cannot be opened yet. */
data class IpFound(val host: String, val label: String, val url: String, val rtspOnly: Boolean)

data class IpUi(
    val scanning: Boolean = false,
    val scanDone: Int = 0,
    val scanTotal: Int = 0,
    val found: List<IpFound> = emptyList(),
    val scanMessage: String = "",
    val connecting: Boolean = false,
    val running: Boolean = false,
    val name: String = "",
    val error: String? = null,
)

/**
 * Finds Wi-Fi / IP cameras on the same network (no internet needed) and reads their live picture.
 * Supported now: Motion-JPEG streams and still-picture (snapshot) addresses over http/https.
 * Pictures are handed to [onJpeg] on a background thread; only the newest one is kept, so a slow
 * analysis never makes the picture lag behind.
 */
class IpCamera(private val onJpeg: (ByteArray) -> Unit) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _ui = MutableStateFlow(IpUi())
    val ui: StateFlow<IpUi> = _ui.asStateFlow()

    private var scanJob: Job? = null
    private var streamJob: Job? = null
    private var workerJob: Job? = null
    private val latest = AtomicReference<ByteArray?>(null)
    @Volatile private var currentConn: HttpURLConnection? = null

    // ---------------------------------------------------------------- scanning

    fun scan() {
        if (_ui.value.scanning) return
        scanJob = scope.launch {
            val net = localNetwork()
            if (net == null) {
                _ui.update {
                    it.copy(scanMessage = "This phone is not on a Wi-Fi network. Join the same Wi-Fi as the camera first.")
                }
                return@launch
            }
            val hosts = IpCams.subnetHosts(net.first, net.second)
            _ui.update {
                it.copy(scanning = true, scanDone = 0, scanTotal = hosts.size, found = emptyList(), scanMessage = "")
            }
            val found = CopyOnWriteArrayList<IpFound>()
            val done = AtomicInteger(0)
            val gate = Semaphore(48)
            coroutineScope {
                for (h in hosts) {
                    launch {
                        gate.withPermit {
                            val hit = probeHost(h)
                            if (hit != null) {
                                found.add(hit)
                                _ui.update { s -> s.copy(found = found.toList()) }
                            }
                            val n = done.incrementAndGet()
                            if (n % 8 == 0) _ui.update { s -> s.copy(scanDone = n) }
                        }
                    }
                }
            }
            _ui.update {
                it.copy(
                    scanning = false,
                    scanDone = hosts.size,
                    scanMessage = if (found.isEmpty()) {
                        "No camera answered. Check that the camera is on and on this Wi-Fi, or type its address below."
                    } else "",
                )
            }
        }
    }

    fun stopScan() {
        scanJob?.cancel()
        scanJob = null
        _ui.update { it.copy(scanning = false) }
    }

    /** This phone's own Wi-Fi address and network size, or null when it is not on Wi-Fi. */
    private fun localNetwork(): Pair<String, Int>? {
        try {
            val all = NetworkInterface.getNetworkInterfaces() ?: return null
            for (ni in java.util.Collections.list(all)) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name.lowercase()
                if (!(n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("eth"))) continue
                for (ia in ni.interfaceAddresses) {
                    val a = ia.address
                    if (a is Inet4Address && a.isSiteLocalAddress) {
                        val host = a.hostAddress ?: continue
                        return Pair(host, ia.networkPrefixLength.toInt())
                    }
                }
            }
        } catch (e: Exception) {
        }
        return null
    }

    /** 0 = open, 1 = closed (the device is there), 2 = no answer (nothing there). */
    private fun portState(host: String, port: Int): Int {
        val s = Socket()
        return try {
            s.connect(InetSocketAddress(host, port), 350)
            0
        } catch (e: SocketTimeoutException) {
            2
        } catch (e: IOException) {
            1
        } finally {
            try {
                s.close()
            } catch (e: Exception) {
            }
        }
    }

    private fun probeHost(host: String): IpFound? {
        val openWeb = ArrayList<Int>()
        val openRtsp = ArrayList<Int>()
        var first = true
        for (p in IpCams.webPorts + IpCams.rtspPorts) {
            val st = portState(host, p)
            if (st == 2 && first) return null // nothing at this address
            first = false
            if (st == 0) {
                if (p in IpCams.rtspPorts) openRtsp.add(p) else openWeb.add(p)
            }
        }
        for (p in openWeb) {
            val base = "http://$host:$p"
            for (path in IpCams.streamPaths + IpCams.snapshotPaths) {
                if (looksLikePicture(base + path)) return IpFound(host, "Camera at $host", base + path, false)
            }
        }
        if (openRtsp.isNotEmpty()) {
            return IpFound(host, "RTSP camera at $host", "rtsp://$host:${openRtsp[0]}/", true)
        }
        return null
    }

    private fun looksLikePicture(url: String): Boolean {
        var c: HttpURLConnection? = null
        return try {
            c = open(url, 800, 1200)
            val type = (c.contentType ?: "").lowercase()
            c.responseCode == 200 && (type.contains("image/jp") || type.contains("multipart/x-mixed-replace"))
        } catch (e: Exception) {
            false
        } finally {
            try {
                c?.disconnect()
            } catch (e: Exception) {
            }
        }
    }

    // --------------------------------------------------------------- streaming

    fun connect(url: String, label: String) {
        stop()
        if (IpCams.isRtsp(url)) {
            _ui.update {
                it.copy(error = "This camera speaks RTSP. RTSP support is coming in the next update. Cameras with a web (http) picture address work now.")
            }
            return
        }
        _ui.update { it.copy(connecting = true, running = false, error = null, name = label) }
        val worker = scope.launch {
            while (isActive) {
                val f = latest.getAndSet(null)
                if (f == null) {
                    delay(8)
                    continue
                }
                try {
                    onJpeg(f)
                } catch (e: Exception) {
                }
            }
        }
        workerJob = worker
        streamJob = scope.launch {
            var everWorked = false
            while (isActive) {
                try {
                    readOnce(url) {
                        if (!everWorked) {
                            everWorked = true
                            _ui.update { s -> s.copy(connecting = false, running = true, error = null) }
                        }
                    }
                } catch (e: CameraRefused) {
                    if (!everWorked) {
                        _ui.update { it.copy(connecting = false, running = false, error = e.message) }
                        break
                    }
                } catch (e: Exception) {
                    if (!everWorked) {
                        _ui.update {
                            it.copy(
                                connecting = false, running = false,
                                error = "Could not open the camera. Check the address, and that this phone and the camera are on the same Wi-Fi.",
                            )
                        }
                        break
                    }
                }
                if (isActive) delay(1500) // the camera blinked: try again
            }
        }
    }

    fun stop() {
        streamJob?.cancel()
        workerJob?.cancel()
        streamJob = null
        workerJob = null
        latest.set(null)
        val c = currentConn
        currentConn = null
        if (c != null) {
            // Closing the connection wakes up a read that is waiting for the camera.
            scope.launch {
                try {
                    c.disconnect()
                } catch (e: Exception) {
                }
            }
        }
        _ui.update { it.copy(connecting = false, running = false, error = null) }
    }

    fun release() {
        scope.cancel()
    }

    private class CameraRefused(message: String) : IOException(message)

    private fun readOnce(url: String, onFirstFrame: () -> Unit) {
        var conn = open(url, 4000, 6000)
        currentConn = conn
        try {
            val code = conn.responseCode
            if (code == 401) throw CameraRefused("The camera asks for a username and password. Type it in the address like http://user:password@192.168.0.5/video")
            if (code != 200) throw CameraRefused("The camera answered with error $code. Check the picture address.")
            val type = (conn.contentType ?: "").lowercase()
            if (type.contains("multipart")) {
                val ins = conn.inputStream
                val splitter = JpegSplitter()
                val buf = ByteArray(16384)
                while (streamJob?.isActive == true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    for (f in splitter.feed(buf, n)) {
                        latest.set(f)
                        onFirstFrame()
                    }
                }
            } else if (type.contains("image")) {
                while (streamJob?.isActive == true) {
                    val bytes = conn.inputStream.use { it.readBytes() }
                    if (bytes.size > 1000) {
                        latest.set(bytes)
                        onFirstFrame()
                    }
                    conn.disconnect()
                    Thread.sleep(80)
                    conn = open(url, 4000, 6000)
                    currentConn = conn
                    if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
                }
            } else {
                throw CameraRefused("This address does not give a picture. Try another picture address of the camera.")
            }
        } finally {
            try {
                conn.disconnect()
            } catch (e: Exception) {
            }
        }
    }

    /** Opens the address. A user name and password written in it (http://user:pass@host/...) are sent as Basic login. */
    private fun open(url: String, connectMs: Int, readMs: Int): HttpURLConnection {
        val u = URL(url)
        val clean = URL(u.protocol, u.host, u.port, u.file)
        val c = clean.openConnection() as HttpURLConnection
        c.connectTimeout = connectMs
        c.readTimeout = readMs
        c.instanceFollowRedirects = false
        val info = u.userInfo
        if (info != null) {
            val decoded = URLDecoder.decode(info.replace("+", "%2B"), "UTF-8")
            c.setRequestProperty("Authorization", "Basic " + Base64.encodeToString(decoded.toByteArray(), Base64.NO_WRAP))
        }
        return c
    }
}
