package com.fingerfit.link

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.fingerfit.Notify
import com.fingerfit.R

/**
 * Keeps the two-phone link alive while the app is in the background, so the phones stay
 * connected until the user taps Disconnect. It only shows a quiet notification.
 */
class LinkService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            Notify.ensureChannels(this)
            val notification = NotificationCompat.Builder(this, Notify.CH_WALK)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Kinetro two-phone link")
                .setContentText("Phones are connected. Open Kinetro to disconnect.")
                .setContentIntent(Notify.openAppIntent(this))
                .setOngoing(true)
                .build()
            ServiceCompat.startForeground(this, 202, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }
}
