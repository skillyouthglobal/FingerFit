package com.fingerfit

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fingerfit.update.UpdateInfo
import com.fingerfit.update.Updater
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class UpdateUi(
    val checking: Boolean = false,
    val available: UpdateInfo? = null,
    val progress: Int = -1,
    val downloaded: File? = null,
    val message: String = "",
)

class UpdateViewModel(private val app: Application) : AndroidViewModel(app) {
    private val _ui = MutableStateFlow(UpdateUi())
    val ui: StateFlow<UpdateUi> = _ui.asStateFlow()
    private var checkedOnce = false

    /** Quiet check at app start: nothing is shown unless a newer version exists. */
    fun checkOnStart() {
        if (checkedOnce) return
        checkedOnce = true
        check(manual = false)
    }

    fun check(manual: Boolean) {
        if (_ui.value.checking || _ui.value.progress >= 0) return
        _ui.update { it.copy(checking = true, message = if (manual) "Checking…" else "") }
        viewModelScope.launch {
            val info = Updater.check(app)
            _ui.update {
                it.copy(
                    checking = false, available = info, downloaded = null,
                    message = when {
                        info != null -> "A new version is ready."
                        manual -> "You have the latest version, or there is no internet right now."
                        else -> ""
                    },
                )
            }
        }
    }

    fun download() {
        val info = _ui.value.available ?: return
        if (_ui.value.progress >= 0) return
        _ui.update { it.copy(progress = 0, message = "Downloading…") }
        viewModelScope.launch {
            val f = Updater.download(app, info) { p -> _ui.update { it.copy(progress = p) } }
            _ui.update {
                if (f != null) it.copy(progress = -1, downloaded = f, message = "Download finished.")
                else it.copy(progress = -1, message = "Download failed. Check your internet and try again.")
            }
        }
    }

    fun note(text: String) = _ui.update { it.copy(message = text) }
}
