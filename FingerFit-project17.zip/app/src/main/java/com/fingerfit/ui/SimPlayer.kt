package com.fingerfit.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fingerfit.logic.PCol
import com.fingerfit.logic.Prim
import com.fingerfit.logic.SimDraw
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import com.fingerfit.logic.SimMath
import com.fingerfit.logic.SimPt
import com.fingerfit.logic.SimView
import com.fingerfit.logic.Sims
import com.fingerfit.logic.ExerciseType
import kotlin.math.max
import kotlin.math.min

private val MatColor = Color(0xFF3FAE91)

private fun roleColor(c: PCol, far: Boolean): Color {
    val base = when (c) {
        PCol.SKIN -> Color(0xFFD9A47A); PCol.SHIRT -> Color(0xFF2FB89A); PCol.SHORTS -> Color(0xFF2D3E6B)
        PCol.SHOE -> Color(0xFFFF8A4C); PCol.HAIR -> Color(0xFF2B2B33); PCol.EYE -> Color(0xFF222222)
        PCol.GLOW -> Color(0xFFFF6A2B); PCol.GHOST -> Color(0xFF7A88B8)
    }
    return if (far) Color(base.red * 0.78f, base.green * 0.78f, base.blue * 0.78f) else base
}

private fun DrawScope.drawPrims(prims: List<Prim>, ox: Float, gy: Float, sc: Float) {
    fun px(x: Float) = ox + x * sc
    fun py(y: Float) = gy - y * sc
    for (p in prims) {
        val col = roleColor(p.col, p.far)
        when (p.kind) {
            1 -> drawCircle(col, p.ra * sc, Offset(px(p.pts[0]), py(p.pts[1])))
            2 -> {
                val path = Path()
                var i = 0
                while (i < p.pts.size) {
                    if (i == 0) path.moveTo(px(p.pts[0]), py(p.pts[1])) else path.lineTo(px(p.pts[i]), py(p.pts[i + 1]))
                    i += 2
                }
                path.close()
                drawPath(path, col)
            }
            else -> {
                val ax = p.pts[0]; val ay = p.pts[1]; val bx = p.pts[2]; val by = p.pts[3]
                var dx = bx - ax; var dy = by - ay
                val l = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1e-5f); dx /= l; dy /= l
                val nx = -dy; val ny = dx
                val path = Path()
                path.moveTo(px(ax + nx * p.ra), py(ay + ny * p.ra))
                path.lineTo(px(bx + nx * p.rb), py(by + ny * p.rb))
                path.lineTo(px(bx - nx * p.rb), py(by - ny * p.rb))
                path.lineTo(px(ax - nx * p.ra), py(ay - ny * p.ra))
                path.close()
                drawPath(path, col)
                drawCircle(col, p.ra * sc, Offset(px(ax), py(ay)))
                drawCircle(col, p.rb * sc, Offset(px(bx), py(by)))
            }
        }
    }
}

/** Draw [prims] as one flat layer so overlapping shapes do not double up when see-through. */
private fun DrawScope.drawLayer(prims: List<Prim>, layerAlpha: Float, ox: Float, gy: Float, sc: Float) {
    if (prims.isEmpty()) return
    drawIntoCanvas { canvas ->
        val paint = Paint()
        paint.alpha = layerAlpha
        canvas.saveLayer(Rect(0f, 0f, size.width, size.height), paint)
        drawPrims(prims, ox, gy, sc)
        canvas.restore()
    }
}

/**
 * A looping demo of the exercise, drawn as a moving figure, with the written step that matches
 * what the figure is doing highlighted underneath. Works for every exercise from SimSpec data.
 */
@Composable
fun SimPlayer(type: ExerciseType, steps: List<String>, modifier: Modifier = Modifier) {
    val spec = remember(type) { Sims.of(type) }
    val bounds = remember(type) { SimMath.bounds(spec) }
    var playing by remember { mutableStateOf(true) }
    var slow by remember { mutableStateOf(false) }
    var clock by remember(type) { mutableStateOf(0f) }

    LaunchedEffect(playing, slow, type) {
        if (!playing) return@LaunchedEffect
        var last = androidx.compose.runtime.withFrameNanos { it }
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            clock += (now - last) / 1_000_000f * (if (slow) 0.5f else 1f)
            last = now
        }
    }

    val frame = SimMath.frameAt(spec, clock.toLong())
    val fig = SimMath.figure(frame.pose, spec.view)
    val step = frame.step.coerceIn(0, max(0, steps.size - 1))

    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            Modifier.fillMaxWidth().height(290.dp)
                .background(HeroTint, RoundedCornerShape(24.dp)),
        ) {
            Canvas(Modifier.fillMaxWidth().height(290.dp)) {
                val padX = 18.dp.toPx(); val floorPad = 30.dp.toPx(); val topPad = 14.dp.toPx()
                val wUnits = bounds[1] - bounds[0]
                val sc = min((size.width - 2 * padX) / wUnits, (size.height - floorPad - topPad) / bounds[2])
                val ox = size.width / 2f - (bounds[0] + bounds[1]) / 2f * sc
                val gy = size.height - floorPad
                
                if (spec.mat) {
                    drawRoundRect(MatColor, Offset(padX * 0.5f, gy - 2.dp.toPx()), Size(size.width - padX, 11.dp.toPx()), CornerRadius(6.dp.toPx()))
                } else {
                    drawLine(Color(0x33000000), Offset(padX * 0.5f, gy), Offset(size.width - padX * 0.5f, gy), 3.dp.toPx(), StrokeCap.Round)
                    // soft shadow that shrinks when the person jumps
                    val lift = (fig.ankleNear.y.coerceAtLeast(0f) * sc / 40.dp.toPx()).coerceIn(0f, 1f)
                    drawOval(Color(0x22000000), Offset(size.width / 2f - 46.dp.toPx() * (1 - 0.3f * lift), gy + 2.dp.toPx()), Size(92.dp.toPx() * (1 - 0.3f * lift), 7.dp.toPx()))
                }
                spec.ghost?.let {
                    drawLayer(SimDraw.build(SimMath.figure(it, spec.view), spec, true, false), 0.17f, ox, gy, sc)
                }
                val all = SimDraw.build(fig, spec, false, true)
                drawPrims(all.filter { it.col != PCol.GLOW }, ox, gy, sc)
                val pulse = 0.38f + 0.10f * kotlin.math.sin(clock / 450f)
                drawLayer(all.filter { it.col == PCol.GLOW }, pulse, ox, gy, sc)
            }
        }

        // the written step that matches the picture
        Column(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (i in steps.indices) {
                    Box(
                        Modifier.size(if (i == step) 12.dp else 8.dp)
                            .background(if (i == step) MaterialTheme.colorScheme.tertiary else Color(0x33000000), CircleShape),
                    )
                }
                androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
                Text("Rep ${frame.cycle + 1}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("Step ${step + 1} of ${steps.size}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
            Text(if (steps.isEmpty()) "" else steps[step], fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            FilledTonalButton(onClick = { playing = !playing }) { Text(if (playing) "⏸ Pause" else "▶ Play") }
            FilterChip(selected = slow, onClick = { slow = !slow }, label = { Text("Slow") })
            FilterChip(selected = false, onClick = { clock = 0f; playing = true }, label = { Text("Restart") })
        }
        Text(
            (if (spec.view == SimView.SIDE) "Side view" else "Front view") + "  ·  Orange shows the muscles that work.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (spec.ghost != null) {
            Text("The faint figure shows the position to reach.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
