package com.fingerfit.ui

import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

private fun strokeIcon(name: String, vararg paths: String): ImageVector {
    val b = ImageVector.Builder(
        name = name, defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f,
    )
    paths.forEach { d ->
        b.addPath(
            pathData = PathParser().parsePathString(d).toNodes(),
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round,
        )
    }
    return b.build()
}

private val HomeIcon = strokeIcon("home", "M3 11l9-8 9 8M5 10v10h14V10")
private val WorkoutIcon = strokeIcon("workouts", "M6.5 6.5v11M17.5 6.5v11M3 9v6M21 9v6M6.5 12h11")
private val PlanIcon = strokeIcon(
    "plan",
    "M7 4h10a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3z",
    "M8 12l3 3 5-6",
)
private val ProfileIcon = strokeIcon(
    "profile",
    "M12 4a4 4 0 1 0 0 8a4 4 0 0 0 0-8z",
    "M4 21c0-4 4-6 8-6s8 2 8 6",
)

object Tabs {
    const val HOME = 0
    const val WORKOUTS = 1
    const val PLAN = 2
    const val PROFILE = 3
}

private class TabItem(val label: String, val icon: ImageVector)

private val ITEMS = listOf(
    TabItem("Home", HomeIcon),
    TabItem("Workouts", WorkoutIcon),
    TabItem("My plan", PlanIcon),
    TabItem("Profile", ProfileIcon),
)

/** The bottom bar with the four main sections. */
@Composable
fun KinetroNavBar(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        ITEMS.forEachIndexed { i, item ->
            NavigationBarItem(
                selected = selected == i,
                onClick = { onSelect(i) },
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.tertiary,
                    selectedTextColor = MaterialTheme.colorScheme.tertiary,
                    indicatorColor = HeroTint,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                ),
            )
        }
    }
}
