package com.fingerfit.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.UpdateViewModel
import com.fingerfit.update.Updater

/**
 * Shows "update available" with one-tap download and install.
 * [always] = true (Settings) also shows a "Check for updates" button when nothing is new.
 */
@Composable
fun UpdateCard(vm: UpdateViewModel, always: Boolean, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    if (!always && ui.available == null) return

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val info = ui.available
            if (info != null) {
                Text("🆕 New version available (${info.name})", fontWeight = FontWeight.Bold)
                if (ui.progress >= 0) {
                    LinearProgressIndicator(progress = { ui.progress / 100f }, modifier = Modifier.fillMaxWidth())
                    Text("Downloading… ${ui.progress}%", fontSize = 13.sp)
                } else if (ui.downloaded != null) {
                    Button(
                        onClick = {
                            val ok = Updater.install(context, ui.downloaded!!)
                            if (!ok) vm.note("Allow Kinetro to install apps, then press Install again.")
                        },
                        shape = RoundedCornerShape(16.dp),
                    ) { Text("Install now") }
                } else {
                    Button(onClick = vm::download, shape = RoundedCornerShape(16.dp)) { Text("Download update") }
                }
                Text(
                    "Your data stays on your phone. Android will ask you to confirm the install.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                Text("App updates", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { vm.check(manual = true) }, enabled = !ui.checking, shape = RoundedCornerShape(16.dp)) {
                        Text("Check for updates")
                    }
                }
            }
            if (ui.message.isNotEmpty()) {
                Text(ui.message, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}


/** Pops up on any main screen as soon as a newer version exists (needs internet only to check). */
@Composable
fun UpdatePrompt(vm: UpdateViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var dismissed by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf(false) }
    val info = ui.available
    val file = ui.downloaded
    androidx.compose.runtime.LaunchedEffect(file, dismissed) {
        if (file != null && !dismissed && !Updater.install(context, file)) {
            vm.note("Allow Kinetro to install apps, then press Install again.")
        }
    }
    if (info == null || dismissed) return
    androidx.compose.material3.AlertDialog(
        onDismissRequest = { if (ui.progress < 0) dismissed = true },
        title = { Text("New version available", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Kinetro ${info.name} is ready. Your data stays on your phone.")
                if (ui.progress >= 0) {
                    LinearProgressIndicator(progress = { ui.progress / 100f }, modifier = Modifier.fillMaxWidth())
                    Text("Downloading… ${ui.progress}%", fontSize = 13.sp)
                } else {
                    Text(
                        "Android will ask you to confirm the install.",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (ui.message.isNotEmpty() && ui.progress < 0) {
                    Text(ui.message, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        confirmButton = {
            if (ui.progress < 0) {
                Button(
                    onClick = {
                        val f = ui.downloaded
                        if (f != null) {
                            if (!Updater.install(context, f)) vm.note("Allow Kinetro to install apps, then press Install again.")
                        } else vm.download()
                    },
                    shape = RoundedCornerShape(16.dp),
                ) { Text(if (ui.downloaded != null) "Install" else "Update now") }
            }
        },
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = { dismissed = true }) { Text("Later") }
        },
    )
}
