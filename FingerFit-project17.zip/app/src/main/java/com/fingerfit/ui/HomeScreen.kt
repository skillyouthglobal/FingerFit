package com.fingerfit.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.data.Repo
import com.fingerfit.data.Session
import com.fingerfit.data.localDate
import com.fingerfit.data.todayReps
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

internal val PRESETS = listOf(10, 20, 50)

@Composable
fun HomeScreen(
    vm: AppViewModel,
    onStart: () -> Unit,
    onSettings: () -> Unit,
    onBody: () -> Unit,
    onWalk: () -> Unit,
    onSleep: () -> Unit,
    onInbox: () -> Unit,
    onLink: () -> Unit,
    linkStatus: String? = null,
    profile: com.fingerfit.data.Profile? = null,
    onProfile: () -> Unit = {},
    updateVm: com.fingerfit.UpdateViewModel? = null,
) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val workouts by Repo.workouts.collectAsStateWithLifecycle()
    val walks by Repo.walks.collectAsStateWithLifecycle()
    val sleeps by Repo.sleeps.collectAsStateWithLifecycle()
    val inbox by Repo.inbox.collectAsStateWithLifecycle()
    val unread = inbox.count { !it.read }
    val bodyReps = remember(workouts) { Repo.todayBodyReps() }
    val walkMin = remember(walks) { Repo.todayWalkSeconds() / 60 }
    val lastSleep = sleeps.firstOrNull { it.date == LocalDate.now().toString() }

    val today = history.todayReps()
    val target = settings.target
    val progress = (today.toFloat() / target).coerceIn(0f, 1f)

    val hour = java.time.LocalTime.now().hour
    val greeting = when {
        hour < 12 -> "Good morning"
        hour < 17 -> "Good afternoon"
        else -> "Good evening"
    }
    val ringProgress = progress

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.systemBarsPadding()) {
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 22.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FingerFitLogo(46.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(greeting, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            profile?.name ?: "Kinetro", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground, maxLines = 1,
                        )
                    }
                    Box(contentAlignment = Alignment.TopEnd) {
                        IconButton(onClick = onInbox) { Text("🔔", fontSize = 22.sp) }
                        if (unread > 0) {
                            Text(
                                "$unread", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 4.dp, end = 4.dp).clip(CircleShape)
                                    .background(Color(0xFFDC2626)).padding(horizontal = 5.dp, vertical = 1.dp),
                            )
                        }
                    }
                    IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, contentDescription = "Settings") }
                }
            }

            if (updateVm != null) {
                item { UpdateCard(updateVm, always = false) }
            }

            item {
                Card(
                    shape = RoundedCornerShape(26.dp),
                    colors = CardDefaults.cardColors(containerColor = HeroTint),
                ) {
                    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
                            val track = Color.White
                            val bar = MaterialTheme.colorScheme.primary
                            androidx.compose.foundation.Canvas(Modifier.size(96.dp)) {
                                val stroke = androidx.compose.ui.graphics.drawscope.Stroke(
                                    width = 12.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round,
                                )
                                val inset = 6.dp.toPx()
                                val arcSize = androidx.compose.ui.geometry.Size(size.width - inset * 2, size.height - inset * 2)
                                val topLeft = androidx.compose.ui.geometry.Offset(inset, inset)
                                drawArc(track, 0f, 360f, false, topLeft, arcSize, style = stroke)
                                if (ringProgress > 0f) drawArc(bar, -90f, 360f * ringProgress, false, topLeft, arcSize, style = stroke)
                            }
                            Text("${(ringProgress * 100).toInt()}%", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Spacer(Modifier.width(18.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("Today", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Finger: $today of $target reps", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Body: $bodyReps reps", fontSize = 14.sp)
                            Text("Walk: $walkMin of ${settings.walkGoalMin} min", fontSize = 14.sp)
                        }
                    }
                }
            }

            if (profile != null) {
                item { ProfileSummaryCard(profile, onProfile) }
            }

            item { Text("Start training", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        TrainTile(
                            "🏋️", "Body workouts",
                            if (bodyReps > 0) "Today: $bodyReps reps" else "8 exercises", onBody, HeroTint,
                            Modifier.weight(1f),
                        )
                        TrainTile("🚶", "Walking", "$walkMin of ${settings.walkGoalMin} min", onWalk, Color(0xFFE3ECFF), Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        TrainTile(
                            "😴", "Sleep",
                            lastSleep?.let { "${it.minutes / 60}h ${it.minutes % 60}m last night" } ?: "Tap to add",
                            onSleep, Color(0xFFEDE7FF), Modifier.weight(1f),
                        )
                        TrainTile(
                            "📷", "Cameras", linkStatus ?: "Wi-Fi camera or 2nd phone", onLink,
                            Color(0xFFFFF4E0), Modifier.weight(1f),
                        )
                    }
                }
            }

        }
    }
}

@Composable
internal fun SessionRow(s: Session) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(dayLabel(s), fontWeight = FontWeight.SemiBold)
                Text(
                    "${formatDuration(s.durationSec * 1000L)}  ·  target ${s.target}",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (s.targetReached) {
                Icon(Icons.Default.Check, contentDescription = "Target reached", tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
            }
            Text("${s.reps} reps", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
internal fun CustomTargetDialog(current: Int, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    var text by remember { mutableStateOf(current.toString()) }
    val value = text.toIntOrNull()
    val valid = value != null && value in 1..1000
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom target") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter(Char::isDigit).take(4) },
                label = { Text("Repetitions (1-1000)") },
                singleLine = true,
                isError = !valid,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(value!!) }, enabled = valid) { Text("Set target") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

fun formatDuration(ms: Long): String {
    val total = (ms / 1000).toInt()
    return "%d:%02d".format(Locale.US, total / 60, total % 60)
}

private fun dayLabel(s: Session): String {
    val today = LocalDate.now()
    val d = s.localDate()
    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(s.timestamp))
    return when (d) {
        today -> "Today, $time"
        today.minusDays(1) -> "Yesterday, $time"
        else -> SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(s.timestamp))
    }
}

@Composable
private fun TrainTile(
    emoji: String, title: String, subtitle: String, onClick: () -> Unit, tint: Color, modifier: Modifier = Modifier,
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.clickable(onClick = onClick),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(44.dp).background(tint, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Text(emoji, fontSize = 24.sp)
            }
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(
                subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2, minLines = 2,
            )
        }
    }
}
