package com.fingerfit.ui

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.Image
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.fingerfit.R
import com.fingerfit.data.ThemeMode

val Mint = Color(0xFF2EE6B0)
val Violet = Color(0xFF2F6BFF)
val Amber = Color(0xFFFFB547)

private val DarkColors = darkColorScheme(
    primary = Mint,
    onPrimary = Color(0xFF04122A),
    secondary = Color(0xFF40DC71),
    tertiary = Mint,
    background = Color(0xFF0A1330),
    onBackground = Color(0xFFEDEFFF),
    surface = Color(0xFF121C42),
    onSurface = Color(0xFFEDEFFF),
    surfaceVariant = Color(0xFF1C2A5C),
    onSurfaceVariant = Color(0xFFA9B8E0),
    error = Color(0xFFFF6B7A),
)

private val LightColors = lightColorScheme(
    primary = Mint,
    onPrimary = Color(0xFF04122A),
    secondary = Violet,
    tertiary = Color(0xFF0B8A6C),
    background = Color(0xFFF4F7FC),
    onBackground = Color(0xFF12203F),
    surface = Color.White,
    onSurface = Color(0xFF12203F),
    surfaceVariant = Color(0xFFE3F5EF),
    onSurfaceVariant = Color(0xFF5B6B8C),
    error = Color(0xFFD8334A),
)

/** Soft mint tint used for hero cards. */
val HeroTint = Color(0xFFDDF5EE)

@Composable
fun FingerFitTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        WindowCompat.getInsetsController(window, view).apply {
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}

/** The Kinetro symbol (official logo mark). */
@Composable
fun FingerFitLogo(size: Dp = 56.dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.kinetro_symbol),
        contentDescription = "Kinetro",
        contentScale = ContentScale.Fit,
        modifier = modifier.size(size),
    )
}
