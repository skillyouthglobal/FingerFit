package com.fingerfit.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fingerfit.data.AppPrefs

private const val T_EN = "Terms of use"
private const val P_EN = "Privacy policy"
private const val TERMS_BODY = "Kinetro gives general fitness and healthy-living suggestions based on World Health Organization (WHO) guidance. It is NOT medical advice and does not diagnose, treat or prevent any disease.\n\nBefore you start any exercise or change your diet, please ask a doctor if you have a health condition, are pregnant, are recovering from illness or injury, or feel unsure. Stop at once if you feel pain, dizziness or shortness of breath.\n\nExercise at your own risk, on a safe, clear and non-slippery floor. Children and teenagers should exercise with an adult's supervision.\n\nCalorie and exercise numbers are estimates and can be wrong for some people. Camera counting may sometimes miss or add a repetition."
private const val PRIVACY_BODY = "Kinetro works offline. Your profile, workouts, sleep and walks are stored only on your phone. There is no account and no cloud sync.\n\nThe camera is used only to see your body or hand and count repetitions. Video is analysed live on your phone and is never recorded, saved or uploaded.\n\nLocation is used only while you track a walk or search for Wi-Fi cameras on your network. Bluetooth and nearby-device access is used only to connect a second phone as a camera.\n\nThe app contacts the internet only to check for a new version of Kinetro. We do not sell or share your data. You can delete your history any time from Settings."

@Composable
private fun TermsBody() {
    Text(T_EN, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    Text(TERMS_BODY, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(8.dp))
    Text(P_EN, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    Text(PRIVACY_BODY, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** Terms + privacy policy, opened from Settings. */
@Composable
fun TermsScreen(onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize().systemBarsPadding()) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            TermsBody()
            Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Close") }
        }
    }
}

/** First launch only: language -> terms -> permissions. */
@Composable
fun FirstRunScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var step by rememberSaveable { mutableStateOf(if (AppPrefs.lang(ctx).isEmpty()) 0 else if (!AppPrefs.termsAccepted(ctx)) 1 else 2) }
    var agree by rememberSaveable { mutableStateOf(false) }

    val perms = buildList {
        add(Manifest.permission.CAMERA)
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) {
            add(Manifest.permission.POST_NOTIFICATIONS)
            add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            add(Manifest.permission.BLUETOOTH_CONNECT)
            add(Manifest.permission.BLUETOOTH_SCAN)
            add(Manifest.permission.BLUETOOTH_ADVERTISE)
        }
    }.toTypedArray()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        AppPrefs.setPermsAsked(ctx); onDone()
    }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize().systemBarsPadding()) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (step) {
                0 -> {
                    Spacer(Modifier.height(24.dp))
                    FingerFitLogo(size = 72.dp)
                    androidx.compose.material3.Text("Welcome to Kinetro  ·  Kinetro-তে স্বাগতম", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    androidx.compose.material3.Text("Choose your language  ·  আপনার ভাষা বেছে নিন", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = { LangState.set(ctx, "bn"); step = 1 }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                        androidx.compose.material3.Text("বাংলা", fontSize = 18.sp)
                    }
                    OutlinedButton(onClick = { LangState.set(ctx, "en"); step = 1 }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                        androidx.compose.material3.Text("English", fontSize = 18.sp)
                    }
                    Text("You can change it any time in Settings.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
                1 -> {
                    Text("Please read and accept to continue.", fontWeight = FontWeight.SemiBold)
                    TermsBody()
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = agree, onCheckedChange = { agree = it })
                        Text("I have read and I agree", modifier = Modifier.weight(1f))
                    }
                    Button(onClick = { AppPrefs.setTermsAccepted(ctx); step = 2 }, enabled = agree, modifier = Modifier.fillMaxWidth()) {
                        Text("Continue")
                    }
                }
                else -> {
                    Spacer(Modifier.height(16.dp))
                    Text("Allow these so everything works smoothly", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Camera: to see your body and count exercises. Video is never recorded or uploaded.")
                    Text("Notifications: daily reminders and progress.")
                    Text("Location: to track outdoor walks and to find Wi-Fi cameras nearby.")
                    Text("Nearby devices and Bluetooth: to connect a second phone as a camera.")
                    Button(onClick = { launcher.launch(perms) }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Allow and start") }
                    TextButton(onClick = { AppPrefs.setPermsAsked(ctx); onDone() }, modifier = Modifier.fillMaxWidth()) { Text("Skip for now") }
                }
            }
        }
    }
}
