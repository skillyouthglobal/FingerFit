package com.fingerfit.ui

import android.Manifest
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.data.Repo
import com.fingerfit.data.SleepRecord
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private fun clock(min: Int): String =
    LocalTime.of(min / 60, min % 60).format(DateTimeFormatter.ofPattern("hh:mm a", Locale.US))

private fun hm(min: Int) = "${min / 60}h ${min % 60}m"

private fun quality(min: Int) = when {
    min < 360 -> "Short"
    min < 420 -> "Okay"
    min <= 540 -> "Good"
    else -> "Long"
}

@Composable
fun SleepScreen(app: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val settings by app.settings.collectAsStateWithLifecycle()
    val sleeps by Repo.sleeps.collectAsStateWithLifecycle()
    BackHandler(onBack = onBack)

    val today = LocalDate.now().toString()
    val existing = sleeps.firstOrNull { it.date == today }
    var bed by remember(existing) { mutableIntStateOf(existing?.bedMin ?: (23 * 60)) }
    var wake by remember(existing) { mutableIntStateOf(existing?.wakeMin ?: (7 * 60)) }
    var saved by remember { mutableStateOf(false) }

    val minutes = ((wake - bed) + 1440) % 1440

    fun pick(initial: Int, onPicked: (Int) -> Unit) {
        TimePickerDialog(context, { _, h, m -> onPicked(h * 60 + m); saved = false }, initial / 60, initial % 60, false).show()
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val week = sleeps.filter { it.date >= LocalDate.now().minusDays(6).toString() }
    val avg = if (week.isEmpty()) 0 else week.sumOf { it.minutes } / week.size

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.systemBarsPadding()) {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                    Text("😴 Sleep", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                ) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Last night's sleep", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = { pick(bed) { bed = it } }, modifier = Modifier.weight(1f)) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Bedtime", fontSize = 12.sp)
                                    Text(clock(bed), fontWeight = FontWeight.Bold)
                                }
                            }
                            OutlinedButton(onClick = { pick(wake) { wake = it } }, modifier = Modifier.weight(1f)) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Wake-up", fontSize = 12.sp)
                                    Text(clock(wake), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Text(
                            "${hm(minutes)}  ·  ${quality(minutes)}",
                            fontSize = 28.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.tertiary,
                        )
                        Button(
                            onClick = {
                                Repo.saveSleep(SleepRecord(today, bed, wake, minutes))
                                if (minutes < 360) {
                                    Repo.addInbox("Short sleep", "You slept only ${hm(minutes)}. Try to get 7 to 9 hours tonight.")
                                }
                                saved = true
                            },
                            enabled = minutes > 0,
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(16.dp),
                        ) { Text(if (existing != null) "Update today's sleep" else "Save sleep", fontWeight = FontWeight.Bold) }
                        if (saved) Text("Saved.", color = MaterialTheme.colorScheme.tertiary)
                    }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Daily reminder", fontWeight = FontWeight.Bold)
                                Text(
                                    "A notification asks you to log your sleep if you have not yet.",
                                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Switch(
                                checked = settings.sleepReminder,
                                onCheckedChange = {
                                    if (it) requestNotifications()
                                    app.setSleepReminder(it)
                                },
                            )
                        }
                        if (settings.sleepReminder) {
                            OutlinedButton(onClick = {
                                pick(settings.sleepHour * 60 + settings.sleepMinute) { m ->
                                    app.setSleepReminder(true, m / 60, m % 60)
                                }
                            }) { Text("Remind me at ${clock(settings.sleepHour * 60 + settings.sleepMinute)}") }
                        }
                    }
                }
            }

            item {
                Text(
                    if (week.isEmpty()) "Sleep history" else "Sleep history  ·  7-day average ${hm(avg)}",
                    fontSize = 18.sp, fontWeight = FontWeight.Bold,
                )
            }
            if (sleeps.isEmpty()) {
                item {
                    Text(
                        "No sleep logged yet. Add your bedtime and wake-up time above.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                items(sleeps.take(14)) { s ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    ) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(s.date, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "${clock(s.bedMin)} → ${clock(s.wakeMin)}",
                                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(hm(s.minutes), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text(quality(s.minutes), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }
    }
}
