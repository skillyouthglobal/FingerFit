package com.fingerfit.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fingerfit.logic.ExerciseType
import com.fingerfit.logic.Guides
import com.fingerfit.logic.Plans
import com.fingerfit.logic.Dosing
import com.fingerfit.data.ProfileRepo
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.graphics.Color

/** What the exercise is, how to do it, its benefits and where to put the camera. */
@Composable
fun GuideScreen(type: ExerciseType, onStart: () -> Unit, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val g = Guides.of(type)
    val profile by ProfileRepo.profile.collectAsStateWithLifecycle()

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.systemBarsPadding()) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp)) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                Text(type.emoji, fontSize = 22.sp)
            }
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Card(
                    shape = RoundedCornerShape(26.dp),
                    colors = CardDefaults.cardColors(containerColor = HeroTint),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            Plans.groupOf(type).chip.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp, color = MaterialTheme.colorScheme.tertiary,
                        )
                        Text(type.title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                        Text(type.benefit, fontSize = 14.sp, color = Color(0xFF3F4F70))
                    }
                }

                GuideCard("Watch how to do it") {
                    SimPlayer(type, g.steps)
                }
                profile?.let { pr ->
                    val age = pr.age()
                    val dose = Dosing.forType(type, age, Plans.isLowImpact(age, pr.bmi()))
                    GuideCard("Recommended for you") {
                        Text("${dose.sets} sets × ${dose.perSet} ${dose.unit}", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Rest ${dose.restSec} sec between sets", fontSize = 14.sp)
                        dose.extra?.let { Text(it, fontSize = 14.sp) }
                        Text(dose.band.who, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                GuideCard("How to do it") {
                    g.steps.forEachIndexed { i, s -> Text("${i + 1}. $s", fontSize = 14.sp) }
                }
                GuideCard("Benefits") {
                    g.benefits.forEach { Text("•  $it", fontSize = 14.sp) }
                }
                GuideCard("📱 Where to put the phone") {
                    Text(g.camera, fontSize = 14.sp)
                    Text(
                        "Tip: you can use a second phone as the camera (Two-Phone Mode) and watch the counter on this one.",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                GuideCard("How Kinetro counts") { Text(g.counting, fontSize = 14.sp) }
                GuideCard("⚠️ Stay safe") { Text(g.safety, fontSize = 14.sp) }
                Spacer(Modifier.height(4.dp))
            }
            Button(
                onClick = onStart,
                modifier = Modifier.fillMaxWidth().padding(16.dp).height(56.dp),
                shape = RoundedCornerShape(18.dp),
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.padding(start = 8.dp))
                Text("Start workout", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun GuideCard(title: String, content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.tertiary)
            content()
        }
    }
}
