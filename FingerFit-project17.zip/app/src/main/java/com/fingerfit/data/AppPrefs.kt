package com.fingerfit.data

import android.content.Context
import com.fingerfit.logic.Bn

/** Small first-run settings kept in plain SharedPreferences (read instantly at start). */
object AppPrefs {
    private fun sp(c: Context) = c.getSharedPreferences("kinetro_app", Context.MODE_PRIVATE)

    /** "" = not chosen yet, otherwise "bn" or "en". */
    fun lang(c: Context): String = sp(c).getString("lang", "") ?: ""
    fun setLang(c: Context, v: String) { sp(c).edit().putString("lang", v).apply(); Bn.bn = v == "bn" }

    fun termsAccepted(c: Context): Boolean = sp(c).getBoolean("terms_v1", false)
    fun setTermsAccepted(c: Context) { sp(c).edit().putBoolean("terms_v1", true).apply() }

    fun permsAsked(c: Context): Boolean = sp(c).getBoolean("perms_asked", false)
    fun setPermsAsked(c: Context) { sp(c).edit().putBoolean("perms_asked", true).apply() }

    /** Call once at start so non-UI code (notifications) also knows the language. */
    fun apply(c: Context) { Bn.bn = lang(c) == "bn" }
}
