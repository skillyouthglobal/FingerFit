package com.fingerfit.data

import android.content.Context
import android.content.SharedPreferences
import com.fingerfit.logic.Gender
import com.fingerfit.logic.Goal
import com.fingerfit.logic.Health
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate

data class Profile(
    val name: String,
    val birth: LocalDate,
    val gender: Gender,
    val heightCm: Float,
    val weightKg: Float,
    val goal: Goal,
) {
    fun age(today: LocalDate = LocalDate.now()): Int = Health.age(birth, today)
    fun bmi(): Float = Health.bmi(weightKg, heightCm)
}

/** The user's profile. Stored only on this phone. */
object ProfileRepo {
    private var prefs: SharedPreferences? = null
    private val _profile = MutableStateFlow<Profile?>(null)
    val profile: StateFlow<Profile?> = _profile.asStateFlow()

    @Synchronized
    fun init(context: Context) {
        if (prefs == null) {
            val p = context.applicationContext.getSharedPreferences("kinetro_profile", Context.MODE_PRIVATE)
            prefs = p
            _profile.value = load(p)
        }
    }

    private fun load(p: SharedPreferences): Profile? = try {
        val name = p.getString("name", null)
        val birth = p.getString("birth", null)
        if (name.isNullOrBlank() || birth == null) {
            null
        } else {
            Profile(
                name = name,
                birth = LocalDate.parse(birth),
                gender = Gender.valueOf(p.getString("gender", Gender.OTHER.name) ?: Gender.OTHER.name),
                heightCm = p.getFloat("height", 0f),
                weightKg = p.getFloat("weight", 0f),
                goal = Goal.valueOf(p.getString("goal", Goal.MAINTAIN.name) ?: Goal.MAINTAIN.name),
            )
        }
    } catch (e: Exception) {
        null
    }

    fun save(p: Profile) {
        prefs?.edit()
            ?.putString("name", p.name)
            ?.putString("birth", p.birth.toString())
            ?.putString("gender", p.gender.name)
            ?.putFloat("height", p.heightCm)
            ?.putFloat("weight", p.weightKg)
            ?.putString("goal", p.goal.name)
            ?.apply()
        _profile.value = p
    }
}
