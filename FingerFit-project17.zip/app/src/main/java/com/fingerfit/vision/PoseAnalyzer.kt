package com.fingerfit.vision

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.fingerfit.logic.BodyPoint

class PoseFrame(
    val points: List<BodyPoint>?,
    val width: Int,
    val height: Int,
    val lightingOk: Boolean,
    val mirrored: Boolean,
    val timeMs: Long,
)

/** CameraX analyzer for body workouts. Frames are analysed in memory and discarded. */
class PoseAnalyzer(
    private val tracker: PoseTracker,
    private val mirror: Boolean,
    private val isActive: () -> Boolean,
    private val onFrame: (PoseFrame?) -> Unit,
    /** Optional: gets the upright picture (before it is recycled), used by the two-phone camera. */
    private val onPicture: ((Bitmap) -> Unit)? = null,
) : ImageAnalysis.Analyzer {

    override fun analyze(image: ImageProxy) {
        try {
            if (!isActive()) {
                onFrame(null)
                return
            }
            val raw = image.toBitmap()
            val matrix = Matrix().apply {
                postRotate(image.imageInfo.rotationDegrees.toFloat())
                if (mirror) postScale(-1f, 1f)
            }
            val upright = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
            val now = SystemClock.uptimeMillis()
            val lightingOk = meanLuma(upright) >= MIN_LUMA
            val points = tracker.detect(upright, now)
            val frame = PoseFrame(points, upright.width, upright.height, lightingOk, mirror, now)
            try {
                onPicture?.invoke(upright)
            } catch (e: Exception) {
            }
            if (upright !== raw) raw.recycle()
            upright.recycle()
            onFrame(frame)
        } catch (e: Exception) {
            onFrame(null)
        } finally {
            image.close()
        }
    }

    private fun meanLuma(b: Bitmap): Float {
        val n = 12
        var sum = 0f
        for (iy in 0 until n) for (ix in 0 until n) {
            val p = b.getPixel(((ix + 0.5f) * b.width / n).toInt(), ((iy + 0.5f) * b.height / n).toInt())
            sum += 0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p)
        }
        return sum / (n * n)
    }

    private companion object {
        const val MIN_LUMA = 40f
    }
}
