package com.fingerfit

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.WorkManager
import com.fingerfit.data.Repo
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

object Notify {
    const val CH_REMINDER = "reminders"
    const val CH_WALK = "walk"

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CH_REMINDER, com.fingerfit.logic.Bn.t("Reminders"), NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_WALK, com.fingerfit.logic.Bn.t("Walk tracking"), NotificationManager.IMPORTANCE_LOW))
    }

    fun canPost(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun openAppIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    fun post(ctx: Context, id: Int, title: String, body: String, channel: String = CH_REMINDER) {
        if (!canPost(ctx)) return
        ensureChannels(ctx)
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(com.fingerfit.logic.Bn.t(title))
            .setContentText(com.fingerfit.logic.Bn.t(body))
            .setStyle(NotificationCompat.BigTextStyle().bigText(com.fingerfit.logic.Bn.t(body)))
            .setContentIntent(openAppIntent(ctx))
            .setAutoCancel(true)
            .build()
        runCatching { ctx.getSystemService(NotificationManager::class.java)?.notify(id, n) }
    }
}

/** Fires once a day: asks the user to log last night's sleep if they have not yet. */
class SleepReminderWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val c = applicationContext
        Repo.init(c)
        val today = LocalDate.now().toString()
        if (Repo.sleeps.value.none { it.date == today }) {
            val title = "Log your sleep"
            val body = "How did you sleep last night? Add your bedtime and wake-up time."
            Repo.addInbox(title, body)
            Notify.post(c, 101, title, body)
        }
        return Result.success()
    }
}

object Reminders {
    private const val WORK_NAME = "sleep_reminder"

    fun scheduleSleep(ctx: Context, enabled: Boolean, hour: Int, minute: Int) {
        val wm = WorkManager.getInstance(ctx.applicationContext)
        if (!enabled) {
            wm.cancelUniqueWork(WORK_NAME)
            return
        }
        val now = LocalDateTime.now()
        var next = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        val delay = Duration.between(now, next).toMillis()
        val req = PeriodicWorkRequestBuilder<SleepReminderWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()
        wm.enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}
