package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private const val W = 480f
private const val H = 640f

private fun j(i: Int, x: Float, y: Float) = Triple(i, x, y)

/** Builds 33 landmarks; the ones not listed are invisible. Index pairs (11,12) etc. are set together. */
private fun pose(vararg parts: Triple<Int, Float, Float>): List<BodyPoint> {
    val a = Array(33) { BodyPoint(0f, 0f, 0f) }
    parts.forEach { a[it.first] = BodyPoint(it.second, it.third, 1f) }
    return a.toList()
}

private fun both(l: Int, r: Int, x: Float, y: Float) = arrayOf(j(l, x, y), j(r, x, y))

private class Run(type: ExerciseType, var mirrored: Boolean = false) {
    val engine = ExerciseEngine(type)
    var t = 1_000L
    var step = 33L
    var last: ExerciseEngine.Out? = null
    fun feed(p: List<BodyPoint>?, frames: Int) {
        repeat(frames) {
            last = engine.update(p, W, H, t, mirrored)
            t += step
        }
    }
}

// ---- synthetic poses -------------------------------------------------------

private val frontStand = pose(
    j(0, 0.5f, 0.15f), j(11, 0.58f, 0.25f), j(12, 0.42f, 0.25f),
    j(15, 0.60f, 0.50f), j(16, 0.40f, 0.50f),
    j(23, 0.56f, 0.50f), j(24, 0.44f, 0.50f),
    j(25, 0.56f, 0.68f), j(26, 0.44f, 0.68f),
    j(27, 0.56f, 0.88f), j(28, 0.44f, 0.88f),
)
private val frontStar = pose(
    j(0, 0.5f, 0.15f), j(11, 0.58f, 0.25f), j(12, 0.42f, 0.25f),
    j(15, 0.70f, 0.08f), j(16, 0.30f, 0.08f),
    j(23, 0.56f, 0.50f), j(24, 0.44f, 0.50f),
    j(25, 0.60f, 0.68f), j(26, 0.40f, 0.68f),
    j(27, 0.70f, 0.88f), j(28, 0.30f, 0.88f),
)
private fun kneeLift(left: Boolean) = pose(
    j(11, 0.58f, 0.25f), j(12, 0.42f, 0.25f),
    j(23, 0.56f, 0.50f), j(24, 0.44f, 0.50f),
    j(25, 0.56f, if (left) 0.52f else 0.68f), j(26, 0.44f, if (left) 0.68f else 0.52f),
)

private val squatUp = pose(*both(23, 24, 0.5f, 0.50f), *both(25, 26, 0.5f, 0.69f), *both(27, 28, 0.5f, 0.88f))
private val squatDown = pose(*both(23, 24, 0.40f, 0.72f), *both(25, 26, 0.62f, 0.72f), *both(27, 28, 0.5f, 0.88f))

private fun pushUp(down: Boolean) = pose(
    *both(11, 12, 0.25f, if (down) 0.70f else 0.55f),
    *both(13, 14, if (down) 0.40f else 0.25f, if (down) 0.78f else 0.72f),
    *both(15, 16, 0.25f, 0.88f),
    *both(23, 24, 0.55f, if (down) 0.68f else 0.60f),
)
private val standingArms = pose(
    *both(11, 12, 0.5f, 0.25f), *both(13, 14, 0.5f, 0.40f),
    *both(15, 16, 0.5f, 0.55f), *both(23, 24, 0.5f, 0.50f),
)

private val lungeStand = pose(
    j(0, 0.60f, 0.15f), *both(23, 24, 0.5f, 0.5f), *both(25, 26, 0.5f, 0.69f), *both(27, 28, 0.5f, 0.88f),
)
private val lungeLeftFront = pose(
    j(0, 0.60f, 0.15f), *both(23, 24, 0.5f, 0.62f),
    j(25, 0.65f, 0.64f), j(27, 0.65f, 0.88f), j(26, 0.40f, 0.80f), j(28, 0.25f, 0.85f),
)
private val lungeRightFront = pose(
    j(0, 0.60f, 0.15f), *both(23, 24, 0.5f, 0.62f),
    j(26, 0.65f, 0.64f), j(28, 0.65f, 0.88f), j(25, 0.40f, 0.80f), j(27, 0.25f, 0.85f),
)

private fun crunch(up: Boolean) = pose(
    *both(11, 12, if (up) 0.30f else 0.25f, if (up) 0.55f else 0.70f),
    *both(23, 24, 0.55f, 0.72f), *both(25, 26, 0.65f, 0.55f),
)
private fun bridge(up: Boolean) = pose(
    *both(11, 12, 0.25f, 0.72f),
    *both(23, 24, 0.50f, if (up) 0.54f else 0.72f),
    *both(25, 26, 0.62f, if (up) 0.45f else 0.55f),
)
private fun plank(good: Boolean) = pose(
    *both(11, 12, 0.25f, 0.55f), *both(23, 24, 0.55f, if (good) 0.58f else 0.35f), *both(27, 28, 0.85f, 0.61f),
)

class BodyClassifierTest {
    private fun read(t: ExerciseType, p: List<BodyPoint>) = BodyClassifier.read(t, p, W, H)

    @Test fun squatUpIsStart() = assertEquals(Pose.OPEN, read(ExerciseType.SQUATS, squatUp).pose)
    @Test fun squatDownIsPeak() = assertEquals(Pose.CLOSED, read(ExerciseType.SQUATS, squatDown).pose)
    @Test fun pushUpUpAndDown() {
        assertEquals(Pose.OPEN, read(ExerciseType.PUSH_UPS, pushUp(false)).pose)
        assertEquals(Pose.CLOSED, read(ExerciseType.PUSH_UPS, pushUp(true)).pose)
    }
    @Test fun standingPersonIsNotAPushUp() = assertTrue(!read(ExerciseType.PUSH_UPS, standingArms).valid)
    @Test fun jumpingJackStates() {
        assertEquals(Pose.OPEN, read(ExerciseType.JUMPING_JACKS, frontStand).pose)
        assertEquals(Pose.CLOSED, read(ExerciseType.JUMPING_JACKS, frontStar).pose)
    }
    @Test fun missingBodyPartsAreInvalid() =
        assertTrue(!read(ExerciseType.SQUATS, pose(*both(23, 24, 0.5f, 0.5f))).valid)
    @Test fun bodyCutOffByFrameIsInvalid() =
        assertTrue(!read(ExerciseType.SQUATS, pose(*both(23, 24, 0.5f, 0.5f), *both(25, 26, 0.5f, 0.69f), *both(27, 28, 0.5f, 1.2f))).valid)
    @Test fun plankGoodAndSagging() {
        assertTrue(read(ExerciseType.PLANK, plank(true)).good)
        assertTrue(!read(ExerciseType.PLANK, plank(false)).good)
    }
}

class ExerciseEngineTest {
    @Test fun squatsCountThree() {
        val r = Run(ExerciseType.SQUATS)
        r.feed(squatUp, 12)
        repeat(3) { r.feed(squatDown, 12); r.feed(squatUp, 12) }
        assertEquals(3, r.engine.reps)
    }

    @Test fun holdingASquatNeverCounts() {
        val r = Run(ExerciseType.SQUATS)
        r.feed(squatUp, 12); r.feed(squatDown, 300)
        assertEquals(0, r.engine.reps)
    }

    @Test fun pushUpsCountFour() {
        val r = Run(ExerciseType.PUSH_UPS)
        r.feed(pushUp(false), 12)
        repeat(4) { r.feed(pushUp(true), 12); r.feed(pushUp(false), 12) }
        assertEquals(4, r.engine.reps)
    }

    @Test fun standingPersonNeverCountsPushUps() {
        val r = Run(ExerciseType.PUSH_UPS)
        r.feed(standingArms, 200)
        assertEquals(0, r.engine.reps)
    }

    @Test fun jumpingJacksCountFive() {
        val r = Run(ExerciseType.JUMPING_JACKS)
        r.feed(frontStand, 6)
        repeat(5) { r.feed(frontStar, 8); r.feed(frontStand, 8) }
        assertEquals(5, r.engine.reps)
    }

    @Test fun highKneesCountEachLeg() {
        val r = Run(ExerciseType.HIGH_KNEES)
        r.feed(frontStand, 6)
        repeat(3) {
            r.feed(kneeLift(true), 6); r.feed(frontStand, 6)
            r.feed(kneeLift(false), 6); r.feed(frontStand, 6)
        }
        assertEquals(6, r.engine.reps)
        assertEquals(3, r.engine.leftReps)
        assertEquals(3, r.engine.rightReps)
    }

    @Test fun lungesAreAttributedToTheFrontLeg() {
        val r = Run(ExerciseType.LUNGES)
        r.feed(lungeStand, 12)
        r.feed(lungeLeftFront, 12); r.feed(lungeStand, 12)
        r.feed(lungeRightFront, 12); r.feed(lungeStand, 12)
        assertEquals(2, r.engine.reps)
        assertEquals(1, r.engine.leftReps)
        assertEquals(1, r.engine.rightReps)
    }

    @Test fun mirroredCameraSwapsLeftAndRight() {
        val r = Run(ExerciseType.LUNGES, mirrored = true)
        r.feed(lungeStand, 12); r.feed(lungeLeftFront, 12); r.feed(lungeStand, 12)
        assertEquals(1, r.engine.rightReps)
        assertEquals(0, r.engine.leftReps)
    }

    @Test fun crunchesCountTwo() {
        val r = Run(ExerciseType.CRUNCHES)
        r.feed(crunch(false), 12)
        repeat(2) { r.feed(crunch(true), 12); r.feed(crunch(false), 12) }
        assertEquals(2, r.engine.reps)
    }

    @Test fun glutBridgesCountTwo() {
        val r = Run(ExerciseType.GLUTE_BRIDGES)
        r.feed(bridge(false), 12)
        repeat(2) { r.feed(bridge(true), 12); r.feed(bridge(false), 12) }
        assertEquals(2, r.engine.reps)
    }

    @Test fun bodyLostMidRepDiscardsIt() {
        val r = Run(ExerciseType.SQUATS)
        r.feed(squatUp, 12); r.feed(squatDown, 12)
        r.feed(null, 60)
        r.feed(squatUp, 12)
        assertEquals(0, r.engine.reps)
    }

    @Test fun plankTimesOnlyWhileFormIsGood() {
        val r = Run(ExerciseType.PLANK)
        r.feed(plank(true), 100)
        val held = r.engine.holdMs
        assertTrue("held=$held", held in 2800..3400)
        r.feed(plank(false), 30) // ~1 s of sagging: grace window then stops
        val afterSag = r.engine.holdMs
        r.feed(plank(false), 30)
        assertEquals(afterSag, r.engine.holdMs)
        r.feed(plank(true), 30)
        assertTrue(r.engine.holdMs > afterSag)
    }

    // A Wi-Fi camera may give only 8 pictures a second: one picture at the bottom, one at the top.
    @Test fun fastPushUpsAtLowFrameRateAllCount() {
        val r = Run(ExerciseType.PUSH_UPS)
        r.step = 125L
        r.feed(pushUp(false), 2)
        repeat(5) {
            r.feed(pushUp(true), 1)
            r.feed(pushUp(false), 3)
        }
        assertEquals(5, r.engine.reps)
    }

    @Test fun fastSquatsAtLowFrameRateAllCount() {
        val r = Run(ExerciseType.SQUATS)
        r.step = 150L
        r.feed(squatUp, 2)
        repeat(5) {
            r.feed(squatDown, 1)
            r.feed(squatUp, 3)
        }
        assertEquals(5, r.engine.reps)
    }

    @Test fun fastJumpingJacksAtLowFrameRateAllCount() {
        val r = Run(ExerciseType.JUMPING_JACKS)
        r.step = 140L
        r.feed(frontStand, 2)
        repeat(6) {
            r.feed(frontStar, 1)
            r.feed(frontStand, 3)
        }
        assertEquals(6, r.engine.reps)
    }
}
