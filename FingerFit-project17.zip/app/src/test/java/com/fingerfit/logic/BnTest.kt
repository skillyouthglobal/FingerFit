package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BnTest {
    @Test fun english_is_untouched() { Bn.bn = false; assertEquals("Settings", Bn.t("Settings")) }
    @Test fun exact_translates() { Bn.bn = true; assertEquals("সেটিংস", Bn.t("Settings")); Bn.bn = false }
    @Test fun pattern_with_numbers_and_bengali_digits() {
        Bn.bn = true
        val r = Bn.t("Target: 20 reps")
        assertTrue(r, r.startsWith("লক্ষ্য:") && r.contains("২০"))
        Bn.bn = false
    }
    @Test fun unknown_stays_english() { Bn.bn = true; assertEquals("Zzzq", Bn.t("Zzzq")); Bn.bn = false }
    @Test fun ip_and_url_not_converted() { Bn.bn = true; assertEquals("192.168.0.5", Bn.t("192.168.0.5")); assertEquals("http://192.168.0.5:8080", Bn.t("http://192.168.0.5:8080")); Bn.bn = false }
    @Test fun pairs_are_even_and_nonblank() {
        assertTrue(BnData.P.size % 2 == 0)
        var i = 0
        while (i < BnData.P.size) { assertTrue(BnData.P[i], BnData.P[i + 1].isNotBlank()); i += 2 }
    }
    @Test fun placeholders_match() {
        val ph = Regex("\\{\\d\\}")
        var i = 0
        while (i < BnData.P.size) {
            val a = ph.findAll(BnData.P[i]).map { it.value }.toSet(); val b = ph.findAll(BnData.P[i + 1]).map { it.value }.toSet()
            assertTrue("${BnData.P[i]} -> ${BnData.P[i + 1]}", a == b); i += 2
        }
    }
    @Test fun dosing_lines_translate() {
        Bn.bn = true
        val a = Bn.t("2 sets × 10 reps"); val b = Bn.t("Rest 60 sec between sets"); val c = Bn.t("Step 2 of 4")
        assertTrue(a, a.contains("সেট") && a.contains("বার") && a.contains("১০"))
        assertTrue(b, b.contains("৬০") && b.contains("বিশ্রাম"))
        assertTrue(c, c.contains("ধাপ"))
        Bn.bn = false
    }
}
