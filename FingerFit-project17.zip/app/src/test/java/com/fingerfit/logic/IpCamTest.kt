package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class IpCamTest {
    @Test fun normalizeUrl() {
        assertEquals("http://192.168.0.105:8080/video", IpCams.normalizeUrl(" 192.168.0.105:8080/video "))
        assertEquals("rtsp://admin:1234@10.0.0.9:554/stream1", IpCams.normalizeUrl("rtsp://admin:1234@10.0.0.9:554/stream1"))
        assertEquals("http://u:p@cam.local/shot.jpg", IpCams.normalizeUrl("http://u:p@cam.local/shot.jpg"))
        assertTrue(IpCams.normalizeUrl("") == null)
        assertTrue(IpCams.normalizeUrl("ftp://1.2.3.4") == null)
        assertTrue(IpCams.normalizeUrl("http://1.2.3.4:99999/x") == null)
        assertTrue(IpCams.normalizeUrl("hello world") == null)
        assertTrue(IpCams.normalizeUrl("http://:80/x") == null)
        assertTrue(IpCams.isRtsp("RTSP://1.2.3.4/x"))
    }

    @Test fun subnetHosts() {
        val h = IpCams.subnetHosts("192.168.1.20", 24)
        assertEquals(253, h.size)
        assertEquals("192.168.1.1", h.first())
        assertEquals("192.168.1.254", h.last())
        assertTrue("192.168.1.20" !in h)
        assertEquals(253, IpCams.subnetHosts("10.141.94.121", 16).size)
        assertEquals("10.141.94.1", IpCams.subnetHosts("10.141.94.121", 16).first())
        val small = IpCams.subnetHosts("192.168.43.1", 28)
        assertEquals(13, small.size)
        assertTrue(IpCams.subnetHosts("bad", 24).isEmpty())
        assertTrue(IpCams.subnetHosts("1.2.3.999", 24).isEmpty())
    }

    private fun jpeg(vararg body: Int): ByteArray =
        (listOf(0xFF, 0xD8) + body.toList() + listOf(0xFF, 0xD9)).map { it.toByte() }.toByteArray()

    @Test fun splitterFindsFramesAcrossChunks() {
        val a = jpeg(1, 2, 3)
        val b = jpeg(9, 8, 7, 6)
        val header = "--frame\r\nContent-Type: image/jpeg\r\n\r\n".toByteArray()
        val stream = header + a + "\r\n".toByteArray() + header + b
        val sp = JpegSplitter()
        val got = ArrayList<ByteArray>()
        var i = 0
        while (i < stream.size) {
            val n = minOf(5, stream.size - i)
            got.addAll(sp.feed(stream.copyOfRange(i, i + n), n))
            i += n
        }
        assertEquals(2, got.size)
        assertTrue(got[0].contentEquals(a))
        assertTrue(got[1].contentEquals(b))
    }

    @Test fun splitterHandlesSplitMarkerAndGarbage() {
        val sp = JpegSplitter()
        val f = jpeg(5, 5)
        assertEquals(0, sp.feed(byteArrayOf(0x41, 0x42, 0xFF.toByte()), 3).size)
        val rest = byteArrayOf(0xD8.toByte()) + f.copyOfRange(2, f.size)
        val got = sp.feed(rest, rest.size)
        assertEquals(1, got.size)
        assertTrue(got[0].contentEquals(f))
    }
}
