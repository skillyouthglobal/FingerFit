package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DosingTest {
    @Test fun age_bands_follow_who() {
        assertEquals(AgeBand.CHILD, Dosing.band(5)); assertEquals(AgeBand.CHILD, Dosing.band(12))
        assertEquals(AgeBand.TEEN, Dosing.band(13)); assertEquals(AgeBand.TEEN, Dosing.band(17))
        assertEquals(AgeBand.ADULT, Dosing.band(18)); assertEquals(AgeBand.ADULT, Dosing.band(64))
        assertEquals(AgeBand.SENIOR, Dosing.band(65))
    }
    @Test fun amounts_are_sensible_for_every_exercise_and_age() {
        for (t in ExerciseType.values()) for (age in listOf(6, 15, 30, 70)) for (low in listOf(false, true)) {
            val d = Dosing.forType(t, age, low)
            assertTrue("${t.name} $age", d.perSet >= t.step && d.sets in 1..3 && d.restSec in 30..120)
            assertTrue(d.perSet % t.step == 0)
        }
    }
    @Test fun older_people_get_less_and_no_jumping() {
        val adult = Dosing.forType(ExerciseType.SQUATS, 30, false)
        val senior = Dosing.forType(ExerciseType.SQUATS, 70, false)
        assertTrue(senior.perSet < adult.perSet)
        assertTrue(Dosing.forType(ExerciseType.JUMPING_JACKS, 70, false).extra != null)
        assertTrue(Dosing.forType(ExerciseType.JUMPING_JACKS, 30, false).extra == null)
    }
}
