package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class HealthTest {
    private val today = LocalDate.of(2026, 11, 1)

    @Test fun ageBeforeAndAfterBirthday() {
        assertEquals(30, Health.age(LocalDate.of(1996, 11, 1), today))
        assertEquals(29, Health.age(LocalDate.of(1996, 11, 2), today))
        assertEquals(0, Health.age(LocalDate.of(2026, 12, 1), today))
    }

    @Test fun bmiAndCategories() {
        assertTrue(kotlin.math.abs(Health.bmi(70f, 175f) - 22.86f) < 0.05f)
        assertEquals("Underweight", Health.bmiCategory(Health.bmi(50f, 175f)))
        assertEquals("Healthy weight", Health.bmiCategory(Health.bmi(70f, 175f)))
        assertEquals("Overweight", Health.bmiCategory(Health.bmi(80f, 175f)))
        assertEquals("Obese", Health.bmiCategory(Health.bmi(95f, 175f)))
        assertEquals(0f, Health.bmi(70f, 0f))
    }

    @Test fun healthyRange() {
        val r = Health.healthyRangeKg(170f)
        assertTrue(kotlin.math.abs(r.first - 53.5f) < 0.1f)
        assertTrue(kotlin.math.abs(r.second - 66.2f) < 0.1f)
    }

    @Test fun dateParsing() {
        assertEquals(LocalDate.of(1995, 2, 28), Health.parseDate(28, 2, 1995, today))
        assertTrue(Health.parseDate(30, 2, 1995, today) == null)
        assertTrue(Health.parseDate(1, 13, 1995, today) == null)
        assertTrue(Health.parseDate(1, 1, 2030, today) == null)
        assertTrue(Health.parseDate(1, 1, 1800, today) == null)
    }
}

class PlanTest {
    @Test fun feetAndInches() {
        assertTrue(kotlin.math.abs(Health.cmFromFeetInches(5, 7) - 170.18f) < 0.05f)
        assertEquals(Pair(5, 7), Health.feetInchesFromCm(170f))
        assertEquals(Pair(5, 11), Health.feetInchesFromCm(180.3f))
        assertEquals(Pair(6, 0), Health.feetInchesFromCm(183f))
    }

    @Test fun caloriesMaintainAndLose() {
        assertEquals(2200, Plans.calories(Gender.MALE, 68f, 170f, 30, Goal.MAINTAIN)!!.kcal)
        assertEquals(1800, Plans.calories(Gender.MALE, 68f, 170f, 30, Goal.LOSE)!!.kcal)
        assertEquals(2500, Plans.calories(Gender.MALE, 68f, 170f, 30, Goal.GAIN)!!.kcal)
    }

    @Test fun caloriesNeverBelowSafeFloorAndNoneForMinors() {
        assertEquals(1200, Plans.calories(Gender.FEMALE, 40f, 150f, 30, Goal.LOSE)!!.kcal)
        assertTrue(Plans.calories(Gender.MALE, 50f, 160f, 15, Goal.MAINTAIN) == null)
        val c = Plans.calories(Gender.MALE, 68f, 170f, 30, Goal.MAINTAIN)!!
        assertEquals(c.kcal - 100, c.low)
        assertEquals(c.kcal + 100, c.high)
    }

    @Test fun exercisePlanByGoalAndAge() {
        val lose = Plans.exercisePlan(30, 23f, Goal.LOSE)
        assertTrue(lose.any { it.type == ExerciseType.JUMPING_JACKS })
        assertTrue(lose.any { it.type == ExerciseType.HIGH_KNEES })
        assertTrue(lose.any { it.type == ExerciseType.PLANK })
        val gain = Plans.exercisePlan(30, 21f, Goal.GAIN)
        assertTrue(gain.any { it.type == ExerciseType.LUNGES })
        assertTrue(gain.none { it.type == ExerciseType.HIGH_KNEES })
        val senior = Plans.exercisePlan(65, 24f, Goal.MAINTAIN)
        assertTrue(senior.none { it.type == ExerciseType.JUMPING_JACKS })
        assertTrue(senior.first().type == null && senior.first().amount == "30 min")
        assertEquals("10 reps", senior.first { it.type == ExerciseType.SQUATS }.amount)
    }

    @Test fun everyExerciseHasAGroup() {
        ExerciseType.values().forEach { Plans.groupOf(it) }
        assertEquals(PlanGroup.CORE, Plans.groupOf(ExerciseType.PLANK))
    }
}
