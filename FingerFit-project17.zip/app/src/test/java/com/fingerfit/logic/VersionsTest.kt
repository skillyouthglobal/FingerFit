package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VersionsTest {
    @Test fun tags() {
        assertEquals(17, Versions.codeFromTag("v1.0.17"))
        assertEquals(5, Versions.codeFromTag(" 1.0.5 "))
        assertTrue(Versions.codeFromTag("latest") == null)
        assertTrue(Versions.codeFromTag(null) == null)
        assertTrue(Versions.codeFromTag("v1.0") == null)
    }

    @Test fun newer() {
        assertTrue(Versions.isNewer(18, 17))
        assertTrue(!Versions.isNewer(17, 17))
        assertTrue(!Versions.isNewer(3, 17))
        assertTrue(!Versions.isNewer(null, 1))
    }
}
