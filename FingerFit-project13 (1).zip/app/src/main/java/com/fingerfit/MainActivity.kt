package com.fingerfit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.ui.Modifier
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.data.ProfileRepo
import com.fingerfit.data.Repo
import com.fingerfit.link.LinkState
import com.fingerfit.logic.ExerciseType
import com.fingerfit.ui.BodyListScreen
import com.fingerfit.ui.CameraHubScreen
import com.fingerfit.ui.ExerciseScreen
import com.fingerfit.ui.FingerFitTheme
import com.fingerfit.ui.GuideScreen
import com.fingerfit.ui.HomeScreen
import com.fingerfit.ui.InboxScreen
import com.fingerfit.ui.LinkScreen
import com.fingerfit.ui.KinetroNavBar
import com.fingerfit.ui.OnboardingScreen
import com.fingerfit.ui.PlanScreen
import com.fingerfit.ui.Tabs
import com.fingerfit.ui.SettingsScreen
import com.fingerfit.ui.SleepScreen
import com.fingerfit.ui.WalkScreen
import com.fingerfit.ui.WorkoutScreen

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    private val workoutVm: WorkoutViewModel by viewModels()
    private val linkVm: LinkViewModel by viewModels()
    private val updateVm: UpdateViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(this)
        ProfileRepo.init(this)
        Notify.ensureChannels(this)
        val s = vm.settings.value
        Reminders.scheduleSleep(this, s.sleepReminder, s.sleepHour, s.sleepMinute)
        // Frames from a linked phone drive the workout whenever it is used as the camera.
        linkVm.setSink { frame -> if (linkVm.useRemote.value) workoutVm.onFrame(frame) }
        enableEdgeToEdge()
        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            FingerFitTheme(settings.theme) { FingerFitApp(vm, workoutVm, linkVm, updateVm) }
        }
    }
}

private const val HOME = "home"
private const val EXERCISE = "exercise"
private const val SETTINGS = "settings"
private const val BODY = "body"
private const val WORKOUT = "workout"
private const val WALK = "walk"
private const val SLEEP = "sleep"
private const val INBOX = "inbox"
private const val LINK = "link"
private const val ONBOARDING = "onboarding"
private const val GUIDE = "guide"
private const val PLAN = "plan"
private const val CAMERAS = "cameras"

@Composable
private fun FingerFitApp(vm: AppViewModel, workoutVm: WorkoutViewModel, linkVm: LinkViewModel, updateVm: UpdateViewModel) {
    LaunchedEffect(Unit) { updateVm.checkOnStart() }
    val profile by ProfileRepo.profile.collectAsStateWithLifecycle()
    var screen by rememberSaveable { mutableStateOf(if (ProfileRepo.profile.value == null) ONBOARDING else HOME) }
    var workoutFrom by rememberSaveable { mutableStateOf(BODY) }
    var guideType by rememberSaveable { mutableStateOf(ExerciseType.JUMPING_JACKS.name) }
    var guideFrom by rememberSaveable { mutableStateOf(BODY) }
    val linkState by linkVm.ui.collectAsStateWithLifecycle()
    val webState by linkVm.webUi.collectAsStateWithLifecycle()
    val ipState by linkVm.ipUi.collectAsStateWithLifecycle()
    val linkStatus = when {
        ipState.running -> "● ${ipState.name} connected. Tap to manage"
        linkState.state == LinkState.CONNECTED -> "● Connected: ${linkState.peerName ?: "phone"}. Tap to manage"
        webState.running -> "● Browser camera is on. Tap to manage"
        else -> null
    }
    val tabIndex = when {
        screen == HOME -> Tabs.HOME
        screen == BODY -> Tabs.WORKOUTS
        screen == PLAN -> Tabs.PLAN
        screen == ONBOARDING && profile != null -> Tabs.PROFILE
        else -> -1
    }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).consumeWindowInsets(if (tabIndex >= 0) WindowInsets.navigationBars else WindowInsets(0))) {
            AppScreens(
                screen, { screen = it }, profile, vm, workoutVm, linkVm, updateVm, linkStatus,
                guideType, { guideType = it }, guideFrom, { guideFrom = it }, workoutFrom, { workoutFrom = it },
            )
        }
        if (tabIndex >= 0) {
            KinetroNavBar(tabIndex) { i ->
                screen = when (i) {
                    Tabs.WORKOUTS -> BODY
                    Tabs.PLAN -> PLAN
                    Tabs.PROFILE -> ONBOARDING
                    else -> HOME
                }
            }
        }
    }
}

@Composable
private fun AppScreens(
    screen: String, setScreen: (String) -> Unit, profile: com.fingerfit.data.Profile?,
    vm: AppViewModel, workoutVm: WorkoutViewModel, linkVm: LinkViewModel, updateVm: UpdateViewModel, linkStatus: String?,
    guideType: String, setGuideType: (String) -> Unit, guideFrom: String, setGuideFrom: (String) -> Unit,
    workoutFrom: String, setWorkoutFrom: (String) -> Unit,
) {
    val goHome = { setScreen(HOME) }
    when (screen) {
        ONBOARDING -> OnboardingScreen(
            initial = profile,
            onDone = { p ->
                ProfileRepo.save(p)
                setScreen(HOME)
            },
            onBack = if (profile != null) goHome else null,
        )
        PLAN -> PlanScreen(
            profile = profile,
            onBack = goHome,
            onEditProfile = { setScreen(ONBOARDING) },
            onOpen = { type: ExerciseType ->
                setGuideType(type.name)
                setGuideFrom(PLAN)
                setScreen(GUIDE)
            },
        )
        CAMERAS -> CameraHubScreen(
            link = linkVm,
            onBack = goHome,
            onPhones = { setScreen(LINK) },
            onWorkouts = { setScreen(BODY) },
        )
        EXERCISE -> ExerciseScreen(vm, onExit = { setScreen(BODY) })
        SETTINGS -> SettingsScreen(vm, updateVm, onBack = goHome)
        BODY -> BodyListScreen(
            vm = vm,
            onBack = goHome,
            onFinger = { vm.prepareSession(); setScreen(EXERCISE) },
            onPick = { type: ExerciseType ->
                setGuideType(type.name)
                setGuideFrom(BODY)
                setScreen(GUIDE)
            },
        )
        GUIDE -> {
            val type = ExerciseType.values().firstOrNull { it.name == guideType } ?: ExerciseType.JUMPING_JACKS
            GuideScreen(
                type = type,
                onStart = {
                    workoutVm.select(type)
                    if (guideFrom == LINK) linkVm.setUseRemote(true)
                    setWorkoutFrom(guideFrom)
                    setScreen(WORKOUT)
                },
                onBack = { setScreen(guideFrom) },
            )
        }
        WORKOUT -> WorkoutScreen(workoutVm, vm, linkVm, onExit = { setScreen(workoutFrom) })
        WALK -> WalkScreen(vm, onBack = goHome)
        SLEEP -> SleepScreen(vm, onBack = goHome)
        INBOX -> InboxScreen(onBack = goHome)
        LINK -> LinkScreen(
            linkVm,
            onBack = { setScreen(CAMERAS) },
            onWorkout = { type: ExerciseType ->
                setGuideType(type.name)
                setGuideFrom(LINK)
                setScreen(GUIDE)
            },
        )
        else -> HomeScreen(
            vm,
            onStart = { vm.prepareSession(); setScreen(EXERCISE) },
            onSettings = { setScreen(SETTINGS) },
            onBody = { setScreen(BODY) },
            onWalk = { setScreen(WALK) },
            onSleep = { setScreen(SLEEP) },
            onInbox = { setScreen(INBOX) },
            onLink = { setScreen(CAMERAS) },
            linkStatus = linkStatus,
            profile = profile,
            onProfile = { setScreen(ONBOARDING) },
            updateVm = updateVm,
        )
    }
}
