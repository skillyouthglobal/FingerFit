package com.fingerfit.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fingerfit.data.Profile
import com.fingerfit.logic.ExerciseType
import com.fingerfit.logic.Health
import com.fingerfit.logic.PlanGroup
import com.fingerfit.logic.Plans
import java.time.LocalDate

private val CardBg: Color @Composable get() = MaterialTheme.colorScheme.surface

/** "My plan": a daily exercise plan grouped by purpose, and a food energy suggestion. */
@Composable
fun PlanScreen(profile: Profile?, onBack: () -> Unit, onOpen: (ExerciseType) -> Unit, onEditProfile: () -> Unit) {
    BackHandler(onBack = onBack)
    var tab by rememberSaveable { mutableStateOf(0) }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.statusBarsPadding()) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 16.dp)) {
            Text("My plan", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "Made for you, from your age, height, weight and goal.",
                fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(14.dp))

            if (profile == null) {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth().clickable(onClick = onEditProfile),
                ) {
                    Text(
                        "Fill in your profile first (name, birth date, height, weight). Tap here.",
                        modifier = Modifier.padding(18.dp),
                    )
                }
            } else {
                val today = LocalDate.now()
                val age = Health.age(profile.birth, today)
                val bmi = profile.bmi()
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Exercise") })
                    FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Food") })
                }
                Spacer(Modifier.height(12.dp))
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (tab == 0) ExerciseTab(age, bmi, profile, onOpen) else FoodTab(age, profile)
                    Disclaimer()
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun ExerciseTab(age: Int, bmi: Float, profile: Profile, onOpen: (ExerciseType) -> Unit) {
    val items = Plans.exercisePlan(age, bmi, profile.goal)
    if (Plans.isLowImpact(age, bmi)) {
        Note("A gentler plan: walking instead of jumping, and fewer reps, to be kind to your joints.")
    }
    PlanGroup.values().forEach { g ->
        val rows = items.filter { it.group == g }
        if (rows.isEmpty()) return@forEach
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        ) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(g.title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                rows.forEach { row ->
                    val t = row.type
                    Row(
                        Modifier.fillMaxWidth()
                            .then(if (t != null) Modifier.clickable { onOpen(t) } else Modifier)
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(row.label, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        Text(row.amount, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                        if (t != null) Text("  ›", fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
    Note(
        "WHO advice for adults: 150 to 300 minutes of moderate activity every week, " +
            "and muscle-strengthening exercise on at least 2 days. Tap an exercise to see how it is done.",
        tint = HeroTint,
    )
}

@Composable
private fun FoodTab(age: Int, profile: Profile) {
    val advice = Plans.calories(profile.gender, profile.weightKg, profile.heightCm, age, profile.goal)
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Food suggestion", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            if (advice == null) {
                Text(
                    "Calorie numbers are not given for people under 18. Children and teenagers grow fast, " +
                        "so please ask a doctor or a parent about food.",
                    fontSize = 14.sp,
                )
            } else {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("${advice.kcal}", fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.tertiary)
                    Text("  kcal a day", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 6.dp))
                }
                Text(
                    "A good range is ${advice.low} to ${advice.high} kcal. Goal: ${profile.goal.label}.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(4.dp))
                listOf("Breakfast" to 0.25, "Lunch" to 0.35, "Snack" to 0.10, "Dinner" to 0.30).forEach { (n, f) ->
                    Row(Modifier.fillMaxWidth()) {
                        Text(n, modifier = Modifier.weight(1f), fontSize = 14.sp)
                        Text("about ${((advice.kcal * f) / 10).toInt() * 10} kcal", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    }
                }
            }
        }
    }
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Healthy eating (WHO)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            listOf(
                "Eat plenty of vegetables, fruit, pulses and whole grains.",
                "Keep salt below 5 g (about 1 teaspoon) a day.",
                "Cut down on sugar, sweet drinks and deep-fried food.",
                "Drink clean water through the day.",
            ).forEach { Text("•  $it", fontSize = 14.sp) }
        }
    }
}

@Composable
private fun Note(text: String, tint: Color = Color(0xFFFFF4E0)) {
    Text(
        text, fontSize = 13.sp, lineHeight = 18.sp, color = Color(0xFF3F4F70),
        modifier = Modifier.fillMaxWidth().background(tint, RoundedCornerShape(16.dp)).padding(14.dp),
    )
}

@Composable
private fun Disclaimer() {
    Note(
        "This is a general suggestion based on World Health Organization healthy-living guidance. " +
            "It is not medical advice. If you have a health condition, are pregnant, or are unsure, please ask a doctor first.",
    )
}
