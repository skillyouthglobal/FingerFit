package com.fingerfit.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.remember
import com.fingerfit.AppViewModel
import com.fingerfit.data.todayReps
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.data.Repo
import com.fingerfit.data.toLocalDate
import com.fingerfit.logic.ExerciseType
import com.fingerfit.logic.PlanGroup
import com.fingerfit.logic.Plans
import java.time.LocalDate

/** The "Workouts" tab: all camera-tracked exercises, filtered by purpose. */
@Composable
fun BodyListScreen(vm: AppViewModel, onBack: () -> Unit, onPick: (ExerciseType) -> Unit, onFinger: () -> Unit) {
    BackHandler(onBack = onBack)
    val workouts by Repo.workouts.collectAsStateWithLifecycle()
    val today = LocalDate.now()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    var showCustom by remember { mutableStateOf(false) }
    val fingerToday = history.todayReps()
    val target = settings.target
    var filter by rememberSaveable { mutableStateOf("ALL") }
    val shown = ExerciseType.values().filter { filter == "ALL" || Plans.groupOf(it).name == filter }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.statusBarsPadding()) {
        Column {
            Column(Modifier.padding(start = 22.dp, end = 22.dp, top = 16.dp)) {
                Text("Workouts", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "The camera counts every rep. Keep your whole body in view.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp,
                )
            }
            Row(
                Modifier.padding(horizontal = 22.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(selected = filter == "ALL", onClick = { filter = "ALL" }, label = { Text("All") })
                PlanGroup.values().forEach { g ->
                    FilterChip(selected = filter == g.name, onClick = { filter = g.name }, label = { Text(g.chip) })
                }
            }
            LazyColumn(
                contentPadding = PaddingValues(start = 22.dp, end = 22.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (filter == "ALL") {
                    item {
                        FingerCard(
                            today = fingerToday, target = target,
                            onTarget = { vm.setTarget(it) }, onCustom = { showCustom = true }, onStart = onFinger,
                        )
                    }
                }
                items(shown) { type ->
                    val done = workouts
                        .filter { it.type == type.name && it.t.toLocalDate() == today }
                        .sumOf { it.reps }
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth().clickable { onPick(type) },
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(52.dp).background(HeroTint, RoundedCornerShape(16.dp)),
                                contentAlignment = Alignment.Center,
                            ) { Text(type.emoji, fontSize = 28.sp) }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(type.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text(
                                    "${Plans.groupOf(type).chip} · target ${type.defaultTarget} ${type.unit}",
                                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                if (done > 0) {
                                    Text(
                                        "Today: $done ${type.unit}", fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold,
                                    )
                                }
                            }
                            Text("›", fontSize = 28.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                if (filter == "ALL") {
                    item {
                        Text("Recent finger workouts", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                    }
                    if (history.isEmpty()) {
                        item {
                            Text(
                                "No finger workouts yet.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp,
                            )
                        }
                    } else {
                        items(history.take(10)) { SessionRow(it) }
                    }
                }
            }
        }
    }
    if (showCustom) CustomTargetDialog(
        current = target,
        onDismiss = { showCustom = false },
        onConfirm = { vm.setTarget(it); showCustom = false },
    )
}

@Composable
private fun FingerCard(today: Int, target: Int, onTarget: (Int) -> Unit, onCustom: () -> Unit, onStart: () -> Unit) {
    val progress = (today.toFloat() / target).coerceIn(0f, 1f)
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).background(HeroTint, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Text("✋", fontSize = 24.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Finger exercise", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(
                        "Hand and finger strength. Open and close your hand.",
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Today: $today of $target reps", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                strokeCap = androidx.compose.ui.graphics.StrokeCap.Round,
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PRESETS.forEach { p ->
                    FilterChip(selected = target == p, onClick = { onTarget(p) }, label = { Text("$p") })
                }
                FilterChip(
                    selected = target !in PRESETS, onClick = onCustom,
                    label = { Text(if (target !in PRESETS) "Custom ($target)" else "Custom") },
                )
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Start finger exercise", fontWeight = FontWeight.Bold)
            }
        }
    }
}
