package com.fingerfit.logic

import java.nio.ByteBuffer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RtspTest {
    private fun hex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    @Test fun target_is_split_and_rebuilt() {
        val t = RtspTarget.parse("rtsp://admin:p%40ss@192.168.0.9:8554/Streaming/Channels/102?x=1")!!
        assertEquals("192.168.0.9", t.host); assertEquals(8554, t.port)
        assertEquals("/Streaming/Channels/102?x=1", t.path)
        assertEquals("admin", t.user); assertEquals("p@ss", t.pass)
        assertEquals("rtsp://192.168.0.9:8554/Streaming/Channels/102?x=1", t.plainUrl())
        assertEquals(t, RtspTarget.parse(t.fullUrl()))
        val d = RtspTarget.parse("rtsp://10.0.0.5")!!
        assertEquals(554, d.port); assertEquals("/", d.path); assertEquals("", d.user)
        assertTrue(RtspTarget.parse("http://1.2.3.4") == null)
        assertTrue(RtspTarget.parse("rtsp://:554/x") == null)
        assertTrue(RtspTarget.parse("rtsp://h:99999/x") == null)
    }

    @Test fun digest_matches_the_rfc_example() {
        val a = RtspAuth("Mufasa", "Circle Of Life") { "0a4f113b" }
        a.challenge(listOf("Digest realm=\"testrealm@host.com\", qop=\"auth,auth-int\", nonce=\"dcd98b7102dd2f0e8b11d0f600bfb0c093\", opaque=\"5ccc069c403ebaf9f0171e9517f40e41\""))
        val h = a.header("GET", "/dir/index.html")!!
        assertTrue(h, h.contains("response=\"6629fae49393a05397450978507c4ef1\""))
        assertTrue(h.contains("nc=00000001")); assertTrue(h.contains("opaque=\"5ccc069c403ebaf9f0171e9517f40e41\""))
        assertTrue(a.header("GET", "/x")!!.contains("nc=00000002"))
    }

    @Test fun basic_login_and_no_login() {
        val a = RtspAuth("u", "p")
        assertTrue(a.header("DESCRIBE", "rtsp://x/") == null)
        a.challenge(listOf("Basic realm=\"cam\""))
        assertEquals("Basic dTpw", a.header("DESCRIBE", "rtsp://x/"))
        val both = RtspAuth("u", "p") { "ab" }
        both.challenge(listOf("Basic realm=\"x\"", "Digest realm=\"r\", nonce=\"n\""))
        assertTrue(both.header("DESCRIBE", "/")!!.startsWith("Digest"))
    }

    @Test fun sdp_video_track_is_read() {
        val sdp = "v=0\r\ns=x\r\na=control:*\r\nm=audio 0 RTP/AVP 8\r\na=rtpmap:8 PCMA/8000\r\na=control:track2\r\n" +
            "m=video 0 RTP/AVP 96\r\na=rtpmap:96 H264/90000\r\na=fmtp:96 packetization-mode=1;profile-level-id=42C016;sprop-parameter-sets=Z0LAFtoCgPbARAAAAwAEAAADAFA8WLqA,aM4PyA==\r\na=control:trackID=1\r\n"
        val v = Sdp.parseVideo(sdp)!!
        assertEquals("H264", v.codec); assertEquals(96, v.payloadType); assertEquals("trackID=1", v.control)
        assertTrue(v.sps != null && v.pps != null)
        assertEquals(Pair(640, 480), H264Sps.size(v.sps!!))
        val h265 = Sdp.parseVideo("m=video 0 RTP/AVP 98\r\na=rtpmap:98 H265/90000\r\n")!!
        assertEquals("H265", h265.codec)
        assertTrue(Sdp.parseVideo("m=audio 0 RTP/AVP 0\r\n") == null)
        assertEquals("rtsp://h:554/a/trackID=1", Sdp.resolve("rtsp://h:554/a/", "trackID=1"))
        assertEquals("rtsp://h:554/a", Sdp.resolve("rtsp://h:554/a", "*"))
        assertEquals("rtsp://q/z", Sdp.resolve("rtsp://h/a", "rtsp://q/z"))
        assertEquals("rtsp://h:554/track1", Sdp.resolve("rtsp://h:554/a/b", "/track1"))
    }

    @Test fun picture_size_comes_out_of_the_sps() {
        assertEquals(Pair(640, 480), H264Sps.size(hex("6742c016da0280f6c044000003000400000300503c58ba80")))
        assertEquals(Pair(1920, 1080), H264Sps.size(hex("67640028acd940780227e5c044000003000400000300283c60c658"))) // cropped from 1088
        assertTrue(H264Sps.size(byteArrayOf(1, 2)) == null)
    }

    // ---- RTP -> pictures -------------------------------------------------------------------

    private fun rtp(seq: Int, ts: Long, marker: Boolean, payload: ByteArray): ByteArray {
        val h = ByteArray(12)
        h[0] = 0x80.toByte(); h[1] = ((if (marker) 0x80 else 0) or 96).toByte()
        h[2] = (seq shr 8).toByte(); h[3] = seq.toByte()
        h[4] = (ts shr 24).toByte(); h[5] = (ts shr 16).toByte(); h[6] = (ts shr 8).toByte(); h[7] = ts.toByte()
        return h + payload
    }

    @Test fun small_and_split_units_are_joined_into_pictures() {
        val got = ArrayList<Pair<ByteArray, Boolean>>()
        val d = H264Depacketizer { data, key -> got.add(Pair(data, key)) }
        val sps = byteArrayOf(0x67, 1, 2, 3); val pps = byteArrayOf(0x68, 9, 8)
        val big = ByteArray(10) { (it + 1).toByte() }; big[0] = 0x65 // IDR in pieces
        val p1 = rtp(1, 1000, false, sps); val p2 = rtp(2, 1000, false, pps)
        val ind = ((big[0].toInt() and 0xE0) or 28).toByte()
        val f1 = rtp(3, 1000, false, byteArrayOf(ind, (0x80 or 5).toByte()) + big.copyOfRange(1, 5))
        val f2 = rtp(4, 1000, true, byteArrayOf(ind, (0x40 or 5).toByte()) + big.copyOfRange(5, 10))
        for (p in listOf(p1, p2, f1, f2)) d.feed(p, 0, p.size)
        assertEquals(1, got.size); assertTrue(got[0].second)
        val expect = byteArrayOf(0, 0, 0, 1) + sps + byteArrayOf(0, 0, 0, 1) + pps + byteArrayOf(0, 0, 0, 1) + big
        assertTrue(got[0].first.contentEquals(expect))
        assertTrue(d.sps!!.contentEquals(sps)); assertTrue(d.pps!!.contentEquals(pps))
        // a following non-key picture; STAP-A with two units; the new time stamp flushes without a marker
        val stap = byteArrayOf(24, 0, 2, 0x41, 7, 0, 3, 0x41, 5, 6)
        val s1 = rtp(5, 4000, false, stap); val s2 = rtp(6, 7000, true, byteArrayOf(0x41, 1))
        d.feed(s1, 0, s1.size); d.feed(s2, 0, s2.size)
        assertEquals(3, got.size); assertTrue(!got[1].second)
        assertEquals(4 + 2 + 4 + 3, got[1].first.size) // two start codes + a 2-byte and a 3-byte unit
    }

    @Test fun a_lost_piece_drops_that_unit_only() {
        val got = ArrayList<Pair<ByteArray, Boolean>>()
        val d = H264Depacketizer { data, key -> got.add(Pair(data, key)) }
        val ind = ((0x65 and 0xE0) or 28).toByte()
        val a = rtp(1, 100, false, byteArrayOf(ind, (0x80 or 5).toByte(), 1, 2))
        val c = rtp(3, 100, true, byteArrayOf(ind, (0x40 or 5).toByte(), 5, 6)) // piece 2 never arrived
        d.feed(a, 0, a.size); d.feed(c, 0, c.size)
        assertEquals(0, got.size)
        val ok = rtp(4, 200, true, byteArrayOf(0x41, 7))
        d.feed(ok, 0, ok.size)
        assertEquals(1, got.size)
    }

    // ---- other helpers ---------------------------------------------------------------------

    @Test fun nv21_copy_with_shrink() {
        val w = 8; val h = 4
        val y = ByteBuffer.wrap(ByteArray(w * h) { it.toByte() })
        val u = ByteBuffer.wrap(ByteArray(w * h / 4) { (100 + it).toByte() })
        val v = ByteBuffer.wrap(ByteArray(w * h / 4) { (200 + it).toByte() })
        val out = ByteArray(Yuv.outSize(w, h, 1))
        val (ow, oh) = Yuv.nv21(w, h, 0, 0, 1, y, w, 1, u, w / 2, 1, v, w / 2, 1, out)
        assertEquals(8, ow); assertEquals(4, oh)
        assertEquals(0, out[0].toInt()); assertEquals(31, out[31].toInt())
        assertEquals(200, out[32].toInt() and 0xFF); assertEquals(100, out[33].toInt() and 0xFF) // V then U
        val half = ByteArray(Yuv.outSize(w, h, 2))
        val (hw, hh) = Yuv.nv21(w, h, 0, 0, 2, y, w, 1, u, w / 2, 1, v, w / 2, 1, half)
        assertEquals(4, hw); assertEquals(2, hh)
        assertEquals(2, half[1].toInt()); assertEquals(16, half[4].toInt())
        assertEquals(1, Yuv.stepFor(640, 480)); assertEquals(2, Yuv.stepFor(1920, 1080)); assertEquals(4, Yuv.stepFor(3840, 2160))
    }

    @Test fun onvif_answer_and_probe() {
        val xml = "<e:Envelope xmlns:d=\"x\"><e:Body><d:ProbeMatches><d:ProbeMatch><d:Scopes>onvif://www.onvif.org/name/Tapo_C200 onvif://www.onvif.org/hardware/C200 onvif://www.onvif.org/type/video_encoder</d:Scopes>" +
            "<d:XAddrs>http://192.168.0.77:2020/onvif/device_service http://[fe80::1]/x</d:XAddrs></d:ProbeMatch></d:ProbeMatches></e:Body></e:Envelope>"
        val hit = Onvif.parse(xml)!!
        assertEquals("192.168.0.77", hit.host)
        assertTrue(hit.hint, hit.hint.contains("Tapo_C200") && hit.hint.contains("C200"))
        assertTrue(Onvif.parse("<x/>") == null)
        assertTrue(Onvif.probeMessage("abc").contains("NetworkVideoTransmitter"))
    }

    @Test fun path_guesses_follow_the_maker() {
        assertEquals("/Streaming/Channels/102", RtspPaths.candidates("Hikvision DS-2CD").first())
        assertTrue(RtspPaths.candidates("amcrest").first().startsWith("/cam/realmonitor"))
        assertEquals("/h264Preview_01_sub", RtspPaths.candidates("Reolink").first())
        assertTrue(RtspPaths.candidates("").size == RtspPaths.candidates("").toSet().size)
    }
}
