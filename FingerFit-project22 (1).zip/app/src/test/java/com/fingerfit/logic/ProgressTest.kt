package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class ProgressTest {
    private val today = LocalDate.of(2026, 11, 12)

    @Test
    fun days_are_listed_oldest_first_and_sums_are_right() {
        val acts = listOf(
            Act(today, 600, 20), Act(today, 90, 10), Act(today.minusDays(2), 1200, 30),
        )
        val r = Progress.perDay(acts, today, 7)
        assertEquals(7, r.size)
        assertEquals(today, r.last().date)
        assertEquals(today.minusDays(6), r.first().date)
        assertEquals(12, r.last().minutes) // 690 s = 11.5 min -> 12
        assertEquals(30, r.last().reps)
        assertEquals(2, r.last().sessions)
        assertEquals(20, r[4].minutes)
        assertEquals(0, r[5].minutes)
    }

    @Test
    fun a_very_short_session_still_counts_one_minute() {
        val r = Progress.perDay(listOf(Act(today, 5, 3)), today, 3)
        assertEquals(1, r.last().minutes)
        assertTrue(r.last().active)
    }

    @Test
    fun streak_counts_back_and_forgives_an_empty_today() {
        val acts = listOf(Act(today.minusDays(1), 60, 5), Act(today.minusDays(2), 60, 5), Act(today.minusDays(4), 60, 5))
        assertEquals(2, Progress.streak(acts, today))
        assertEquals(3, Progress.streak(acts + Act(today, 60, 5), today))
        assertEquals(0, Progress.streak(emptyList(), today))
        assertEquals(0, Progress.streak(listOf(Act(today.minusDays(3), 60, 5)), today))
    }

    @Test
    fun ring_is_limited_between_zero_and_one() {
        assertTrue(Math.abs(Progress.ring(15, 30) - 0.5f) < 0.001f)
        assertTrue(Math.abs(Progress.ring(60, 30) - 1f) < 0.001f)
        assertTrue(Math.abs(Progress.ring(10, 0)) < 0.001f)
    }
}
