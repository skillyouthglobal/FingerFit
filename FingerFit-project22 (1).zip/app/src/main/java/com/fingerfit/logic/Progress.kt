package com.fingerfit.logic

import java.time.LocalDate

/** One finished activity: a workout or a walk. */
class Act(val date: LocalDate, val seconds: Int, val reps: Int)

/** What happened on one day. */
class DayStat(val date: LocalDate, val minutes: Int, val reps: Int, val sessions: Int) {
    val active: Boolean get() = sessions > 0
}

/** Pure helpers for the Progress screen and the Home ring. */
object Progress {

    /** One entry per day for the last [days] days, oldest first, the last one being [today]. */
    fun perDay(acts: List<Act>, today: LocalDate, days: Int): List<DayStat> {
        val out = ArrayList<DayStat>()
        for (i in days - 1 downTo 0) {
            val d = today.minusDays(i.toLong())
            val day = acts.filter { it.date == d }
            val sec = day.sumOf { it.seconds }
            // anything done counts as at least one minute, so a short session is never shown as nothing
            val min = if (day.isEmpty()) 0 else maxOf(1, (sec + 30) / 60)
            out.add(DayStat(d, min, day.sumOf { it.reps }, day.size))
        }
        return out
    }

    /** Days in a row with some activity, counted back from today. Today may still be empty without breaking the streak. */
    fun streak(acts: List<Act>, today: LocalDate): Int {
        val dates = acts.map { it.date }.toSet()
        var d = if (today in dates) today else today.minusDays(1)
        var n = 0
        while (d in dates) {
            n++
            d = d.minusDays(1)
        }
        return n
    }

    /** Share of today's activity goal reached, from 0 to 1. */
    fun ring(minutesToday: Int, goalMinutes: Int): Float {
        if (goalMinutes <= 0) return 0f
        return (minutesToday.toFloat() / goalMinutes).coerceIn(0f, 1f)
    }
}
