package com.fingerfit.logic

import java.io.ByteArrayOutputStream
import java.net.URLDecoder
import java.security.MessageDigest

/** Pure RTSP helpers (no Android needed, so they can be tested): address, login, SDP, H.264 parts. */

/** An RTSP address split into its parts. [path] always starts with "/" and may carry a ?query. */
data class RtspTarget(val host: String, val port: Int, val path: String, val user: String = "", val pass: String = "") {

    /** The address without any login (this is what goes into the request line). */
    fun plainUrl(): String = "rtsp://$host:$port$path"

    /** The address with the login written in it (what the app stores and shows to the camera layer). */
    fun fullUrl(): String {
        if (user.isEmpty()) return plainUrl()
        val u = java.net.URLEncoder.encode(user, "UTF-8").replace("+", "%20")
        val p = java.net.URLEncoder.encode(pass, "UTF-8").replace("+", "%20")
        return "rtsp://$u:$p@$host:$port$path"
    }

    fun withPath(p: String) = copy(path = if (p.startsWith("/")) p else "/$p")
    fun withLogin(u: String, p: String) = copy(user = u, pass = p)

    companion object {
        fun parse(url: String): RtspTarget? {
            val t = url.trim()
            if (!t.startsWith("rtsp://", ignoreCase = true)) return null
            val rest = t.substring(7)
            val slash = rest.indexOf('/')
            val authority = if (slash >= 0) rest.substring(0, slash) else rest
            val path = if (slash >= 0) rest.substring(slash) else "/"
            val at = authority.lastIndexOf('@')
            val info = if (at >= 0) authority.substring(0, at) else ""
            val hostPort = if (at >= 0) authority.substring(at + 1) else authority
            val host = hostPort.substringBefore(':')
            if (host.isEmpty()) return null
            val port = if (hostPort.contains(':')) hostPort.substringAfter(':').toIntOrNull() ?: return null else 554
            if (port !in 1..65535) return null
            var user = ""
            var pass = ""
            if (info.isNotEmpty()) {
                user = dec(info.substringBefore(':'))
                pass = if (info.contains(':')) dec(info.substringAfter(':')) else ""
            }
            return RtspTarget(host, port, path.ifEmpty { "/" }, user, pass)
        }

        private fun dec(s: String): String = try {
            URLDecoder.decode(s.replace("+", "%2B"), "UTF-8")
        } catch (e: Exception) {
            s
        }
    }
}

/** Where cameras of the common makers keep their picture. Smaller pictures (sub streams) first: they are quicker. */
object RtspPaths {
    private val hik = listOf("/Streaming/Channels/102", "/Streaming/Channels/101")
    private val dahua = listOf("/cam/realmonitor?channel=1&subtype=1", "/cam/realmonitor?channel=1&subtype=0")
    private val tapo = listOf("/stream2", "/stream1")
    private val reolink = listOf("/h264Preview_01_sub", "/h264Preview_01_main")
    private val generic = listOf(
        "/stream2", "/stream1", "/live/ch1", "/live/ch0", "/11", "/12", "/onvif2", "/onvif1",
        "/media/video2", "/media/video1", "/videoSub", "/videoMain", "/axis-media/media.amp",
        "/ch0_1.h264", "/h264", "/live", "/0", "/1", "/",
    )

    /** Addresses to try, best guess first. [hint] is any text the camera told about itself (maker, model). */
    fun candidates(hint: String = ""): List<String> {
        val h = hint.lowercase()
        val first = ArrayList<String>()
        if (h.contains("hik") || h.contains("ds-")) first += hik
        if (h.contains("dahua") || h.contains("amcrest") || h.contains("ipc-")) first += dahua
        if (h.contains("tapo") || h.contains("tp-link") || h.contains("tplink")) first += tapo
        if (h.contains("reolink")) first += reolink
        if (h.contains("kinetro")) first += listOf("/stream1", "/stream2")
        return (first + hik + dahua + reolink + generic).distinct()
    }
}

/** A login the camera asked for (Basic or Digest, RFC 2617). */
class RtspAuth(private val user: String, private val pass: String, private val cnonce: () -> String = { randomHex() }) {
    private var digest = false
    private var basic = false
    private var realm = ""
    private var nonce = ""
    private var opaque: String? = null
    private var qopAuth = false
    private var nc = 0

    val ready: Boolean get() = digest || basic

    /** Reads the camera's WWW-Authenticate lines. Digest is preferred when the camera offers both. */
    fun challenge(headers: List<String>) {
        var d: String? = null
        var b: String? = null
        for (h in headers) {
            val v = h.trim()
            if (v.startsWith("Digest", ignoreCase = true)) d = v.substring(6)
            else if (v.startsWith("Basic", ignoreCase = true)) b = v.substring(5)
        }
        if (d != null) {
            val p = params(d)
            realm = p["realm"] ?: ""
            nonce = p["nonce"] ?: ""
            opaque = p["opaque"]
            qopAuth = (p["qop"] ?: "").split(',').any { it.trim().equals("auth", ignoreCase = true) }
            nc = 0
            digest = true
            basic = false
        } else if (b != null) {
            digest = false
            basic = true
        }
    }

    /** The Authorization header value for one request, or null when no login is known yet. */
    fun header(method: String, uri: String): String? {
        if (digest) {
            val ha1 = md5("$user:$realm:$pass")
            val ha2 = md5("$method:$uri")
            val sb = StringBuilder("Digest username=\"$user\", realm=\"$realm\", nonce=\"$nonce\", uri=\"$uri\", ")
            if (qopAuth) {
                nc++
                val ncs = String.format("%08x", nc)
                val cn = cnonce()
                val resp = md5("$ha1:$nonce:$ncs:$cn:auth:$ha2")
                sb.append("response=\"$resp\", qop=auth, nc=$ncs, cnonce=\"$cn\"")
            } else {
                sb.append("response=\"${md5("$ha1:$nonce:$ha2")}\"")
            }
            opaque?.let { sb.append(", opaque=\"$it\"") }
            return sb.toString()
        }
        if (basic) return "Basic " + java.util.Base64.getEncoder().encodeToString("$user:$pass".toByteArray())
        return null
    }

    private fun params(s: String): Map<String, String> {
        val m = HashMap<String, String>()
        Regex("(\\w+)=(\"([^\"]*)\"|[^,\\s]*)").findAll(s).forEach {
            m[it.groupValues[1].lowercase()] = if (it.groupValues[3].isNotEmpty() || it.groupValues[2].startsWith("\"")) it.groupValues[3] else it.groupValues[2]
        }
        return m
    }

    companion object {
        fun md5(s: String): String {
            val d = MessageDigest.getInstance("MD5").digest(s.toByteArray())
            val sb = StringBuilder()
            for (b in d) sb.append(String.format("%02x", b.toInt() and 0xFF))
            return sb.toString()
        }

        fun randomHex(): String {
            val r = java.util.Random()
            return String.format("%08x", r.nextInt())
        }
    }
}

/** The video part of a camera's SDP description. */
class SdpVideo(
    val codec: String,          // "H264", "H265" ...
    val payloadType: Int,
    val control: String?,       // the track address (relative or absolute), null = use the main address
    val sps: ByteArray?,
    val pps: ByteArray?,
)

object Sdp {
    /** The first video track of the description, or null when there is none. */
    fun parseVideo(sdp: String): SdpVideo? {
        var inVideo = false
        var pt = -1
        var codec = ""
        var control: String? = null
        var sps: ByteArray? = null
        var pps: ByteArray? = null
        var seen = false
        for (raw in sdp.split('\n')) {
            val line = raw.trim()
            if (line.startsWith("m=")) {
                if (inVideo) break
                inVideo = line.startsWith("m=video")
                if (inVideo) {
                    seen = true
                    pt = line.split(' ').getOrNull(3)?.toIntOrNull() ?: -1
                }
                continue
            }
            if (!inVideo) continue
            when {
                line.startsWith("a=rtpmap:") -> {
                    val v = line.substring(9)
                    val num = v.substringBefore(' ').toIntOrNull()
                    if (num == pt) codec = v.substringAfter(' ').substringBefore('/').uppercase()
                }
                line.startsWith("a=control:") -> control = line.substring(10).trim()
                line.startsWith("a=fmtp:") -> {
                    val v = line.substring(7)
                    if (v.substringBefore(' ').toIntOrNull() == pt) {
                        val sp = v.substringAfter(' ').split(';').map { it.trim() }
                            .firstOrNull { it.startsWith("sprop-parameter-sets=", ignoreCase = true) }
                        if (sp != null) {
                            val parts = sp.substringAfter('=').split(',')
                            try {
                                val dec = java.util.Base64.getDecoder()
                                if (parts.isNotEmpty() && parts[0].isNotEmpty()) sps = dec.decode(parts[0])
                                if (parts.size > 1 && parts[1].isNotEmpty()) pps = dec.decode(parts[1])
                            } catch (e: Exception) {
                            }
                        }
                    }
                }
            }
        }
        if (!seen) return null
        if (codec.isEmpty() && pt == 26) codec = "JPEG"
        return SdpVideo(codec, pt, control, sps, pps)
    }

    /** The full address of a track. */
    fun resolve(base: String, control: String?): String {
        if (control == null || control == "*" || control.isEmpty()) return base
        if (control.startsWith("rtsp://", ignoreCase = true)) return control
        val b = base.trimEnd('/')
        return if (control.startsWith("/")) b.substringBefore("://") + "://" + b.substringAfter("://").substringBefore('/') + control
        else "$b/$control"
    }
}

/** Reads the picture size out of an H.264 sequence parameter set (SPS). */
object H264Sps {

    private class Bits(val d: ByteArray) {
        var pos = 0
        fun bit(): Int {
            if (pos >= d.size * 8) throw IllegalStateException("end")
            val v = (d[pos shr 3].toInt() shr (7 - (pos and 7))) and 1
            pos++
            return v
        }
        fun bits(n: Int): Int {
            var v = 0
            repeat(n) { v = (v shl 1) or bit() }
            return v
        }
        fun ue(): Int {
            var zeros = 0
            while (bit() == 0) {
                zeros++
                if (zeros > 31) throw IllegalStateException("bad")
            }
            return if (zeros == 0) 0 else ((1 shl zeros) - 1 + bits(zeros))
        }
        fun se(): Int {
            val k = ue()
            return if (k and 1 == 1) (k + 1) / 2 else -(k / 2)
        }
    }

    /** Removes the 0x03 bytes the stream adds after two zeros. */
    private fun unescape(b: ByteArray): ByteArray {
        val o = ByteArrayOutputStream()
        var zeros = 0
        for (x in b) {
            if (zeros >= 2 && x.toInt() == 3) {
                zeros = 0
                continue
            }
            o.write(x.toInt())
            zeros = if (x.toInt() == 0) zeros + 1 else 0
        }
        return o.toByteArray()
    }

    /** Width and height in pixels of the SPS NAL unit (with its 1-byte header), or null if it cannot be read. */
    fun size(sps: ByteArray): Pair<Int, Int>? {
        if (sps.size < 5) return null
        try {
            val r = Bits(unescape(sps.copyOfRange(1, sps.size)))
            val profile = r.bits(8)
            r.bits(8)
            r.bits(8)
            r.ue()
            var chroma = 1
            if (profile in intArrayOf(100, 110, 122, 244, 44, 83, 86, 118, 128, 138, 139, 134, 135)) {
                chroma = r.ue()
                if (chroma == 3) r.bit()
                r.ue()
                r.ue()
                r.bit()
                if (r.bit() == 1) {
                    val lists = if (chroma != 3) 8 else 12
                    for (i in 0 until lists) {
                        if (r.bit() == 1) {
                            val size = if (i < 6) 16 else 64
                            var last = 8
                            var next = 8
                            for (j in 0 until size) {
                                if (next != 0) {
                                    next = (last + r.se() + 256) % 256
                                }
                                last = if (next == 0) last else next
                            }
                        }
                    }
                }
            }
            r.ue()
            val pocType = r.ue()
            if (pocType == 0) r.ue()
            else if (pocType == 1) {
                r.bit()
                r.se()
                r.se()
                val n = r.ue()
                repeat(n) { r.se() }
            }
            r.ue()
            r.bit()
            val wMbs = r.ue() + 1
            val hMapUnits = r.ue() + 1
            val frameMbsOnly = r.bit()
            if (frameMbsOnly == 0) r.bit()
            r.bit()
            var cl = 0
            var cr = 0
            var ct = 0
            var cb = 0
            if (r.bit() == 1) {
                cl = r.ue()
                cr = r.ue()
                ct = r.ue()
                cb = r.ue()
            }
            val cropX = if (chroma == 0) 1 else if (chroma == 3) 1 else 2
            val cropY = (if (chroma == 1) 2 else 1) * (2 - frameMbsOnly)
            val w = wMbs * 16 - (cl + cr) * cropX
            val h = (2 - frameMbsOnly) * hMapUnits * 16 - (ct + cb) * cropY
            if (w <= 0 || h <= 0 || w > 8192 || h > 8192) return null
            return Pair(w, h)
        } catch (e: Exception) {
            return null
        }
    }
}

/**
 * Turns RTP packets of an H.264 stream (RFC 6184) into whole pictures ("access units") in Annex-B form
 * (each NAL unit behind 00 00 00 01), which is what the phone's video decoder wants.
 */
class H264Depacketizer(private val onUnit: (data: ByteArray, key: Boolean) -> Unit) {
    private val au = ByteArrayOutputStream()
    private var auKey = false
    private var auTime = -1L
    private var fu: ByteArrayOutputStream? = null
    private var lastSeq = -1

    /** In-band parameter sets seen in the stream (cameras that leave them out of the SDP). */
    var sps: ByteArray? = null
        private set
    var pps: ByteArray? = null
        private set

    /** One whole RTP packet. */
    fun feed(p: ByteArray, off: Int, len: Int) {
        if (len < 13) return
        val b0 = p[off].toInt() and 0xFF
        if ((b0 shr 6) != 2) return
        val cc = b0 and 0x0F
        val ext = (b0 and 0x10) != 0
        val pad = (b0 and 0x20) != 0
        val b1 = p[off + 1].toInt() and 0xFF
        val marker = (b1 and 0x80) != 0
        val seq = ((p[off + 2].toInt() and 0xFF) shl 8) or (p[off + 3].toInt() and 0xFF)
        val ts = ((p[off + 4].toLong() and 0xFF) shl 24) or ((p[off + 5].toLong() and 0xFF) shl 16) or
            ((p[off + 6].toLong() and 0xFF) shl 8) or (p[off + 7].toLong() and 0xFF)
        var start = off + 12 + 4 * cc
        var end = off + len
        if (ext) {
            if (start + 4 > end) return
            val words = ((p[start + 2].toInt() and 0xFF) shl 8) or (p[start + 3].toInt() and 0xFF)
            start += 4 + 4 * words
        }
        if (pad && end > off) end -= (p[end - 1].toInt() and 0xFF)
        if (start >= end) return

        // a lost packet inside a split NAL unit ruins that unit
        if (lastSeq >= 0 && seq != ((lastSeq + 1) and 0xFFFF)) {
            fu = null
        }
        lastSeq = seq

        if (auTime >= 0 && ts != auTime) flush()
        auTime = ts

        val type = p[start].toInt() and 0x1F
        when {
            type in 1..23 -> nal(p, start, end - start)
            type == 24 -> { // several small NAL units in one packet
                var i = start + 1
                while (i + 2 <= end) {
                    val sz = ((p[i].toInt() and 0xFF) shl 8) or (p[i + 1].toInt() and 0xFF)
                    i += 2
                    if (sz <= 0 || i + sz > end) break
                    nal(p, i, sz)
                    i += sz
                }
            }
            type == 28 -> { // one big NAL unit cut in pieces
                if (end - start < 3) return
                val ind = p[start].toInt() and 0xFF
                val hdr = p[start + 1].toInt() and 0xFF
                val s = (hdr and 0x80) != 0
                val e = (hdr and 0x40) != 0
                if (s) {
                    val o = ByteArrayOutputStream()
                    o.write((ind and 0xE0) or (hdr and 0x1F))
                    fu = o
                }
                val o = fu
                if (o != null) {
                    o.write(p, start + 2, end - start - 2)
                    if (e) {
                        val bytes = o.toByteArray()
                        fu = null
                        nal(bytes, 0, bytes.size)
                    }
                }
            }
        }
        if (marker) flush()
    }

    private fun nal(b: ByteArray, off: Int, len: Int) {
        if (len < 1) return
        val t = b[off].toInt() and 0x1F
        if (t == 5) auKey = true
        if (t == 7) sps = b.copyOfRange(off, off + len)
        if (t == 8) pps = b.copyOfRange(off, off + len)
        au.write(0)
        au.write(0)
        au.write(0)
        au.write(1)
        au.write(b, off, len)
    }

    private fun flush() {
        if (au.size() > 0) {
            val d = au.toByteArray()
            val k = auKey
            au.reset()
            auKey = false
            onUnit(d, k)
        }
    }
}

/** Reads the answer of a probe of the camera's own announcement (ONVIF discovery). */
object Onvif {
    class Hit(val host: String, val address: String, val hint: String)

    /** The WS-Discovery probe message. */
    fun probeMessage(id: String): String =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?><e:Envelope xmlns:e=\"http://www.w3.org/2003/05/soap-envelope\" " +
            "xmlns:w=\"http://schemas.xmlsoap.org/ws/2004/08/addressing\" " +
            "xmlns:d=\"http://schemas.xmlsoap.org/ws/2005/04/discovery\" " +
            "xmlns:dn=\"http://www.onvif.org/ver10/network/wsdl\"><e:Header>" +
            "<w:MessageID>uuid:$id</w:MessageID>" +
            "<w:To>urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To>" +
            "<w:Action>http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action></e:Header>" +
            "<e:Body><d:Probe><d:Types>dn:NetworkVideoTransmitter</d:Types></d:Probe></e:Body></e:Envelope>"

    /** A camera from one answer message: its address and what it says about itself (maker, model). */
    fun parse(xml: String): Hit? {
        val xaddrs = Regex("<[^>]*XAddrs[^>]*>([^<]+)<", RegexOption.IGNORE_CASE).find(xml)?.groupValues?.get(1)?.trim() ?: return null
        val first = xaddrs.split(Regex("\\s+")).firstOrNull { it.startsWith("http") } ?: return null
        val host = first.substringAfter("://").substringBefore('/').substringBefore(':')
        if (host.isEmpty()) return null
        val scopes = Regex("<[^>]*Scopes[^>]*>([^<]+)<", RegexOption.IGNORE_CASE).find(xml)?.groupValues?.get(1) ?: ""
        val hint = scopes.split(Regex("\\s+")).filter { it.contains("/name/") || it.contains("/hardware/") }
            .joinToString(" ") { java.net.URLDecoder.decode(it.substringAfterLast('/'), "UTF-8") }
        return Hit(host, first, hint)
    }
}

/** Turns the phone's decoded video planes into the NV21 bytes that Android can compress to a JPEG picture. */
object Yuv {
    /**
     * Copies a [w] x [h] area starting at ([left], [top]) while keeping every [step]-th pixel (a cheap shrink).
     * The three planes are given as accessors so this works with any stride; [uPix] / [vPix] are the pixel steps.
     */
    fun nv21(
        w: Int, h: Int, left: Int, top: Int, step: Int,
        y: java.nio.ByteBuffer, yRow: Int, yPix: Int,
        u: java.nio.ByteBuffer, uRow: Int, uPix: Int,
        v: java.nio.ByteBuffer, vRow: Int, vPix: Int,
        out: ByteArray,
    ): Pair<Int, Int> {
        val ow = (w / step) and 1.inv()
        val oh = (h / step) and 1.inv()
        var o = 0
        for (r in 0 until oh) {
            val base = (top + r * step) * yRow + left * yPix
            for (c in 0 until ow) out[o++] = y.get(base + c * step * yPix)
        }
        for (r in 0 until oh / 2) {
            val cy = (top + r * step) / 2
            for (c in 0 until ow / 2) {
                val cx = (left + c * step) / 2
                out[o++] = v.get(cy * vRow + cx * vPix)
                out[o++] = u.get(cy * uRow + cx * uPix)
            }
        }
        return Pair(ow, oh)
    }

    fun outSize(w: Int, h: Int, step: Int): Int {
        val ow = (w / step) and 1.inv()
        val oh = (h / step) and 1.inv()
        return ow * oh * 3 / 2
    }

    /** How much to shrink so the longest side stays near 960 pixels. */
    fun stepFor(w: Int, h: Int): Int {
        val big = maxOf(w, h)
        return when {
            big >= 2400 -> 4
            big >= 1200 -> 2
            else -> 1
        }
    }
}
