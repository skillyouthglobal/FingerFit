package com.fingerfit.logic

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket

/** Why an RTSP camera could not be used. */
enum class RtspFail { LOGIN, NOT_FOUND, CODEC, NETWORK, PROTOCOL }

class RtspException(val kind: RtspFail, message: String, val codec: String = "") : IOException(message)

/** What a quick look at one camera address found. */
class RtspProbe(val ok: Boolean, val fail: RtspFail?, val codec: String = "")

/**
 * A small RTSP client for H.264 cameras. Pictures come over the same connection (TCP), so no extra
 * ports are needed. It runs on the calling thread until [close] is called or the camera stops.
 * No Android classes are used here, so it can be tested on a computer.
 */
class RtspClient(
    private val target: RtspTarget,
    private val connectMs: Int = 3000,
    private val readMs: Int = 6000,
) {
    interface Listener {
        /** Called once, before the first picture: the codec set-up data and the picture size. */
        fun onStream(sps: ByteArray?, pps: ByteArray?, width: Int, height: Int)

        /** One whole picture, ready for the decoder. */
        fun onUnit(data: ByteArray, key: Boolean)
    }

    @Volatile private var sock: Socket? = null
    @Volatile private var closed = false
    private var input: InputStream? = null
    private var cseq = 0
    private var session: String? = null
    private val auth = RtspAuth(target.user, target.pass)
    private var baseUrl = target.plainUrl()

    fun close() {
        closed = true
        try {
            sock?.close()
        } catch (e: Exception) {
        }
    }

    private class Reply(val code: Int, val headers: Map<String, String>, val authLines: List<String>, val body: String)

    // ------------------------------------------------------------------ one question and its answer

    private fun send(method: String, url: String, extra: List<String> = emptyList()): Int {
        val sb = StringBuilder()
        sb.append(method).append(' ').append(url).append(" RTSP/1.0\r\n")
        val n = ++cseq
        sb.append("CSeq: ").append(n).append("\r\n")
        sb.append("User-Agent: Kinetro\r\n")
        session?.let { sb.append("Session: ").append(it).append("\r\n") }
        auth.header(method, url)?.let { sb.append("Authorization: ").append(it).append("\r\n") }
        for (e in extra) sb.append(e).append("\r\n")
        sb.append("\r\n")
        val out = sock!!.getOutputStream()
        out.write(sb.toString().toByteArray())
        out.flush()
        return n
    }

    private fun readLine(ins: InputStream): String? {
        val b = ByteArrayOutputStream()
        while (true) {
            val c = ins.read()
            if (c < 0) return if (b.size() == 0) null else b.toString("UTF-8")
            if (c == '\n'.code) break
            if (c != '\r'.code) b.write(c)
            if (b.size() > 16384) throw RtspException(RtspFail.PROTOCOL, "Line too long")
        }
        return b.toString("UTF-8")
    }

    /** Reads one answer (after its first line has been read), including its body. */
    private fun readReply(ins: InputStream, statusLine: String): Reply {
        val code = statusLine.split(' ').getOrNull(1)?.toIntOrNull() ?: throw RtspException(RtspFail.PROTOCOL, "Bad answer")
        val headers = HashMap<String, String>()
        val authLines = ArrayList<String>()
        while (true) {
            val l = readLine(ins) ?: throw RtspException(RtspFail.NETWORK, "Camera closed the connection")
            if (l.isEmpty()) break
            val i = l.indexOf(':')
            if (i <= 0) continue
            val k = l.substring(0, i).trim().lowercase()
            val v = l.substring(i + 1).trim()
            if (k == "www-authenticate") authLines.add(v) else headers[k] = v
        }
        val len = headers["content-length"]?.toIntOrNull() ?: 0
        var body = ""
        if (len > 0) {
            val buf = ByteArray(len)
            var got = 0
            while (got < len) {
                val n = ins.read(buf, got, len - got)
                if (n < 0) throw RtspException(RtspFail.NETWORK, "Camera closed the connection")
                got += n
            }
            body = String(buf, Charsets.UTF_8)
        }
        return Reply(code, headers, authLines, body)
    }

    /** Sends a request, answers a login question once, and returns the final answer. */
    private fun ask(method: String, url: String, extra: List<String> = emptyList()): Reply {
        val ins = input!!
        var tries = 0
        while (true) {
            send(method, url, extra)
            var line = readLine(ins) ?: throw RtspException(RtspFail.NETWORK, "Camera closed the connection")
            // data of a running stream may still be in the way: skip it
            while (!line.startsWith("RTSP/")) {
                line = readLine(ins) ?: throw RtspException(RtspFail.NETWORK, "Camera closed the connection")
            }
            val r = readReply(ins, line)
            if (r.code == 401) {
                if (target.user.isEmpty() || tries >= 1) throw RtspException(RtspFail.LOGIN, "Login needed or wrong")
                auth.challenge(r.authLines)
                if (!auth.ready) throw RtspException(RtspFail.LOGIN, "Login needed or wrong")
                tries++
                continue
            }
            return r
        }
    }

    private fun connect() {
        val s = Socket()
        sock = s
        try {
            s.connect(InetSocketAddress(target.host, target.port), connectMs)
        } catch (e: IOException) {
            throw RtspException(RtspFail.NETWORK, "Cannot reach the camera")
        }
        s.soTimeout = readMs
        s.tcpNoDelay = true
        input = BufferedInputStream(s.getInputStream(), 65536)
    }

    private class Described(val video: SdpVideo, val base: String)

    private fun describe(): Described {
        val r = ask("DESCRIBE", target.plainUrl(), listOf("Accept: application/sdp"))
        if (r.code == 404 || r.code == 454) throw RtspException(RtspFail.NOT_FOUND, "No picture at this address")
        if (r.code != 200) throw RtspException(RtspFail.PROTOCOL, "Camera answered ${r.code}")
        val video = Sdp.parseVideo(r.body) ?: throw RtspException(RtspFail.PROTOCOL, "No video in the stream")
        if (video.codec != "H264") throw RtspException(RtspFail.CODEC, "Video is ${video.codec}", video.codec)
        val base = r.headers["content-base"] ?: r.headers["content-location"]?.takeIf { it.startsWith("rtsp://") } ?: target.plainUrl()
        return Described(video, base)
    }

    // ------------------------------------------------------------------ public

    /** Only asks whether this address gives an H.264 picture (nothing is played). */
    fun probe(): RtspProbe {
        return try {
            connect()
            describe()
            RtspProbe(true, null)
        } catch (e: RtspException) {
            RtspProbe(false, e.kind, e.codec)
        } catch (e: IOException) {
            RtspProbe(false, RtspFail.NETWORK)
        } finally {
            close()
        }
    }

    /** Connects and plays until [close] is called or the camera stops. Throws [RtspException] on trouble. */
    fun run(listener: Listener) {
        try {
            connect()
            val d = describe()
            baseUrl = d.base
            val trackUrl = Sdp.resolve(d.base, d.video.control)

            var width = 0
            var height = 0
            d.video.sps?.let { s -> H264Sps.size(s)?.let { width = it.first; height = it.second } }

            val setup = ask("SETUP", trackUrl, listOf("Transport: RTP/AVP/TCP;unicast;interleaved=0-1"))
            if (setup.code != 200) {
                throw RtspException(RtspFail.PROTOCOL, "Camera refused to send pictures (${setup.code})")
            }
            var rtpChannel = 0
            Regex("interleaved=(\\d+)").find(setup.headers["transport"] ?: "")?.let { rtpChannel = it.groupValues[1].toInt() }
            var timeoutSec = 60
            setup.headers["session"]?.let {
                session = it.substringBefore(';').trim()
                Regex("timeout=(\\d+)").find(it)?.let { m -> timeoutSec = m.groupValues[1].toInt() }
            }

            // The listener needs the set-up data first; hand it over as soon as it is known.
            var told = false
            fun tell(sps: ByteArray?, pps: ByteArray?) {
                if (told) return
                told = true
                var w = width
                var h = height
                if ((w == 0 || h == 0) && sps != null) H264Sps.size(sps)?.let { w = it.first; h = it.second }
                listener.onStream(sps, pps, w, h)
            }
            lateinit var dep: H264Depacketizer
            dep = H264Depacketizer { data, key ->
                if (!told) {
                    // from the description, or — when the camera leaves it out — from the stream itself
                    val s = dep.sps ?: d.video.sps
                    val p = dep.pps ?: d.video.pps
                    if (s != null && p != null) tell(s, p)
                }
                if (told) listener.onUnit(data, key)
            }
            if (d.video.sps != null && d.video.pps != null) tell(d.video.sps, d.video.pps)

            val play = ask("PLAY", baseUrl, listOf("Range: npt=0.000-"))
            if (play.code != 200) throw RtspException(RtspFail.PROTOCOL, "Camera would not start (${play.code})")

            val ins = input!!
            var lastKeep = System.currentTimeMillis()
            val keepEvery = (timeoutSec.coerceIn(10, 120) * 1000L) / 2
            val buf = ByteArray(65536)
            while (!closed) {
                val c = ins.read()
                if (c < 0) throw RtspException(RtspFail.NETWORK, "Camera stopped sending")
                if (c == '$'.code) {
                    val ch = ins.read()
                    val hi = ins.read()
                    val lo = ins.read()
                    if (ch < 0 || hi < 0 || lo < 0) throw RtspException(RtspFail.NETWORK, "Camera stopped sending")
                    val n = (hi shl 8) or lo
                    val data = if (n <= buf.size) buf else ByteArray(n)
                    var got = 0
                    while (got < n) {
                        val k = ins.read(data, got, n - got)
                        if (k < 0) throw RtspException(RtspFail.NETWORK, "Camera stopped sending")
                        got += k
                    }
                    if (ch == rtpChannel) dep.feed(data, 0, n)
                } else if (c == 'R'.code) {
                    // an answer (to our keep-alive): read it and forget it
                    val rest = readLine(ins) ?: break
                    readReply(ins, "R$rest")
                }
                val now = System.currentTimeMillis()
                if (now - lastKeep > keepEvery) {
                    lastKeep = now
                    try {
                        send("GET_PARAMETER", baseUrl)
                    } catch (e: IOException) {
                        throw RtspException(RtspFail.NETWORK, "Connection lost")
                    }
                }
            }
        } catch (e: RtspException) {
            if (closed) return
            throw e
        } catch (e: IOException) {
            if (closed) return
            throw RtspException(RtspFail.NETWORK, e.message ?: "Connection lost")
        } finally {
            try {
                if (!closed && sock?.isClosed == false) send("TEARDOWN", baseUrl)
            } catch (e: Exception) {
            }
            close()
        }
    }
}
