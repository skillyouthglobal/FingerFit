package com.fingerfit.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.LinkViewModel
import com.fingerfit.link.IpFound
import com.fingerfit.logic.IpCams
import com.fingerfit.logic.RtspTarget
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.remember
import androidx.compose.ui.text.input.PasswordVisualTransformation

/** All the ways to use another camera: a Wi-Fi / IP camera, or a second phone. */
@Composable
fun CameraHubScreen(link: LinkViewModel, onBack: () -> Unit, onPhones: () -> Unit, onWorkouts: () -> Unit) {
    BackHandler(onBack = onBack)
    val ip by link.ipUi.collectAsStateWithLifecycle()
    val preview by link.preview.collectAsStateWithLifecycle()
    val streamOk by link.streamOk.collectAsStateWithLifecycle()
    var address by rememberSaveable { mutableStateOf("") }
    var addressError by rememberSaveable { mutableStateOf<String?>(null) }
    var loginFor by remember { mutableStateOf<IpFound?>(null) }
    var loginUser by rememberSaveable { mutableStateOf("") }
    var loginPass by rememberSaveable { mutableStateOf("") }
    val last = remember(ip.running, ip.connecting) { link.lastCamera() }

    loginFor?.let { cam ->
        AlertDialog(
            onDismissRequest = { loginFor = null },
            title = { Text("Camera login") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(cam.label, fontSize = 13.sp)
                    OutlinedTextField(
                        value = loginUser, onValueChange = { loginUser = it.take(60) },
                        label = { Text("User name") }, singleLine = true,
                    )
                    OutlinedTextField(
                        value = loginPass, onValueChange = { loginPass = it.take(60) },
                        label = { Text("Password") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val t = RtspTarget.parse(cam.url)
                    loginFor = null
                    if (t != null) link.startIp(t.withLogin(loginUser, loginPass).fullUrl(), cam.label)
                }) { Text("Connect") }
            },
            dismissButton = { TextButton(onClick = { loginFor = null }) { Text("Cancel") } },
        )
    }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.systemBarsPadding()) {
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp)) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                Text("Cameras", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            }
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(
                    "Use a Wi-Fi camera fixed in your exercise room, or a second phone. No internet is needed.",
                    fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                if (ip.running || ip.connecting) {
                    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = HeroTint)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                if (ip.running) "● Connected: ${ip.name}" else "Connecting to ${ip.name}…",
                                fontWeight = FontWeight.Bold, fontSize = 16.sp,
                            )
                            val pic = preview
                            if (pic != null && ip.running) {
                                Image(
                                    bitmap = pic.asImageBitmap(), contentDescription = "Camera view",
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxWidth().height(200.dp).background(androidx.compose.ui.graphics.Color.Black, RoundedCornerShape(16.dp)),
                                )
                            }
                            if (ip.running && !streamOk) {
                                Text("Waiting for pictures from the camera…", fontSize = 13.sp)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(onClick = onWorkouts, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) {
                                    Text("Choose exercise", fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(onClick = { link.stop() }, shape = RoundedCornerShape(16.dp)) { Text("Disconnect") }
                            }
                        }
                    }
                }

                ip.error?.let {
                    Text(
                        it, color = MaterialTheme.colorScheme.error, fontSize = 14.sp,
                        modifier = Modifier.fillMaxWidth().background(androidx.compose.ui.graphics.Color(0xFFFDE8EA), RoundedCornerShape(16.dp)).padding(14.dp),
                    )
                }

                if (last != null && !ip.running && !ip.connecting) {
                    Button(
                        onClick = { link.startIp(last.first, last.second) },
                        modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp),
                    ) { Text("Connect again: ${last.second}", fontWeight = FontWeight.Bold) }
                }

                HubCard("Find Wi-Fi cameras") {
                    Text(
                        "Your phone and the camera must be on the same Wi-Fi (or the phone connected to the camera's own hotspot).",
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(
                        onClick = { if (ip.scanning) link.stopScanIp() else link.scanIp() },
                        modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp),
                    ) { Text(if (ip.scanning) "Stop searching" else "Find cameras", fontWeight = FontWeight.Bold) }
                    if (ip.scanning) {
                        LinearProgressIndicator(
                            progress = { if (ip.scanTotal > 0) ip.scanDone.toFloat() / ip.scanTotal else 0f },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Text("Searching… ${ip.scanDone} of ${ip.scanTotal}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (ip.scanMessage.isNotEmpty()) Text(ip.scanMessage, fontSize = 13.sp)
                    ip.found.forEach { cam ->
                        Row(
                            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp)).padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(cam.label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                if (cam.needsLogin) {
                                    Text("Needs a user name and password", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Button(
                                onClick = { if (cam.needsLogin) loginFor = cam else link.startIp(cam.url, cam.label) },
                                shape = RoundedCornerShape(14.dp),
                            ) { Text("Connect") }
                        }
                    }
                }

                HubCard("Type the camera address") {
                    OutlinedTextField(
                        value = address, onValueChange = { address = it.take(200); addressError = null },
                        label = { Text("Picture address (http or rtsp)") }, singleLine = true,
                        placeholder = { Text("192.168.0.105:8080/video") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        "With a password: http://user:password@192.168.0.105/video  or  rtsp://user:password@192.168.0.105/stream1",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    addressError?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
                    Button(
                        onClick = {
                            val url = IpCams.normalizeUrl(address)
                            if (url == null) addressError = "That does not look like a camera address."
                            else link.startIp(url, "Camera")
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp),
                    ) { Text("Connect", fontWeight = FontWeight.Bold) }
                }

                HubCard("No camera yet? Test for free") {
                    Text(
                        "1. On an old Android phone, install the free app \"IP Webcam\".\n2. Open it and tap \"Start server\".\n3. Put both phones on the same Wi-Fi, then tap \"Find cameras\" above.\n4. For the quickest response, in IP Webcam set Video resolution to 640x480 and quality to about 50%.",
                        fontSize = 13.sp, lineHeight = 19.sp,
                    )
                }

                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth().clickable(onClick = onPhones),
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("📲", fontSize = 28.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Use a second phone", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                "With the Kinetro app, or just a browser on the other phone.",
                                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Text("›", fontSize = 26.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun HubCard(title: String, content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            content()
        }
    }
}
