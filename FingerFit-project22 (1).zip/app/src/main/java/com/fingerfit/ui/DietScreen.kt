package com.fingerfit.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fingerfit.data.AppPrefs
import com.fingerfit.data.Profile
import com.fingerfit.logic.Health
import com.fingerfit.logic.Plans
import java.time.LocalDate

/**
 * The "Diet" tab. The layout of the food list and of adding a food is already here; the foods themselves
 * (with calories and photos) arrive in a later update and plug into the meal cards below.
 */
@Composable
fun DietScreen(profile: Profile?, onEditProfile: () -> Unit) {
    val context = LocalContext.current
    val today = LocalDate.now()
    var water by remember { mutableStateOf(AppPrefs.water(context, today.toString())) }
    var soon by remember { mutableStateOf(false) }
    val advice = profile?.let {
        Plans.calories(it.gender, it.weightKg, it.heightCm, Health.age(it.birth, today), it.goal)
    }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.statusBarsPadding()) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("Diet", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)

            if (profile == null) {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().clickable(onClick = onEditProfile),
                ) {
                    Text("Fill in your profile first (name, birth date, height, weight). Tap here.", modifier = Modifier.padding(18.dp))
                }
            } else {
                Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFD8F5E6))) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Today's food plan", fontSize = 14.sp, color = Color(0xFF3F4F70))
                        if (advice == null) {
                            Text(
                                "Calorie numbers are not given for people under 18. Children and teenagers grow fast, so please ask a doctor or a parent about food.",
                                fontSize = 14.sp, color = Color(0xFF12203F),
                            )
                        } else {
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text("${advice.kcal}", fontSize = 44.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF0B6B52))
                                Text("  kcal a day", fontSize = 15.sp, color = Color(0xFF3F4F70), modifier = Modifier.padding(bottom = 8.dp))
                            }
                            Text(
                                "A good range is ${advice.low} to ${advice.high} kcal. Goal: ${profile.goal.label}.",
                                fontSize = 13.sp, color = Color(0xFF3F4F70),
                            )
                        }
                    }
                }

                Text("Meals", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                val meals = listOf(
                    Triple("🍳", "Breakfast", 0.25),
                    Triple("🍛", "Lunch", 0.35),
                    Triple("🍎", "Snack", 0.10),
                    Triple("🍽️", "Dinner", 0.30),
                )
                meals.forEach { (emoji, name, share) ->
                    val kcal = advice?.let { ((it.kcal * share) / 10).toInt() * 10 }
                    MealCard(emoji, name, if (kcal != null) "about $kcal kcal" else "Ask a parent or doctor") { soon = true }
                }
            }

            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F1FF)),
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("💧", fontSize = 30.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Drink water", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF12203F))
                        Text("$water of 8 glasses", fontSize = 13.sp, color = Color(0xFF3F4F70))
                    }
                    RoundButton("−") {
                        water = (water - 1).coerceAtLeast(0)
                        AppPrefs.setWater(context, today.toString(), water)
                    }
                    Spacer(Modifier.width(10.dp))
                    RoundButton("+") {
                        water += 1
                        AppPrefs.setWater(context, today.toString(), water)
                    }
                }
            }

            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            ) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Healthy eating (WHO)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    listOf(
                        "Eat plenty of vegetables, fruit, pulses and whole grains.",
                        "Keep salt below 5 g (about 1 teaspoon) a day.",
                        "Cut down on sugar, sweet drinks and deep-fried food.",
                        "Drink clean water through the day.",
                    ).forEach { Text("•  $it", fontSize = 14.sp) }
                }
            }
            Spacer(Modifier.height(4.dp))
        }
    }

    if (soon) {
        AlertDialog(
            onDismissRequest = { soon = false },
            title = { Text("Food list is coming") },
            text = {
                Text("Choosing foods with calories and photos will arrive in a coming update. For now, use the calorie guide above.")
            },
            confirmButton = { TextButton(onClick = { soon = false }) { Text("OK") } },
        )
    }
}

@Composable
private fun MealCard(emoji: String, name: String, note: String, onAdd: () -> Unit) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onAdd),
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).background(Color(0xFFFFEFD9), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                Text(emoji, fontSize = 28.sp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(note, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box(Modifier.size(36.dp).background(MaterialTheme.colorScheme.tertiary, CircleShape), contentAlignment = Alignment.Center) {
                Text("+", fontSize = 22.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun RoundButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(38.dp).background(Color.White, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0B6B52)) }
}
