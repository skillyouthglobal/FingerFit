package com.fingerfit.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.data.Repo
import com.fingerfit.logic.Progress
import java.time.LocalDate

/** The "Progress" tab: what you did this week or this month, a streak, and small rewards. */
@Composable
fun ProgressScreen(vm: AppViewModel) {
    val workouts by Repo.workouts.collectAsStateWithLifecycle()
    val walks by Repo.walks.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    var month by rememberSaveable { mutableStateOf(false) }
    val today = LocalDate.now()
    val acts = remember(workouts, walks, history) { allActs(workouts, walks, history) }
    val days = if (month) 30 else 7
    val stats = remember(acts, days) { Progress.perDay(acts, today, days) }
    val streak = remember(acts) { Progress.streak(acts, today) }
    val activeDays = stats.count { it.active }
    val totalMin = stats.sumOf { it.minutes }
    val totalReps = stats.sumOf { it.reps }
    val sessions = workouts.size + walks.size + history.size
    val km = walks.sumOf { it.meters.toDouble() } / 1000.0

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.statusBarsPadding()) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("Progress", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !month, onClick = { month = false }, label = { Text("Week") })
                FilterChip(selected = month, onClick = { month = true }, label = { Text("Month") })
            }

            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            ) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Active minutes each day", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    BarChart(stats.map { it.minutes })
                    if (!month) {
                        Row(Modifier.fillMaxWidth()) {
                            stats.forEach { d ->
                                Text(
                                    dayName(d.date.dayOfWeek.value), fontSize = 11.sp, textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                    } else {
                        Text("Last 30 days", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SumTile("📅", "$activeDays of $days", "active days", Color(0xFFD8F5E6), Modifier.weight(1f))
                SumTile("⏱️", "$totalMin", "minutes", Color(0xFFE3ECFF), Modifier.weight(1f))
                SumTile("🔥", "$totalReps", "reps", Color(0xFFFFEFD9), Modifier.weight(1f))
            }

            Text("Your rewards", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SumTile("🏆", "$streak", if (streak == 1) "day in a row" else "days in a row", Color(0xFFFFF4D6), Modifier.weight(1f))
                SumTile("✅", "$sessions", "workouts and walks", Color(0xFFE3F1FF), Modifier.weight(1f))
                SumTile("👟", String.format(java.util.Locale.US, "%.1f", km), "km walked", Color(0xFFEDE7FF), Modifier.weight(1f))
            }

            Text(
                if (sessions == 0) "Your first workout will start your chart. Open the Exercise tab and begin."
                else if (streak >= 3) "Great! You are on a streak. Keep going."
                else "Every session counts. A little each day is the best habit.",
                fontSize = 14.sp, color = Color(0xFF3F4F70),
                modifier = Modifier.fillMaxWidth().background(Color(0xFFFFF4E0), RoundedCornerShape(18.dp)).padding(16.dp),
            )
        }
    }
}

private fun dayName(isoDay: Int): String = when (isoDay) {
    1 -> "Mon"
    2 -> "Tue"
    3 -> "Wed"
    4 -> "Thu"
    5 -> "Fri"
    6 -> "Sat"
    else -> "Sun"
}

@Composable
private fun BarChart(values: List<Int>) {
    val bar = MaterialTheme.colorScheme.tertiary
    val last = MaterialTheme.colorScheme.primary
    val empty = MaterialTheme.colorScheme.surfaceVariant
    Canvas(Modifier.fillMaxWidth().height(140.dp)) {
        val n = values.size.coerceAtLeast(1)
        val top = (values.maxOrNull() ?: 0).coerceAtLeast(10).toFloat()
        val slot = size.width / n
        val w = slot * 0.62f
        values.forEachIndexed { i, v ->
            val h = if (v == 0) 6.dp.toPx() else (v / top) * (size.height - 8.dp.toPx()) + 6.dp.toPx()
            val x = i * slot + (slot - w) / 2f
            drawRoundRect(
                color = if (v == 0) empty else if (i == values.size - 1) last else bar,
                topLeft = Offset(x, size.height - h),
                size = Size(w, h),
                cornerRadius = CornerRadius(w / 2.5f, w / 2.5f),
            )
        }
    }
}

@Composable
private fun SumTile(emoji: String, value: String, label: String, tint: Color, modifier: Modifier) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = tint), modifier = modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 24.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = Color(0xFF12203F), maxLines = 1)
            Text(label, fontSize = 11.sp, color = Color(0xFF3F4F70), textAlign = TextAlign.Center, maxLines = 2, minLines = 2)
        }
    }
}
