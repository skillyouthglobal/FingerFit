package com.fingerfit.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.data.Repo
import com.fingerfit.data.Session
import com.fingerfit.data.localDate
import com.fingerfit.data.todayReps
import com.fingerfit.data.toLocalDate
import com.fingerfit.logic.Act
import com.fingerfit.logic.Progress
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

internal val PRESETS = listOf(10, 20, 50)

@Composable
fun HomeScreen(
    vm: AppViewModel,
    onPlan: () -> Unit,
    onExercise: () -> Unit,
    onDiet: () -> Unit,
    onWalk: () -> Unit,
    onSleep: () -> Unit,
    onInbox: () -> Unit,
    onLink: () -> Unit,
    linkStatus: String? = null,
    lastCamera: String? = null,
    onReconnect: () -> Unit = {},
    profile: com.fingerfit.data.Profile? = null,
    updateVm: com.fingerfit.UpdateViewModel? = null,
) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val workouts by Repo.workouts.collectAsStateWithLifecycle()
    val walks by Repo.walks.collectAsStateWithLifecycle()
    val sleeps by Repo.sleeps.collectAsStateWithLifecycle()
    val inbox by Repo.inbox.collectAsStateWithLifecycle()
    val unread = inbox.count { !it.read }
    val today = LocalDate.now()
    val walkMin = remember(walks) { Repo.todayWalkSeconds() / 60 }
    val lastSleep = sleeps.firstOrNull { it.date == today.toString() }

    val acts = remember(workouts, walks, history) { allActs(workouts, walks, history) }
    val todayStat = remember(acts) { Progress.perDay(acts, today, 1)[0] }
    val goal = settings.walkGoalMin
    val ring = Progress.ring(todayStat.minutes, goal)
    val doneToday = remember(workouts, history) {
        workouts.filter { it.t.toLocalDate() == today }.map { it.type }.toSet().size +
            (if (history.todayReps() > 0) 1 else 0)
    }

    val hour = java.time.LocalTime.now().hour
    val greeting = when {
        hour < 12 -> "Good morning"
        hour < 17 -> "Good afternoon"
        else -> "Good evening"
    }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.systemBarsPadding()) {
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FingerFitLogo(46.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(greeting, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            profile?.name ?: "Kinetro", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground, maxLines = 1,
                        )
                    }
                    Box(contentAlignment = Alignment.TopEnd) {
                        IconButton(onClick = onInbox) { Text("🔔", fontSize = 24.sp) }
                        if (unread > 0) {
                            Text(
                                "$unread", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 4.dp, end = 4.dp).clip(CircleShape)
                                    .background(Color(0xFFDC2626)).padding(horizontal = 5.dp, vertical = 1.dp),
                            )
                        }
                    }
                }
            }

            if (updateVm != null) {
                item { UpdateCard(updateVm, always = false) }
            }

            item {
                Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = HeroTint)) {
                    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(116.dp), contentAlignment = Alignment.Center) {
                            val track = Color.White
                            val bar = MaterialTheme.colorScheme.tertiary
                            androidx.compose.foundation.Canvas(Modifier.size(116.dp)) {
                                val stroke = androidx.compose.ui.graphics.drawscope.Stroke(
                                    width = 13.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round,
                                )
                                val inset = 7.dp.toPx()
                                val arcSize = androidx.compose.ui.geometry.Size(size.width - inset * 2, size.height - inset * 2)
                                val topLeft = androidx.compose.ui.geometry.Offset(inset, inset)
                                drawArc(track, 0f, 360f, false, topLeft, arcSize, style = stroke)
                                if (ring > 0f) drawArc(bar, -90f, 360f * ring, false, topLeft, arcSize, style = stroke)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${(ring * 100).toInt()}%", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF12203F))
                                Text("done today", fontSize = 11.sp, color = Color(0xFF3F4F70))
                            }
                        }
                        Spacer(Modifier.width(18.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatLine("🔥", "${todayStat.reps}", "reps today")
                            StatLine("⏱️", "${todayStat.minutes} of $goal", "active minutes")
                            StatLine("🏅", "$doneToday", "exercises done")
                        }
                    }
                }
            }

            item { CameraCard(linkStatus, lastCamera, onLink, onReconnect) }

            item {
                Button(
                    onClick = onPlan,
                    modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(18.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.tertiary, contentColor = Color.White,
                    ),
                ) {
                    Text("📋  Today's plan", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.weight(1f))
                    Text("›", fontSize = 26.sp)
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    BigTile(
                        "🏋️", "Exercise", "Start now", onExercise, Color(0xFFE3ECFF), Modifier.weight(1f),
                    )
                    BigTile(
                        "🍎", "Diet", "Plan your food", onDiet, Color(0xFFFFEFD9), Modifier.weight(1f),
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TrainTile("🚶", "Walking", "$walkMin of ${settings.walkGoalMin} min", onWalk, Color(0xFFE3ECFF), Modifier.weight(1f))
                    TrainTile(
                        "😴", "Sleep",
                        lastSleep?.let { "${it.minutes / 60}h ${it.minutes % 60}m last night" } ?: "Tap to add",
                        onSleep, Color(0xFFEDE7FF), Modifier.weight(1f),
                    )
                }
            }

            item {
                Text(
                    "\"Small steps every day make a strong body.\"",
                    fontSize = 14.sp, fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().background(HeroTint, RoundedCornerShape(20.dp)).padding(16.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
    }
}

/** Everything done so far as plain activities (workouts, walks, finger sessions), for the ring and the charts. */
internal fun allActs(
    workouts: List<com.fingerfit.data.WorkoutRecord>,
    walks: List<com.fingerfit.data.WalkRecord>,
    history: List<Session>,
): List<Act> =
    workouts.map { Act(it.t.toLocalDate(), it.seconds, it.reps) } +
        walks.map { Act(it.t.toLocalDate(), it.seconds, 0) } +
        history.map { Act(it.localDate(), it.durationSec, it.reps) }

@Composable
private fun StatLine(emoji: String, value: String, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 20.sp)
        Spacer(Modifier.width(8.dp))
        Column {
            Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = Color(0xFF12203F))
            Text(label, fontSize = 12.sp, color = Color(0xFF3F4F70))
        }
    }
}

/** The camera is the heart of Kinetro, so its state is always the first thing shown after today's numbers. */
@Composable
private fun CameraCard(linkStatus: String?, lastCamera: String?, onLink: () -> Unit, onReconnect: () -> Unit) {
    val on = linkStatus != null
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = if (on) Color(0xFFD8F5E6) else Color(0xFFFFF4E0)),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onLink),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("📷", fontSize = 28.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (on) "Camera is ready" else "Set up your camera",
                        fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF12203F),
                    )
                    Text(
                        linkStatus ?: "A Wi-Fi camera or a second phone counts your exercise hands-free.",
                        fontSize = 13.sp, color = Color(0xFF3F4F70),
                    )
                }
                Text("›", fontSize = 26.sp, color = Color(0xFF3F4F70))
            }
            if (!on && lastCamera != null) {
                Button(onClick = onReconnect, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(14.dp)) {
                    Text("Connect again: $lastCamera", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun BigTile(emoji: String, title: String, subtitle: String, onClick: () -> Unit, tint: Color, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = tint),
        modifier = modifier.clickable(onClick = onClick),
    ) {
        Column(Modifier.fillMaxWidth().padding(vertical = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 38.sp)
            Spacer(Modifier.height(6.dp))
            Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color(0xFF12203F))
            Text(subtitle, fontSize = 12.sp, color = Color(0xFF3F4F70))
        }
    }
}

@Composable
internal fun SessionRow(s: Session) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(dayLabel(s), fontWeight = FontWeight.SemiBold)
                Text(
                    "${formatDuration(s.durationSec * 1000L)}  ·  target ${s.target}",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (s.targetReached) {
                Icon(Icons.Default.Check, contentDescription = "Target reached", tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
            }
            Text("${s.reps} reps", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
internal fun CustomTargetDialog(current: Int, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    var text by remember { mutableStateOf(current.toString()) }
    val value = text.toIntOrNull()
    val valid = value != null && value in 1..1000
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom target") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter(Char::isDigit).take(4) },
                label = { Text("Repetitions (1-1000)") },
                singleLine = true,
                isError = !valid,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(value!!) }, enabled = valid) { Text("Set target") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

fun formatDuration(ms: Long): String {
    val total = (ms / 1000).toInt()
    return "%d:%02d".format(Locale.US, total / 60, total % 60)
}

private fun dayLabel(s: Session): String {
    val today = LocalDate.now()
    val d = s.localDate()
    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(s.timestamp))
    return when (d) {
        today -> "Today, $time"
        today.minusDays(1) -> "Yesterday, $time"
        else -> SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(s.timestamp))
    }
}

@Composable
private fun TrainTile(
    emoji: String, title: String, subtitle: String, onClick: () -> Unit, tint: Color, modifier: Modifier = Modifier,
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.clickable(onClick = onClick),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(44.dp).background(tint, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Text(emoji, fontSize = 24.sp)
            }
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(
                subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2, minLines = 2,
            )
        }
    }
}
