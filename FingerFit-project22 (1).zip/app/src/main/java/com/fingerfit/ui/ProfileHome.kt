package com.fingerfit.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.data.Profile
import com.fingerfit.data.Repo
import com.fingerfit.logic.Health
import com.fingerfit.logic.Progress
import java.time.LocalDate

/** The "Profile" tab: who you are, a few numbers, and the way to every other part of the app. */
@Composable
fun ProfileHomeScreen(
    vm: AppViewModel,
    profile: Profile?,
    onEdit: () -> Unit,
    onPlan: () -> Unit,
    onCameras: () -> Unit,
    onInbox: () -> Unit,
    onSettings: () -> Unit,
) {
    val workouts by Repo.workouts.collectAsStateWithLifecycle()
    val walks by Repo.walks.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val inbox by Repo.inbox.collectAsStateWithLifecycle()
    val acts = remember(workouts, walks, history) { allActs(workouts, walks, history) }
    val today = LocalDate.now()
    val streak = remember(acts) { Progress.streak(acts, today) }
    val sessions = workouts.size + walks.size + history.size
    val minutes = remember(acts) { acts.sumOf { it.seconds } / 60 }
    val unread = inbox.count { !it.read }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.statusBarsPadding()) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("Profile", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)

            Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = HeroTint)) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(64.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                        FingerFitLogo(44.dp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(profile?.name ?: "Kinetro", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF12203F), maxLines = 1)
                        if (profile != null) {
                            val age = Health.age(profile.birth, today)
                            Text(
                                "$age years · ${profile.heightCm.toInt()} cm · ${profile.weightKg.toInt()} kg",
                                fontSize = 13.sp, color = Color(0xFF3F4F70),
                            )
                            Text("Goal: ${profile.goal.label}", fontSize = 13.sp, color = Color(0xFF0B6B52), fontWeight = FontWeight.SemiBold)
                        } else {
                            Text("Fitness and longevity", fontSize = 13.sp, color = Color(0xFF3F4F70))
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Mini("🏆", "$streak", "day streak", Color(0xFFFFF4D6), Modifier.weight(1f))
                Mini("✅", "$sessions", "sessions", Color(0xFFD8F5E6), Modifier.weight(1f))
                Mini("⏱️", "$minutes", "minutes", Color(0xFFE3ECFF), Modifier.weight(1f))
            }

            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            ) {
                Column(Modifier.fillMaxWidth()) {
                    Row1("✏️", "My details", "Name, age, height, weight, goal", onEdit)
                    Row1("📋", "My plan", "Exercise plan made for you", onPlan)
                    Row1("📷", "Cameras", "Wi-Fi camera or second phone", onCameras)
                    Row1("🔔", "Notifications", if (unread > 0) "$unread new" else "Messages and reminders", onInbox)
                    Row1("⚙️", "Settings", "Language, voice, theme, updates", onSettings)
                }
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun Mini(emoji: String, value: String, label: String, tint: Color, modifier: Modifier) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = tint), modifier = modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 24.sp)
            Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color(0xFF12203F))
            Text(label, fontSize = 11.sp, color = Color(0xFF3F4F70))
        }
    }
}

@Composable
private fun Row1(emoji: String, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(emoji, fontSize = 24.sp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("›", fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
