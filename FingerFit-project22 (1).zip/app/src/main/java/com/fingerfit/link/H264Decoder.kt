package com.fingerfit.link

import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.os.Build
import android.os.SystemClock
import com.fingerfit.logic.Yuv
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

/**
 * Decodes the H.264 pictures of an RTSP camera with the phone's own video chip and hands each one on as a
 * small JPEG picture, the same form the other camera types use. Only about 16 pictures a second are
 * passed on (the body analysis cannot use more); the rest are skipped so the picture never falls behind.
 */
class H264Decoder(private val onJpeg: (ByteArray, Long) -> Unit) {

    private var codec: MediaCodec? = null
    @Volatile private var running = false
    private var drainThread: Thread? = null
    private var pts = 0L
    @Volatile private var needKey = true
    private var lastOut = 0L
    private var nv = ByteArray(0)
    private val jpegOut = ByteArrayOutputStream(64 * 1024)
    private val startCode = byteArrayOf(0, 0, 0, 1)

    /** Starts the decoder. Throws when the phone cannot decode this video. */
    fun start(sps: ByteArray?, pps: ByteArray?, width: Int, height: Int) {
        val w = if (width > 0) width else 1280
        val h = if (height > 0) height else 720
        val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        if (sps != null) f.setByteBuffer("csd-0", ByteBuffer.wrap(startCode + sps))
        if (pps != null) f.setByteBuffer("csd-1", ByteBuffer.wrap(startCode + pps))
        f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
        if (Build.VERSION.SDK_INT >= 30) f.setInteger("low-latency", 1)
        val c = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        try {
            c.configure(f, null, null, 0)
            c.start()
        } catch (e: Exception) {
            try {
                c.release()
            } catch (x: Exception) {
            }
            throw e
        }
        codec = c
        running = true
        needKey = true
        val t = Thread({ drain(c) }, "kinetro-h264-out")
        drainThread = t
        t.start()
    }

    /** One whole picture in Annex-B form. */
    fun feed(au: ByteArray, key: Boolean) {
        val c = codec ?: return
        if (needKey && !key) return // wait for a full picture to start from
        try {
            val i = c.dequeueInputBuffer(30_000)
            if (i < 0) {
                needKey = true // the decoder is behind: skip this one and restart from the next full picture
                return
            }
            val b = c.getInputBuffer(i) ?: return
            b.clear()
            if (au.size > b.capacity()) {
                c.queueInputBuffer(i, 0, 0, 0, 0)
                needKey = true
                return
            }
            b.put(au)
            pts += 33_333
            c.queueInputBuffer(i, 0, au.size, pts, 0)
            if (key) needKey = false
        } catch (e: Exception) {
            // the decoder was stopped at the same moment: nothing to do
        }
    }

    private fun drain(c: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        while (running) {
            try {
                val i = c.dequeueOutputBuffer(info, 20_000)
                if (i >= 0) {
                    val now = SystemClock.uptimeMillis()
                    if (now - lastOut >= MIN_GAP_MS) {
                        lastOut = now
                        val img = c.getOutputImage(i)
                        if (img != null) {
                            try {
                                toJpeg(img)
                            } finally {
                                img.close()
                            }
                        }
                    }
                    c.releaseOutputBuffer(i, false)
                }
            } catch (e: IllegalStateException) {
                break
            } catch (e: Exception) {
                // one bad picture: go on with the next
            }
        }
    }

    private fun toJpeg(img: android.media.Image) {
        val crop = img.cropRect
        val w = crop.width()
        val h = crop.height()
        if (w < 16 || h < 16) return
        val step = Yuv.stepFor(w, h)
        val need = Yuv.outSize(w, h, step)
        if (nv.size < need) nv = ByteArray(need)
        val p = img.planes
        val size = Yuv.nv21(
            w, h, crop.left, crop.top, step,
            p[0].buffer, p[0].rowStride, p[0].pixelStride,
            p[1].buffer, p[1].rowStride, p[1].pixelStride,
            p[2].buffer, p[2].rowStride, p[2].pixelStride,
            nv,
        )
        jpegOut.reset()
        YuvImage(nv, ImageFormat.NV21, size.first, size.second, null)
            .compressToJpeg(Rect(0, 0, size.first, size.second), 72, jpegOut)
        onJpeg(jpegOut.toByteArray(), SystemClock.uptimeMillis())
    }

    fun stop() {
        running = false
        val c = codec
        codec = null
        try {
            drainThread?.join(400)
        } catch (e: Exception) {
        }
        drainThread = null
        if (c != null) {
            try {
                c.stop()
            } catch (e: Exception) {
            }
            try {
                c.release()
            } catch (e: Exception) {
            }
        }
    }

    private companion object {
        const val MIN_GAP_MS = 60L
    }
}
