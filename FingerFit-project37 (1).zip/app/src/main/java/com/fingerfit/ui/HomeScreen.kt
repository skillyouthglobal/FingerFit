package com.fingerfit.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import com.fingerfit.logic.Burn
import kotlin.math.roundToInt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.R
import com.fingerfit.data.Repo
import com.fingerfit.data.Session
import com.fingerfit.data.localDate
import com.fingerfit.data.todayReps
import com.fingerfit.data.toLocalDate
import com.fingerfit.logic.Act
import com.fingerfit.logic.ExerciseType
import com.fingerfit.logic.Plans
import com.fingerfit.logic.Progress
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

internal val PRESETS = listOf(10, 20, 50)

private val BrandGreen = Color(0xFF0B8A6C)
private val BrandDeep = Color(0xFF065F46)
private val BrandBlue = Color(0xFF2F6BFF)
private val Warn = Color(0xFFD97706)

/** A quiet, bordered surface: the one card style used on Home, so nothing looks like a loose button. */
@Composable
private fun Panel(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier.clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
    ) { content() }
}

@Composable
private fun IconBadge(icon: ImageVector, tint: Color, size: Dp = 40.dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(tint.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.55f)) }
}

private class Banner(
    val res: Int, val dark: Boolean,
    val en: String, val bn: String, val subEn: String, val subBn: String,
    val ctaEn: String, val ctaBn: String, val onClick: () -> Unit,
)

@Composable
private fun BannerCard(b: Banner, isBn: Boolean, s: Float) {
    val fg = if (b.dark) Color.White else Color(0xFF0B3B2A)
    Box(Modifier.fillMaxWidth().aspectRatio(2.8f).clip(RoundedCornerShape(20.dp))) {
        Image(
            painter = painterResource(b.res), contentDescription = null,
            modifier = Modifier.matchParentSize(), contentScale = ContentScale.Crop, alignment = Alignment.CenterEnd,
        )
        Column(
            Modifier.fillMaxHeight().fillMaxWidth(0.5f).padding(start = 16.dp, top = 10.dp, bottom = 10.dp),
            verticalArrangement = Arrangement.Center,
        ) {
            Text(
                pick(isBn, b.en, b.bn), fontSize = (16 * s).sp, lineHeight = (19 * s).sp,
                fontWeight = FontWeight.ExtraBold, color = fg, maxLines = 2,
            )
            Spacer(Modifier.height(4.dp))
            Text(pick(isBn, b.subEn, b.subBn), fontSize = (11 * s).sp, lineHeight = (13 * s).sp, color = fg.copy(alpha = 0.88f), maxLines = 2)
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.clip(CircleShape).background(if (b.dark) Color.White else BrandGreen)
                    .clickable(onClick = b.onClick).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    pick(isBn, b.ctaEn, b.ctaBn), fontSize = (12 * s).sp, fontWeight = FontWeight.Bold,
                    color = if (b.dark) BrandDeep else Color.White, maxLines = 1,
                )
                Spacer(Modifier.width(6.dp))
                Icon(KIcon.Arrow, contentDescription = null, tint = if (b.dark) BrandDeep else Color.White, modifier = Modifier.size(14.dp))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BannerPager(banners: List<Banner>, isBn: Boolean, s: Float) {
    val pager = rememberPagerState { banners.size }
    LaunchedEffect(pager) {
        while (true) {
            delay(5500)
            pager.animateScrollToPage((pager.currentPage + 1) % banners.size)
        }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        HorizontalPager(state = pager, pageSpacing = 12.dp) { i -> BannerCard(banners[i], isBn, s) }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            repeat(banners.size) { i ->
                val on = i == pager.currentPage
                Box(
                    Modifier.height(5.dp).width(if (on) 16.dp else 5.dp).clip(CircleShape)
                        .background(if (on) BrandGreen else MaterialTheme.colorScheme.outlineVariant),
                )
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
        if (action != null) {
            Row(Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onAction).padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(action, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = BrandGreen)
                Icon(KIcon.ChevronRight, contentDescription = null, tint = BrandGreen, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun CircleBadge(icon: ImageVector, tint: Color, size: Dp) {
    Box(Modifier.size(size).clip(CircleShape).background(tint.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

/** One of the four main sections (diet, exercise, walking, sleep). */
@Composable
private fun SectionCard(icon: ImageVector, tint: Color, title: String, subtitle: String, onClick: () -> Unit, modifier: Modifier, s: Float) {
    Panel(modifier, onClick) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            CircleBadge(icon, tint, (42 * s).dp)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = (15 * s).sp, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                Text(subtitle, fontSize = (11 * s).sp, lineHeight = (14 * s).sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            }
            if (s >= 0.97f) {
                Icon(KIcon.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun StatColumn(icon: ImageVector, tint: Color, label: String, value: String, sub: String, modifier: Modifier, s: Float) {
    Column(modifier.padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
        Text(label, fontSize = (11 * s).sp, lineHeight = (13 * s).sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, minLines = 2)
        Text(value, fontSize = (16 * s).sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
        Text(sub, fontSize = (10.5f * s).sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

/**
 * The camera button floats above the whole Home screen. The person can drag it anywhere and it remembers where it was left.
 * Tap opens the camera section; if a camera was connected before, a small question offers to connect it again.
 */
@Composable
private fun CameraFab(on: Boolean, lastCamera: String?, onLink: () -> Unit, onReconnect: () -> Unit, boxW: Int, boxH: Int, isBn: Boolean) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("kinetro_ui", android.content.Context.MODE_PRIVATE) }
    val sizePx = with(LocalDensity.current) { 56.dp.toPx() }
    var fx by remember { mutableStateOf(prefs.getFloat("fab_x", 0.03f).coerceIn(0f, 1f)) }
    var fy by remember { mutableStateOf(prefs.getFloat("fab_y", 0.97f).coerceIn(0f, 1f)) }
    var ask by remember { mutableStateOf(false) }
    val freeW = (boxW - sizePx).coerceAtLeast(1f)
    val freeH = (boxH - sizePx).coerceAtLeast(1f)
    Box(
        Modifier
            .offset { IntOffset((fx * freeW).roundToInt(), (fy * freeH).roundToInt()) }
            .size(56.dp)
            .shadow(6.dp, CircleShape)
            .clip(CircleShape)
            .background(BrandGreen)
            .pointerInput(on, lastCamera) {
                detectTapGestures(onTap = { if (!on && lastCamera != null) { ask = true } else { onLink() } })
            }
            .pointerInput(freeW, freeH) {
                detectDragGestures(
                    onDragEnd = { prefs.edit().putFloat("fab_x", fx).putFloat("fab_y", fy).apply() },
                ) { change, drag ->
                    change.consume()
                    fx = (fx + drag.x / freeW).coerceIn(0f, 1f)
                    fy = (fy + drag.y / freeH).coerceIn(0f, 1f)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(KIcon.Camera, contentDescription = pick(isBn, "Camera", "ক্যামেরা"), tint = Color.White, modifier = Modifier.size(26.dp))
        Box(
            Modifier.align(Alignment.TopEnd).padding(10.dp).size(10.dp).clip(CircleShape)
                .background(if (on) Color(0xFF22C55E) else Warn),
        )
    }
    if (ask && lastCamera != null) {
        AlertDialog(
            onDismissRequest = { ask = false },
            title = { Text(pick(isBn, "Camera", "ক্যামেরা")) },
            text = { Text(pick(isBn, "Connect $lastCamera again?", "$lastCamera আবার সংযুক্ত করবেন?")) },
            confirmButton = { TextButton(onClick = { ask = false; onReconnect() }) { Text(pick(isBn, "Connect again", "আবার সংযুক্ত করুন")) } },
            dismissButton = { TextButton(onClick = { ask = false; onLink() }) { Text(pick(isBn, "Camera settings", "ক্যামেরা সেটিংস")) } },
        )
    }
}

@Composable
fun HomeScreen(
    vm: AppViewModel,
    onPlan: () -> Unit,
    onExercise: () -> Unit,
    onDiet: () -> Unit,
    onWalk: () -> Unit,
    onSleep: () -> Unit,
    onInbox: () -> Unit,
    onLink: () -> Unit,
    linkStatus: String? = null,
    lastCamera: String? = null,
    onReconnect: () -> Unit = {},
    profile: com.fingerfit.data.Profile? = null,
    updateVm: com.fingerfit.UpdateViewModel? = null,
    onProgress: () -> Unit = {},
    onProfile: () -> Unit = {},
    onOpenExercise: (ExerciseType) -> Unit = {},
) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val workouts by Repo.workouts.collectAsStateWithLifecycle()
    val walks by Repo.walks.collectAsStateWithLifecycle()
    val sleeps by Repo.sleeps.collectAsStateWithLifecycle()
    val inbox by Repo.inbox.collectAsStateWithLifecycle()
    val unread = inbox.count { !it.read }
    val today = LocalDate.now()
    val isBn = LangState.bn
    val walkMin = remember(walks) { Repo.todayWalkSeconds() / 60 }
    val lastSleep = sleeps.firstOrNull { it.date == today.toString() }

    val acts = remember(workouts, walks, history) { allActs(workouts, walks, history) }
    val todayStat = remember(acts) { Progress.perDay(acts, today, 1)[0] }
    val goal = settings.walkGoalMin
    val ring = Progress.ring(todayStat.minutes, goal)
    val doneToday = remember(workouts, history) {
        workouts.filter { it.t.toLocalDate() == today }.map { it.type }.toSet().size +
            (if (history.todayReps() > 0) 1 else 0)
    }
    val weight = profile?.weightKg ?: 65f
    val burned = Burn.kcal(weight, todayStat.minutes)
    val burnGoal = Burn.target(weight, goal)
    val burnLeft = (burnGoal - burned).coerceAtLeast(0)

    val hour = java.time.LocalTime.now().hour
    val greeting = when {
        hour < 12 -> pick(isBn, "Good morning", "শুভ সকাল")
        hour < 17 -> pick(isBn, "Good afternoon", "শুভ অপরাহ্ন")
        else -> pick(isBn, "Good evening", "শুভ সন্ধ্যা")
    }
    val planCount = profile?.let { Plans.exercisePlan(it.age(today), it.bmi(), it.goal, today.dayOfYear).size }
    val popular = remember { POPULAR }
    val on = linkStatus != null
    val banners = listOf(
        Banner(
            R.drawable.banner_run, true, "Stay healthy, stay active", "সুস্থ থাকুন, সক্রিয় থাকুন",
            "Fitness is part of life.", "ফিটনেসই হোক জীবনের অংশ।", "Start", "শুরু করুন", onExercise,
        ),
        Banner(
            R.drawable.banner_food, false, "Eat well, move well", "ভালো খান, নিয়মিত নড়ুন",
            "Balanced food and daily exercise build lasting health.", "সুষম খাবার আর নিয়মিত ব্যায়ামেই টেকসই সুস্থতা।",
            "Today's plan", "আজকের পরিকল্পনা", onPlan,
        ),
        Banner(
            R.drawable.banner_gym, true, "Every rep counts", "প্রতিটি বার গুরুত্বপূর্ণ",
            "Small steps every day make a strong body.", "প্রতিদিনের ছোট পদক্ষেপই গড়ে শক্ত শরীর।",
            "Set up camera", "ক্যামেরা যুক্ত করুন", onLink,
        ),
    )

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.systemBarsPadding()) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            // Every phone is a different size: text and the ring scale with the screen width, and very wide screens stay readable.
            val s = (maxWidth.value / 392f).coerceIn(0.88f, 1.2f)
            val boxW = constraints.maxWidth
            val boxH = constraints.maxHeight
            Box(Modifier.fillMaxSize()) {
                LazyColumn(
                    modifier = Modifier.widthIn(max = 600.dp).fillMaxWidth().align(Alignment.TopCenter),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            FingerFitLogo(42.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(greeting, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                Text(
                                    profile?.name ?: "Kinetro", fontSize = (21 * s).sp, fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onBackground, maxLines = 1,
                                )
                            }
                            Box(contentAlignment = Alignment.TopEnd) {
                                IconButton(onClick = onInbox) {
                                    Icon(KIcon.Bell, contentDescription = pick(isBn, "Notifications", "নোটিফিকেশন"), tint = MaterialTheme.colorScheme.onBackground)
                                }
                                if (unread > 0) {
                                    Text(
                                        if (unread > 9) "9+" else "$unread", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(top = 6.dp, end = 6.dp).clip(CircleShape)
                                            .background(Color(0xFFDC2626)).padding(horizontal = 5.dp, vertical = 1.dp),
                                    )
                                }
                            }
                            IconButton(onClick = onProfile) {
                                Icon(com.fingerfit.ui.ProfileIcon, contentDescription = pick(isBn, "Profile", "প্রোফাইল"), tint = MaterialTheme.colorScheme.onBackground)
                            }
                        }
                    }

                    if (updateVm != null) {
                        item { UpdateCard(updateVm, always = false) }
                    }

                    item { BannerPager(banners, isBn, s) }

                    item {
                        Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SectionCard(
                                com.fingerfit.ui.DietIcon, BrandGreen, pick(isBn, "Diet", "ডায়েট"),
                                pick(isBn, "Right food plan", "সঠিক খাবার পরিকল্পনা"),
                                onDiet, Modifier.weight(1f).fillMaxHeight(), s,
                            )
                            SectionCard(
                                com.fingerfit.ui.WorkoutIcon, BrandBlue, pick(isBn, "Exercise", "ব্যায়াম"),
                                pick(isBn, "Stay fit always", "ফিট থাকুন সবসময়"),
                                onExercise, Modifier.weight(1f).fillMaxHeight(), s,
                            )
                        }
                    }
                    item {
                        Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SectionCard(
                                KIcon.Walk, BrandGreen, pick(isBn, "Walking", "হাঁটা"),
                                pick(isBn, "$walkMin of $goal min today", "আজ ${num(true, walkMin)} / ${num(true, goal)} মিনিট"),
                                onWalk, Modifier.weight(1f).fillMaxHeight(), s,
                            )
                            SectionCard(
                                KIcon.Moon, BrandBlue, pick(isBn, "Sleep", "ঘুম"),
                                lastSleep?.let { pick(isBn, "${it.minutes / 60}h ${it.minutes % 60}m last night", "গত রাতে ${num(true, it.minutes / 60)} ঘণ্টা ${num(true, it.minutes % 60)} মিনিট") }
                                    ?: pick(isBn, "Sleep well, tap to add", "ভালো ঘুম নিশ্চিত করুন"),
                                onSleep, Modifier.weight(1f).fillMaxHeight(), s,
                            )
                        }
                    }

                    item {
                        Panel(Modifier.fillMaxWidth(), onPlan) {
                            Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                CircleBadge(KIcon.Clipboard, BrandGreen, (42 * s).dp)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(pick(isBn, "Today's plan", "আজকের পরিকল্পনা"), fontWeight = FontWeight.Bold, fontSize = (15 * s).sp, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                                    Text(
                                        if (planCount != null) pick(isBn, "$planCount exercises picked for you", "আপনার জন্য ${num(true, planCount)}টি ব্যায়াম")
                                        else pick(isBn, "Add your profile to get a plan", "পরিকল্পনা পেতে প্রোফাইল পূরণ করুন"),
                                        fontSize = (12 * s).sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                                    )
                                }
                                Icon(KIcon.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    item {
                        Panel(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(KIcon.Progress, contentDescription = null, tint = BrandGreen, modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text(pick(isBn, "Today's progress", "আজকের অগ্রগতি"), fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
                                    Row(
                                        Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onProgress).padding(horizontal = 6.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Text(pick(isBn, "Weekly progress", "সাপ্তাহিক অগ্রগতি"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = BrandGreen)
                                        Icon(KIcon.ChevronRight, contentDescription = null, tint = BrandGreen, modifier = Modifier.size(16.dp))
                                    }
                                }
                                Row(Modifier.height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
                                    val ringSize = (84 * s).dp
                                    Box(Modifier.size(ringSize), contentAlignment = Alignment.Center) {
                                        val track = MaterialTheme.colorScheme.outlineVariant
                                        androidx.compose.foundation.Canvas(Modifier.size(ringSize)) {
                                            val stroke = androidx.compose.ui.graphics.drawscope.Stroke(
                                                width = 9.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round,
                                            )
                                            val inset = 5.dp.toPx()
                                            val arcSize = androidx.compose.ui.geometry.Size(size.width - inset * 2, size.height - inset * 2)
                                            val topLeft = androidx.compose.ui.geometry.Offset(inset, inset)
                                            drawArc(track, 0f, 360f, false, topLeft, arcSize, style = stroke)
                                            if (ring > 0f) drawArc(BrandGreen, -90f, 360f * ring, false, topLeft, arcSize, style = stroke)
                                        }
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("${num(isBn, (ring * 100).toInt())}%", fontSize = (19 * s).sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface)
                                            Text(pick(isBn, "of goal", "লক্ষ্য অর্জন"), fontSize = 9.5f.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                        }
                                    }
                                    Box(Modifier.padding(horizontal = 4.dp).width(1.dp).fillMaxHeight().background(MaterialTheme.colorScheme.outlineVariant))
                                    StatColumn(
                                        KIcon.Flame, Warn, pick(isBn, "Calories burned", "ক্যালরি ব্যয়"), num(isBn, burned),
                                        if (burnLeft > 0) pick(isBn, "${burnLeft} left", "বাকি ${num(true, burnLeft)}") else pick(isBn, "Goal reached", "লক্ষ্য পূর্ণ"),
                                        Modifier.weight(1f), s,
                                    )
                                    Box(Modifier.width(1.dp).fillMaxHeight().background(MaterialTheme.colorScheme.outlineVariant))
                                    StatColumn(
                                        KIcon.Clock, BrandGreen, pick(isBn, "Active time", "সক্রিয় সময়"), num(isBn, todayStat.minutes),
                                        pick(isBn, "of $goal min", "${num(true, goal)} মিনিটের"), Modifier.weight(1f), s,
                                    )
                                    Box(Modifier.width(1.dp).fillMaxHeight().background(MaterialTheme.colorScheme.outlineVariant))
                                    StatColumn(
                                        KIcon.Trophy, BrandBlue, pick(isBn, "Exercises done", "ব্যায়াম সম্পন্ন"), num(isBn, doneToday),
                                        pick(isBn, "${todayStat.reps} reps", "${num(true, todayStat.reps)} বার"), Modifier.weight(1f), s,
                                    )
                                }
                            }
                        }
                    }

                    item { SectionTitle(pick(isBn, "Popular exercises", "জনপ্রিয় ব্যায়াম"), pick(isBn, "See all", "সব দেখুন"), onExercise) }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(popular, key = { it.name }) { t ->
                                Panel(Modifier.width((150 * s).dp), onClick = { onOpenExercise(t) }) {
                                    Column {
                                        val photo = ExerciseImages.of(t.name)
                                        if (photo != null) {
                                            Image(
                                                painter = painterResource(photo), contentDescription = t.title,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxWidth().aspectRatio(4f / 3f),
                                            )
                                        }
                                        Text(
                                            t.title, fontWeight = FontWeight.Bold, fontSize = (13 * s).sp, maxLines = 1,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                CameraFab(on, lastCamera, onLink, onReconnect, boxW, boxH, isBn)
            }
        }
    }
}

/** Everything done so far as plain activities (workouts, walks, finger sessions), for the ring and the charts. */
internal fun allActs(
    workouts: List<com.fingerfit.data.WorkoutRecord>,
    walks: List<com.fingerfit.data.WalkRecord>,
    history: List<Session>,
): List<Act> =
    workouts.map { Act(it.t.toLocalDate(), it.seconds, it.reps) } +
        walks.map { Act(it.t.toLocalDate(), it.seconds, 0) } +
        history.map { Act(it.localDate(), it.durationSec, it.reps) }

@Composable
internal fun SessionRow(s: Session) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(dayLabel(s), fontWeight = FontWeight.SemiBold)
                Text(
                    "${formatDuration(s.durationSec * 1000L)}  ·  target ${s.target}",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (s.targetReached) {
                Icon(Icons.Default.Check, contentDescription = "Target reached", tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
            }
            Text("${s.reps} reps", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
internal fun CustomTargetDialog(current: Int, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    var text by remember { mutableStateOf(current.toString()) }
    val value = text.toIntOrNull()
    val valid = value != null && value in 1..1000
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom target") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter(Char::isDigit).take(4) },
                label = { Text("Repetitions (1-1000)") },
                singleLine = true,
                isError = !valid,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(value!!) }, enabled = valid) { Text("Set target") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

fun formatDuration(ms: Long): String {
    val total = (ms / 1000).toInt()
    return "%d:%02d".format(Locale.US, total / 60, total % 60)
}

private fun dayLabel(s: Session): String {
    val today = LocalDate.now()
    val d = s.localDate()
    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(s.timestamp))
    return when (d) {
        today -> "Today, $time"
        today.minusDays(1) -> "Yesterday, $time"
        else -> SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(s.timestamp))
    }
}
