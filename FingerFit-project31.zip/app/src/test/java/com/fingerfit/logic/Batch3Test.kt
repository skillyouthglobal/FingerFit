package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private const val W3 = 480f
private const val H3 = 640f

private fun tri3(i: Int, x: Float, y: Float) = Triple(i, x / W3, y / H3)
private fun both3(i: Int, x: Float, y: Float) = arrayOf(tri3(i, x, y), tri3(i + 1, x, y))

private fun pts3(vararg v: Triple<Int, Float, Float>): List<BodyPoint> {
    val a = Array(33) { BodyPoint(0f, 0f, 0f) }
    v.forEach { a[it.first] = BodyPoint(it.second, it.third, 1f) }
    return a.toList()
}

private class Run3(type: ExerciseType) {
    val engine = ExerciseEngine(type)
    var t = 1_000L
    var last: ExerciseEngine.Out? = null
    fun feed(p: List<BodyPoint>?, frames: Int) {
        repeat(frames) { last = engine.update(p, W3, H3, t, false); t += 33L }
    }
}

/** Front view, torso 140 px long; the hips are placed at (hx, hy). */
private fun front(hx: Float, hy: Float) = pts3(*both3(11, hx, hy - 140f), *both3(23, hx, hy))

private fun twist(wx: Float) = pts3(
    *both3(11, 240f, 200f), *both3(23, 240f, 340f), *both3(15, wx, 330f),
)

private fun lyingKick(lAnkleY: Float, rAnkleY: Float) = pts3(
    *both3(11, 100f, 520f), *both3(23, 250f, 540f),
    tri3(27, 420f, lAnkleY), tri3(28, 420f, rAnkleY),
)

private fun hingeSide(bent: Boolean) = pts3(
    tri3(11, if (bent) 370f else 250f, if (bent) 330f else 200f), tri3(23, 250f, 340f), tri3(25, 250f, 450f),
    tri3(27, 250f, 560f), tri3(28, 120f, 380f),
)

private fun toeStand() = pts3(
    *both3(11, 240f, 200f), *both3(23, 240f, 340f), tri3(15, 190f, 340f), tri3(16, 290f, 340f), tri3(27, 215f, 560f), tri3(28, 265f, 560f),
)
private fun toeTouchL() = pts3( // left hand reaches the raised right foot
    *both3(11, 240f, 200f), *both3(23, 240f, 340f), tri3(15, 255f, 390f), tri3(16, 290f, 340f), tri3(27, 215f, 560f), tri3(28, 265f, 400f),
)
private fun toeTouchR() = pts3(
    *both3(11, 240f, 200f), *both3(23, 240f, 340f), tri3(15, 190f, 340f), tri3(16, 225f, 390f), tri3(27, 215f, 400f), tri3(28, 265f, 560f),
)

private fun inStand() = pts3(*both3(11, 240f, 200f), *both3(23, 240f, 340f), *both3(27, 240f, 560f))
private fun inPlank() = pts3(*both3(11, 400f, 420f), *both3(23, 250f, 440f), *both3(27, 90f, 460f))

class Batch3Test {
    @Test fun jumpRopeCountsLandingsOnly() {
        val ground = front(240f, 340f)
        val air = front(240f, 322f)
        val r = Run3(ExerciseType.JUMP_ROPE)
        r.feed(ground, 10)
        repeat(6) { r.feed(air, 3); r.feed(ground, 3) }
        assertEquals(6, r.engine.reps)
        val q = Run3(ExerciseType.JUMP_ROPE)
        q.feed(ground, 10)
        repeat(10) { q.feed(front(240f, 338f), 2); q.feed(ground, 2) } // tiny jitter only
        assertEquals(0, q.engine.reps)
    }

    @Test fun skaterHopsAndSideShuffleCountSideChanges() {
        for (t in listOf(ExerciseType.SKATER_HOPS, ExerciseType.SIDE_SHUFFLE)) {
            val left = front(190f, 340f)
            val right = front(290f, 340f)
            val r = Run3(t)
            r.feed(left, 6)
            repeat(4) { r.feed(right, 6); r.feed(left, 6) }
            assertTrue(t.name + " " + r.engine.reps, r.engine.reps in 7..8)
            val q = Run3(t)
            q.feed(left, 6)
            repeat(6) { q.feed(front(200f, 340f), 6); q.feed(left, 6) } // sways only a little
            assertEquals(0, q.engine.reps)
        }
    }

    @Test fun russianTwistCountsEachSide() {
        val r = Run3(ExerciseType.RUSSIAN_TWIST)
        r.feed(twist(180f), 6)
        repeat(5) { r.feed(twist(300f), 6); r.feed(twist(180f), 6) }
        assertTrue("" + r.engine.reps, r.engine.reps in 9..10)
        val q = Run3(ExerciseType.RUSSIAN_TWIST)
        q.feed(twist(235f), 6)
        repeat(5) { q.feed(twist(250f), 6); q.feed(twist(235f), 6) }
        assertEquals(0, q.engine.reps)
    }

    @Test fun flutterAndScissorKicksCountSwaps() {
        for (t in listOf(ExerciseType.FLUTTER_KICKS, ExerciseType.SCISSOR_KICKS)) {
            val a = lyingKick(470f, 560f)
            val b = lyingKick(560f, 470f)
            val r = Run3(t)
            r.feed(a, 4)
            repeat(6) { r.feed(b, 4); r.feed(a, 4) }
            assertTrue(t.name + " " + r.engine.reps, r.engine.reps in 11..12)
            val q = Run3(t)
            q.feed(lyingKick(520f, 524f), 100)
            assertEquals(0, q.engine.reps)
            val standing = front(240f, 340f)
            assertTrue(!BodyClassifier.read(t, standing, W3, H3).valid)
        }
    }

    @Test fun singleLegDeadliftCounts() {
        assertEquals(Pose.OPEN, BodyClassifier.read(ExerciseType.SL_RDL, hingeSide(false), W3, H3).pose)
        assertEquals(Pose.CLOSED, BodyClassifier.read(ExerciseType.SL_RDL, hingeSide(true), W3, H3).pose)
        val r = Run3(ExerciseType.SL_RDL)
        r.feed(hingeSide(false), 10)
        repeat(4) { r.feed(hingeSide(true), 8); r.feed(hingeSide(false), 8) }
        assertEquals(4, r.engine.reps)
    }

    @Test fun walkingToeTouchCountsBothHands() {
        val r = Run3(ExerciseType.WALKING_TOE_TOUCH)
        r.feed(toeStand(), 10)
        repeat(3) { r.feed(toeTouchL(), 8); r.feed(toeStand(), 8); r.feed(toeTouchR(), 8); r.feed(toeStand(), 8) }
        assertEquals(6, r.engine.reps)
        assertEquals(3, r.engine.leftReps)
        assertEquals(3, r.engine.rightReps)
    }

    @Test fun inchwormNeedsThePlank() {
        val r = Run3(ExerciseType.INCHWORM)
        r.feed(inStand(), 15)
        repeat(3) { r.feed(inPlank(), 20); r.feed(inStand(), 20) }
        assertEquals(3, r.engine.reps)
        val q = Run3(ExerciseType.INCHWORM)
        q.feed(inStand(), 15)
        repeat(3) { q.feed(inStand(), 20) }
        assertEquals(0, q.engine.reps)
    }

    @Test fun everyNewExerciseIsInTheLibrary() {
        val ids = listOf("jump_rope", "skater_hops", "side_shuffle", "russian_twist", "flutter_kicks", "scissor_kicks", "sl_rdl",
            "walking_toe_touch", "inchworm")
        for (id in ids) {
            val it = Library.byId(id)
            assertTrue(id, it != null && it.type != null && it.camera)
        }
    }
}
