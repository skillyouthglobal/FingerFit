package com.fingerfit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.ui.ExerciseScreen
import com.fingerfit.ui.FingerFitTheme
import com.fingerfit.ui.HomeScreen
import com.fingerfit.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            FingerFitTheme(settings.theme) { FingerFitApp(vm) }
        }
    }
}

private const val HOME = "home"
private const val EXERCISE = "exercise"
private const val SETTINGS = "settings"

@Composable
private fun FingerFitApp(vm: AppViewModel) {
    var screen by rememberSaveable { mutableStateOf(HOME) }
    when (screen) {
        EXERCISE -> ExerciseScreen(vm, onExit = { screen = HOME })
        SETTINGS -> SettingsScreen(vm, onBack = { screen = HOME })
        else -> HomeScreen(
            vm,
            onStart = { vm.prepareSession(); screen = EXERCISE },
            onSettings = { screen = SETTINGS },
        )
    }
}
