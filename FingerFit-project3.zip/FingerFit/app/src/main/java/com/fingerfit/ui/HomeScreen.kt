package com.fingerfit.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.data.Session
import com.fingerfit.data.localDate
import com.fingerfit.data.todayReps
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

private val PRESETS = listOf(10, 20, 50)

@Composable
fun HomeScreen(vm: AppViewModel, onStart: () -> Unit, onSettings: () -> Unit) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    var showCustom by remember { mutableStateOf(false) }

    val today = history.todayReps()
    val target = settings.target
    val progress = (today.toFloat() / target).coerceIn(0f, 1f)

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.systemBarsPadding()) {
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FingerFitLogo(52.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("FingerFit", fontSize = 26.sp, fontWeight = FontWeight.Black)
                        Text(
                            "AI Hand Exercise Counter",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp,
                        )
                    }
                    IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, contentDescription = "Settings") }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Today", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text("$today", fontSize = 56.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                            Text(
                                "  reps",
                                fontSize = 18.sp,
                                modifier = Modifier.padding(bottom = 10.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth().height(10.dp),
                            trackColor = MaterialTheme.colorScheme.surfaceVariant,
                            strokeCap = androidx.compose.ui.graphics.StrokeCap.Round,
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Target: $target reps  ·  ${(progress * 100).toInt()}% of target",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PRESETS.forEach { p ->
                                FilterChip(
                                    selected = target == p,
                                    onClick = { vm.setTarget(p) },
                                    label = { Text("$p") },
                                )
                            }
                            FilterChip(
                                selected = target !in PRESETS,
                                onClick = { showCustom = true },
                                label = { Text(if (target !in PRESETS) "Custom ($target)" else "Custom") },
                            )
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = onStart,
                    modifier = Modifier.fillMaxWidth().height(60.dp),
                    shape = RoundedCornerShape(20.dp),
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Start Exercise", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }

            item {
                Text("Recent workouts", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
            }

            if (history.isEmpty()) {
                item {
                    Text(
                        "No workouts yet. Press Start Exercise and open and close your hand in front of the camera.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                items(history.take(15)) { SessionRow(it) }
            }
        }
    }

    if (showCustom) CustomTargetDialog(
        current = target,
        onDismiss = { showCustom = false },
        onConfirm = { vm.setTarget(it); showCustom = false },
    )
}

@Composable
private fun SessionRow(s: Session) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(dayLabel(s), fontWeight = FontWeight.SemiBold)
                Text(
                    "${formatDuration(s.durationSec * 1000L)}  ·  target ${s.target}",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (s.targetReached) {
                Icon(Icons.Default.Check, contentDescription = "Target reached", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
            }
            Text("${s.reps} reps", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
private fun CustomTargetDialog(current: Int, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    var text by remember { mutableStateOf(current.toString()) }
    val value = text.toIntOrNull()
    val valid = value != null && value in 1..1000
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom target") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter(Char::isDigit).take(4) },
                label = { Text("Repetitions (1-1000)") },
                singleLine = true,
                isError = !valid,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(value!!) }, enabled = valid) { Text("Set target") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

fun formatDuration(ms: Long): String {
    val total = (ms / 1000).toInt()
    return "%d:%02d".format(Locale.US, total / 60, total % 60)
}

private fun dayLabel(s: Session): String {
    val today = LocalDate.now()
    val d = s.localDate()
    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(s.timestamp))
    return when (d) {
        today -> "Today, $time"
        today.minusDays(1) -> "Yesterday, $time"
        else -> SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(s.timestamp))
    }
}
