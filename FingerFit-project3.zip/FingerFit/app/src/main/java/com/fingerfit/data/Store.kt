package com.fingerfit.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class Settings(
    val sound: Boolean = true,
    val vibration: Boolean = true,
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val target: Int = 20,
    val frontCamera: Boolean = true,
)

data class Session(
    val timestamp: Long,
    val reps: Int,
    val durationSec: Int,
    val target: Int,
    val targetReached: Boolean,
)

fun Session.localDate(): LocalDate =
    Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).toLocalDate()

fun List<Session>.todayReps(): Int {
    val today = LocalDate.now()
    return filter { it.localDate() == today }.sumOf { it.reps }
}

/** Everything is stored on the device only (SharedPreferences). Nothing is uploaded. */
class Store(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("fingerfit", Context.MODE_PRIVATE)

    fun loadSettings(): Settings = Settings(
        sound = sp.getBoolean("sound", true),
        vibration = sp.getBoolean("vibration", true),
        theme = runCatching { ThemeMode.valueOf(sp.getString("theme", "SYSTEM") ?: "SYSTEM") }
            .getOrDefault(ThemeMode.SYSTEM),
        target = sp.getInt("target", 20).coerceIn(1, 1000),
        frontCamera = sp.getBoolean("front_camera", true),
    )

    fun saveSettings(s: Settings) {
        sp.edit()
            .putBoolean("sound", s.sound)
            .putBoolean("vibration", s.vibration)
            .putString("theme", s.theme.name)
            .putInt("target", s.target)
            .putBoolean("front_camera", s.frontCamera)
            .apply()
    }

    fun loadHistory(): List<Session> {
        val raw = sp.getString("history", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Session(
                    timestamp = o.getLong("t"),
                    reps = o.getInt("r"),
                    durationSec = o.getInt("d"),
                    target = o.getInt("g"),
                    targetReached = o.optBoolean("ok", false),
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveHistory(list: List<Session>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("t", it.timestamp)
                    .put("r", it.reps)
                    .put("d", it.durationSec)
                    .put("g", it.target)
                    .put("ok", it.targetReached),
            )
        }
        sp.edit().putString("history", arr.toString()).apply()
    }
}
