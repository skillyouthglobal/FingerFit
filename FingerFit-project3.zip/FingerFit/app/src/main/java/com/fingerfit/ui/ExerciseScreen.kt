package com.fingerfit.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.SessionUi
import com.fingerfit.Status
import com.fingerfit.vision.HandTracker

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

private fun cameraGranted(context: Context) =
    ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

@Composable
fun ExerciseScreen(vm: AppViewModel, onExit: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    var hasPermission by remember { mutableStateOf(cameraGranted(context)) }
    var denied by remember { mutableStateOf(false) }
    var tracker by remember { mutableStateOf<HandTracker?>(null) }
    var modelError by remember { mutableStateOf<String?>(null) }
    var retry by remember { mutableIntStateOf(0) }
    var showEndDialog by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted
        denied = !granted
    }

    // Pause when the app goes to the background (but not on a simple screen rotation);
    // re-check the permission when returning from system settings.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> hasPermission = cameraGranted(context)
                Lifecycle.Event.ON_PAUSE ->
                    if (context.findActivity()?.isChangingConfigurations != true) vm.pauseIfRunning()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Load the on-device hand model once the camera is allowed; free it when leaving.
    DisposableEffect(hasPermission) {
        var t: HandTracker? = null
        if (hasPermission) {
            try {
                t = HandTracker(context.applicationContext)
                modelError = null
            } catch (e: Throwable) {
                modelError = "The hand-tracking model could not be loaded (${e.localizedMessage ?: "unknown error"}). " +
                    "Reinstall the app."
            }
            tracker = t
        }
        onDispose {
            tracker = null
            t?.close()
        }
    }

    BackHandler {
        if (ui.status == Status.RUNNING) vm.pause()
        showEndDialog = true
    }

    val leave = {
        vm.dismissSummary()
        onExit()
    }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    if (ui.status == Status.RUNNING) vm.pause()
                    showEndDialog = true
                }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                Text("Exercise", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }

            if (!hasPermission) {
                PermissionCard(
                    denied = denied,
                    onAllow = { launcher.launch(Manifest.permission.CAMERA) },
                    onOpenSettings = {
                        context.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)),
                        )
                    },
                )
            } else {
                val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
                val cameraPane: @Composable (Modifier) -> Unit = { mod ->
                    CameraPane(
                        vm = vm,
                        ui = ui,
                        front = settings.frontCamera,
                        tracker = tracker,
                        error = modelError ?: ui.error,
                        retryKey = retry,
                        onFlip = { vm.setFrontCamera(!settings.frontCamera); vm.clearError() },
                        onRetry = { vm.clearError(); retry++ },
                        modifier = mod,
                    )
                }
                if (landscape) {
                    Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        cameraPane(Modifier.weight(1.3f).fillMaxSize())
                        ControlsPanel(vm, ui, Modifier.weight(1f).fillMaxSize()) { showEndDialog = true }
                    }
                } else {
                    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        cameraPane(Modifier.weight(1f).fillMaxWidth())
                        ControlsPanel(vm, ui, Modifier.fillMaxWidth()) { showEndDialog = true }
                    }
                }
            }
        }
    }

    if (showEndDialog && ui.status != Status.FINISHED) {
        AlertDialog(
            onDismissRequest = { showEndDialog = false },
            title = { Text("End exercise?") },
            text = {
                Text(
                    if (ui.reps > 0) "Your ${ui.reps} repetitions will be saved to your history."
                    else "No repetitions were counted yet.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showEndDialog = false
                    if (ui.status == Status.IDLE) leave() else vm.endSession()
                }) { Text("End exercise") }
            },
            dismissButton = { TextButton(onClick = { showEndDialog = false }) { Text("Keep going") } },
        )
    }

    ui.summary?.let { s ->
        if (ui.status == Status.FINISHED) {
            AlertDialog(
                onDismissRequest = {},
                title = { Text(if (s.targetReached) "Target completed!" else "Session summary") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (s.targetReached) Text("Great work - you reached your target of ${s.target} repetitions.")
                        Text("Repetitions: ${s.reps}", fontWeight = FontWeight.SemiBold)
                        Text("Time: ${formatDuration(s.durationSec * 1000L)}")
                        Text("Target: ${s.target}")
                    }
                },
                confirmButton = { TextButton(onClick = leave) { Text("Done") } },
            )
        }
    }
}

@Composable
private fun CameraPane(
    vm: AppViewModel,
    ui: SessionUi,
    front: Boolean,
    tracker: HandTracker?,
    error: String?,
    retryKey: Int,
    onFlip: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier,
) {
    Box(modifier.clip(RoundedCornerShape(24.dp)).background(Color.Black)) {
        if (tracker != null && error == null) {
            key(front, retryKey) {
                CameraView(vm = vm, front = front, tracker = tracker, onError = vm::onCameraError, modifier = Modifier.fillMaxSize())
            }
            HandOverlay(vm, Modifier.fillMaxSize())
        }

        // hand-detection indicator
        val running = ui.status == Status.RUNNING
        val chipColor = when {
            !running -> Color(0xFF6B7280)
            ui.handDetected -> Color(0xFF16A34A)
            else -> Color(0xFFDC2626)
        }
        Row(
            Modifier.align(Alignment.TopStart).padding(12.dp).clip(RoundedCornerShape(50)).background(Color(0x99000000))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(chipColor))
            Spacer(Modifier.width(8.dp))
            Text(
                when {
                    !running -> "Camera ready"
                    ui.handDetected -> "Hand detected"
                    else -> "No hand"
                },
                color = Color.White, fontSize = 13.sp,
            )
        }

        IconButton(
            onClick = onFlip,
            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).clip(CircleShape).background(Color(0x99000000)),
        ) { Icon(Icons.Default.Refresh, contentDescription = "Switch camera", tint = Color.White) }

        if (error != null) {
            Column(
                Modifier.align(Alignment.Center).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(error, color = Color.White, textAlign = TextAlign.Center)
                if (tracker != null) OutlinedButton(onClick = onRetry) { Text("Try again", color = Color.White) }
            }
        } else {
            Text(
                ui.message,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp).clip(RoundedCornerShape(16.dp))
                    .background(if (ui.message.startsWith("Repetition")) Color(0xCC16A34A) else Color(0xAA000000))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            )
        }
    }
}

@Composable
private fun ControlsPanel(vm: AppViewModel, ui: SessionUi, modifier: Modifier, onEnd: () -> Unit) {
    val pulse = remember { Animatable(1f) }
    LaunchedEffect(ui.repFlash) {
        if (ui.repFlash > 0) {
            pulse.animateTo(1.22f, tween(90))
            pulse.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy))
        }
    }

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                "${ui.reps}",
                fontSize = 84.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.scale(pulse.value),
            )
            Text(
                " / ${ui.target}",
                fontSize = 26.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 16.dp),
            )
        }
        Text(formatDuration(ui.elapsedMs), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        LinearProgressIndicator(
            progress = { (ui.reps.toFloat() / ui.target).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)),
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
        )
        Spacer(Modifier.height(4.dp))

        when (ui.status) {
            Status.IDLE, Status.FINISHED -> Button(
                onClick = vm::start,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(18.dp),
                enabled = ui.status == Status.IDLE,
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Start", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Status.RUNNING, Status.PAUSED -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { if (ui.status == Status.RUNNING) vm.pause() else vm.resume() },
                    modifier = Modifier.weight(1.3f).height(56.dp),
                    shape = RoundedCornerShape(18.dp),
                ) { Text(if (ui.status == Status.RUNNING) "Pause" else "Resume", fontWeight = FontWeight.Bold) }
                OutlinedButton(
                    onClick = vm::resetSession,
                    modifier = Modifier.weight(1f).height(56.dp),
                    shape = RoundedCornerShape(18.dp),
                ) { Text("Reset") }
                OutlinedButton(
                    onClick = onEnd,
                    modifier = Modifier.weight(1f).height(56.dp),
                    shape = RoundedCornerShape(18.dp),
                ) { Text("End") }
            }
        }
    }
}

@Composable
private fun PermissionCard(denied: Boolean, onAllow: () -> Unit, onOpenSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(16.dp))
        Text("Camera access needed", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "FingerFit uses the camera only to see your hand and count repetitions. " +
                "Video is analysed live on your phone and is never recorded, saved or uploaded.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (denied) {
            Spacer(Modifier.height(12.dp))
            Text(
                "Camera permission was denied. Allow it to continue, or turn it on in the app settings.",
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.error,
            )
        }
        Spacer(Modifier.height(20.dp))
        Button(onClick = onAllow, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
            Text("Allow camera")
        }
        if (denied) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onOpenSettings, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                Text("Open app settings")
            }
        }
    }
}
