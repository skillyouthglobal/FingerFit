package com.fingerfit.ui

import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.logic.Pose
import com.fingerfit.vision.HandAnalyzer
import com.fingerfit.vision.HandTracker
import java.util.concurrent.Executors
import kotlin.math.min

/**
 * Live camera preview + analysis, bound to the lifecycle: the camera is released
 * automatically when the screen leaves composition or the app goes to the background.
 * Frames stay in memory; nothing is recorded or uploaded.
 */
@Composable
fun CameraView(
    vm: AppViewModel,
    front: Boolean,
    tracker: HandTracker,
    onError: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val errorCallback by rememberUpdatedState(onError)
    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FIT_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }

    DisposableEffect(front, tracker, lifecycleOwner) {
        val executor = Executors.newSingleThreadExecutor()
        val providerFuture = ProcessCameraProvider.getInstance(context)
        var provider: ProcessCameraProvider? = null
        var disposed = false

        providerFuture.addListener({
            if (disposed) return@addListener
            try {
                val p = providerFuture.get()
                provider = p
                val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                if (!p.hasCamera(selector)) {
                    errorCallback(
                        if (front) "This phone has no front camera. Try the rear camera."
                        else "This phone has no rear camera. Try the front camera.",
                    )
                    return@addListener
                }
                val resolution = ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy(AspectRatio.RATIO_4_3, AspectRatioStrategy.FALLBACK_RULE_AUTO))
                    .build()
                val preview = Preview.Builder().setResolutionSelector(resolution).build()
                    .also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(resolution)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor, HandAnalyzer(tracker, front, vm::isActive, vm::onFrame))

                p.unbindAll()
                p.bindToLifecycle(lifecycleOwner, selector, preview, analysis)
            } catch (e: Exception) {
                errorCallback("The camera could not start (${e.localizedMessage ?: "unknown error"}). Close other apps that use the camera and try again.")
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            disposed = true
            provider?.unbindAll()
            executor.shutdown()
        }
    }

    AndroidView(factory = { previewView }, modifier = modifier)
}

private val CONNECTIONS = listOf(
    0 to 1, 1 to 2, 2 to 3, 3 to 4,
    0 to 5, 5 to 6, 6 to 7, 7 to 8,
    5 to 9, 9 to 10, 10 to 11, 11 to 12,
    9 to 13, 13 to 14, 14 to 15, 15 to 16,
    13 to 17, 17 to 18, 18 to 19, 19 to 20, 0 to 17,
)

/** Draws the tracked hand skeleton, aligned with the FIT_CENTER preview. */
@Composable
fun HandOverlay(vm: AppViewModel, modifier: Modifier = Modifier) {
    val overlay by vm.overlay.collectAsStateWithLifecycle()
    Canvas(modifier) {
        val o = overlay ?: return@Canvas
        val pts = o.points ?: return@Canvas
        val scale = min(size.width / o.width, size.height / o.height)
        val ox = (size.width - o.width * scale) / 2f
        val oy = (size.height - o.height * scale) / 2f
        fun map(i: Int) = Offset(ox + pts[i].x * o.width * scale, oy + pts[i].y * o.height * scale)

        val color = when (o.pose) {
            Pose.OPEN -> Color(0xFF2DE0C4)
            Pose.CLOSED -> Color(0xFFFFB547)
            Pose.UNKNOWN -> Color.White
        }
        CONNECTIONS.forEach { (a, b) -> drawLine(color.copy(alpha = 0.85f), map(a), map(b), 5f, StrokeCap.Round) }
        for (i in pts.indices) drawCircle(color, 7f, map(i))
    }
}
