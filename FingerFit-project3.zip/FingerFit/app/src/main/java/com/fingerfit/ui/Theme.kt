package com.fingerfit.ui

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.Canvas
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.fingerfit.data.ThemeMode

val Mint = Color(0xFF2DE0C4)
val Violet = Color(0xFF7C5CFF)
val Amber = Color(0xFFFFB547)

private val DarkColors = darkColorScheme(
    primary = Mint,
    onPrimary = Color(0xFF04201B),
    secondary = Color(0xFF9B8CFF),
    background = Color(0xFF0E1020),
    onBackground = Color(0xFFEDEFFF),
    surface = Color(0xFF171A30),
    onSurface = Color(0xFFEDEFFF),
    surfaceVariant = Color(0xFF22264A),
    onSurfaceVariant = Color(0xFFA9AED6),
    error = Color(0xFFFF6B7A),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF5B3FE0),
    onPrimary = Color.White,
    secondary = Color(0xFF0FB5A0),
    background = Color(0xFFF5F6FC),
    onBackground = Color(0xFF14172B),
    surface = Color.White,
    onSurface = Color(0xFF14172B),
    surfaceVariant = Color(0xFFE8EAF8),
    onSurfaceVariant = Color(0xFF5A5F86),
    error = Color(0xFFD8334A),
)

@Composable
fun FingerFitTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        WindowCompat.getInsetsController(window, view).apply {
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}

/** The FingerFit logo: an open hand on a gradient tile. */
@Composable
fun FingerFitLogo(size: Dp = 56.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        drawRoundRect(
            brush = Brush.linearGradient(listOf(Color(0xFF2B1B7A), Violet)),
            size = Size(s, s),
            cornerRadius = CornerRadius(s * 0.28f),
        )
        val stroke = s * 0.075f
        val xs = floatArrayOf(0.34f, 0.45f, 0.56f, 0.67f)
        val tops = floatArrayOf(0.33f, 0.26f, 0.28f, 0.37f)
        for (i in xs.indices) {
            drawLine(Color.White, Offset(s * xs[i], s * 0.55f), Offset(s * xs[i], s * tops[i]), stroke, StrokeCap.Round)
        }
        drawLine(Mint, Offset(s * 0.28f, s * 0.62f), Offset(s * 0.19f, s * 0.49f), stroke, StrokeCap.Round)
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(s * 0.28f, s * 0.52f),
            size = Size(s * 0.45f, s * 0.30f),
            cornerRadius = CornerRadius(s * 0.14f),
        )
    }
}
