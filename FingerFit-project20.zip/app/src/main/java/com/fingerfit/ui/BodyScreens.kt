package com.fingerfit.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.LinkViewModel
import com.fingerfit.Status
import com.fingerfit.WorkoutUi
import com.fingerfit.WorkoutViewModel
import com.fingerfit.data.Repo
import com.fingerfit.data.toLocalDate
import com.fingerfit.link.LinkRole
import com.fingerfit.link.LinkState
import com.fingerfit.logic.ExerciseType
import com.fingerfit.vision.PoseAnalyzer
import com.fingerfit.vision.PoseTracker
import java.time.LocalDate
import kotlin.math.min

private fun cameraGranted(context: Context) =
    ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

// ---------------------------------------------------------------------------
// Exercise list
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Workout screen
// ---------------------------------------------------------------------------

@Composable
fun WorkoutScreen(vm: WorkoutViewModel, app: AppViewModel, link: LinkViewModel, onExit: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    val settings by app.settings.collectAsStateWithLifecycle()

    // A linked phone (app or browser) can be used as the camera.
    val linkUi by link.ui.collectAsStateWithLifecycle()
    val webUi by link.webUi.collectAsStateWithLifecycle()
    val ipUi by link.ipUi.collectAsStateWithLifecycle()
    val streamOk by link.streamOk.collectAsStateWithLifecycle()
    val fps by link.fps.collectAsStateWithLifecycle()
    val lag by link.lagMs.collectAsStateWithLifecycle()
    val useRemote by link.useRemote.collectAsStateWithLifecycle()
    val remoteAvailable = (linkUi.state == LinkState.CONNECTED && linkUi.role == LinkRole.DISPLAY) || webUi.running || ipUi.running
    val remote = remoteAvailable && useRemote
    val remoteName = if (ipUi.running) ipUi.name.ifBlank { "Wi-Fi camera" } else if (webUi.running) "Browser camera" else (linkUi.peerName ?: "Camera phone")

    var hasPermission by remember { mutableStateOf(cameraGranted(context)) }
    var denied by remember { mutableStateOf(false) }
    var tracker by remember { mutableStateOf<PoseTracker?>(null) }
    var modelError by remember { mutableStateOf<String?>(null) }
    var retry by remember { mutableIntStateOf(0) }
    var showEnd by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted
        denied = !granted
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> hasPermission = cameraGranted(context)
                Lifecycle.Event.ON_PAUSE -> {
                    val changing = (context as? android.app.Activity)?.isChangingConfigurations == true
                    if (!changing) vm.pauseIfRunning()
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    DisposableEffect(hasPermission, remote) {
        var t: PoseTracker? = null
        if (hasPermission && !remote) {
            try {
                t = PoseTracker(context.applicationContext)
                modelError = null
            } catch (e: Throwable) {
                modelError = "The body-tracking model could not be loaded (${e.localizedMessage ?: "unknown error"}). Reinstall the app."
            }
            tracker = t
        }
        onDispose {
            tracker = null
            t?.close()
        }
    }

    val leave = {
        vm.leave()
        onExit()
    }

    BackHandler {
        if (ui.status == Status.IDLE) leave()
        else {
            if (ui.status == Status.RUNNING) vm.pause()
            showEnd = true
        }
    }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    if (ui.status == Status.IDLE) leave()
                    else {
                        if (ui.status == Status.RUNNING) vm.pause()
                        showEnd = true
                    }
                }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                Text("${ui.type.emoji} ${ui.type.title}", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }

            if (remoteAvailable) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(
                        selected = !useRemote, onClick = { link.setUseRemote(false) },
                        enabled = ui.status == Status.IDLE, label = { Text("This phone") },
                    )
                    FilterChip(
                        selected = useRemote, onClick = { link.setUseRemote(true) },
                        enabled = ui.status == Status.IDLE, label = { Text(if (streamOk && fps > 0 && lag > 0 && ipUi.running) "📷 $remoteName · $fps fps · $lag ms" else if (streamOk && fps > 0) "📷 $remoteName · $fps fps" else "📷 $remoteName") },
                    )
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { vm.pauseIfRunning(); link.stop() }) { Text("Disconnect") }
                }
            }

            if (!hasPermission && !remote) {
                BodyPermissionCard(
                    denied = denied,
                    onAllow = { launcher.launch(Manifest.permission.CAMERA) },
                    onOpenSettings = {
                        context.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)),
                        )
                    },
                )
            } else {
                val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
                val pane: @Composable (Modifier) -> Unit = { mod ->
                    BodyCameraPane(
                        vm = vm, ui = ui, front = settings.frontCamera, tracker = tracker,
                        error = if (remote) null else (modelError ?: ui.error), retryKey = retry,
                        remote = remote, link = link, streamOk = streamOk, remoteName = remoteName,
                        onFlip = { app.setFrontCamera(!settings.frontCamera); vm.clearError() },
                        onRetry = { vm.clearError(); retry++ },
                        modifier = mod,
                    )
                }
                if (landscape) {
                    Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        pane(Modifier.weight(1.3f).fillMaxSize())
                        WorkoutControls(vm, ui, Modifier.weight(1f).fillMaxSize()) { showEnd = true }
                    }
                } else {
                    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        pane(Modifier.weight(1f).fillMaxWidth())
                        WorkoutControls(vm, ui, Modifier.fillMaxWidth()) { showEnd = true }
                    }
                }
            }
        }
    }

    if (showEnd && ui.status != Status.FINISHED) {
        AlertDialog(
            onDismissRequest = { showEnd = false },
            title = { Text("End workout?") },
            text = {
                Text(
                    if (ui.reps > 0) "Your ${ui.reps} ${ui.type.unit} will be saved to your history."
                    else "Nothing was counted yet.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showEnd = false
                    if (ui.status == Status.IDLE) leave() else vm.end()
                }) { Text("End workout") }
            },
            dismissButton = { TextButton(onClick = { showEnd = false }) { Text("Keep going") } },
        )
    }

    ui.summary?.let { s ->
        if (ui.status == Status.FINISHED) {
            AlertDialog(
                onDismissRequest = {},
                title = { Text(if (s.reached) "Target completed!" else "Workout summary") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (s.reached) Text("Great work. You reached your target of ${s.target} ${s.type.unit}.")
                        Text(s.type.title, fontWeight = FontWeight.SemiBold)
                        Text("${if (s.type.isHold) "Held" else "Repetitions"}: ${s.reps}${if (s.type.isHold) " sec" else ""}")
                        if (s.type.isSided) Text("Left: ${s.left}   Right: ${s.right}")
                        Text("Time: ${formatDuration(s.seconds * 1000L)}")
                    }
                },
                confirmButton = { TextButton(onClick = leave) { Text("Done") } },
            )
        }
    }
}

@Composable
private fun BodyCameraPane(
    vm: WorkoutViewModel,
    ui: WorkoutUi,
    front: Boolean,
    tracker: PoseTracker?,
    error: String?,
    retryKey: Int,
    remote: Boolean,
    link: LinkViewModel,
    streamOk: Boolean,
    remoteName: String,
    onFlip: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier,
) {
    Box(modifier.clip(RoundedCornerShape(24.dp)).background(Color.Black)) {
        if (remote) {
            val preview by link.preview.collectAsStateWithLifecycle()
            preview?.let {
                Image(
                    bitmap = it.asImageBitmap(), contentDescription = "Camera phone view",
                    contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize(),
                )
            }
            BodyOverlayView(vm, Modifier.fillMaxSize())
        } else if (tracker != null && error == null) {
            key(front, retryKey) {
                val analyzer = remember(tracker, front) { PoseAnalyzer(tracker, front, vm::isActive, vm::onFrame) }
                CameraView(front = front, analyzer = analyzer, onError = vm::onCameraError, modifier = Modifier.fillMaxSize())
            }
            BodyOverlayView(vm, Modifier.fillMaxSize())
        }

        val chipColor = if (ui.detected) Color(0xFF16A34A) else Color(0xFFDC2626)
        Row(
            Modifier.align(Alignment.TopStart).padding(12.dp).clip(RoundedCornerShape(50)).background(Color(0x99000000))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(chipColor))
            Spacer(Modifier.width(8.dp))
            Text(if (ui.detected) "Body detected" else "No body", color = Color.White, fontSize = 13.sp)
        }

        if (!remote) {
            IconButton(
                onClick = onFlip,
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).clip(CircleShape).background(Color(0x99000000)),
            ) { Icon(Icons.Default.Refresh, contentDescription = "Switch camera", tint = Color.White) }
        } else {
            val ipRunning by link.ipUi.collectAsStateWithLifecycle()
            if (ipRunning.running) {
                Text(
                    "↻ Rotate picture", color = Color.White, fontSize = 13.sp,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp).clip(RoundedCornerShape(50))
                        .background(Color(0x99000000)).clickable { link.rotateIp() }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
            Text(
                "📷 $remoteName", color = Color.White, fontSize = 12.sp,
                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp).clip(RoundedCornerShape(50))
                    .background(Color(0x99000000)).padding(horizontal = 10.dp, vertical = 6.dp),
            )
        }

        if (remote && !streamOk) {
            Text(
                "Waiting for the camera phone…\nKeep it open with the camera running.",
                color = Color.White, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).padding(24.dp),
            )
        } else if (error != null) {
            Column(
                Modifier.align(Alignment.Center).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(error, color = Color.White, textAlign = TextAlign.Center)
                if (tracker != null) OutlinedButton(onClick = onRetry) { Text("Try again", color = Color.White) }
            }
        } else if (ui.message.isNotEmpty()) {
            Text(
                ui.message,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp).clip(RoundedCornerShape(16.dp))
                    .background(if (ui.message.startsWith("Repetition")) Color(0xCC16A34A) else Color(0xAA000000))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            )
        }
    }
}

@Composable
internal fun WorkoutControls(vm: WorkoutViewModel, ui: WorkoutUi, modifier: Modifier, onEnd: () -> Unit) {
    val pulse = remember { Animatable(1f) }
    LaunchedEffect(ui.repFlash) {
        if (ui.repFlash > 0) {
            pulse.animateTo(1.2f, tween(90))
            pulse.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy))
        }
    }
    val unit = ui.type.unit

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                "${ui.reps}",
                fontSize = 76.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.scale(pulse.value),
            )
            Text(
                " / ${ui.target} $unit",
                fontSize = 20.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 12.dp),
            )
        }
        if (ui.type.isSided) {
            Text("Left: ${ui.left}      Right: ${ui.right}", fontWeight = FontWeight.SemiBold)
        }
        Text(formatDuration(ui.elapsedMs), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        LinearProgressIndicator(
            progress = { (ui.reps.toFloat() / ui.target).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
        )

        when (ui.status) {
            Status.IDLE, Status.FINISHED -> {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { vm.bumpTarget(false) }, enabled = ui.status == Status.IDLE) { Text("-") }
                    Text("Target: ${ui.target} $unit", fontWeight = FontWeight.SemiBold)
                    OutlinedButton(onClick = { vm.bumpTarget(true) }, enabled = ui.status == Status.IDLE) { Text("+") }
                }
                Button(
                    onClick = vm::start,
                    enabled = ui.status == Status.IDLE,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(18.dp),
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Start", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
            Status.RUNNING, Status.PAUSED -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { if (ui.status == Status.RUNNING) vm.pause() else vm.resume() },
                    modifier = Modifier.weight(1.3f).height(54.dp),
                    shape = RoundedCornerShape(18.dp),
                ) { Text(if (ui.status == Status.RUNNING) "Pause" else "Resume", fontWeight = FontWeight.Bold) }
                OutlinedButton(
                    onClick = vm::resetSession,
                    modifier = Modifier.weight(1f).height(54.dp),
                    shape = RoundedCornerShape(18.dp),
                ) { Text("Reset") }
                OutlinedButton(
                    onClick = onEnd,
                    modifier = Modifier.weight(1f).height(54.dp),
                    shape = RoundedCornerShape(18.dp),
                ) { Text("End") }
            }
        }
    }
}

private val BODY_LINES = listOf(
    11 to 12, 11 to 13, 13 to 15, 12 to 14, 14 to 16,
    11 to 23, 12 to 24, 23 to 24,
    23 to 25, 25 to 27, 24 to 26, 26 to 28,
)

/** Draws the tracked skeleton, aligned with the FIT_CENTER camera preview. */
@Composable
internal fun BodyOverlayView(vm: WorkoutViewModel, modifier: Modifier) {
    val overlay by vm.overlay.collectAsStateWithLifecycle()
    Canvas(modifier) {
        val o = overlay ?: return@Canvas
        val scale = min(size.width / o.width, size.height / o.height)
        val ox = (size.width - o.width * scale) / 2f
        val oy = (size.height - o.height * scale) / 2f
        fun at(i: Int) = Offset(ox + o.points[i].x * o.width * scale, oy + o.points[i].y * o.height * scale)
        fun seen(i: Int) = o.points[i].v >= 0.5f
        val color = Color(0xFF2DE0C4)
        BODY_LINES.forEach { (a, b) ->
            if (seen(a) && seen(b)) drawLine(color.copy(alpha = 0.9f), at(a), at(b), 6f, StrokeCap.Round)
        }
        listOf(11, 12, 13, 14, 15, 16, 23, 24, 25, 26, 27, 28).forEach {
            if (seen(it)) drawCircle(Color.White, 8f, at(it))
        }
    }
}

@Composable
private fun BodyPermissionCard(denied: Boolean, onAllow: () -> Unit, onOpenSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(16.dp))
        Text("Camera access needed", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Kinetro uses the camera only to see your body and count repetitions. Video is analysed live on your phone and is never recorded, saved or uploaded.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (denied) {
            Spacer(Modifier.height(12.dp))
            Text(
                "Camera permission was denied. Allow it to continue, or turn it on in the app settings.",
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.error,
            )
        }
        Spacer(Modifier.height(20.dp))
        Button(onClick = onAllow, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
            Text("Allow camera")
        }
        if (denied) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onOpenSettings, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                Text("Open app settings")
            }
        }
    }
}
