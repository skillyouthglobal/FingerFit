package com.fingerfit.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.data.ThemeMode

@Composable
fun SettingsScreen(vm: AppViewModel, updateVm: com.fingerfit.UpdateViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    var confirmClear by remember { mutableStateOf(false) }
    var showTerms by remember { mutableStateOf(false) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    if (showTerms) { TermsScreen(onClose = { showTerms = false }); return }
    BackHandler(onBack = onBack)

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.systemBarsPadding()) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp)) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                Text("Settings", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }

            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                SettingsCard {
                    SwitchRow("Sound after each repetition", s.sound, vm::setSound)
                    SwitchRow("Vibration after each repetition", s.vibration, vm::setVibration)
                }

                SettingsCard {
                    Text("Language", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = LangState.bn, onClick = { LangState.set(ctx, "bn") }, label = { androidx.compose.material3.Text("বাংলা") })
                        FilterChip(selected = !LangState.bn, onClick = { LangState.set(ctx, "en") }, label = { androidx.compose.material3.Text("English") })
                    }
                    OutlinedButton(onClick = { showTerms = true }) { Text("Terms and privacy policy") }
                }

                VoiceCard()

                SettingsCard {
                    Text("Theme", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeMode.values().forEach { mode ->
                            FilterChip(
                                selected = s.theme == mode,
                                onClick = { vm.setTheme(mode) },
                                label = { Text(when (mode) { ThemeMode.LIGHT -> "Light"; ThemeMode.DARK -> "Dark"; else -> "System" }) },
                            )
                        }
                    }
                }

                UpdateCard(updateVm, always = true)

                SettingsCard {
                    Text("Your data", fontWeight = FontWeight.SemiBold)
                    Text(
                        "Workout history is stored only on this phone. Kinetro has no account, no cloud sync, and never records or uploads camera video. Hand detection runs fully offline.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 14.sp,
                    )
                    OutlinedButton(onClick = { confirmClear = true }) { Text("Clear exercise history") }
                }

                Text(
                    "Kinetro 1.0  ·  Fitness & Longevity",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear history?") },
            text = { Text("All saved workouts will be deleted from this phone.") },
            confirmButton = { TextButton(onClick = { vm.clearHistory(); confirmClear = false }) { Text("Clear") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun VoiceCard() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var on by remember { mutableStateOf(com.fingerfit.data.AppPrefs.voiceOn(ctx)) }
    var speed by remember { mutableStateOf(com.fingerfit.data.AppPrefs.voiceSpeed(ctx)) }
    val status by com.fingerfit.voice.Voice.status.collectAsStateWithLifecycle()
    val count by com.fingerfit.voice.Voice.voiceCount.collectAsStateWithLifecycle()
    val picked by com.fingerfit.voice.Voice.pickedIndex.collectAsStateWithLifecycle()
    val profile by com.fingerfit.data.ProfileRepo.profile.collectAsStateWithLifecycle()
    SettingsCard {
        Text("Voice coach", fontWeight = FontWeight.SemiBold)
        SwitchRow("Speak counts and tips while I exercise", on) { on = it; com.fingerfit.voice.Voice.setEnabled(it) }
        when (status) {
            com.fingerfit.voice.VoiceStatus.NO_ENGINE -> Text(
                "No text-to-speech engine was found on this phone. Install Speech Services by Google from the Play Store.",
                color = MaterialTheme.colorScheme.error, fontSize = 13.sp,
            )
            com.fingerfit.voice.VoiceStatus.NO_LANGUAGE -> {
                Text(
                    "The voice for this language is not installed on this phone yet. Open the voice settings and download it (it works offline afterwards).",
                    color = MaterialTheme.colorScheme.error, fontSize = 13.sp,
                )
                OutlinedButton(onClick = { com.fingerfit.voice.Voice.openSettings(ctx) }) { Text("Open voice settings") }
            }
            else -> {
                Text("Speed", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Slow", "Normal", "Fast").forEachIndexed { i, label ->
                        FilterChip(selected = speed == i, onClick = { speed = i; com.fingerfit.voice.Voice.setSpeed(i) }, label = { Text(label) })
                    }
                }
                if (count > 1) {
                    Text("Voice", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (i in 0 until minOf(count, 4)) {
                            FilterChip(selected = picked == i, onClick = { com.fingerfit.voice.Voice.choose(i) }, label = { Text("Voice ${i + 1}") })
                        }
                    }
                }
                OutlinedButton(onClick = {
                    com.fingerfit.voice.Voice.test(com.fingerfit.logic.Coach(LangState.bn, profile?.name ?: "").sample().text)
                }) { Text("Test voice") }
            }
        }
    }
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
