package com.fingerfit.voice

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice as SysVoice
import com.fingerfit.data.AppPrefs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class VoiceStatus { STARTING, READY, NO_ENGINE, NO_LANGUAGE }

/**
 * The coach's voice: the phone's own text-to-speech (works offline once the voice is installed).
 * It picks the best installed voice for the app language and lets the person choose another.
 */
object Voice {
    private var tts: TextToSpeech? = null
    private var app: Context? = null
    private var bn = false
    private var voices: List<SysVoice> = emptyList()

    private val _status = MutableStateFlow(VoiceStatus.STARTING)
    val status: StateFlow<VoiceStatus> = _status.asStateFlow()
    private val _count = MutableStateFlow(0)
    /** How many voices of the current language are installed. */
    val voiceCount: StateFlow<Int> = _count.asStateFlow()
    private val _picked = MutableStateFlow(0)
    val pickedIndex: StateFlow<Int> = _picked.asStateFlow()

    fun init(ctx: Context) {
        if (tts != null) return
        val c = ctx.applicationContext
        app = c
        bn = AppPrefs.lang(c) == "bn"
        try {
            tts = TextToSpeech(c) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    try {
                        tts?.setAudioAttributes(
                            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
                        )
                    } catch (e: Exception) {
                    }
                    apply()
                } else {
                    _status.value = VoiceStatus.NO_ENGINE
                }
            }
        } catch (e: Exception) {
            _status.value = VoiceStatus.NO_ENGINE
        }
    }

    /** The app language changed: use a voice of that language. */
    fun setLang(isBn: Boolean) {
        bn = isBn
        if (tts != null && _status.value != VoiceStatus.STARTING && _status.value != VoiceStatus.NO_ENGINE) apply()
    }

    private fun quality(v: SysVoice): Int {
        var q = v.quality * 10
        if (v.features?.contains("notInstalled") == true) q -= 10_000
        if (v.isNetworkConnectionRequired) q -= 50
        return q
    }

    private fun apply() {
        val t = tts ?: return
        val c = app ?: return
        var r = if (bn) t.setLanguage(Locale("bn", "BD")) else t.setLanguage(Locale.US)
        if (bn && (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)) r = t.setLanguage(Locale("bn", "IN"))
        if (!bn && (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)) r = t.setLanguage(Locale.ENGLISH)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            voices = emptyList(); _count.value = 0
            _status.value = VoiceStatus.NO_LANGUAGE
            return
        }
        val lang = if (bn) "bn" else "en"
        voices = try {
            (t.voices ?: emptySet()).filter { it.locale.language == lang }.sortedByDescending { quality(it) }
        } catch (e: Exception) {
            emptyList()
        }
        _count.value = voices.size
        if (voices.isNotEmpty()) {
            val saved = AppPrefs.voiceName(c, lang)
            val idx = voices.indexOfFirst { it.name == saved }.let { if (it < 0) 0 else it }
            _picked.value = idx
            try { t.voice = voices[idx] } catch (e: Exception) { }
        }
        t.setPitch(1.0f)
        t.setSpeechRate(rateFor(AppPrefs.voiceSpeed(c)))
        _status.value = VoiceStatus.READY
    }

    private fun rateFor(level: Int) = when (level) { 0 -> 0.82f; 2 -> 1.12f; else -> 0.96f }

    fun setSpeed(level: Int) {
        val c = app ?: return
        AppPrefs.setVoiceSpeed(c, level)
        tts?.setSpeechRate(rateFor(level))
    }

    fun choose(index: Int) {
        val c = app ?: return
        val t = tts ?: return
        if (index !in voices.indices) return
        try { t.voice = voices[index] } catch (e: Exception) { return }
        _picked.value = index
        AppPrefs.setVoiceName(c, if (bn) "bn" else "en", voices[index].name)
    }

    fun enabled(): Boolean = app?.let { AppPrefs.voiceOn(it) } ?: false

    fun setEnabled(on: Boolean) {
        val c = app ?: return
        AppPrefs.setVoiceOn(c, on)
        if (!on) stop()
    }

    /** Say [text]. [flush] cuts off what is being said now (used for the count). */
    fun speak(text: String, flush: Boolean) {
        if (text.isBlank() || !enabled() || _status.value != VoiceStatus.READY) return
        try {
            tts?.speak(text, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "kinetro")
        } catch (e: Exception) {
        }
    }

    /** Speak even if the coach is switched off (the Test button). */
    fun test(text: String) {
        if (_status.value != VoiceStatus.READY) return
        try { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kinetro-test") } catch (e: Exception) { }
    }

    fun stop() {
        try { tts?.stop() } catch (e: Exception) { }
    }

    /** Opens the phone's voice settings so the Bengali voice can be downloaded. */
    fun openSettings(ctx: Context) {
        val intents = listOf(Intent("com.android.settings.TTS_SETTINGS"), Intent(android.provider.Settings.ACTION_SETTINGS))
        for (i in intents) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                return
            } catch (e: Exception) {
            }
        }
    }
}
