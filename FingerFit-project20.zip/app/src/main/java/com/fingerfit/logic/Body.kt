package com.fingerfit.logic

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.hypot

/** One of the 33 MediaPipe pose landmarks (x,y normalised 0..1) with its visibility score. */
class BodyPoint(val x: Float, val y: Float, val v: Float)

/** MediaPipe pose landmark indices used by the app. */
object Joint {
    const val NOSE = 0
    const val L_SH = 11
    const val R_SH = 12
    const val L_EL = 13
    const val R_EL = 14
    const val L_WR = 15
    const val R_WR = 16
    const val L_HIP = 23
    const val R_HIP = 24
    const val L_KN = 25
    const val R_KN = 26
    const val L_AN = 27
    const val R_AN = 28
}

enum class ExerciseType(
    val emoji: String,
    val title: String,
    val benefit: String,
    val setup: String,
    val unit: String,
    val defaultTarget: Int,
    val step: Int,
    val startCue: String,
    val peakCue: String,
    val backCue: String,
) {
    JUMPING_JACKS(
        "🤸", "Jumping Jacks",
        "Boosts heart fitness and endurance, improves arm-leg coordination.",
        "Face the camera with your whole body in view.",
        "reps", 20, 5,
        "Stand with feet together, arms down", "Jump: arms up, feet apart", "Jump back to the start",
    ),
    SQUATS(
        "🏋️", "Bodyweight Squats",
        "Strengthens thighs and glutes, makes sitting and standing easier.",
        "Stand sideways to the camera, whole body in view.",
        "reps", 15, 5,
        "Stand tall", "Squat down", "Stand back up",
    ),
    PUSH_UPS(
        "💪", "Push-ups",
        "Strengthens chest, shoulders and arms, builds core stability.",
        "Put the phone on the floor beside you (side view), whole body in view.",
        "reps", 10, 2,
        "Arms straight, body in one line", "Lower your chest", "Push back up",
    ),
    LUNGES(
        "🦵", "Alternating Lunges",
        "Strengthens legs and glutes, improves balance and control.",
        "Stand sideways to the camera, whole body in view.",
        "reps", 12, 2,
        "Stand tall", "Step into a lunge", "Return to standing",
    ),
    HIGH_KNEES(
        "🏃", "High Knees",
        "Boosts heart fitness and endurance, improves speed and coordination.",
        "Face the camera with your whole body in view.",
        "reps", 40, 10,
        "Stand ready", "Lift your knees", "Keep alternating knees",
    ),
    CRUNCHES(
        "🧘", "Abdominal Crunches",
        "Strengthens the abdominal muscles and core stability.",
        "Lie on your back with the camera at your side, whole body in view.",
        "reps", 15, 5,
        "Lie flat, knees bent", "Curl your shoulders up", "Lower back down",
    ),
    GLUTE_BRIDGES(
        "🍑", "Glute Bridges",
        "Strengthens glutes and hamstrings, improves hip control.",
        "Lie on your back with the camera at your side, whole body in view.",
        "reps", 12, 2,
        "Lie flat, knees bent", "Lift your hips", "Lower your hips",
    ),
    PLANK(
        "🧱", "Plank",
        "Strengthens abs and core, builds muscular endurance.",
        "Put the phone on the floor beside you (side view), whole body in view.",
        "sec", 30, 10,
        "Get into plank position", "", "",
    );

    val isHold: Boolean get() = this == PLANK
    val isSided: Boolean get() = this == LUNGES || this == HIGH_KNEES
}

/** Pixel-space geometry helper over the 33 landmarks. */
class Geo(private val p: List<BodyPoint>, private val w: Float, private val h: Float) {
    fun x(i: Int) = p[i].x * w
    fun y(i: Int) = p[i].y * h
    fun dist(a: Int, b: Int) = hypot(x(a) - x(b), y(a) - y(b))
    fun midX(a: Int, b: Int) = (x(a) + x(b)) / 2f
    fun midY(a: Int, b: Int) = (y(a) + y(b)) / 2f

    /** All listed joints are visible and inside the frame. */
    fun ok(vararg ids: Int) = ids.all {
        val q = p[it]
        q.v >= MIN_VIS && q.x > -0.02f && q.x < 1.02f && q.y > -0.02f && q.y < 1.02f
    }

    fun minVis(vararg ids: Int) = ids.minOf { p[it].v }

    /** Angle in degrees at joint [b] between [a] and [c]. */
    fun angle(a: Int, b: Int, c: Int): Float {
        val ax = x(a) - x(b)
        val ay = y(a) - y(b)
        val cx = x(c) - x(b)
        val cy = y(c) - y(b)
        val d = hypot(ax, ay) * hypot(cx, cy)
        if (d < 1e-3f) return 0f
        val cos = ((ax * cx + ay * cy) / d).coerceIn(-1f, 1f)
        return Math.toDegrees(acos(cos).toDouble()).toFloat()
    }

    /** 1 = the line a-b is horizontal in the image, 0 = vertical. */
    /** Hip position against the straight line shoulder -> ankle (+ = below the line). */
    fun hipSag(sh: Int, hip: Int, an: Int): Float {
        val len = dist(sh, an)
        val dx = x(an) - x(sh)
        if (len < 10f || abs(dx) < 10f) return 0f
        val t = (x(hip) - x(sh)) / dx
        val lineY = y(sh) + t * (y(an) - y(sh))
        return (y(hip) - lineY) / len
    }

    fun horizontalness(a: Int, b: Int): Float {
        val d = dist(a, b)
        return if (d < 1e-3f) 0f else abs(x(a) - x(b)) / d
    }

    companion object {
        const val MIN_VIS = 0.5f
    }
}

/**
 * What one frame says about the exercise. Pose.OPEN = START position of the
 * exercise, Pose.CLOSED = PEAK position (so one repetition = start -> peak -> start).
 */
class BodyRead(
    val valid: Boolean,
    val pose: Pose = Pose.UNKNOWN,
    val poseL: Pose = Pose.UNKNOWN,
    val poseR: Pose = Pose.UNKNOWN,
    val frontLeft: Boolean? = null,
    val good: Boolean = false,
    val hint: String? = null,
    /** Squat: knee angle. Push-up: elbow angle. (Smaller = deeper.) */
    val depth: Float = 180f,
    /** Hip height against the shoulder-ankle line as a share of body length: + = hips sag, - = hips too high. */
    val sag: Float = 0f,
    /** How far the movement went: jumping jack = hands above shoulders (share of torso), crunch = shoulder lift, bridge = hip angle. */
    val reach: Float = 0f,
    /** High knees: knee drop below the hip as a share of torso (small = high knee). */
    val ratioL: Float = 1f,
    val ratioR: Float = 1f,
)

object BodyClassifier {
    private const val IN_VIEW = "Step back so your whole body is in view."

    fun read(type: ExerciseType, pts: List<BodyPoint>, w: Float, h: Float): BodyRead {
        if (pts.size < 33 || w <= 0f || h <= 0f) return BodyRead(false, hint = IN_VIEW)
        val g = Geo(pts, w, h)
        return when (type) {
            ExerciseType.SQUATS -> squat(g)
            ExerciseType.PUSH_UPS -> pushUp(g)
            ExerciseType.JUMPING_JACKS -> jumpingJack(g)
            ExerciseType.HIGH_KNEES -> highKnees(g)
            ExerciseType.LUNGES -> lunge(g)
            ExerciseType.CRUNCHES -> crunch(g)
            ExerciseType.GLUTE_BRIDGES -> bridge(g)
            ExerciseType.PLANK -> plank(g)
        }
    }

    private fun invalid(hint: String) = BodyRead(false, hint = hint)

    /** The left or right triple of joints that is fully visible (best visibility wins). */
    private fun bestSide(g: Geo, l1: Int, l2: Int, l3: Int, r1: Int, r2: Int, r3: Int): IntArray? {
        val lOk = g.ok(l1, l2, l3)
        val rOk = g.ok(r1, r2, r3)
        return when {
            lOk && rOk ->
                if (g.minVis(l1, l2, l3) >= g.minVis(r1, r2, r3)) intArrayOf(l1, l2, l3) else intArrayOf(r1, r2, r3)
            lOk -> intArrayOf(l1, l2, l3)
            rOk -> intArrayOf(r1, r2, r3)
            else -> null
        }
    }

    private fun squat(g: Geo): BodyRead {
        val s = bestSide(g, Joint.L_HIP, Joint.L_KN, Joint.L_AN, Joint.R_HIP, Joint.R_KN, Joint.R_AN)
            ?: return invalid(IN_VIEW)
        val a = g.angle(s[0], s[1], s[2])
        val pose = when {
            a >= 155f -> Pose.OPEN
            a <= 120f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a)
    }

    private fun pushUp(g: Geo): BodyRead {
        val hint = "Get into push-up position, side view."
        val s = bestSide(g, Joint.L_SH, Joint.L_EL, Joint.L_WR, Joint.R_SH, Joint.R_EL, Joint.R_WR)
            ?: return invalid(hint)
        val hip = s[0] + 12 // shoulder index + 12 = hip index on the same side
        if (!g.ok(hip) || g.horizontalness(s[0], hip) < 0.77f) return invalid(hint)
        val a = g.angle(s[0], s[1], s[2])
        val pose = when {
            a >= 150f -> Pose.OPEN
            a <= 110f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        val ankle = if (g.ok(hip + 4)) hip + 4 else -1 // same side ankle
        val sag = if (ankle >= 0) g.hipSag(s[0], hip, ankle) else 0f
        return BodyRead(true, pose, depth = a, sag = sag)
    }

    private fun jumpingJack(g: Geo): BodyRead {
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP, Joint.L_WR, Joint.R_WR, Joint.L_AN, Joint.R_AN)) {
            return invalid(IN_VIEW)
        }
        val sw = abs(g.x(Joint.L_SH) - g.x(Joint.R_SH))
        val torso = g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_SH, Joint.R_SH)
        if (sw < 10f || torso < 10f) return invalid("Face the camera, standing upright.")
        val ankles = abs(g.x(Joint.L_AN) - g.x(Joint.R_AN)) / sw
        val up = g.y(Joint.L_WR) < g.y(Joint.L_SH) && g.y(Joint.R_WR) < g.y(Joint.R_SH)
        val down = g.y(Joint.L_WR) > g.y(Joint.L_SH) + 0.4f * torso &&
            g.y(Joint.R_WR) > g.y(Joint.R_SH) + 0.4f * torso
        val pose = when {
            up && ankles >= 1.5f -> Pose.CLOSED
            down && ankles <= 1.0f -> Pose.OPEN
            else -> Pose.UNKNOWN
        }
        val reach = minOf(
            (g.y(Joint.L_SH) - g.y(Joint.L_WR)) / torso,
            (g.y(Joint.R_SH) - g.y(Joint.R_WR)) / torso,
        )
        return BodyRead(true, pose, reach = reach)
    }

    private fun highKnees(g: Geo): BodyRead {
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP, Joint.L_KN, Joint.R_KN)) return invalid(IN_VIEW)
        val torso = g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_SH, Joint.R_SH)
        if (torso < 10f) return invalid("Face the camera, standing upright.")
        fun ratio(hip: Int, knee: Int) = (g.y(knee) - g.y(hip)) / torso
        fun leg(hip: Int, knee: Int): Pose {
            val r = ratio(hip, knee)
            return when {
                r <= 0.25f -> Pose.CLOSED // knee lifted to hip level
                r >= 0.5f -> Pose.OPEN
                else -> Pose.UNKNOWN
            }
        }
        return BodyRead(
            true,
            poseL = leg(Joint.L_HIP, Joint.L_KN), poseR = leg(Joint.R_HIP, Joint.R_KN),
            ratioL = ratio(Joint.L_HIP, Joint.L_KN), ratioR = ratio(Joint.R_HIP, Joint.R_KN),
        )
    }

    private fun lunge(g: Geo): BodyRead {
        val hint = "Stand sideways to the camera, whole body in view."
        if (!g.ok(Joint.NOSE, Joint.L_HIP, Joint.R_HIP, Joint.L_KN, Joint.R_KN, Joint.L_AN, Joint.R_AN)) return invalid(hint)
        val hipX = g.midX(Joint.L_HIP, Joint.R_HIP)
        if (abs(g.x(Joint.NOSE) - hipX) < 8f) return invalid(hint)
        val facing = if (g.x(Joint.NOSE) >= hipX) 1f else -1f
        val kL = g.angle(Joint.L_HIP, Joint.L_KN, Joint.L_AN)
        val kR = g.angle(Joint.R_HIP, Joint.R_KN, Joint.R_AN)
        val frontLeft = (g.x(Joint.L_AN) - hipX) * facing >= (g.x(Joint.R_AN) - hipX) * facing
        val front = if (frontLeft) kL else kR
        val pose = when {
            kL >= 155f && kR >= 155f -> Pose.OPEN
            front <= 110f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, frontLeft = frontLeft, depth = front)
    }

    private fun crunch(g: Geo): BodyRead {
        val hint = "Lie on your back with the camera at your side."
        val s = bestSide(g, Joint.L_SH, Joint.L_HIP, Joint.L_KN, Joint.R_SH, Joint.R_HIP, Joint.R_KN)
            ?: return invalid(hint)
        val len = g.dist(s[0], s[1])
        if (len < 10f || g.horizontalness(s[0], s[1]) < 0.5f) return invalid(hint)
        val lift = (g.y(s[1]) - g.y(s[0])) / len // shoulders rising above the hips
        val pose = when {
            lift <= 0.15f -> Pose.OPEN
            lift >= 0.33f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, reach = lift)
    }

    private fun bridge(g: Geo): BodyRead {
        val hint = "Lie on your back with the camera at your side."
        val s = bestSide(g, Joint.L_SH, Joint.L_HIP, Joint.L_KN, Joint.R_SH, Joint.R_HIP, Joint.R_KN)
            ?: return invalid(hint)
        if (g.horizontalness(s[0], s[1]) < 0.6f) return invalid(hint)
        val a = g.angle(s[0], s[1], s[2]) // shoulder-hip-knee: ~120-150 flat, ~175 at the top
        val pose = when {
            a <= 150f -> Pose.OPEN
            a >= 163f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, reach = a)
    }

    private fun plank(g: Geo): BodyRead {
        val hint = "Get into plank position, side view."
        val s = bestSide(g, Joint.L_SH, Joint.L_HIP, Joint.L_AN, Joint.R_SH, Joint.R_HIP, Joint.R_AN)
            ?: return invalid(hint)
        val straight = g.angle(s[0], s[1], s[2]) >= 155f
        val flat = g.horizontalness(s[0], s[2]) >= 0.8f
        if (!flat) return invalid(hint)
        return BodyRead(true, good = straight, hint = if (straight) null else "Keep your body in a straight line.", sag = g.hipSag(s[0], s[1], s[2]))
    }
}

/** Turns a stream of pose frames into repetitions (or hold time for the plank). */
class ExerciseEngine(val type: ExerciseType) {

    class Out(
        val detected: Boolean,
        val reliable: Boolean,
        val repDone: Boolean,
        val pose: Pose,
        val phase: RepCounter.Phase,
        val hint: String?,
        /** A form fix to say aloud (found while doing the repetition / while holding). */
        val form: FormTip? = null,
    )

    var leftReps = 0
        private set
    var rightReps = 0
        private set
    var holdMs = 0L
        private set

    private val counter = RepCounter(cfg(type))
    private val counterL = RepCounter(cfg(type))
    private val counterR = RepCounter(cfg(type))
    private var bottomFrontLeft: Boolean? = null

    // plank state
    private var lastT = -1L
    private var goodStreak = 0
    private var lastGoodT = 0L
    private var holding = false

    /** Repetitions, or whole seconds held for the plank. */
    val reps: Int
        get() = when {
            type.isHold -> (holdMs / 1000).toInt()
            type == ExerciseType.HIGH_KNEES -> counterL.count + counterR.count
            else -> counter.count
        }

    fun update(pts: List<BodyPoint>?, w: Float, h: Float, t: Long, mirrored: Boolean): Out {
        if (pts == null) {
            lose(t)
            return Out(false, false, false, Pose.UNKNOWN, phase(), "Step back so your whole body is in view.")
        }
        val r = BodyClassifier.read(type, pts, w, h)
        if (!r.valid) {
            lose(t)
            return Out(true, false, false, Pose.UNKNOWN, phase(), r.hint)
        }
        return when {
            type.isHold -> plank(r, t)
            type == ExerciseType.HIGH_KNEES -> knees(r, t, mirrored)
            else -> single(r, t, mirrored)
        }
    }

    // form tracking for the repetition in progress
    private var repMinDepth = 180f
    private var repMaxSag = 0f
    private var repMinSag = 0f

    private var repMaxReach = -9f
    private var attemptMax = 0f // best reach of a crunch / bridge that has not (yet) counted

    private fun formOfRep(): FormTip? {
        val tip = when (type) {
            ExerciseType.LUNGES -> if (repMinDepth > LUNGE_DEEP) FormTip.LUNGE_SHALLOW else null
            ExerciseType.JUMPING_JACKS -> if (repMaxReach < ARMS_HIGH) FormTip.ARMS_LOW else null
            ExerciseType.PUSH_UPS -> when {
                repMaxSag > SAG_LIMIT -> FormTip.HIPS_SAG
                repMinSag < -SAG_LIMIT -> FormTip.HIPS_HIGH
                repMinDepth > PUSHUP_DEEP -> FormTip.PUSHUP_SHALLOW
                else -> null
            }
            ExerciseType.SQUATS -> if (repMinDepth > SQUAT_DEEP) FormTip.SQUAT_SHALLOW else null
            else -> null
        }
        repMinDepth = 180f; repMaxSag = 0f; repMinSag = 0f; repMaxReach = -9f
        return tip
    }

    private fun single(r: BodyRead, t: Long, mirrored: Boolean): Out {
        if (r.pose != Pose.OPEN) {
            if (r.depth < repMinDepth) repMinDepth = r.depth
            if (r.sag > repMaxSag) repMaxSag = r.sag
            if (r.sag < repMinSag) repMinSag = r.sag
            if (r.reach > repMaxReach) repMaxReach = r.reach
            if (r.reach > attemptMax) attemptMax = r.reach
        }
        val e = counter.update(Observation(t, true, true, r.pose))
        if (e == RepCounter.Event.CLOSED_CONFIRMED) bottomFrontLeft = r.frontLeft
        val done = e == RepCounter.Event.REP_COMPLETED
        if (done && type == ExerciseType.LUNGES) {
            val indexLeft = bottomFrontLeft
            if (indexLeft != null) {
                if (indexLeft != mirrored) leftReps++ else rightReps++
            }
        }
        var tip = if (done) formOfRep() else null
        if (done) attemptMax = 0f
        if (!done && counter.phase == RepCounter.Phase.WAIT_CLOSE) {
            repMinDepth = 180f; repMaxSag = 0f; repMinSag = 0f; repMaxReach = -9f
            // back at the start without reaching the top: tell the person to go further
            if (r.pose == Pose.OPEN) {
                if (type == ExerciseType.CRUNCHES && attemptMax >= CRUNCH_TRY) tip = FormTip.CRUNCH_SHALLOW
                if (type == ExerciseType.GLUTE_BRIDGES && attemptMax >= BRIDGE_TRY) tip = FormTip.BRIDGE_LOW
                attemptMax = 0f
            }
        }
        return Out(true, true, done, r.pose, counter.phase, null, tip)
    }

    private var kneeMinL = 9f
    private var kneeMinR = 9f

    private fun knees(r: BodyRead, t: Long, mirrored: Boolean): Out {
        var tip: FormTip? = null
        if (r.ratioL < kneeMinL) kneeMinL = r.ratioL
        if (r.ratioR < kneeMinR) kneeMinR = r.ratioR
        if (r.poseL == Pose.OPEN) { if (kneeMinL > KNEE_HIP && kneeMinL < KNEE_TRY) tip = FormTip.KNEES_LOW; kneeMinL = 9f }
        if (r.poseR == Pose.OPEN) { if (kneeMinR > KNEE_HIP && kneeMinR < KNEE_TRY) tip = FormTip.KNEES_LOW; kneeMinR = 9f }
        val eL = counterL.update(Observation(t, true, true, r.poseL))
        val eR = counterR.update(Observation(t, true, true, r.poseR))
        var done = false
        if (eL == RepCounter.Event.REP_COMPLETED) {
            done = true
            if (true != mirrored) leftReps++ else rightReps++ // model-left leg
        }
        if (eR == RepCounter.Event.REP_COMPLETED) {
            done = true
            if (false != mirrored) leftReps++ else rightReps++ // model-right leg
        }
        return Out(true, true, done, Pose.UNKNOWN, phase(), null, tip)
    }

    private fun plank(r: BodyRead, t: Long): Out {
        val dt = if (lastT >= 0) (t - lastT).coerceIn(0L, 250L) else 0L
        lastT = t
        if (r.good) {
            goodStreak++
            lastGoodT = t
            if (goodStreak >= 3) holding = true
        } else {
            goodStreak = 0
            if (t - lastGoodT > 600) holding = false
        }
        if (holding) holdMs += dt
        val tip = if (r.good) null else when {
            r.sag > PLANK_SAG -> FormTip.HIPS_SAG
            r.sag < -PLANK_SAG -> FormTip.HIPS_HIGH
            else -> null
        }
        return Out(true, true, false, Pose.UNKNOWN, phase(), if (holding) null else r.hint, tip)
    }

    private fun lose(t: Long) {
        attemptMax = 0f; kneeMinL = 9f; kneeMinR = 9f
        if (type.isHold) {
            lastT = t
            goodStreak = 0
            if (t - lastGoodT > 600) holding = false
            return
        }
        val o = Observation(t, false, false, Pose.UNKNOWN)
        if (type == ExerciseType.HIGH_KNEES) {
            counterL.update(o)
            counterR.update(o)
        } else {
            counter.update(o)
        }
    }

    private fun phase(): RepCounter.Phase {
        if (type != ExerciseType.HIGH_KNEES) return counter.phase
        val a = counterL.phase
        val b = counterR.phase
        return when {
            a == RepCounter.Phase.WAIT_CLOSE || b == RepCounter.Phase.WAIT_CLOSE -> RepCounter.Phase.WAIT_CLOSE
            a == RepCounter.Phase.WAIT_REOPEN || b == RepCounter.Phase.WAIT_REOPEN -> RepCounter.Phase.WAIT_REOPEN
            a == RepCounter.Phase.NO_HAND && b == RepCounter.Phase.NO_HAND -> RepCounter.Phase.NO_HAND
            else -> RepCounter.Phase.WAIT_OPEN
        }
    }

    /** Forget the movement in progress but keep the totals (used on pause / resume). */
    fun restartCycle() {
        counter.resetCycle()
        counterL.resetCycle()
        counterR.resetCycle()
        holding = false
        goodStreak = 0
        lastT = -1L
        attemptMax = 0f; kneeMinL = 9f; kneeMinR = 9f
    }

    val isHolding: Boolean get() = holding

    private companion object {
        const val SAG_LIMIT = 0.08f
        const val PLANK_SAG = 0.05f
        const val SQUAT_DEEP = 105f
        const val PUSHUP_DEEP = 95f
        const val LUNGE_DEEP = 100f   // front knee angle: at or below = deep enough
        const val ARMS_HIGH = 0.6f    // jumping jack: hands at least this far above the shoulders (head height)
        const val CRUNCH_TRY = 0.22f  // shoulder lift that shows a real attempt (counts at 0.33)
        const val BRIDGE_TRY = 156f   // hip angle that shows a real attempt (counts at 163)
        const val KNEE_HIP = 0.25f    // knee at hip level (counts)
        const val KNEE_TRY = 0.42f    // knee lifted well past half way but not to the hip

        fun cfg(t: ExerciseType) = when (t) {
            // One confirming frame is enough: a Wi-Fi camera gives only 6 to 10 pictures a second, so a
            // quick repetition may show its lowest point in a single picture. The wide gap between the
            // START and PEAK angles already keeps noise from counting.
            ExerciseType.JUMPING_JACKS -> RepCounter.Config(1, 0, 1000, 300)
            ExerciseType.HIGH_KNEES -> RepCounter.Config(1, 0, 1000, 200)
            else -> RepCounter.Config(1, 0, 1500, 400)
        }
    }
}
