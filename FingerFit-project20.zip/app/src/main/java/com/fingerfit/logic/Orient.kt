package com.fingerfit.logic

/**
 * Many Wi-Fi cameras send their picture turned sideways or upside down (a phone used as an IP camera
 * reports its own turning only in a tag that streams ignore). The body model only finds people who are
 * upright, so we try the four turnings and keep the one where a whole body is found.
 */
object Orient {
    private val CORE = intArrayOf(11, 12, 23, 24, 25, 26, 27, 28)

    /** 0..1: how sure we are that a whole standing/lying body is in the picture. */
    fun score(p: List<BodyPoint>?): Float {
        if (p == null || p.size < 33) return 0f
        var sum = 0f
        for (i in CORE) sum += p[i].v
        return sum / CORE.size
    }

    /** Which turning (0, 90, 180, 270) to use, given the score of each turning in that order and the current one. */
    fun pick(scores: FloatArray, current: Int): Int {
        val cur = scores[(current / 90) % 4]
        if (cur >= 0.5f) return current
        var best = -1
        var bestScore = 0.45f
        for (i in 0 until 4) if (scores[i] > bestScore) { bestScore = scores[i]; best = i }
        return if (best < 0) current else best * 90
    }
}
