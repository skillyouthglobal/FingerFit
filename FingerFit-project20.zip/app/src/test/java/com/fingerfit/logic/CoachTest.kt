package com.fingerfit.logic

import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CoachTest {
    private fun coach(bn: Boolean, name: String = "Rahim") = Coach(bn, name, Random(7))

    @Test fun counts_in_bengali_words() {
        val c = coach(true)
        assertEquals("তিন", c.rep(ExerciseType.SQUATS, 3, 20)!!.text)
        assertTrue(c.rep(ExerciseType.SQUATS, 4, 20)!!.text.startsWith("চার")) // every second count also says the name
        assertEquals("চব্বিশ", c.num(24)); assertEquals("একশ", c.num(100)); assertEquals("101", c.num(101))
    }

    @Test fun names_are_used_and_never_left_as_braces() {
        for (bn in listOf(true, false)) for (name in listOf("Rahim Uddin", "")) {
            val c = coach(bn, name)
            val lines = ArrayList<String>()
            for (t in ExerciseType.values()) {
                lines += c.intro(t, 20).text
                for (r in 1..20) c.rep(t, r, 20)?.let { lines += it.text }
                for (s in 1..40) c.hold(s, 40)?.let { lines += it.text }
                lines += c.finish(t, 20, true).text; lines += c.finish(t, 8, false).text; lines += c.finish(t, 0, false).text
                lines += c.pause().text; lines += c.resume().text
            }
            for (tip in FormTip.values()) lines += Coach(bn, name, Random(3)).tip(tip, 5, 100_000)!!.text
            for (l in lines) {
                assertTrue(l, !l.contains("{") && !l.contains("}") && l.isNotBlank())
                assertTrue(l, !l.startsWith("!") && !l.startsWith(",") && !l.contains(" ,") && !l.contains("  "))
            }
            if (name.isNotEmpty()) {
                assertTrue(lines.any { it.contains("Rahim") })
                // every real sentence (not a bare count) carries the name
                for (l in lines.filter { it.length > 14 }) assertTrue(l, l.contains("Rahim"))
            }
        }
    }

    @Test fun halfway_and_last_three_are_announced() {
        val c = coach(false)
        assertTrue(c.rep(ExerciseType.SQUATS, 10, 20)!!.text.contains("alf"))
        assertTrue(c.rep(ExerciseType.SQUATS, 18, 20)!!.text.contains("2"))
        assertTrue(c.rep(ExerciseType.SQUATS, 20, 20) == null) // finish() speaks the end
    }

    @Test fun fast_exercises_count_every_fifth() {
        val c = coach(true)
        assertTrue(c.rep(ExerciseType.JUMPING_JACKS, 3, 40) == null)
        assertTrue(c.rep(ExerciseType.JUMPING_JACKS, 5, 40) != null)
    }

    @Test fun tips_are_throttled() {
        val c = coach(false)
        assertTrue(c.tip(FormTip.HIPS_SAG, 3, 10_000) != null)
        assertTrue(c.tip(FormTip.HIPS_SAG, 4, 12_000) == null)   // too soon
        assertTrue(c.tip(FormTip.HIPS_SAG, 5, 20_000) == null)   // same fix again within 3 reps
        assertTrue(c.tip(FormTip.HIPS_SAG, 8, 30_000) != null)
    }

    @Test fun lost_body_is_reported_after_a_pause_once() {
        val c = coach(true)
        assertTrue(c.visibility(false, 1_000) == null)
        assertTrue(c.visibility(false, 2_500) == null)
        assertTrue(c.visibility(false, 4_100) != null)
        assertTrue(c.visibility(false, 5_000) == null)
        assertTrue(c.visibility(true, 6_000) != null) // "I can see you again"
        assertTrue(c.visibility(true, 7_000) == null)
    }

    // ---- form found from the body points -------------------------------------------------

    private val W = 480f; private val H = 640f
    private fun kneePose(theta: Double): List<BodyPoint> {
        val a = Array(33) { BodyPoint(0f, 0f, 0f) }
        val ankle = 240f to 576f; val knee = 240f to 448f
        val hip = (240f + 128f * sin(Math.toRadians(theta)).toFloat()) to (448f + 128f * cos(Math.toRadians(theta)).toFloat())
        a[23] = BodyPoint(hip.first / W, hip.second / H, 1f); a[25] = BodyPoint(knee.first / W, knee.second / H, 1f); a[27] = BodyPoint(ankle.first / W, ankle.second / H, 1f)
        return a.toList()
    }
    private fun squatRep(deepAngle: Double): FormTip? {
        val e = ExerciseEngine(ExerciseType.SQUATS); var t = 1000L; var tip: FormTip? = null; var done = false
        fun feed(p: List<BodyPoint>, n: Int) = repeat(n) { val o = e.update(p, W, H, t, false); t += 33; if (o.repDone) { done = true; tip = o.form } }
        feed(kneePose(172.0), 8); feed(kneePose(deepAngle), 8); feed(kneePose(172.0), 8)
        assertTrue("rep counted", done)
        return tip
    }
    @Test fun shallow_squat_is_flagged_and_deep_squat_is_not() {
        assertEquals(FormTip.SQUAT_SHALLOW, squatRep(115.0))
        assertTrue(squatRep(90.0) == null)
    }

    private fun plankPose(sagFraction: Float): List<BodyPoint> {
        val a = Array(33) { BodyPoint(0f, 0f, 0f) }
        // side view: shoulder left, ankle right, nearly level; hip at the middle shifted by sagFraction of the length
        a[11] = BodyPoint(0.2f, 0.60f, 1f); a[27] = BodyPoint(0.8f, 0.64f, 1f)
        val len = Math.hypot(0.6 * W.toDouble(), 0.04 * H.toDouble()).toFloat()
        a[23] = BodyPoint(0.5f, 0.62f + sagFraction * len / H, 1f)
        return a.toList()
    }
    @Test fun plank_sag_and_pike_are_told_apart() {
        fun tipFor(p: List<BodyPoint>): FormTip? { val e = ExerciseEngine(ExerciseType.PLANK); var o: ExerciseEngine.Out? = null; for (i in 0 until 6) o = e.update(p, W, H, 1000L + i * 33, false); return o!!.form }
        assertEquals(FormTip.HIPS_SAG, tipFor(plankPose(0.12f)))
        assertEquals(FormTip.HIPS_HIGH, tipFor(plankPose(-0.12f)))
        assertTrue(tipFor(plankPose(0.0f)) == null)
    }

    // ---- form of the other five exercises ---------------------------------------------------------

    private fun pts(vararg m: Pair<Int, Pair<Float, Float>>): List<BodyPoint> {
        val a = Array(33) { BodyPoint(0f, 0f, 0f) }
        for ((i, xy) in m) a[i] = BodyPoint(xy.first / W, xy.second / H, 1f)
        return a.toList()
    }
    /** Feeds the frames and reports (counted?, form tip of the counted repetition, any form tip at all). */
    private fun run(type: ExerciseType, vararg seq: Pair<List<BodyPoint>, Int>): Triple<Boolean, FormTip?, FormTip?> {
        val e = ExerciseEngine(type); var t = 1000L; var done = false; var repTip: FormTip? = null; var anyTip: FormTip? = null
        for ((p, n) in seq) repeat(n) {
            val o = e.update(p, W, H, t, false); t += 33
            if (o.repDone) { done = true; repTip = o.form }
            if (o.form != null) anyTip = o.form
        }
        return Triple(done, repTip, anyTip)
    }

    private fun jack(reach: Float, wide: Boolean, armsUp: Boolean): List<BodyPoint> {
        val la = if (wide) 180f else 230f; val ra = if (wide) 300f else 250f
        val wy = if (armsUp) 200f - reach * 160f else 340f
        return pts(11 to (200f to 200f), 12 to (280f to 200f), 23 to (210f to 360f), 24 to (270f to 360f),
            15 to (170f to wy), 16 to (310f to wy), 27 to (la to 560f), 28 to (ra to 560f))
    }
    @Test fun jumping_jack_with_low_arms_is_flagged() {
        val down = jack(0f, false, false)
        val low = run(ExerciseType.JUMPING_JACKS, down to 6, jack(0.2f, true, true) to 6, down to 6)
        assertTrue(low.first); assertEquals(FormTip.ARMS_LOW, low.second)
        val good = run(ExerciseType.JUMPING_JACKS, down to 6, jack(1.0f, true, true) to 6, down to 6)
        assertTrue(good.first); assertTrue(good.second == null)
    }

    private fun lunge(frontKnee: Double, down: Boolean): List<BodyPoint> {
        if (!down) return pts(0 to (300f to 120f), 23 to (240f to 350f), 24 to (240f to 350f), 25 to (240f to 450f), 26 to (240f to 450f), 27 to (240f to 550f), 28 to (240f to 550f))
        val kx = 300f; val ky = 440f
        val th = Math.atan2((ky - 350f).toDouble(), (kx - 240f).toDouble())
        val sh = th - Math.toRadians(180.0 - frontKnee)   // rotate the shin so the knee angle is frontKnee
        val ax = kx + 100f * cos(sh).toFloat(); val ay = ky + 100f * sin(sh).toFloat()
        return pts(0 to (300f to 120f), 23 to (240f to 350f), 24 to (240f to 350f), 25 to (kx to ky), 26 to (200f to 450f), 27 to (ax to ay), 28 to (170f to 540f))
    }
    @Test fun lunge_depth_is_checked() {
        val up = lunge(180.0, false)
        val shallow = run(ExerciseType.LUNGES, up to 6, lunge(106.0, true) to 6, up to 6)
        assertTrue(shallow.first); assertEquals(FormTip.LUNGE_SHALLOW, shallow.second)
        val deep = run(ExerciseType.LUNGES, up to 6, lunge(90.0, true) to 6, up to 6)
        assertTrue(deep.first); assertTrue(deep.second == null)
    }

    private fun knees(leftY: Float): List<BodyPoint> =
        pts(11 to (200f to 200f), 12 to (280f to 200f), 23 to (210f to 360f), 24 to (270f to 360f), 25 to (210f to leftY), 26 to (270f to 488f))
    @Test fun high_knee_that_stops_short_is_flagged() {
        val down = knees(488f)
        val short = run(ExerciseType.HIGH_KNEES, down to 6, knees(416f) to 6, down to 6)
        assertTrue(!short.first); assertEquals(FormTip.KNEES_LOW, short.third)
        val full = run(ExerciseType.HIGH_KNEES, down to 6, knees(376f) to 6, down to 6)
        assertTrue(full.first); assertTrue(full.third == null)
    }

    private fun crunch(lift: Float): List<BodyPoint> {
        val dx = 100f * Math.sqrt(1.0 - lift * lift).toFloat(); val dy = 100f * lift
        return pts(11 to (300f - dx to 400f - dy), 23 to (300f to 400f), 25 to (350f to 450f))
    }
    @Test fun crunch_that_stops_short_is_flagged() {
        val flat = crunch(0.05f)
        val half = run(ExerciseType.CRUNCHES, flat to 6, crunch(0.27f) to 6, flat to 6)
        assertTrue(!half.first); assertEquals(FormTip.CRUNCH_SHALLOW, half.third)
        val full = run(ExerciseType.CRUNCHES, flat to 6, crunch(0.45f) to 6, flat to 6)
        assertTrue(full.first); assertTrue(full.third == null)
    }

    private fun bridge(a: Double): List<BodyPoint> {
        val phi = Math.toRadians(180.0 - a)
        return pts(11 to (200f to 400f), 23 to (300f to 400f), 25 to (300f + 100f * cos(phi).toFloat() to 400f - 100f * sin(phi).toFloat()))
    }
    @Test fun bridge_that_stops_low_is_flagged() {
        val flat = bridge(130.0)
        val low = run(ExerciseType.GLUTE_BRIDGES, flat to 6, bridge(158.0) to 6, flat to 6)
        assertTrue(!low.first); assertEquals(FormTip.BRIDGE_LOW, low.third)
        val full = run(ExerciseType.GLUTE_BRIDGES, flat to 6, bridge(175.0) to 6, flat to 6)
        assertTrue(full.first); assertTrue(full.third == null)
    }

    // ---- picture turning -------------------------------------------------------------------

    @Test fun orientation_picks_the_turning_that_sees_a_body() {
        assertEquals(90, Orient.pick(floatArrayOf(0.1f, 0.9f, 0.2f, 0.1f), 0))
        assertEquals(0, Orient.pick(floatArrayOf(0.8f, 0.9f, 0.2f, 0.1f), 0))   // already fine: keep
        assertEquals(180, Orient.pick(floatArrayOf(0.1f, 0.1f, 0.3f, 0.1f), 180)) // nothing sure: keep
        assertEquals(270, Orient.pick(floatArrayOf(0.2f, 0.3f, 0.1f, 0.7f), 90))
    }
}
