package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Builds a synthetic 21-point hand in a 480x640 image. openness 0 = fist, 1 = fully open. */
private fun hand(openness: Float, shiftX: Float = 0f): List<Landmark> {
    val w = 480f
    val h = 640f
    val pts = ArrayList<Landmark>()
    fun add(px: Float, py: Float) = pts.add(Landmark(px / w, py / h))
    add(240f + shiftX, 500f) // 0 wrist
    repeat(4) { i -> add(215f + shiftX - i * 8f, 480f - i * 12f) } // 1..4 thumb (unused)
    val tipY = 430f + openness * (310f - 430f)
    for (f in 0 until 4) { // index, middle, ring, pinky
        val x = 240f + shiftX + (f - 1.5f) * 28f
        val mcpY = 400f
        add(x, mcpY)                                  // MCP
        add(x, mcpY + (tipY - mcpY) * 0.33f)          // PIP
        add(x, mcpY + (tipY - mcpY) * 0.66f)          // DIP
        add(x, tipY)                                  // TIP
    }
    return pts
}

private fun classify(o: Float, score: Float = 1f, shiftX: Float = 0f) =
    GestureClassifier.classify(hand(o, shiftX), 480f, 640f, score)

/** Feeds [frames] identical frames at ~30 fps; returns the next free timestamp. */
private class Feeder(val counter: RepCounter) {
    var t = 1_000L
    val repTimes = ArrayList<Long>()
    fun feed(pose: Pose, frames: Int, detected: Boolean = true, reliable: Boolean = true) {
        repeat(frames) {
            val e = counter.update(Observation(t, detected, reliable, pose))
            if (e == RepCounter.Event.REP_COMPLETED) repTimes.add(t)
            t += 33
        }
    }
    fun gap(ms: Long) { t += ms }
    fun cycle(openFrames: Int = 12, closedFrames: Int = 12) {
        feed(Pose.OPEN, openFrames); feed(Pose.CLOSED, closedFrames); feed(Pose.OPEN, openFrames)
    }
}

class GestureClassifierTest {
    @Test fun openHandIsOpen() = assertEquals(Pose.OPEN, classify(1f).pose)
    @Test fun fistIsClosed() = assertEquals(Pose.CLOSED, classify(0f).pose)
    @Test fun halfClosedIsUnknown() = assertEquals(Pose.UNKNOWN, classify(0.5f).pose)
    @Test fun lowConfidenceIsUnreliable() = assertTrue(!classify(1f, score = 0.3f).reliable)
    @Test fun handCutOffByFrameIsUnreliable() = assertTrue(!classify(1f, shiftX = 300f).reliable)
    @Test fun tinyHandIsUnreliable() {
        val tiny = hand(1f).map { Landmark(0.5f + (it.x - 0.5f) * 0.05f, 0.5f + (it.y - 0.5f) * 0.05f) }
        assertTrue(!GestureClassifier.classify(tiny, 480f, 640f).reliable)
    }
}

class RepCounterTest {
    @Test fun oneFullCycleCountsExactlyOne() {
        val f = Feeder(RepCounter()); f.cycle()
        assertEquals(1, f.counter.count)
    }

    @Test fun holdingOpenOrClosedNeverCounts() {
        val f = Feeder(RepCounter())
        f.feed(Pose.OPEN, 300)
        assertEquals(0, f.counter.count)
        f.feed(Pose.CLOSED, 300)
        assertEquals(0, f.counter.count)
    }

    @Test fun staysAtOneWhileHandRemainsOpenAfterRep() {
        val f = Feeder(RepCounter()); f.cycle(); f.feed(Pose.OPEN, 300)
        assertEquals(1, f.counter.count)
    }

    @Test fun fiveCyclesCountFive() {
        val f = Feeder(RepCounter())
        f.feed(Pose.OPEN, 12)
        repeat(5) { f.feed(Pose.CLOSED, 12); f.feed(Pose.OPEN, 12) }
        assertEquals(5, f.counter.count)
    }

    @Test fun startingWithFistWaitsForOpenHand() {
        val f = Feeder(RepCounter())
        f.feed(Pose.CLOSED, 20); f.feed(Pose.OPEN, 12)
        assertEquals(0, f.counter.count) // only the first open: cycle not finished
        f.feed(Pose.CLOSED, 12); f.feed(Pose.OPEN, 12)
        assertEquals(1, f.counter.count)
    }

    @Test fun handLostMidCycleDiscardsTheCycle() {
        val f = Feeder(RepCounter())
        f.feed(Pose.OPEN, 12); f.feed(Pose.CLOSED, 12)
        f.feed(Pose.UNKNOWN, 40, detected = false) // ~1.3 s without a hand
        f.feed(Pose.OPEN, 12)
        assertEquals(0, f.counter.count)
        assertEquals(RepCounter.Phase.WAIT_CLOSE, f.counter.phase)
    }

    @Test fun briefDropoutDoesNotLoseTheCycle() {
        val f = Feeder(RepCounter())
        f.feed(Pose.OPEN, 12); f.feed(Pose.CLOSED, 12)
        f.feed(Pose.UNKNOWN, 8, detected = false) // ~260 ms
        f.feed(Pose.OPEN, 12)
        assertEquals(1, f.counter.count)
    }

    @Test fun unreliableFramesNeverCount() {
        val f = Feeder(RepCounter())
        f.feed(Pose.OPEN, 12)
        f.feed(Pose.CLOSED, 12, reliable = false)
        f.feed(Pose.OPEN, 12, reliable = false)
        assertEquals(0, f.counter.count)
    }

    @Test fun flickeringPoseIsNeverConfirmed() {
        val c = RepCounter(); var t = 0L
        repeat(200) { i ->
            c.update(Observation(t, true, true, if (i % 2 == 0) Pose.OPEN else Pose.CLOSED)); t += 33
        }
        assertEquals(0, c.count)
    }

    @Test fun debounceKeepsCountsAtLeastMinIntervalApart() {
        val f = Feeder(RepCounter())
        f.feed(Pose.OPEN, 6)
        repeat(8) { f.feed(Pose.CLOSED, 6); f.feed(Pose.OPEN, 6) } // very fast cycles
        assertTrue(f.repTimes.size >= 2)
        for (i in 1 until f.repTimes.size) assertTrue(f.repTimes[i] - f.repTimes[i - 1] >= 450)
    }

    @Test fun resetCycleKeepsCountResetClearsIt() {
        val f = Feeder(RepCounter()); f.cycle()
        f.counter.resetCycle()
        assertEquals(1, f.counter.count)
        assertEquals(RepCounter.Phase.NO_HAND, f.counter.phase)
        f.counter.reset()
        assertEquals(0, f.counter.count)
    }
}
