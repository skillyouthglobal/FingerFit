hand_landmarker.task is downloaded here at build time (see app/build.gradle.kts).
