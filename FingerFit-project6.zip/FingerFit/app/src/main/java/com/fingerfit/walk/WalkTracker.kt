package com.fingerfit.walk

import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.fingerfit.data.Repo
import com.fingerfit.data.Store
import com.fingerfit.data.WalkRecord
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class WalkState { IDLE, RUNNING, PAUSED }

data class WalkUi(
    val state: WalkState = WalkState.IDLE,
    val meters: Float = 0f,
    val elapsedMs: Long = 0,
    val message: String = "",
    /** Route as (latitude, longitude) pairs. */
    val route: List<Pair<Double, Double>> = emptyList(),
) {
    val km: Float get() = meters / 1000f
    val avgKmh: Float get() = if (elapsedMs < 5_000L) 0f else km / (elapsedMs / 3_600_000f)
}

/** Shared walk state, fed by [WalkService] and read by the walk screen. */
object WalkTracker {
    private val _ui = MutableStateFlow(WalkUi())
    val ui: StateFlow<WalkUi> = _ui.asStateFlow()

    private var runStart = 0L
    private var accumulated = 0L
    private var meters = 0f
    private var last: Location? = null
    private val route = ArrayList<Pair<Double, Double>>()

    private fun elapsed(): Long =
        accumulated + if (_ui.value.state == WalkState.RUNNING) SystemClock.elapsedRealtime() - runStart else 0L

    @Synchronized
    fun begin(ctx: Context) {
        runStart = SystemClock.elapsedRealtime()
        accumulated = 0
        meters = 0f
        last = null
        route.clear()
        _ui.value = WalkUi(WalkState.RUNNING, message = "Waiting for GPS signal...")
        ContextCompat.startForegroundService(ctx, Intent(ctx, WalkService::class.java))
    }

    @Synchronized
    fun pause() {
        if (_ui.value.state != WalkState.RUNNING) return
        accumulated += SystemClock.elapsedRealtime() - runStart
        last = null // do not count the gap while paused
        _ui.value = _ui.value.copy(state = WalkState.PAUSED, elapsedMs = accumulated, message = "Paused")
    }

    @Synchronized
    fun resume() {
        if (_ui.value.state != WalkState.PAUSED) return
        runStart = SystemClock.elapsedRealtime()
        _ui.value = _ui.value.copy(state = WalkState.RUNNING, message = "Waiting for GPS signal...")
    }

    @Synchronized
    fun tick() {
        val s = _ui.value
        if (s.state != WalkState.IDLE) _ui.value = s.copy(elapsedMs = elapsed())
    }

    @Synchronized
    fun setMessage(m: String) {
        _ui.value = _ui.value.copy(message = m)
    }

    @Synchronized
    fun onLocation(loc: Location) {
        if (_ui.value.state != WalkState.RUNNING) return
        if (loc.hasAccuracy() && loc.accuracy > 30f) {
            _ui.value = _ui.value.copy(message = "Weak GPS signal. Move to an open area.")
            return
        }
        val prev = last
        if (prev == null) {
            last = loc
            route.add(loc.latitude to loc.longitude)
            _ui.value = _ui.value.copy(message = "Tracking your walk", route = route.toList())
            return
        }
        val d = prev.distanceTo(loc)
        val dtSec = (loc.elapsedRealtimeNanos - prev.elapsedRealtimeNanos) / 1e9f
        val minStep = maxOf(3f, if (loc.hasAccuracy()) loc.accuracy * 0.6f else 3f)
        if (d < minStep) return // GPS jitter while standing still
        if (dtSec > 0f && d / dtSec > 8f) return // impossible jump for walking
        meters += d
        last = loc
        route.add(loc.latitude to loc.longitude)
        _ui.value = _ui.value.copy(
            meters = meters, elapsedMs = elapsed(), message = "Tracking your walk", route = route.toList(),
        )
    }

    /** Stops tracking, saves the walk to the history and returns it (null if too short to keep). */
    @Synchronized
    fun finish(ctx: Context): WalkRecord? {
        val seconds = (elapsed() / 1000).toInt()
        val m = meters
        ctx.stopService(Intent(ctx, WalkService::class.java))
        _ui.value = WalkUi()
        last = null
        route.clear()
        accumulated = 0
        meters = 0f
        if (seconds < 10) return null

        Repo.init(ctx)
        val goal = Store(ctx).loadSettings().walkGoalMin
        val before = Repo.todayWalkSeconds()
        val rec = WalkRecord(System.currentTimeMillis(), m, seconds, goal)
        Repo.addWalk(rec)
        if (before < goal * 60 && before + seconds >= goal * 60) {
            Repo.addInbox("Walking goal reached", "You walked $goal minutes today. Great job!")
        }
        return rec
    }
}
