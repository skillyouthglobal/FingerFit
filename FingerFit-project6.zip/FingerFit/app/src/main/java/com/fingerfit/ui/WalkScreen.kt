package com.fingerfit.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.data.Repo
import com.fingerfit.data.WalkRecord
import com.fingerfit.data.toLocalDate
import com.fingerfit.walk.WalkState
import com.fingerfit.walk.WalkTracker
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min

private fun fmtKm(meters: Float) = "%.2f".format(Locale.US, meters / 1000f)
private fun fmtKmh(kmh: Float) = "%.1f".format(Locale.US, kmh)

@Composable
fun WalkScreen(app: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val ui by WalkTracker.ui.collectAsStateWithLifecycle()
    val settings by app.settings.collectAsStateWithLifecycle()
    val walks by Repo.walks.collectAsStateWithLifecycle()
    var summary by remember { mutableStateOf<WalkRecord?>(null) }
    var info by remember { mutableStateOf<String?>(null) }

    BackHandler(onBack = onBack)

    fun hasLocation() =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    val startWalk = {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            info = "Turn on Location (GPS) on your phone, then try again."
        } else {
            info = null
            WalkTracker.begin(context)
        }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasLocation()) startWalk() else info = "Location permission is needed to track your walk."
    }

    LaunchedEffect(ui.state) {
        if (ui.state != WalkState.IDLE) {
            while (true) {
                WalkTracker.tick()
                delay(1000)
            }
        }
    }

    val today = LocalDate.now()
    val todaySeconds = walks.filter { it.t.toLocalDate() == today }.sumOf { it.seconds } +
        if (ui.state != WalkState.IDLE) (ui.elapsedMs / 1000).toInt() else 0
    val goalSec = settings.walkGoalMin * 60
    val progress = (todaySeconds.toFloat() / goalSec).coerceIn(0f, 1f)

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.systemBarsPadding()) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                    Text("🚶 Outdoor Walking", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                fmtKm(ui.meters), fontSize = 60.sp, fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.primary,
                            )
                            Text(" km", fontSize = 20.sp, modifier = Modifier.padding(bottom = 12.dp))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                            Stat("Time", formatDuration(ui.elapsedMs))
                            Stat("Avg speed", "${fmtKmh(ui.avgKmh)} km/h")
                        }
                        if (ui.message.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            Text(ui.message, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (ui.route.size >= 2) {
                            Spacer(Modifier.height(12.dp))
                            RouteView(ui.route, Modifier.fillMaxWidth().height(170.dp))
                        }
                    }
                }
            }

            item {
                info?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                }
                when (ui.state) {
                    WalkState.IDLE -> Button(
                        onClick = {
                            if (hasLocation()) startWalk()
                            else {
                                val perms = mutableListOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION,
                                )
                                if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
                                launcher.launch(perms.toTypedArray())
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape = RoundedCornerShape(18.dp),
                    ) { Text("Start Walk", fontSize = 18.sp, fontWeight = FontWeight.Bold) }

                    else -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { if (ui.state == WalkState.RUNNING) WalkTracker.pause() else WalkTracker.resume() },
                            modifier = Modifier.weight(1f).height(56.dp),
                            shape = RoundedCornerShape(18.dp),
                        ) { Text(if (ui.state == WalkState.RUNNING) "Pause" else "Resume", fontWeight = FontWeight.Bold) }
                        OutlinedButton(
                            onClick = {
                                val rec = WalkTracker.finish(context)
                                summary = rec
                                if (rec == null) info = "Walk was too short to save."
                            },
                            modifier = Modifier.weight(1f).height(56.dp),
                            shape = RoundedCornerShape(18.dp),
                        ) { Text("Stop") }
                    }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Daily goal", fontWeight = FontWeight.Bold)
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth().height(10.dp),
                            trackColor = MaterialTheme.colorScheme.surfaceVariant,
                            strokeCap = StrokeCap.Round,
                        )
                        Text(
                            "${todaySeconds / 60} of ${settings.walkGoalMin} min today",
                            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(30, 45, 60).forEach { m ->
                                FilterChip(
                                    selected = settings.walkGoalMin == m,
                                    onClick = { app.setWalkGoal(m) },
                                    label = { Text("$m min") },
                                )
                            }
                        }
                    }
                }
            }

            item { Text("Recent walks", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            if (walks.isEmpty()) {
                item {
                    Text(
                        "No walks yet. Press Start Walk and go for a stroll. " +
                            "Tracking keeps running when the screen is off.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                items(walks.take(15)) { w ->
                    val km = w.meters / 1000f
                    val kmh = if (w.seconds > 0) km / (w.seconds / 3600f) else 0f
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    ) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(w.t)),
                                    fontWeight = FontWeight.SemiBold,
                                )
                                Text(
                                    "${formatDuration(w.seconds * 1000L)}  ·  ${fmtKmh(kmh)} km/h",
                                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Text("${fmtKm(w.meters)} km", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                    }
                }
            }
        }
    }

    summary?.let { w ->
        val km = w.meters / 1000f
        AlertDialog(
            onDismissRequest = { summary = null },
            title = { Text("Walk summary") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Distance: ${fmtKm(w.meters)} km")
                    Text("Time: ${formatDuration(w.seconds * 1000L)}")
                    Text("Average speed: ${fmtKmh(if (w.seconds > 0) km / (w.seconds / 3600f) else 0f)} km/h")
                }
            },
            confirmButton = { TextButton(onClick = { summary = null }) { Text("Done") } },
        )
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** The walked route drawn as a line (no map tiles, so it works fully offline). */
@Composable
private fun RouteView(route: List<Pair<Double, Double>>, modifier: Modifier) {
    Canvas(modifier) {
        if (route.size < 2) return@Canvas
        val minLat = route.minOf { it.first }
        val maxLat = route.maxOf { it.first }
        val minLon = route.minOf { it.second }
        val maxLon = route.maxOf { it.second }
        val cosLat = cos(Math.toRadians((minLat + maxLat) / 2)).toFloat()
        val w = ((maxLon - minLon).toFloat() * cosLat).coerceAtLeast(1e-6f)
        val h = (maxLat - minLat).toFloat().coerceAtLeast(1e-6f)
        val pad = 24f
        val scale = min((size.width - 2 * pad) / w, (size.height - 2 * pad) / h)
        val ox = (size.width - w * scale) / 2f
        val oy = (size.height - h * scale) / 2f
        fun pt(p: Pair<Double, Double>) = Offset(
            ox + (p.second - minLon).toFloat() * cosLat * scale,
            oy + (maxLat - p.first).toFloat() * scale,
        )
        for (i in 1 until route.size) drawLine(Mint, pt(route[i - 1]), pt(route[i]), 8f, StrokeCap.Round)
        drawCircle(Violet, 11f, pt(route.first()))
        drawCircle(Amber, 11f, pt(route.last()))
    }
}
