package com.fingerfit.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

data class WorkoutRecord(
    val t: Long,
    val type: String,
    val reps: Int,
    val left: Int,
    val right: Int,
    val seconds: Int,
    val target: Int,
    val reached: Boolean,
)

data class WalkRecord(val t: Long, val meters: Float, val seconds: Int, val goalMin: Int)

/** One night of sleep, keyed by the wake-up date (yyyy-MM-dd). Times are minutes after midnight. */
data class SleepRecord(val date: String, val bedMin: Int, val wakeMin: Int, val minutes: Int)

data class InboxItem(val id: Long, val t: Long, val title: String, val body: String, val read: Boolean)

fun Long.toLocalDate(): LocalDate = Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).toLocalDate()

/**
 * All local data for workouts, walks, sleep and the notification inbox.
 * Stored on the device only. Safe to use from the UI, the walk service and the reminder worker.
 */
object Repo {
    private var sp: SharedPreferences? = null
    private val lock = Any()

    private val _workouts = MutableStateFlow<List<WorkoutRecord>>(emptyList())
    private val _walks = MutableStateFlow<List<WalkRecord>>(emptyList())
    private val _sleeps = MutableStateFlow<List<SleepRecord>>(emptyList())
    private val _inbox = MutableStateFlow<List<InboxItem>>(emptyList())

    val workouts: StateFlow<List<WorkoutRecord>> = _workouts.asStateFlow()
    val walks: StateFlow<List<WalkRecord>> = _walks.asStateFlow()
    val sleeps: StateFlow<List<SleepRecord>> = _sleeps.asStateFlow()
    val inbox: StateFlow<List<InboxItem>> = _inbox.asStateFlow()

    fun init(context: Context) {
        synchronized(lock) {
            if (sp != null) return
            val p = context.applicationContext.getSharedPreferences("fingerfit_data", Context.MODE_PRIVATE)
            sp = p
            _workouts.value = readList(p, "workouts") { o ->
                WorkoutRecord(
                    o.getLong("t"), o.getString("ty"), o.getInt("r"), o.optInt("l"), o.optInt("rt"),
                    o.getInt("s"), o.getInt("g"), o.optBoolean("ok"),
                )
            }
            _walks.value = readList(p, "walks") { o ->
                WalkRecord(o.getLong("t"), o.getDouble("m").toFloat(), o.getInt("s"), o.optInt("g", 30))
            }
            _sleeps.value = readList(p, "sleeps") { o ->
                SleepRecord(o.getString("d"), o.getInt("b"), o.getInt("w"), o.getInt("m"))
            }
            _inbox.value = readList(p, "inbox") { o ->
                InboxItem(o.getLong("id"), o.getLong("t"), o.getString("ti"), o.getString("b"), o.optBoolean("rd"))
            }
        }
    }

    private fun <T> readList(p: SharedPreferences, key: String, parse: (JSONObject) -> T): List<T> {
        val raw = p.getString(key, null) ?: return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { parse(a.getJSONObject(it)) }
        }.getOrDefault(emptyList())
    }

    private fun <T> write(key: String, list: List<T>, build: (T) -> JSONObject) {
        val a = JSONArray()
        list.forEach { a.put(build(it)) }
        sp?.edit()?.putString(key, a.toString())?.apply()
    }

    // ---- workouts ----------------------------------------------------------

    fun addWorkout(r: WorkoutRecord) = synchronized(lock) {
        val list = (listOf(r) + _workouts.value).take(300)
        _workouts.value = list
        write("workouts", list) {
            JSONObject().put("t", it.t).put("ty", it.type).put("r", it.reps).put("l", it.left)
                .put("rt", it.right).put("s", it.seconds).put("g", it.target).put("ok", it.reached)
        }
    }

    /** Total repetitions (or plank seconds are excluded) done today across body exercises. */
    fun todayBodyReps(): Int {
        val today = LocalDate.now()
        return _workouts.value.filter { it.t.toLocalDate() == today && it.type != "PLANK" }.sumOf { it.reps }
    }

    // ---- walks -------------------------------------------------------------

    fun addWalk(r: WalkRecord) = synchronized(lock) {
        val list = (listOf(r) + _walks.value).take(300)
        _walks.value = list
        write("walks", list) {
            JSONObject().put("t", it.t).put("m", it.meters.toDouble()).put("s", it.seconds).put("g", it.goalMin)
        }
    }

    fun todayWalkSeconds(): Int {
        val today = LocalDate.now()
        return _walks.value.filter { it.t.toLocalDate() == today }.sumOf { it.seconds }
    }

    // ---- sleep -------------------------------------------------------------

    fun saveSleep(r: SleepRecord) = synchronized(lock) {
        val list = (listOf(r) + _sleeps.value.filter { it.date != r.date }).sortedByDescending { it.date }.take(120)
        _sleeps.value = list
        write("sleeps", list) {
            JSONObject().put("d", it.date).put("b", it.bedMin).put("w", it.wakeMin).put("m", it.minutes)
        }
    }

    // ---- inbox -------------------------------------------------------------

    fun addInbox(title: String, body: String) = synchronized(lock) {
        val now = System.currentTimeMillis()
        val list = (listOf(InboxItem(now, now, title, body, false)) + _inbox.value).take(100)
        saveInbox(list)
    }

    fun markAllRead() = synchronized(lock) {
        if (_inbox.value.any { !it.read }) saveInbox(_inbox.value.map { it.copy(read = true) })
    }

    fun clearInbox() = synchronized(lock) { saveInbox(emptyList()) }

    private fun saveInbox(list: List<InboxItem>) {
        _inbox.value = list
        write("inbox", list) {
            JSONObject().put("id", it.id).put("t", it.t).put("ti", it.title).put("b", it.body).put("rd", it.read)
        }
    }

    fun clearWorkoutsAndWalks() = synchronized(lock) {
        _workouts.value = emptyList()
        _walks.value = emptyList()
        write("workouts", emptyList<WorkoutRecord>()) { JSONObject() }
        write("walks", emptyList<WalkRecord>()) { JSONObject() }
    }
}
