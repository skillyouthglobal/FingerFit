package com.fingerfit.logic

/** One processed camera frame, as seen by the counter. */
data class Observation(
    val timeMs: Long,
    val handDetected: Boolean,
    val reliable: Boolean,
    val pose: Pose,
)

/**
 * Counts open -> close -> open repetitions.
 *
 * A repetition is counted exactly once, at the moment the hand is confirmed
 * OPEN again after having been confirmed OPEN and then CLOSED. Holding any
 * pose never counts anything. Safeguards:
 *  - Stable-frame check: a pose must persist for [Config.stableFrames] frames
 *    AND [Config.stableMs] milliseconds before it is "confirmed".
 *  - Hand lost / unreliable for longer than [Config.lostGraceMs]: the cycle in
 *    progress is discarded (no count) and the user must show an open hand again.
 *  - Debounce: two counts can never be closer than [Config.minRepIntervalMs].
 *  - Transition frames (UNKNOWN pose) break the stability streak, so a
 *    flickering classifier cannot confirm a pose.
 */
class RepCounter(private val cfg: Config = Config()) {

    data class Config(
        val stableFrames: Int = 4,
        val stableMs: Long = 120,
        val lostGraceMs: Long = 600,
        val minRepIntervalMs: Long = 450,
    )

    enum class Phase { NO_HAND, WAIT_OPEN, WAIT_CLOSE, WAIT_REOPEN }

    enum class Event {
        NONE, HAND_FOUND, HAND_LOST, OPEN_CONFIRMED, CLOSED_CONFIRMED, REP_COMPLETED,
    }

    var count: Int = 0
        private set
    var phase: Phase = Phase.NO_HAND
        private set

    private var candidate: Pose? = null
    private var streak = 0
    private var streakStartMs = 0L
    private var lastUsableMs = NEVER
    private var lastRepMs = NEVER

    fun update(o: Observation): Event {
        val usable = o.handDetected && o.reliable

        if (!usable) {
            candidate = null
            streak = 0
            if (phase != Phase.NO_HAND && o.timeMs - lastUsableMs > cfg.lostGraceMs) {
                phase = Phase.NO_HAND
                return Event.HAND_LOST
            }
            return Event.NONE
        }

        lastUsableMs = o.timeMs
        var event = Event.NONE
        if (phase == Phase.NO_HAND) {
            phase = Phase.WAIT_OPEN
            event = Event.HAND_FOUND
        }

        if (o.pose == Pose.UNKNOWN) {
            candidate = null
            streak = 0
            return event
        }

        if (o.pose == candidate) {
            streak++
        } else {
            candidate = o.pose
            streak = 1
            streakStartMs = o.timeMs
        }

        val confirmed = streak >= cfg.stableFrames && o.timeMs - streakStartMs >= cfg.stableMs
        if (!confirmed) return event

        when (phase) {
            Phase.WAIT_OPEN -> if (o.pose == Pose.OPEN) {
                phase = Phase.WAIT_CLOSE
                return Event.OPEN_CONFIRMED
            }
            Phase.WAIT_CLOSE -> if (o.pose == Pose.CLOSED) {
                phase = Phase.WAIT_REOPEN
                return Event.CLOSED_CONFIRMED
            }
            Phase.WAIT_REOPEN -> if (o.pose == Pose.OPEN) {
                phase = Phase.WAIT_CLOSE // hand is open: ready for the next close
                if (o.timeMs - lastRepMs >= cfg.minRepIntervalMs) {
                    count++
                    lastRepMs = o.timeMs
                    return Event.REP_COMPLETED
                }
                return event
            }
            Phase.NO_HAND -> Unit
        }
        return event
    }

    /** Forget the cycle in progress but keep the count (used on pause / resume). */
    fun resetCycle() {
        phase = Phase.NO_HAND
        candidate = null
        streak = 0
        lastUsableMs = NEVER
    }

    /** Start over from zero. */
    fun reset() {
        resetCycle()
        count = 0
        lastRepMs = NEVER
    }

    private companion object {
        /** 'Long ago' without risking Long overflow when subtracting. */
        const val NEVER = Long.MIN_VALUE / 2
    }
}
