package com.fingerfit.vision

import android.content.Context
import android.graphics.Bitmap
import com.fingerfit.logic.BodyPoint
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker

/** Wrapper around MediaPipe Pose Landmarker (model packaged in the APK, fully on-device). */
class PoseTracker(context: Context) {

    private val landmarker: PoseLandmarker
    private var closed = false
    private var lastTimestampMs = 0L

    init {
        val base = BaseOptions.builder().setModelAssetPath(MODEL_ASSET).build()
        val options = PoseLandmarker.PoseLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.VIDEO)
            .setNumPoses(1)
            .setMinPoseDetectionConfidence(0.5f)
            .setMinPosePresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .build()
        landmarker = PoseLandmarker.createFromOptions(context.applicationContext, options)
    }

    /** The 33 body landmarks, or null when no person was found. */
    @Synchronized
    fun detect(upright: Bitmap, timeMs: Long): List<BodyPoint>? {
        if (closed) return null
        val ts = if (timeMs <= lastTimestampMs) lastTimestampMs + 1 else timeMs
        lastTimestampMs = ts
        val result = landmarker.detectForVideo(BitmapImageBuilder(upright).build(), ts)
        val pose = result.landmarks().firstOrNull() ?: return null
        if (pose.size < 33) return null
        return pose.map { BodyPoint(it.x(), it.y(), it.visibility().orElse(0f)) }
    }

    @Synchronized
    fun close() {
        if (closed) return
        closed = true
        landmarker.close()
    }

    companion object {
        const val MODEL_ASSET = "pose_landmarker_lite.task"
    }
}
