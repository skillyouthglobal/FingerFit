package com.fingerfit

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** Optional vibration / beep feedback. */
class Feedback(context: Context) {
    private val vibrator: Vibrator? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    private var tone: ToneGenerator? = null

    fun repDone(sound: Boolean, vibrate: Boolean) = emit(sound, vibrate, 40L, 80)

    fun targetDone(sound: Boolean, vibrate: Boolean) = emit(sound, vibrate, 250L, 300)

    private fun emit(sound: Boolean, vibrate: Boolean, vibMs: Long, toneMs: Int) {
        if (vibrate) {
            runCatching {
                vibrator?.vibrate(VibrationEffect.createOneShot(vibMs, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        }
        if (sound) {
            runCatching {
                if (tone == null) tone = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
                tone?.startTone(ToneGenerator.TONE_PROP_BEEP, toneMs)
            }
        }
    }

    fun release() {
        tone?.release()
        tone = null
    }
}
