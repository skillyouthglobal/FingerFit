package com.fingerfit.logic

import kotlin.math.hypot
import kotlin.math.min

enum class Pose { OPEN, CLOSED, UNKNOWN }

/** One hand landmark in MediaPipe's normalised image coordinates (0..1). */
class Landmark(val x: Float, val y: Float, val z: Float = 0f)

data class GestureResult(
    val pose: Pose,
    /** 0 = all four fingers curled, 1 = all four fingers fully straight. */
    val openness: Float,
    /** False when the hand is clipped by the frame, too small, or low-confidence. */
    val reliable: Boolean,
)

/**
 * Classifies a hand as OPEN, CLOSED (fist) or UNKNOWN (in transition) from the
 * 21 MediaPipe hand landmarks.
 *
 * Method: for each of the four fingers, compare the distance wrist->fingertip
 * with the distance wrist->finger base (MCP). The ratio is ~1.8-2.0 for a
 * straight finger and ~0.8-1.1 for a curled one, and it does not depend on
 * hand size, distance or rotation in the image. The thumb is intentionally not
 * used: it folds in many different ways and would cause missed repetitions.
 *
 * Landmark indices: 0 wrist; 5/9/13/17 = index/middle/ring/pinky MCP;
 * 8/12/16/20 = the fingertips.
 */
object GestureClassifier {
    private val TIPS = intArrayOf(8, 12, 16, 20)
    private val MCPS = intArrayOf(5, 9, 13, 17)

    const val OPEN_RATIO = 1.65f
    const val CLOSED_RATIO = 1.20f
    const val MIN_HAND_SCORE = 0.5f

    fun classify(
        lm: List<Landmark>,
        widthPx: Float,
        heightPx: Float,
        handScore: Float = 1f,
    ): GestureResult {
        val bad = GestureResult(Pose.UNKNOWN, 0f, false)
        if (lm.size < 21 || widthPx <= 0f || heightPx <= 0f) return bad
        if (handScore < MIN_HAND_SCORE) return bad

        // Hand cut off by the edge of the frame -> measurements are not trustworthy.
        val m = 0.02f
        val outside = lm.count { it.x < -m || it.x > 1f + m || it.y < -m || it.y > 1f + m }
        if (outside > 2) return bad

        // Hand too small / too far away.
        val palm = dist(lm[0], lm[9], widthPx, heightPx)
        if (palm < 0.03f * min(widthPx, heightPx)) return bad

        val per = FloatArray(4) { i ->
            val baseLen = dist(lm[0], lm[MCPS[i]], widthPx, heightPx)
            if (baseLen < 1e-3f) {
                0f
            } else {
                val ratio = dist(lm[0], lm[TIPS[i]], widthPx, heightPx) / baseLen
                ((ratio - CLOSED_RATIO) / (OPEN_RATIO - CLOSED_RATIO)).coerceIn(0f, 1f)
            }
        }
        val avg = per.sum() / per.size
        val lo = per.min()
        val hi = per.max()

        val pose = when {
            avg >= 0.85f && lo >= 0.6f -> Pose.OPEN
            avg <= 0.15f && hi <= 0.4f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return GestureResult(pose, avg, true)
    }

    private fun dist(a: Landmark, b: Landmark, w: Float, h: Float): Float =
        hypot((a.x - b.x) * w, (a.y - b.y) * h)
}
