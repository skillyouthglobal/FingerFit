package com.fingerfit.vision

import android.content.Context
import android.graphics.Bitmap
import com.fingerfit.logic.Landmark
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker

/**
 * Thin wrapper around MediaPipe Hand Landmarker. The model file is packaged in
 * the APK (assets/hand_landmarker.task); everything runs on-device.
 * All public methods are synchronized so closing can never race with a frame.
 */
class HandTracker(context: Context) {

    class Detection(
        /** 21 landmarks, or null when no hand was found. */
        val landmarks: List<Landmark>?,
        val score: Float,
    )

    private val landmarker: HandLandmarker
    private var closed = false
    private var lastTimestampMs = 0L

    init {
        val base = BaseOptions.builder().setModelAssetPath(MODEL_ASSET).build()
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.VIDEO)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.6f)
            .setMinHandPresenceConfidence(0.6f)
            .setMinTrackingConfidence(0.6f)
            .build()
        landmarker = HandLandmarker.createFromOptions(context.applicationContext, options)
    }

    /** [upright] must already be rotated (and mirrored for the front camera). */
    @Synchronized
    fun detect(upright: Bitmap, timeMs: Long): Detection? {
        if (closed) return null
        val ts = if (timeMs <= lastTimestampMs) lastTimestampMs + 1 else timeMs
        lastTimestampMs = ts

        val result = landmarker.detectForVideo(BitmapImageBuilder(upright).build(), ts)
        val hand = result.landmarks().firstOrNull() ?: return Detection(null, 0f)
        val score = result.handedness().firstOrNull()?.firstOrNull()?.score() ?: 0f
        return Detection(hand.map { Landmark(it.x(), it.y(), it.z()) }, score)
    }

    @Synchronized
    fun close() {
        if (closed) return
        closed = true
        landmarker.close()
    }

    companion object {
        const val MODEL_ASSET = "hand_landmarker.task"
    }
}
