package com.fingerfit.vision

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.fingerfit.logic.GestureClassifier
import com.fingerfit.logic.GestureResult
import com.fingerfit.logic.Landmark
import com.fingerfit.logic.Observation
import com.fingerfit.logic.Pose

/** Everything the UI / counter needs to know about one analysed frame. */
class FrameResult(
    val observation: Observation,
    val gesture: GestureResult?,
    val landmarks: List<Landmark>?,
    val imageWidth: Int,
    val imageHeight: Int,
    val lightingOk: Boolean,
)

/**
 * CameraX analyzer: frame -> upright (and, for the front camera, mirrored) bitmap
 * -> MediaPipe landmarks -> gesture. Frames are analysed in memory only; nothing
 * is recorded or stored.
 */
class HandAnalyzer(
    private val tracker: HandTracker,
    private val mirror: Boolean,
    private val isActive: () -> Boolean,
    private val onFrame: (FrameResult?) -> Unit,
) : ImageAnalysis.Analyzer {

    override fun analyze(image: ImageProxy) {
        try {
            if (!isActive()) {
                onFrame(null)
                return
            }
            val raw = image.toBitmap()
            val matrix = Matrix().apply {
                postRotate(image.imageInfo.rotationDegrees.toFloat())
                if (mirror) postScale(-1f, 1f)
            }
            val upright = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
            val now = SystemClock.uptimeMillis()
            val lightingOk = meanLuma(upright) >= MIN_LUMA

            val detection = tracker.detect(upright, now)
            val w = upright.width
            val h = upright.height

            val frame = if (detection?.landmarks != null) {
                val g = GestureClassifier.classify(detection.landmarks, w.toFloat(), h.toFloat(), detection.score)
                FrameResult(
                    Observation(now, handDetected = true, reliable = g.reliable && lightingOk, pose = g.pose),
                    g, detection.landmarks, w, h, lightingOk,
                )
            } else {
                FrameResult(
                    Observation(now, handDetected = false, reliable = false, pose = Pose.UNKNOWN),
                    null, null, w, h, lightingOk,
                )
            }

            if (upright !== raw) raw.recycle()
            upright.recycle()
            onFrame(frame)
        } catch (e: Exception) {
            // A single bad frame must never crash the session or add a repetition.
            onFrame(null)
        } finally {
            image.close()
        }
    }

    /** Average brightness (0..255) from a coarse 12x12 sample grid. */
    private fun meanLuma(b: Bitmap): Float {
        val n = 12
        var sum = 0f
        for (iy in 0 until n) for (ix in 0 until n) {
            val p = b.getPixel(((ix + 0.5f) * b.width / n).toInt(), ((iy + 0.5f) * b.height / n).toInt())
            sum += 0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p)
        }
        return sum / (n * n)
    }

    private companion object {
        const val MIN_LUMA = 40f
    }
}
