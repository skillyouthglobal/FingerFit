package com.fingerfit.walk

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.fingerfit.Notify
import com.fingerfit.R

/**
 * Foreground service that keeps GPS running while the screen is off.
 * Uses the phone's GPS chip directly: no internet, no Google services, nothing uploaded.
 */
class WalkService : Service() {

    private var lm: LocationManager? = null

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            WalkTracker.onLocation(location)
        }

        // Required on Android 8-10, where these are not default methods.
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {
            WalkTracker.setMessage("GPS is off. Turn on location to track your walk.")
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("MissingPermission")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notify.ensureChannels(this)
        val notification = NotificationCompat.Builder(this, Notify.CH_WALK)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Kinetro walk in progress")
            .setContentText("Tracking distance and time")
            .setContentIntent(Notify.openAppIntent(this))
            .setOngoing(true)
            .build()
        try {
            ServiceCompat.startForeground(this, 201, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            val manager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm = manager
            if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                WalkTracker.setMessage("GPS is off. Turn on location to track your walk.")
            }
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 0f, listener, Looper.getMainLooper())
        } catch (e: Exception) {
            WalkTracker.setMessage("Could not start GPS tracking. Check the location permission.")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        runCatching { lm?.removeUpdates(listener) }
        super.onDestroy()
    }
}
