package com.fingerfit

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fingerfit.data.Repo
import com.fingerfit.data.Session
import com.fingerfit.data.Settings
import com.fingerfit.data.Store
import com.fingerfit.data.ThemeMode
import com.fingerfit.logic.Landmark
import com.fingerfit.logic.Pose
import com.fingerfit.logic.RepCounter
import com.fingerfit.vision.FrameResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Status { IDLE, RUNNING, PAUSED, FINISHED }

data class Summary(val reps: Int, val durationSec: Int, val target: Int, val targetReached: Boolean)

data class SessionUi(
    val status: Status = Status.IDLE,
    val reps: Int = 0,
    val target: Int = 20,
    val elapsedMs: Long = 0,
    val message: String = "Press Start when your hand is in view.",
    val handDetected: Boolean = false,
    val pose: Pose = Pose.UNKNOWN,
    /** Increments on each completed repetition (drives the counter animation). */
    val repFlash: Int = 0,
    val error: String? = null,
    val summary: Summary? = null,
)

/** Landmarks to draw on top of the preview. */
class Overlay(val points: List<Landmark>?, val width: Int, val height: Int, val pose: Pose)

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = Store(app)
    private val feedback = Feedback(app)

    init {
        Repo.init(app)
    }

    private val _settings = MutableStateFlow(store.loadSettings())
    val settings: StateFlow<Settings> = _settings.asStateFlow()

    private val _history = MutableStateFlow(store.loadHistory())
    val history: StateFlow<List<Session>> = _history.asStateFlow()

    private val _ui = MutableStateFlow(SessionUi(target = _settings.value.target))
    val ui: StateFlow<SessionUi> = _ui.asStateFlow()

    private val _overlay = MutableStateFlow<Overlay?>(null)
    val overlay: StateFlow<Overlay?> = _overlay.asStateFlow()

    private val counter = RepCounter()
    private val lock = Any()

    @Volatile private var running = false
    private var runStartMs = 0L
    private var accumulatedMs = 0L
    private var sessionTarget = 20
    private var lastRepAt = 0L
    private var ticker: Job? = null

    /** Called from the camera analysis thread. */
    fun isActive(): Boolean = running

    // ---- session control ---------------------------------------------------

    /** Opening the exercise screen: start from a clean, idle session. */
    fun prepareSession() = synchronized(lock) {
        if (_ui.value.status == Status.RUNNING || _ui.value.status == Status.PAUSED) return@synchronized
        stopTicker()
        running = false
        counter.reset()
        accumulatedMs = 0
        _overlay.value = null
        _ui.value = SessionUi(target = _settings.value.target)
    }

    fun start() = synchronized(lock) {
        counter.reset()
        accumulatedMs = 0
        sessionTarget = _settings.value.target
        runStartMs = SystemClock.uptimeMillis()
        running = true
        _ui.value = SessionUi(
            status = Status.RUNNING,
            target = sessionTarget,
            message = "Show your hand to the camera.",
        )
        startTicker()
    }

    fun pause() = synchronized(lock) {
        if (!running) return@synchronized
        accumulatedMs += SystemClock.uptimeMillis() - runStartMs
        running = false
        counter.resetCycle()
        stopTicker()
        _overlay.value = null
        _ui.update { it.copy(status = Status.PAUSED, message = "Paused", handDetected = false, elapsedMs = accumulatedMs) }
    }

    fun resume() = synchronized(lock) {
        if (_ui.value.status != Status.PAUSED) return@synchronized
        runStartMs = SystemClock.uptimeMillis()
        running = true
        counter.resetCycle()
        _ui.update { it.copy(status = Status.RUNNING, message = "Show your hand to the camera.", error = null) }
        startTicker()
    }

    fun resetSession() = synchronized(lock) {
        stopTicker()
        running = false
        counter.reset()
        accumulatedMs = 0
        _overlay.value = null
        _ui.value = SessionUi(target = _settings.value.target)
    }

    /** User pressed End Exercise: save (if anything was done) and show the summary. */
    fun endSession() = synchronized(lock) {
        finishLocked(targetReached = false)
    }

    fun dismissSummary() = synchronized(lock) {
        stopTicker()
        running = false
        counter.reset()
        accumulatedMs = 0
        _overlay.value = null
        _ui.value = SessionUi(target = _settings.value.target)
    }

    /** App went to the background: pause instead of silently counting. */
    fun pauseIfRunning() {
        if (running) pause()
    }

    private fun elapsedNow(): Long =
        accumulatedMs + if (running) SystemClock.uptimeMillis() - runStartMs else 0L

    private fun finishLocked(targetReached: Boolean) {
        val duration = (elapsedNow() / 1000).toInt()
        val reps = counter.count
        running = false
        accumulatedMs = duration * 1000L
        stopTicker()
        _overlay.value = null
        if (reps > 0) {
            val s = Session(System.currentTimeMillis(), reps, duration, sessionTarget, targetReached)
            val list = (listOf(s) + _history.value).take(300)
            _history.value = list
            store.saveHistory(list)
            if (targetReached) Repo.addInbox("Target completed", "Finger exercise: $reps repetitions done. Great work!")
        }
        _ui.update {
            it.copy(
                status = Status.FINISHED,
                reps = reps,
                elapsedMs = duration * 1000L,
                handDetected = false,
                summary = Summary(reps, duration, sessionTarget, targetReached),
            )
        }
    }

    private fun startTicker() {
        stopTicker()
        ticker = viewModelScope.launch {
            while (true) {
                val e = synchronized(lock) { elapsedNow() }
                _ui.update { it.copy(elapsedMs = e) }
                delay(250)
            }
        }
    }

    private fun stopTicker() {
        ticker?.cancel()
        ticker = null
    }

    // ---- camera frames -----------------------------------------------------

    /** Called from the camera analysis thread for every frame. null = nothing to analyse. */
    fun onFrame(frame: FrameResult?) {
        if (frame == null) {
            if (_overlay.value != null) _overlay.value = null
            return
        }
        synchronized(lock) {
            if (!running) return
            val event = counter.update(frame.observation)
            val now = SystemClock.uptimeMillis()

            if (event == RepCounter.Event.REP_COMPLETED) {
                lastRepAt = now
                val s = _settings.value
                feedback.repDone(s.sound, s.vibration)
            }

            _overlay.value = frame.landmarks?.let { Overlay(it, frame.imageWidth, frame.imageHeight, frame.observation.pose) }

            val reps = counter.count
            val message = messageFor(frame, counter.phase, now - lastRepAt < 900 && reps > 0)
            _ui.update {
                it.copy(
                    reps = reps,
                    message = message,
                    handDetected = frame.observation.handDetected && frame.observation.reliable,
                    pose = frame.observation.pose,
                    repFlash = if (event == RepCounter.Event.REP_COMPLETED) it.repFlash + 1 else it.repFlash,
                )
            }

            if (reps >= sessionTarget) {
                val s = _settings.value
                feedback.targetDone(s.sound, s.vibration)
                finishLocked(targetReached = true)
            }
        }
    }

    private fun messageFor(frame: FrameResult, phase: RepCounter.Phase, justCompleted: Boolean): String = when {
        !frame.observation.handDetected && !frame.lightingOk -> "Too dark. Move to a brighter place."
        !frame.observation.handDetected -> "Show your hand to the camera."
        !frame.lightingOk -> "Too dark. Move to a brighter place."
        !frame.observation.reliable -> "Keep your whole hand inside the frame."
        justCompleted -> "Repetition completed!"
        phase == RepCounter.Phase.WAIT_OPEN -> "Hand detected. Open your fingers."
        phase == RepCounter.Phase.WAIT_CLOSE -> "Close your hand."
        phase == RepCounter.Phase.WAIT_REOPEN -> "Open your fingers."
        else -> "Show your hand to the camera."
    }

    // ---- errors ------------------------------------------------------------

    fun onCameraError(message: String) {
        pauseIfRunning()
        _ui.update { it.copy(error = message) }
    }

    fun clearError() = _ui.update { it.copy(error = null) }

    // ---- settings & history ------------------------------------------------

    private fun updateSettings(block: (Settings) -> Settings) {
        val s = block(_settings.value)
        _settings.value = s
        store.saveSettings(s)
    }

    fun setSound(v: Boolean) = updateSettings { it.copy(sound = v) }
    fun setVibration(v: Boolean) = updateSettings { it.copy(vibration = v) }
    fun setTheme(v: ThemeMode) = updateSettings { it.copy(theme = v) }
    fun setFrontCamera(v: Boolean) = updateSettings { it.copy(frontCamera = v) }
    fun setWalkGoal(v: Int) = updateSettings { it.copy(walkGoalMin = v.coerceIn(10, 180)) }
    fun setSleepReminder(on: Boolean, hour: Int = _settings.value.sleepHour, minute: Int = _settings.value.sleepMinute) {
        updateSettings { it.copy(sleepReminder = on, sleepHour = hour, sleepMinute = minute) }
        Reminders.scheduleSleep(getApplication<Application>(), on, hour, minute)
    }
    fun setTarget(v: Int) {
        updateSettings { it.copy(target = v.coerceIn(1, 1000)) }
        if (_ui.value.status == Status.IDLE) _ui.update { it.copy(target = _settings.value.target) }
    }

    fun clearHistory() {
        _history.value = emptyList()
        store.saveHistory(emptyList())
        Repo.clearWorkoutsAndWalks()
    }

    override fun onCleared() {
        running = false
        stopTicker()
        feedback.release()
    }
}
