package com.fingerfit

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fingerfit.data.Repo
import com.fingerfit.data.Store
import com.fingerfit.data.WorkoutRecord
import com.fingerfit.logic.BodyPoint
import com.fingerfit.logic.ExerciseEngine
import com.fingerfit.logic.ExerciseType
import com.fingerfit.logic.RepCounter
import com.fingerfit.vision.PoseFrame
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class WorkoutSummary(
    val type: ExerciseType,
    val reps: Int,
    val left: Int,
    val right: Int,
    val seconds: Int,
    val target: Int,
    val reached: Boolean,
)

data class WorkoutUi(
    val status: Status = Status.IDLE,
    val type: ExerciseType = ExerciseType.JUMPING_JACKS,
    /** Repetitions, or seconds held for the plank. */
    val reps: Int = 0,
    val left: Int = 0,
    val right: Int = 0,
    val target: Int = 20,
    val elapsedMs: Long = 0,
    val message: String = "",
    val detected: Boolean = false,
    val repFlash: Int = 0,
    val error: String? = null,
    val summary: WorkoutSummary? = null,
)

class BodyOverlay(val points: List<BodyPoint>, val width: Int, val height: Int)

class WorkoutViewModel(app: Application) : AndroidViewModel(app) {

    private val feedback = Feedback(app)

    private val _ui = MutableStateFlow(WorkoutUi())
    val ui: StateFlow<WorkoutUi> = _ui.asStateFlow()

    private val _overlay = MutableStateFlow<BodyOverlay?>(null)
    val overlay: StateFlow<BodyOverlay?> = _overlay.asStateFlow()

    private val lock = Any()
    private var engine = ExerciseEngine(ExerciseType.JUMPING_JACKS)

    /** Camera frames are analysed while positioning (idle) and while running. */
    @Volatile private var analyzing = false
    @Volatile private var running = false
    private var runStartMs = 0L
    private var accumulatedMs = 0L
    private var sessionTarget = 20
    private var lastRepAt = 0L
    private var sound = true
    private var vibrate = true
    private var ticker: Job? = null

    init {
        Repo.init(app)
    }

    fun isActive(): Boolean = analyzing

    // ---- session control ---------------------------------------------------

    fun select(type: ExerciseType) = synchronized(lock) {
        stopTicker()
        running = false
        engine = ExerciseEngine(type)
        accumulatedMs = 0
        _overlay.value = null
        _ui.value = WorkoutUi(type = type, target = type.defaultTarget, message = type.setup)
        analyzing = true
    }

    fun bumpTarget(up: Boolean) {
        val s = _ui.value
        if (s.status != Status.IDLE) return
        val v = (s.target + if (up) s.type.step else -s.type.step).coerceIn(1, 999)
        _ui.update { it.copy(target = v) }
    }

    fun start() = synchronized(lock) {
        val type = _ui.value.type
        val st = Store(getApplication<Application>()).loadSettings()
        sound = st.sound
        vibrate = st.vibration
        engine = ExerciseEngine(type)
        accumulatedMs = 0
        sessionTarget = _ui.value.target
        runStartMs = SystemClock.uptimeMillis()
        running = true
        analyzing = true
        _ui.update {
            it.copy(
                status = Status.RUNNING, reps = 0, left = 0, right = 0, elapsedMs = 0,
                message = type.startCue, summary = null, error = null,
            )
        }
        startTicker()
    }

    fun pause() = synchronized(lock) {
        if (!running) return@synchronized
        accumulatedMs += SystemClock.uptimeMillis() - runStartMs
        running = false
        analyzing = false
        stopTicker()
        _overlay.value = null
        _ui.update { it.copy(status = Status.PAUSED, message = "Paused", detected = false, elapsedMs = accumulatedMs) }
    }

    fun resume() = synchronized(lock) {
        if (_ui.value.status != Status.PAUSED) return@synchronized
        engine.restartCycle()
        runStartMs = SystemClock.uptimeMillis()
        running = true
        analyzing = true
        _ui.update { it.copy(status = Status.RUNNING, message = it.type.startCue, error = null) }
        startTicker()
    }

    fun resetSession() = synchronized(lock) {
        val type = _ui.value.type
        stopTicker()
        running = false
        engine = ExerciseEngine(type)
        accumulatedMs = 0
        _overlay.value = null
        _ui.value = WorkoutUi(type = type, target = _ui.value.target, message = type.setup)
        analyzing = true
    }

    fun end() = synchronized(lock) { finishLocked(false) }

    /** Leaving the workout screen. */
    fun leave() = synchronized(lock) {
        stopTicker()
        running = false
        analyzing = false
        _overlay.value = null
        _ui.update { it.copy(status = Status.IDLE, summary = null, reps = 0, left = 0, right = 0, elapsedMs = 0) }
    }

    fun pauseIfRunning() {
        if (running) pause()
    }

    private fun elapsedNow(): Long =
        accumulatedMs + if (running) SystemClock.uptimeMillis() - runStartMs else 0L

    private fun finishLocked(reached: Boolean) {
        val type = _ui.value.type
        val seconds = (elapsedNow() / 1000).toInt()
        val reps = engine.reps
        running = false
        analyzing = false
        stopTicker()
        _overlay.value = null
        if (reps > 0) {
            Repo.addWorkout(
                WorkoutRecord(
                    System.currentTimeMillis(), type.name, reps, engine.leftReps, engine.rightReps,
                    seconds, sessionTarget, reached,
                ),
            )
            if (reached) {
                Repo.addInbox("Target completed", "${type.title}: $reps ${type.unit} done. Great work!")
            }
        }
        _ui.update {
            it.copy(
                status = Status.FINISHED, reps = reps, left = engine.leftReps, right = engine.rightReps,
                elapsedMs = seconds * 1000L, detected = false,
                summary = WorkoutSummary(type, reps, engine.leftReps, engine.rightReps, seconds, sessionTarget, reached),
            )
        }
    }

    private fun startTicker() {
        stopTicker()
        ticker = viewModelScope.launch {
            while (true) {
                val e = synchronized(lock) { elapsedNow() }
                _ui.update { it.copy(elapsedMs = e) }
                delay(250)
            }
        }
    }

    private fun stopTicker() {
        ticker?.cancel()
        ticker = null
    }

    // ---- camera frames -----------------------------------------------------

    fun onFrame(f: PoseFrame?) {
        if (f == null) {
            if (_overlay.value != null) _overlay.value = null
            return
        }
        synchronized(lock) {
            if (!analyzing) return
            val pts = f.points
            _overlay.value = pts?.let { BodyOverlay(it, f.width, f.height) }
            val type = _ui.value.type

            if (!running) { // positioning preview before Start
                _ui.update {
                    it.copy(
                        detected = pts != null,
                        message = when {
                            !f.lightingOk -> "Too dark. Move to a brighter place."
                            pts != null -> "Body detected. Press Start when ready."
                            else -> type.setup
                        },
                    )
                }
                return
            }

            val o = engine.update(pts, f.width.toFloat(), f.height.toFloat(), f.timeMs, f.mirrored)
            val now = SystemClock.uptimeMillis()
            if (o.repDone) {
                lastRepAt = now
                feedback.repDone(sound, vibrate)
            }
            val reps = engine.reps
            val msg = when {
                !f.lightingOk -> "Too dark. Move to a brighter place."
                !o.detected -> "Step back so your whole body is in view."
                !o.reliable -> o.hint ?: "Keep your whole body in view."
                type.isHold -> if (engine.isHolding) "Holding. Keep going!" else (o.hint ?: type.startCue)
                now - lastRepAt < 900 && reps > 0 -> "Repetition completed!"
                o.phase == RepCounter.Phase.WAIT_CLOSE -> type.peakCue
                o.phase == RepCounter.Phase.WAIT_REOPEN -> type.backCue
                else -> type.startCue
            }
            _ui.update {
                it.copy(
                    reps = reps, left = engine.leftReps, right = engine.rightReps, message = msg,
                    detected = o.detected && o.reliable,
                    repFlash = if (o.repDone) it.repFlash + 1 else it.repFlash,
                )
            }
            if (reps >= sessionTarget) {
                feedback.targetDone(sound, vibrate)
                finishLocked(true)
            }
        }
    }

    fun onCameraError(message: String) {
        pauseIfRunning()
        _ui.update { it.copy(error = message) }
    }

    fun clearError() = _ui.update { it.copy(error = null) }

    override fun onCleared() {
        running = false
        analyzing = false
        stopTicker()
        feedback.release()
    }
}
