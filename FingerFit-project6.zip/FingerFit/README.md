# FingerFit – AI Hand Exercise Counter

Native Android app (Kotlin, Jetpack Compose, CameraX, MediaPipe Hand Landmarker).
Counts open → close → open hand repetitions using the phone camera, fully offline.

## Get the APK (pick one)

**A. Android Studio (easiest)**
1. Install Android Studio, choose *Open* and select this folder. Let Gradle sync (internet needed once).
2. Plug in your phone (USB debugging on) and press *Run*, or build the file with
   *Build ▸ Build APK(s)*. Result: `app/build/outputs/apk/debug/app-debug.apk`.

**B. Command line** (JDK 17 + Android SDK installed)
```
./gradlew :app:assembleRelease
```
Result: `app/build/outputs/apk/release/app-release.apk` – rename it to `FingerFit.apk`.
The release build is signed with the standard debug key, so it installs directly on a phone
(fine for personal use; not for Google Play).

**C. No Android Studio at all: build in the cloud**
Create a free GitHub repository, upload this whole folder (keep `.github/workflows`), open the
*Actions* tab ▸ *Build FingerFit APK* ▸ *Run workflow*. When it finishes, download `FingerFit.apk`
from the run's *Artifacts*.

Then copy the APK to your phone, open it, and allow "install unknown apps" for your file manager/browser.

## The hand model
`hand_landmarker.task` is downloaded **once, at build time** into `app/src/main/assets/` and packaged
inside the APK, so the installed app never downloads anything. If your build machine is offline, download
it yourself and place it at that path:
https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task

## How counting works
- `logic/Gesture.kt` – for each of the 4 fingers: distance(wrist, fingertip) / distance(wrist, finger base).
  ≈1.8–2.0 straight, ≈0.8–1.1 curled; independent of hand size/rotation. OPEN / CLOSED / UNKNOWN with hysteresis.
  The thumb is intentionally ignored (it folds in too many ways). Hands cut off by the frame edge,
  tiny/far hands, low confidence, or dark rooms are "unreliable" and never counted.
- `logic/RepCounter.kt` – state machine NO_HAND → WAIT_OPEN → WAIT_CLOSE → WAIT_REOPEN.
  A pose must be stable for ≥4 frames and ≥120 ms; one rep is counted only on the final
  OPEN confirmation; holding a pose never counts; losing the hand for >0.6 s discards the cycle;
  two counts are at least 450 ms apart.

## Tips for best accuracy
Hold the hand upright, palm toward the camera, whole hand in view, in decent light.
Fingers pointing straight at the lens (foreshortened) are hard for any 2-D tracker.

## Privacy
Camera frames are analysed in memory and discarded. No recording, no network use, no account.
History and settings live in the app's private storage on the phone.

## Tests
`./gradlew :app:testDebugUnitTest` runs `app/src/test/.../LogicTest.kt` (17 tests).
