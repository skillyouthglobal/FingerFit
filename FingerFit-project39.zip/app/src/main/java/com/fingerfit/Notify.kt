package com.fingerfit

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.workDataOf
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.WorkManager
import com.fingerfit.data.AppPrefs
import com.fingerfit.data.ProfileRepo
import com.fingerfit.data.Repo
import com.fingerfit.data.Store
import com.fingerfit.data.WeightRepo
import com.fingerfit.logic.NudgeFacts
import com.fingerfit.logic.NudgeKind
import com.fingerfit.logic.Nudges
import com.fingerfit.logic.Progress
import com.fingerfit.logic.WeightLog
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

object Notify {
    const val CH_REMINDER = "reminders"
    const val CH_WALK = "walk"
    const val CH_NUDGE = "nudges"

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CH_REMINDER, com.fingerfit.logic.Bn.t("Reminders"), NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(
            NotificationChannel(CH_NUDGE, com.fingerfit.logic.Bn.t("Personal reminders"), NotificationManager.IMPORTANCE_HIGH).apply {
                description = com.fingerfit.logic.Bn.t("Daily messages for you by name: exercise, progress, weight and sleep.")
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC // shown on the lock screen with the full text
                enableVibration(true)
                enableLights(true)
            },
        )
        nm.createNotificationChannel(NotificationChannel(CH_WALK, com.fingerfit.logic.Bn.t("Walk tracking"), NotificationManager.IMPORTANCE_LOW))
    }

    fun canPost(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun openAppIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    fun post(ctx: Context, id: Int, title: String, body: String, channel: String = CH_REMINDER) {
        if (!canPost(ctx)) return
        ensureChannels(ctx)
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(com.fingerfit.logic.Bn.t(title))
            .setContentText(com.fingerfit.logic.Bn.t(body))
            .setStyle(NotificationCompat.BigTextStyle().bigText(com.fingerfit.logic.Bn.t(body)))
            .setContentIntent(openAppIntent(ctx))
            .setAutoCancel(true)
            .build()
        runCatching { ctx.getSystemService(NotificationManager::class.java)?.notify(id, n) }
    }
}

/** A personal message: already written in the right language with the person's name; shown on the lock screen and kept in the phone's notification list. */
fun Notify.postNudge(ctx: Context, id: Int, title: String, body: String) {
    if (!canPost(ctx)) return
    ensureChannels(ctx)
    val n = NotificationCompat.Builder(ctx, Notify.CH_NUDGE)
        .setSmallIcon(R.drawable.ic_stat)
        .setContentTitle(title)
        .setContentText(body)
        .setStyle(NotificationCompat.BigTextStyle().bigText(body))
        .setContentIntent(openAppIntent(ctx))
        .setAutoCancel(true)
        .setCategory(NotificationCompat.CATEGORY_REMINDER)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setDefaults(NotificationCompat.DEFAULT_ALL)
        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        .setShowWhen(true)
        .setWhen(System.currentTimeMillis())
        .build()
    runCatching { ctx.getSystemService(NotificationManager::class.java)?.notify(id, n) }
}

/** Collects what is known about the person today and sends the matching personal message. */
object NudgeSender {
    private fun idOf(kind: NudgeKind) = when (kind) {
        NudgeKind.MORNING -> 201
        NudgeKind.EVENING -> 202
        NudgeKind.WEIGHT -> 203
        NudgeKind.SLEEP -> 101
    }

    fun facts(c: Context): NudgeFacts {
        AppPrefs.apply(c)
        Repo.init(c)
        ProfileRepo.init(c)
        WeightRepo.init(c)
        val store = Store(c)
        val today = LocalDate.now()
        val acts = com.fingerfit.ui.allActs(Repo.workouts.value, Repo.walks.value, store.loadHistory())
        val minutes = Progress.perDay(acts, today, 1).last().minutes
        return NudgeFacts(
            name = ProfileRepo.profile.value?.name.orEmpty(),
            bn = com.fingerfit.logic.Bn.bn,
            streak = Progress.streak(acts, today),
            minutesToday = minutes,
            goalMinutes = store.loadSettings().walkGoalMin,
            daysSinceWeight = WeightLog.daysSinceLast(WeightRepo.list.value, today),
            today = today,
        )
    }

    /** [force] = a test from Settings: send even if the rules would stay silent. Returns true when something was sent. */
    fun send(c: Context, kind: NudgeKind, force: Boolean = false): Boolean {
        val f = facts(c)
        var text = Nudges.build(kind, f)
        if (text == null && force) text = Nudges.build(kind, NudgeFacts(f.name, f.bn, f.streak, f.minutesToday, f.goalMinutes, null, f.today))
        if (text == null) return false
        if (kind == NudgeKind.WEIGHT && !force) {
            val day = LocalDate.now().toEpochDay()
            if (day - AppPrefs.lastWeightNudge(c) < 3) return false // not every day
            AppPrefs.setLastWeightNudge(c, day)
        }
        Repo.addInbox(text.title, text.body)
        Notify.postNudge(c, idOf(kind), text.title, text.body)
        return true
    }
}

/** Sends one personal message at the chosen time, then plans the next day's. */
class NudgeWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val c = applicationContext
        val kind = runCatching { NudgeKind.valueOf(inputData.getString("kind") ?: "") }.getOrNull() ?: return Result.success()
        try {
            if (AppPrefs.nudgeOn(c, kind.name)) NudgeSender.send(c, kind)
        } catch (e: Exception) {
            // a failed message must never stop tomorrow's
        } finally {
            Reminders.scheduleNudge(c, kind, fromWorker = true)
        }
        return Result.success()
    }
}

/** Fires once a day: asks the user to log last night's sleep if they have not yet. */
class SleepReminderWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val c = applicationContext
        Repo.init(c)
        val today = LocalDate.now().toString()
        if (Repo.sleeps.value.none { it.date == today }) {
            NudgeSender.send(c, NudgeKind.SLEEP, force = true)
        }
        return Result.success()
    }
}

object Reminders {
    private const val WORK_NAME = "sleep_reminder"

    /** Plans the next personal message of this kind at the chosen time (or cancels it when switched off). */
    fun scheduleNudge(ctx: Context, kind: NudgeKind, fromWorker: Boolean = false) {
        val wm = WorkManager.getInstance(ctx.applicationContext)
        val name = "nudge_${kind.name}"
        if (!AppPrefs.nudgeOn(ctx, kind.name)) {
            wm.cancelUniqueWork(name)
            return
        }
        val delay = Nudges.delayMillis(LocalDateTime.now(), AppPrefs.nudgeMinute(ctx, kind.name))
        val req = OneTimeWorkRequestBuilder<NudgeWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("kind" to kind.name))
            .build()
        // from inside the running message, queue behind it; otherwise replace what was planned before
        wm.enqueueUniqueWork(name, if (fromWorker) ExistingWorkPolicy.APPEND_OR_REPLACE else ExistingWorkPolicy.REPLACE, req)
    }

    fun scheduleAll(ctx: Context) {
        listOf(NudgeKind.MORNING, NudgeKind.EVENING, NudgeKind.WEIGHT).forEach { scheduleNudge(ctx, it) }
    }

    fun scheduleSleep(ctx: Context, enabled: Boolean, hour: Int, minute: Int) {
        val wm = WorkManager.getInstance(ctx.applicationContext)
        if (!enabled) {
            wm.cancelUniqueWork(WORK_NAME)
            return
        }
        val now = LocalDateTime.now()
        var next = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        val delay = Duration.between(now, next).toMillis()
        val req = PeriodicWorkRequestBuilder<SleepReminderWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()
        wm.enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}
