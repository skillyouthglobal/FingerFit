package com.fingerfit.logic

import kotlin.math.abs

/** What an exercise is mainly for. */
enum class LibCat(val code: Char, val en: String, val bn: String, val words: String) {
    HEART('H', "Heart & cardio", "হার্ট ও কার্ডিও", "heart cardio stamina endurance হার্ট হৃদয় হৃদযন্ত্র কার্ডিও"),
    CHEST('C', "Chest", "বুক", "chest বুক"),
    ARMS('S', "Shoulders & arms", "কাঁধ ও হাত", "shoulder shoulders arm arms কাঁধ হাত বাহু"),
    BACK('B', "Back", "পিঠ", "back spine posture পিঠ মেরুদণ্ড"),
    CORE('K', "Core & belly", "পেট ও কোর", "core abs abdomen belly stomach পেট কোর"),
    LEGS('L', "Legs & hips", "পা ও নিতম্ব", "leg legs thigh hip hips পা উরু নিতম্ব"),
    FLEX('F', "Stretch & mobility", "নমনীয়তা ও স্ট্রেচ", "stretch stretching flexibility mobility yoga নমনীয়তা স্ট্রেচ ইয়োগা"),
    FULL('U', "Full body", "পুরো শরীর", "full whole body পুরো সম্পূর্ণ শরীর"),
}

/** The body part an exercise works. */
enum class LibPart(val code: Char, val en: String, val bn: String, val words: String) {
    CHEST('C', "Chest", "বুক", "chest বুক"),
    SHOULDERS('S', "Shoulders", "কাঁধ", "shoulder shoulders কাঁধ"),
    ARMS('A', "Arms", "হাত", "arm arms biceps triceps হাত বাহু বাইসেপস ট্রাইসেপস"),
    BACK('B', "Back", "পিঠ ও কোমর", "back lower spine posture waist পিঠ কোমর মেরুদণ্ড"),
    CORE('K', "Belly & core", "পেট ও কোর", "core abs abdomen belly stomach waist পেট পেটের কোর কোমর"),
    GLUTES('G', "Hips & glutes", "নিতম্ব ও হিপ", "hip hips glutes butt waist নিতম্ব হিপ কোমর"),
    THIGHS('T', "Thighs & legs", "উরু ও পা", "thigh thighs leg legs hamstring quad উরু পা পায়ের"),
    CALVES('V', "Calves & ankles", "গোড়ালি ও কাফ", "calf calves ankle ankles foot feet গোড়ালি কাফ পায়ের পাতা পা"),
    HANDS('H', "Hands & fingers", "হাত ও আঙুল", "hand hands finger fingers হাত আঙুল আঙ্গুল"),
}

enum class LibEquip(val code: Char, val en: String, val bn: String, val words: String) {
    NONE('N', "No equipment", "কোনো সরঞ্জাম লাগে না", "no equipment bodyweight সরঞ্জাম"),
    WEIGHT('W', "Water bottle or light weight", "পানির বোতল বা হালকা ওজন", "bottle dumbbell weight water বোতল ডাম্বেল ওজন"),
    SUPPORT('S', "Table, bench, wall or chair", "টেবিল, বেঞ্চ, দেয়াল বা চেয়ার", "table bench wall chair টেবিল বেঞ্চ দেয়াল চেয়ার"),
    ROPE('R', "Jump rope", "লাফানোর দড়ি", "rope jump দড়ি"),
}

/** One exercise in the library. Exercises the camera counts link to [type]; the others are guided (timer / tap counter). */
class LibItem(
    val id: String,
    val emoji: String,
    val cat: LibCat,
    val parts: List<LibPart>,
    val level: Int,
    val equip: LibEquip,
    val floor: Boolean,
    val timed: Boolean,
    val target: Int,
    val en: String,
    private val bnName: String?,
    private val enBody: String,
    private val bnBody: String?,
    private val enBenefits: List<String>,
    private val bnBenefits: List<String>,
    private val enHow: String,
    private val bnHow: String?,
    val type: ExerciseType? = null,
    val finger: Boolean = false,
) {
    val camera: Boolean get() = type != null || finger
    fun name(bn: Boolean): String = if (bn) (bnName ?: Bn.toBn(en)) else en
    fun body(bn: Boolean): String = if (bn) (bnBody ?: partsText(true)) else enBody.ifEmpty { partsText(false) }
    fun benefits(bn: Boolean): List<String> = if (bn) (if (bnBenefits.isNotEmpty()) bnBenefits else enBenefits.map { Bn.toBn(it) }) else enBenefits
    fun how(bn: Boolean): String = if (bn) (bnHow ?: Bn.toBn(enHow)) else enHow
    fun partsText(bn: Boolean): String = parts.joinToString(if (bn) ", " else ", ") { if (bn) it.bn else it.en }
    val unitEn: String get() = if (timed) "sec" else "reps"

    /** The same exercise, now counted by the camera as [t]. */
    fun withType(t: ExerciseType) = LibItem(
        id, emoji, cat, parts, level, equip, floor, t.isHold, t.defaultTarget, en, bnName, enBody, bnBody,
        enBenefits, bnBenefits, enHow, bnHow, type = t, finger = finger,
    )

    companion object {
        fun guided(
            id: String, emoji: String, cat: Char, parts: String, level: Int, equip: Char, floor: Boolean, timed: Boolean, target: Int,
            en: String, bn: String, enBody: String, bnBody: String, enBenefits: List<String>, bnBenefits: List<String>, enHow: String, bnHow: String,
        ) = LibItem(
            id, emoji, LibCat.values().first { it.code == cat }, parts.map { c -> LibPart.values().first { it.code == c } }, level,
            LibEquip.values().first { it.code == equip }, floor, timed, target, en, bn, enBody, bnBody, enBenefits, bnBenefits, enHow, bnHow,
        )
    }
}

object Library {
    private fun fromType(t: ExerciseType): LibItem {
        val cat: LibCat
        val parts: List<LibPart>
        var equip = LibEquip.NONE
        var floor = false
        var level = 1
        when (t) {
            ExerciseType.JUMPING_JACKS -> { cat = LibCat.HEART; parts = listOf(LibPart.THIGHS, LibPart.SHOULDERS, LibPart.CALVES) }
            ExerciseType.HIGH_KNEES -> { cat = LibCat.HEART; parts = listOf(LibPart.THIGHS, LibPart.CORE) }
            ExerciseType.SQUATS -> { cat = LibCat.LEGS; parts = listOf(LibPart.THIGHS, LibPart.GLUTES) }
            ExerciseType.PUSH_UPS -> { cat = LibCat.CHEST; parts = listOf(LibPart.CHEST, LibPart.SHOULDERS, LibPart.ARMS); floor = true; level = 2 }
            ExerciseType.LUNGES -> { cat = LibCat.LEGS; parts = listOf(LibPart.THIGHS, LibPart.GLUTES); level = 2 }
            ExerciseType.CRUNCHES -> { cat = LibCat.CORE; parts = listOf(LibPart.CORE); floor = true }
            ExerciseType.GLUTE_BRIDGES -> { cat = LibCat.CORE; parts = listOf(LibPart.GLUTES, LibPart.BACK, LibPart.CORE); floor = true }
            ExerciseType.PLANK -> { cat = LibCat.CORE; parts = listOf(LibPart.CORE, LibPart.SHOULDERS, LibPart.BACK); floor = true; level = 2 }
            ExerciseType.SIT_TO_STAND -> { cat = LibCat.LEGS; parts = listOf(LibPart.THIGHS, LibPart.GLUTES); equip = LibEquip.SUPPORT }
            ExerciseType.CALF_RAISES -> { cat = LibCat.LEGS; parts = listOf(LibPart.CALVES) }
            ExerciseType.SIDE_LEG_RAISES -> { cat = LibCat.LEGS; parts = listOf(LibPart.GLUTES, LibPart.THIGHS) }
            else -> { cat = LibCat.FULL; parts = listOf(LibPart.CORE) } // exercises promoted from the library carry their own entry
        }
        return LibItem(
            "t_" + t.name, t.emoji, cat, parts, level, equip, floor, t.isHold, t.defaultTarget, t.title, null, "", null,
            listOf(t.benefit), emptyList(), t.setup, null, type = t,
        )
    }

    private val finger = LibItem(
        "finger", "✋", LibCat.ARMS, listOf(LibPart.HANDS), 1, LibEquip.NONE, false, false, 10, "Finger exercise", null,
        "Hands and fingers.", null, listOf("Keeps the fingers and hands flexible and strong."), emptyList(),
        "Show your hand to the camera and open and close your fingers.", null, finger = true,
    )

    /** Library entries whose camera counting is ready: they open the camera workout. */
    val promoted: Map<String, ExerciseType> = mapOf(
        "incline_pushup" to ExerciseType.INCLINE_PUSHUPS,
        "decline_pushup" to ExerciseType.DECLINE_PUSHUPS,
        "biceps_curl" to ExerciseType.BICEPS_CURL,
        "triceps_ext" to ExerciseType.TRICEPS_EXTENSION,
        "front_raise" to ExerciseType.FRONT_RAISE,
        "lateral_raise" to ExerciseType.LATERAL_RAISE,
        "butt_kicks" to ExerciseType.BUTT_KICKS,
        "good_morning" to ExerciseType.GOOD_MORNING,
        "leg_raise" to ExerciseType.LEG_RAISE,
        "pike_pushup" to ExerciseType.PIKE_PUSHUPS,
        "bulgarian_squat" to ExerciseType.BULGARIAN_SPLIT_SQUAT,
        "squat_pulses" to ExerciseType.SQUAT_PULSES,
        "burpee" to ExerciseType.BURPEE,
        "squat_thrust" to ExerciseType.SQUAT_THRUST,
        "v_ups" to ExerciseType.V_UPS,
        "tibialis_raise" to ExerciseType.TIBIALIS_RAISE,
        "downward_dog" to ExerciseType.DOWNWARD_DOG,
        "hollow_hold" to ExerciseType.HOLLOW_BODY_HOLD,
        "childs_pose" to ExerciseType.CHILD_POSE,
        "cobra_stretch" to ExerciseType.COBRA_STRETCH,
        "jump_rope" to ExerciseType.JUMP_ROPE,
        "skater_hops" to ExerciseType.SKATER_HOPS,
        "side_shuffle" to ExerciseType.SIDE_SHUFFLE,
        "russian_twist" to ExerciseType.RUSSIAN_TWIST,
        "flutter_kicks" to ExerciseType.FLUTTER_KICKS,
        "scissor_kicks" to ExerciseType.SCISSOR_KICKS,
        "sl_rdl" to ExerciseType.SL_RDL,
        "walking_toe_touch" to ExerciseType.WALKING_TOE_TOUCH,
        "inchworm" to ExerciseType.INCHWORM,
    )

    /** Camera-counted exercises first, then the guided ones. */
    val all: List<LibItem> by lazy {
        val own = ExerciseType.values().filter { it !in promoted.values }.map { fromType(it) }
        val ready = LibData.extra.filter { promoted.containsKey(it.id) }.map { it.withType(promoted.getValue(it.id)) }
        val rest = LibData.extra.filter { !promoted.containsKey(it.id) }
        own + finger + ready + rest
    }

    fun byId(id: String): LibItem? = all.firstOrNull { it.id == id }

    /** Applies the chip filters (null / false = no filter). */
    fun filter(items: List<LibItem>, cat: LibCat?, part: LibPart?, noEquip: Boolean, cameraOnly: Boolean): List<LibItem> =
        items.filter {
            (cat == null || it.cat == cat) &&
                (part == null || part in it.parts) &&
                (!noEquip || it.equip == LibEquip.NONE) &&
                (!cameraOnly || it.camera)
        }
}

/** Forgiving search: Bengali or English, any spelling of "push-up", small typos, body-part words like "কোমর" or "belly". */
object LibSearch {
    private fun isWordChar(c: Char): Boolean {
        if (c.isLetterOrDigit()) return true
        val t = Character.getType(c)
        return t == Character.NON_SPACING_MARK.toInt() || t == Character.COMBINING_SPACING_MARK.toInt()
    }

    /** Lower-case words; hyphens and other symbols split words. */
    fun words(s: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (c in s.lowercase()) {
            if (isWordChar(c)) sb.append(c) else { if (sb.isNotEmpty()) { out.add(sb.toString()); sb.setLength(0) } }
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    private fun joined(s: String): String = s.lowercase().filter { isWordChar(it) }

    private class Entry(val name: List<String>, val tags: List<String>, val rest: List<String>)

    private val cache = HashMap<String, Entry>()

    private fun entry(it: LibItem): Entry = synchronized(cache) {
        cache.getOrPut(it.id) {
            val name = ArrayList<String>()
            name.addAll(words(it.en)); name.addAll(words(it.name(true)))
            name.add(joined(it.en)); name.add(joined(it.name(true)))
            val tags = ArrayList<String>()
            tags.addAll(words(it.cat.words)); tags.addAll(words(it.cat.en)); tags.addAll(words(it.cat.bn))
            for (p in it.parts) { tags.addAll(words(p.words)); tags.addAll(words(p.en)); tags.addAll(words(p.bn)) }
            tags.addAll(words(it.equip.words))
            val rest = ArrayList<String>()
            for (b in it.benefits(false)) rest.addAll(words(b))
            for (b in it.benefits(true)) rest.addAll(words(b))
            rest.addAll(words(it.body(false))); rest.addAll(words(it.body(true)))
            Entry(name, tags, rest)
        }
    }

    fun distance(a: String, b: String): Int {
        if (a == b) return 0
        if (abs(a.length - b.length) > 3) return 99
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            prev = cur
        }
        return prev[b.length]
    }

    private fun hit(t: String, w: String): Boolean {
        if (w.startsWith(t)) return true
        if (t.length >= 3 && w.contains(t)) return true
        if (w.length >= 4 && t.startsWith(w)) return true // "pushups" finds "pushup"
        if (t.length >= 4) {
            val limit = if (t.length >= 8) 2 else 1
            if (distance(t, w) <= limit) return true
            if (w.length > t.length && distance(t, w.substring(0, t.length)) <= limit) return true
        }
        return false
    }

    private fun best(t: String, e: Entry): Int {
        if (e.name.any { hit(t, it) }) return 6
        if (e.tags.any { hit(t, it) }) return 3
        if (e.rest.any { hit(t, it) }) return 1
        return 0
    }

    /** Items that match every word typed, best matches first. An empty query keeps everything in order. */
    fun search(items: List<LibItem>, query: String): List<LibItem> {
        val toks = words(query)
        if (toks.isEmpty()) return items
        val scored = ArrayList<Pair<Int, Int>>()
        for ((i, it) in items.withIndex()) {
            val e = entry(it)
            var total = 0
            var ok = true
            for (t in toks) {
                val s = best(t, e)
                if (s == 0) { ok = false; break }
                total += s
            }
            if (ok) scored.add(Pair(total, i))
        }
        return scored.sortedWith(compareBy({ -it.first }, { it.second })).map { items[it.second] }
    }
}
