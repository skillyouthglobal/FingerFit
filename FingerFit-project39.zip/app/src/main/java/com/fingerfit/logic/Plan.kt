package com.fingerfit.logic

import kotlin.math.roundToInt

enum class PlanGroup(val title: String, val chip: String) {
    HEART("For your heart", "Heart"),
    MUSCLE("For your muscles", "Muscle"),
    CORE("For your core", "Core"),
}

/** One line of the daily exercise plan. [type] is null for activities outside the camera list (a brisk walk). */
class PlanItem(val type: ExerciseType?, val label: String, val amount: String, val group: PlanGroup)

/** A daily food-energy suggestion. */
class CalorieAdvice(val kcal: Int, val low: Int, val high: Int)

/**
 * Simple offline planning rules. These are general suggestions only, not medical advice.
 * Physical activity follows the WHO adult guidance: 150 to 300 minutes of moderate activity a week
 * plus muscle-strengthening on at least 2 days.
 */
object Plans {

    fun groupOf(type: ExerciseType): PlanGroup = when (type) {
        ExerciseType.JUMPING_JACKS, ExerciseType.HIGH_KNEES, ExerciseType.BUTT_KICKS,
        ExerciseType.BURPEE, ExerciseType.SQUAT_THRUST,
        ExerciseType.JUMP_ROPE, ExerciseType.SKATER_HOPS, ExerciseType.SIDE_SHUFFLE -> PlanGroup.HEART
        ExerciseType.SQUATS, ExerciseType.LUNGES, ExerciseType.PUSH_UPS,
        ExerciseType.SIT_TO_STAND, ExerciseType.CALF_RAISES, ExerciseType.SIDE_LEG_RAISES,
        ExerciseType.INCLINE_PUSHUPS, ExerciseType.DECLINE_PUSHUPS, ExerciseType.BICEPS_CURL, ExerciseType.TRICEPS_EXTENSION,
        ExerciseType.FRONT_RAISE, ExerciseType.LATERAL_RAISE, ExerciseType.GOOD_MORNING,
        ExerciseType.PIKE_PUSHUPS, ExerciseType.BULGARIAN_SPLIT_SQUAT, ExerciseType.SQUAT_PULSES, ExerciseType.TIBIALIS_RAISE, ExerciseType.DOWNWARD_DOG,
        ExerciseType.SL_RDL, ExerciseType.WALKING_TOE_TOUCH, ExerciseType.INCHWORM -> PlanGroup.MUSCLE
        ExerciseType.CRUNCHES, ExerciseType.GLUTE_BRIDGES, ExerciseType.PLANK, ExerciseType.LEG_RAISE,
        ExerciseType.V_UPS, ExerciseType.HOLLOW_BODY_HOLD, ExerciseType.CHILD_POSE, ExerciseType.COBRA_STRETCH,
        ExerciseType.RUSSIAN_TWIST, ExerciseType.FLUTTER_KICKS, ExerciseType.SCISSOR_KICKS -> PlanGroup.CORE
    }

    /** Mifflin-St Jeor resting energy use (kcal per day). */
    fun bmr(gender: Gender, weightKg: Float, heightCm: Float, age: Int): Double {
        val base = 10.0 * weightKg + 6.25 * heightCm - 5.0 * age
        return base + when (gender) {
            Gender.MALE -> 5.0
            Gender.FEMALE -> -161.0
            Gender.OTHER -> -78.0
        }
    }

    /** Null for people under 18: they should ask a doctor or parent instead of using a calorie number. */
    fun calories(gender: Gender, weightKg: Float, heightCm: Float, age: Int, goal: Goal): CalorieAdvice? {
        if (age < 18) return null
        val maintain = bmr(gender, weightKg, heightCm, age) * 1.375 // light activity
        val raw = when (goal) {
            Goal.LOSE -> maintain - 400.0
            Goal.MAINTAIN -> maintain
            Goal.GAIN -> maintain + 300.0
        }
        val floor = when (gender) {
            Gender.MALE -> 1500
            Gender.FEMALE -> 1200
            Gender.OTHER -> 1350
        }
        val kcal = ((raw / 50.0).roundToInt() * 50).coerceAtLeast(floor)
        return CalorieAdvice(kcal, (kcal - 100).coerceAtLeast(floor), kcal + 100)
    }

    fun isLowImpact(age: Int, bmi: Float): Boolean = age >= 60 || bmi >= 27.5f

    private fun amount(type: ExerciseType, lowImpact: Boolean): String {
        val scaled = if (lowImpact) type.defaultTarget * 0.7f else type.defaultTarget.toFloat()
        val n = ((scaled / type.step).roundToInt() * type.step).coerceAtLeast(type.step)
        return "$n ${type.unit}"
    }

    private fun item(type: ExerciseType, lowImpact: Boolean) =
        PlanItem(type, type.title, amount(type, lowImpact), groupOf(type))

    private fun <T> rotate(pool: List<T>, day: Int, n: Int): List<T> =
        List(minOf(n, pool.size)) { pool[(day + it).mod(pool.size)] }

    /** A balanced daily plan: heart, muscles and core, with the extras changing from day to day. */
    fun exercisePlan(age: Int, bmi: Float, goal: Goal, day: Int = 0): List<PlanItem> {
        val low = isLowImpact(age, bmi)
        val types = mutableListOf<ExerciseType>()
        val out = mutableListOf<PlanItem>()
        if (low) {
            out += PlanItem(null, "Brisk walk", "30 min", PlanGroup.HEART)
            types += rotate(listOf(ExerciseType.BUTT_KICKS, ExerciseType.SIDE_LEG_RAISES), day, 1)
            types += ExerciseType.SQUATS
            types += ExerciseType.SIT_TO_STAND
            types += ExerciseType.PUSH_UPS
            if (goal == Goal.GAIN) types += ExerciseType.LUNGES
            types += rotate(listOf(ExerciseType.CALF_RAISES, ExerciseType.INCLINE_PUSHUPS, ExerciseType.BICEPS_CURL,
                ExerciseType.LATERAL_RAISE, ExerciseType.TRICEPS_EXTENSION, ExerciseType.FRONT_RAISE), day, 2)
            types += ExerciseType.PLANK
            types += rotate(listOf(ExerciseType.GLUTE_BRIDGES, ExerciseType.CRUNCHES, ExerciseType.LEG_RAISE,
                ExerciseType.COBRA_STRETCH), day, 2)
            types += ExerciseType.CHILD_POSE
        } else {
            types += ExerciseType.JUMPING_JACKS
            if (goal != Goal.GAIN) types += ExerciseType.HIGH_KNEES
            val heartPool = listOf(ExerciseType.BUTT_KICKS, ExerciseType.SKATER_HOPS, ExerciseType.SIDE_SHUFFLE,
                ExerciseType.JUMP_ROPE, ExerciseType.SQUAT_THRUST, ExerciseType.BURPEE)
            types += rotate(heartPool, day, if (goal == Goal.LOSE) 3 else 1)
            types += ExerciseType.SQUATS
            types += ExerciseType.PUSH_UPS
            if (goal == Goal.GAIN) types += ExerciseType.LUNGES
            types += rotate(listOf(ExerciseType.LUNGES, ExerciseType.INCLINE_PUSHUPS, ExerciseType.PIKE_PUSHUPS,
                ExerciseType.BULGARIAN_SPLIT_SQUAT, ExerciseType.BICEPS_CURL, ExerciseType.TRICEPS_EXTENSION,
                ExerciseType.LATERAL_RAISE, ExerciseType.SL_RDL, ExerciseType.GOOD_MORNING, ExerciseType.SQUAT_PULSES,
                ExerciseType.DECLINE_PUSHUPS, ExerciseType.CALF_RAISES).filter { it !in types }, day, if (goal == Goal.GAIN) 4 else 3)
            types += ExerciseType.PLANK
            types += rotate(listOf(ExerciseType.CRUNCHES, ExerciseType.V_UPS, ExerciseType.RUSSIAN_TWIST,
                ExerciseType.FLUTTER_KICKS, ExerciseType.SCISSOR_KICKS, ExerciseType.HOLLOW_BODY_HOLD,
                ExerciseType.GLUTE_BRIDGES, ExerciseType.LEG_RAISE), day, 3)
            types += rotate(listOf(ExerciseType.DOWNWARD_DOG, ExerciseType.CHILD_POSE, ExerciseType.COBRA_STRETCH), day, 1)
        }
        types.distinct().forEach { out += item(it, low) }
        return out
    }
}
