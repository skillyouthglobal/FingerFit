package com.fingerfit.logic

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.hypot

/** One of the 33 MediaPipe pose landmarks (x,y normalised 0..1) with its visibility score. */
class BodyPoint(val x: Float, val y: Float, val v: Float)

/** MediaPipe pose landmark indices used by the app. */
object Joint {
    const val NOSE = 0
    const val L_SH = 11
    const val R_SH = 12
    const val L_EL = 13
    const val R_EL = 14
    const val L_WR = 15
    const val R_WR = 16
    const val L_HIP = 23
    const val R_HIP = 24
    const val L_KN = 25
    const val R_KN = 26
    const val L_AN = 27
    const val R_AN = 28
    const val L_HEEL = 29
    const val R_HEEL = 30
    const val L_FOOT = 31
    const val R_FOOT = 32
}

enum class ExerciseType(
    val emoji: String,
    val title: String,
    val benefit: String,
    val setup: String,
    val unit: String,
    val defaultTarget: Int,
    val step: Int,
    val startCue: String,
    val peakCue: String,
    val backCue: String,
) {
    JUMPING_JACKS(
        "🤸", "Jumping Jacks",
        "Boosts heart fitness and endurance, improves arm-leg coordination.",
        "Face the camera with your whole body in view.",
        "reps", 20, 5,
        "Stand with feet together, arms down", "Jump: arms up, feet apart", "Jump back to the start",
    ),
    SQUATS(
        "🏋️", "Bodyweight Squats",
        "Strengthens thighs and glutes, makes sitting and standing easier.",
        "Stand sideways to the camera, whole body in view.",
        "reps", 15, 5,
        "Stand tall", "Squat down", "Stand back up",
    ),
    PUSH_UPS(
        "💪", "Push-ups",
        "Strengthens chest, shoulders and arms, builds core stability.",
        "Put the phone on the floor beside you (side view), whole body in view.",
        "reps", 10, 2,
        "Arms straight, body in one line", "Lower your chest", "Push back up",
    ),
    LUNGES(
        "🦵", "Alternating Lunges",
        "Strengthens legs and glutes, improves balance and control.",
        "Stand sideways to the camera, whole body in view.",
        "reps", 12, 2,
        "Stand tall", "Step into a lunge", "Return to standing",
    ),
    HIGH_KNEES(
        "🏃", "High Knees",
        "Boosts heart fitness and endurance, improves speed and coordination.",
        "Face the camera with your whole body in view.",
        "reps", 40, 10,
        "Stand ready", "Lift your knees", "Keep alternating knees",
    ),
    CRUNCHES(
        "🧘", "Abdominal Crunches",
        "Strengthens the abdominal muscles and core stability.",
        "Lie on your back with the camera at your side, whole body in view.",
        "reps", 15, 5,
        "Lie flat, knees bent", "Curl your shoulders up", "Lower back down",
    ),
    GLUTE_BRIDGES(
        "🍑", "Glute Bridges",
        "Strengthens glutes and hamstrings, improves hip control.",
        "Lie on your back with the camera at your side, whole body in view.",
        "reps", 12, 2,
        "Lie flat, knees bent", "Lift your hips", "Lower your hips",
    ),
    PLANK(
        "🧱", "Plank",
        "Strengthens abs and core, builds muscular endurance.",
        "Put the phone on the floor beside you (side view), whole body in view.",
        "sec", 30, 10,
        "Get into plank position", "", "",
    ),
    SIT_TO_STAND(
        "💺", "Sit-to-Stand",
        "Builds leg and hip strength for standing up and climbing stairs, and supports balance and independence.",
        "Put a sturdy chair against a wall. Sit sideways to the camera, whole body in view.",
        "reps", 10, 2,
        "Sit on the chair", "Stand up fully", "Sit back down",
    ),
    CALF_RAISES(
        "👟", "Calf Raises",
        "Strengthens the calves and ankles, and improves balance and walking.",
        "Stand sideways to the camera, whole body and both feet in view.",
        "reps", 15, 5,
        "Stand flat on your feet", "Rise onto your toes", "Lower your heels",
    ),
    SIDE_LEG_RAISES(
        "🕺", "Side Leg Raises",
        "Strengthens the hips and outer thighs, and improves balance and stability.",
        "Face the camera, 2 to 3 metres away, whole body in view. Hold a chair if you need balance.",
        "reps", 20, 4,
        "Stand tall", "Lift one leg out to the side", "Lower it and switch",
    ),
    INCLINE_PUSHUPS(
        "💪", "Incline Push-ups",
        "Builds the chest, shoulders and arms with less load than floor push-ups. A good first step for beginners.",
        "Put your hands on a sturdy table or bench. Stand sideways to the camera, 2 to 3 metres away, whole body in view.",
        "reps", 10, 2,
        "Arms straight, body in one line", "Lower your chest to the bench", "Push back up",
    ),
    DECLINE_PUSHUPS(
        "🦾", "Decline Push-ups",
        "Works the upper chest and shoulders harder than floor push-ups and builds upper-body strength.",
        "Put your feet on a sturdy bench and your hands on the floor. Phone on the floor beside you (side view), whole body in view.",
        "reps", 8, 2,
        "Arms straight, body in one line", "Lower your chest toward the floor", "Push back up",
    ),
    BICEPS_CURL(
        "💪", "Biceps Curls",
        "Strengthens the front of the arms and makes carrying and lifting easier.",
        "Hold a water bottle or light weight in each hand. Face the camera, 2 to 3 metres away, whole body in view.",
        "reps", 12, 2,
        "Arms down by your sides", "Curl your hands up to your shoulders", "Lower slowly",
    ),
    TRICEPS_EXTENSION(
        "🙆", "Overhead Triceps Extension",
        "Strengthens the back of the arms and the ability to straighten the elbow.",
        "Hold one light weight with both hands overhead. Stand sideways to the camera, 2 to 3 metres away, whole body in view.",
        "reps", 10, 2,
        "Arms straight overhead", "Bend your elbows, lower behind your head", "Straighten your arms up",
    ),
    FRONT_RAISE(
        "🙋", "Front Arm Raises",
        "Builds shoulder strength and makes lifting the arms forward easier.",
        "Stand sideways to the camera, 2 to 3 metres away, whole body in view.",
        "reps", 12, 2,
        "Arms down in front", "Raise your arms to shoulder height", "Lower slowly",
    ),
    LATERAL_RAISE(
        "🙌", "Lateral Arm Raises",
        "Strengthens the sides of the shoulders and improves shoulder shape and control.",
        "Hold a light weight in each hand. Face the camera, 2 to 3 metres away, whole body in view.",
        "reps", 12, 2,
        "Arms down by your sides", "Raise your arms out to shoulder height", "Lower slowly",
    ),
    BUTT_KICKS(
        "🏃", "Heel-to-Butt Kicks",
        "Raises your heart rate, builds leg speed and warms up the back of the thighs.",
        "Face the camera or stand sideways, 2 to 3 metres away, whole body in view.",
        "reps", 30, 5,
        "Jog on the spot", "Kick one heel up toward your glutes", "Switch legs",
    ),
    GOOD_MORNING(
        "🌅", "Good Mornings",
        "Teaches the hip-hinge movement and strengthens the back of the thighs and hips.",
        "Stand sideways to the camera, 2 to 3 metres away, whole body in view.",
        "reps", 12, 2,
        "Stand tall, hands on your chest", "Hinge forward from the hips, back straight", "Stand back up",
    ),
    LEG_RAISE(
        "🦵", "Lying Leg Raises",
        "Strengthens the tummy muscles and improves core control.",
        "Lie on your back on a mat. Put the phone on the floor beside your hips (side view), 2 to 3 metres away, whole body in view.",
        "reps", 10, 2,
        "Legs straight on the floor", "Lift both legs up", "Lower with control",
    ),
    PIKE_PUSHUPS(
        "🙆", "Pike Push-ups",
        "Builds the shoulders and arms and trains pushing overhead.",
        "Hands and feet on the floor, hips lifted high like an upside-down V. Phone on the floor beside you (side view), 2 to 3 metres away, whole body in view.",
        "reps", 8, 2,
        "Hips high, arms straight", "Bend your elbows, head toward the floor", "Push back up",
    ),
    BULGARIAN_SPLIT_SQUAT(
        "🏋️", "Bulgarian Split Squats",
        "Strengthens the thighs and glutes one leg at a time and improves balance.",
        "Rest the top of your back foot on a sturdy bench or chair behind you. Stand sideways to the camera, 2 to 3 metres away, whole body in view.",
        "reps", 10, 2,
        "Front foot forward, back foot on the bench", "Lower straight down", "Push up through your front heel",
    ),
    SQUAT_PULSES(
        "🏋️", "Squat Pulses",
        "Keeps the thigh and glute muscles working for endurance.",
        "Stand sideways to the camera, 2 to 3 metres away, whole body in view.",
        "reps", 20, 5,
        "Squat down and hold low", "Pulse down a little", "Come up a little, do not stand",
    ),
    BURPEE(
        "🔥", "Burpees",
        "Raises your heart rate fast and works the whole body.",
        "Put the phone on the floor, side view, 2 to 3 metres away, with room to lie out flat. Whole body in view.",
        "reps", 8, 2,
        "Stand tall", "Hands down, feet back to a plank", "Jump up and stand tall",
    ),
    SQUAT_THRUST(
        "🔥", "Squat Thrusts",
        "Raises your heart rate and works the legs, chest and core, without the jump of a burpee.",
        "Put the phone on the floor, side view, 2 to 3 metres away, with room to lie out flat. Whole body in view.",
        "reps", 8, 2,
        "Stand tall", "Hands down, feet back to a plank", "Feet in, stand up",
    ),
    V_UPS(
        "✌️", "V-Ups",
        "Strengthens the whole abdominal area and the hip muscles.",
        "Lie on your back on a mat. Phone on the floor beside you (side view), 2 to 3 metres away, whole body in view.",
        "reps", 10, 2,
        "Lie flat, arms overhead", "Lift legs and chest into a V", "Lower back down with control",
    ),
    TIBIALIS_RAISE(
        "🦶", "Tibialis Raises",
        "Strengthens the front of the lower leg and helps protect the shins and ankles.",
        "Lean your back against a wall with your feet a little way out in front. Stand sideways to the camera, 2 to 3 metres away, feet in view.",
        "reps", 15, 5,
        "Heels on the floor, toes flat", "Lift your toes up high", "Lower your toes slowly",
    ),
    DOWNWARD_DOG(
        "🐕", "Downward Dog",
        "Stretches the back of the legs, the back and the shoulders.",
        "Put the phone on the floor beside you (side view), 2 to 3 metres away, whole body in view.",
        "sec", 30, 5,
        "Get into an upside-down V", "", "",
    ),
    HOLLOW_BODY_HOLD(
        "🛶", "Hollow Body Hold",
        "Builds strong deep abdominal muscles and body control.",
        "Lie on your back on a mat. Phone on the floor beside you (side view), 2 to 3 metres away, whole body in view.",
        "sec", 20, 5,
        "Lie on your back, arms overhead", "", "",
    ),
    CHILD_POSE(
        "🧎", "Child's Pose",
        "Gently stretches the back, hips and thighs and helps you relax.",
        "Put the phone on the floor beside you (side view), 2 to 3 metres away, whole body in view.",
        "sec", 30, 5,
        "Kneel and sit back on your heels", "", "",
    ),
    COBRA_STRETCH(
        "🐍", "Cobra Stretch",
        "Stretches the tummy and chest and strengthens the back.",
        "Lie face down on a mat. Phone on the floor beside you (side view), 2 to 3 metres away, whole body in view.",
        "sec", 20, 5,
        "Lie face down, then lift your chest", "", "",
    ),
    JUMP_ROPE(
        "🪢", "Jump Rope",
        "Raises your heart rate, builds stamina and improves coordination and foot speed.",
        "Face the camera, 2 to 3 metres away, whole body in view. You can jump with a real rope or without one.",
        "reps", 100, 20,
        "Get ready to jump", "Jump", "Keep jumping",
    ),
    SKATER_HOPS(
        "⛸️", "Skater Hops",
        "Raises your heart rate and builds balance and strength in the legs and hips.",
        "Face the camera, 2 to 3 metres away, whole body in view, with a wide clear space on both sides.",
        "reps", 20, 5,
        "Stand on one leg", "Hop sideways", "Hop back",
    ),
    SIDE_SHUFFLE(
        "↔️", "Side Shuffle",
        "Raises your heart rate and builds leg strength, speed and agility.",
        "Face the camera, 2 to 3 metres away, whole body in view, with a wide clear space on both sides.",
        "reps", 20, 5,
        "Get into a low stance", "Shuffle to one side", "Shuffle back",
    ),
    RUSSIAN_TWIST(
        "🌀", "Russian Twist",
        "Strengthens the sides of the tummy and the whole core.",
        "Sit on a mat facing the camera, 2 to 3 metres away, leaning back a little. Whole body in view.",
        "reps", 20, 4,
        "Lean back, hands together in front", "Twist to one side", "Twist to the other side",
    ),
    FLUTTER_KICKS(
        "🦶", "Flutter Kicks",
        "Strengthens the lower tummy muscles and the hip muscles.",
        "Lie on your back on a mat. Phone on the floor beside you (side view), 2 to 3 metres away, whole body in view.",
        "reps", 30, 10,
        "Lie flat, legs just off the floor", "Kick one leg up", "Kick the other leg up",
    ),
    SCISSOR_KICKS(
        "✂️", "Scissor Kicks",
        "Strengthens the lower tummy muscles and improves control of the legs.",
        "Lie on your back on a mat. Phone on the floor beside you (side view), 2 to 3 metres away, whole body in view.",
        "reps", 30, 10,
        "Lie flat, legs raised", "Open the legs wide", "Cross the legs over",
    ),
    SL_RDL(
        "🦩", "Single Leg Romanian Deadlift",
        "Strengthens the back of the thigh, glutes and lower back and improves balance.",
        "Stand sideways to the camera, 2 to 3 metres away, whole body in view. Hold a wall or chair if you need balance.",
        "reps", 8, 2,
        "Stand tall on one leg", "Hinge forward, back leg goes up", "Stand back up",
    ),
    WALKING_TOE_TOUCH(
        "🚶", "Walking Toe Touch",
        "Warms up and stretches the back of the legs and improves balance.",
        "Face the camera or stand sideways, 2 to 3 metres away, whole body in view. Do it on the spot.",
        "reps", 10, 2,
        "Stand tall, arms out", "Kick up and touch your toes", "Lower and switch",
    ),
    INCHWORM(
        "🐛", "Inchworm Walkout",
        "Stretches the back of the legs and strengthens the shoulders and core.",
        "Put the phone on the floor, side view, 2 to 3 metres away, with room to walk your hands out. Whole body in view.",
        "reps", 6, 2,
        "Stand tall", "Walk your hands out to a plank", "Walk back and stand up",
    );

    val isHold: Boolean get() = this == PLANK || this == DOWNWARD_DOG || this == HOLLOW_BODY_HOLD || this == CHILD_POSE || this == COBRA_STRETCH
    val isSided: Boolean get() = this == LUNGES || this == HIGH_KNEES || this == SIDE_LEG_RAISES || this == BUTT_KICKS || this == WALKING_TOE_TOUCH

    /** Each leg is counted on its own (left and right separately). */
    val isTwoLeg: Boolean get() = this == HIGH_KNEES || this == SIDE_LEG_RAISES || this == BUTT_KICKS || this == WALKING_TOE_TOUCH

    /** Counted from how the body moves (bounce, side to side, alternating legs) instead of from a start and a peak pose. */
    val isMotion: Boolean get() = this == JUMP_ROPE || this == SKATER_HOPS || this == SIDE_SHUFFLE || this == RUSSIAN_TWIST || this == FLUTTER_KICKS || this == SCISSOR_KICKS
}

/** Pixel-space geometry helper over the 33 landmarks. */
class Geo(private val p: List<BodyPoint>, private val w: Float, private val h: Float) {
    fun x(i: Int) = p[i].x * w
    fun y(i: Int) = p[i].y * h
    fun dist(a: Int, b: Int) = hypot(x(a) - x(b), y(a) - y(b))
    fun midX(a: Int, b: Int) = (x(a) + x(b)) / 2f
    fun midY(a: Int, b: Int) = (y(a) + y(b)) / 2f

    /** All listed joints are visible and inside the frame. */
    fun ok(vararg ids: Int) = ids.all {
        val q = p[it]
        q.v >= MIN_VIS && q.x > -0.02f && q.x < 1.02f && q.y > -0.02f && q.y < 1.02f
    }

    fun minVis(vararg ids: Int) = ids.minOf { p[it].v }

    /** Angle in degrees at joint [b] between [a] and [c]. */
    fun angle(a: Int, b: Int, c: Int): Float {
        val ax = x(a) - x(b)
        val ay = y(a) - y(b)
        val cx = x(c) - x(b)
        val cy = y(c) - y(b)
        val d = hypot(ax, ay) * hypot(cx, cy)
        if (d < 1e-3f) return 0f
        val cos = ((ax * cx + ay * cy) / d).coerceIn(-1f, 1f)
        return Math.toDegrees(acos(cos).toDouble()).toFloat()
    }

    /** 1 = the line a-b is horizontal in the image, 0 = vertical. */
    /** Hip position against the straight line shoulder -> ankle (+ = below the line). */
    fun hipSag(sh: Int, hip: Int, an: Int): Float {
        val len = dist(sh, an)
        val dx = x(an) - x(sh)
        if (len < 10f || abs(dx) < 10f) return 0f
        val t = (x(hip) - x(sh)) / dx
        val lineY = y(sh) + t * (y(an) - y(sh))
        return (y(hip) - lineY) / len
    }

    /** Angle in degrees between the line a -> b and straight down (0 = hanging straight, 90 = level with a). */
    fun tiltFromVertical(a: Int, b: Int): Float {
        val dxp = abs(x(b) - x(a))
        val dyp = y(b) - y(a)
        return Math.toDegrees(atan2(dxp.toDouble(), dyp.toDouble())).toFloat()
    }

    fun horizontalness(a: Int, b: Int): Float {
        val d = dist(a, b)
        return if (d < 1e-3f) 0f else abs(x(a) - x(b)) / d
    }

    companion object {
        const val MIN_VIS = 0.5f
    }
}

/**
 * What one frame says about the exercise. Pose.OPEN = START position of the
 * exercise, Pose.CLOSED = PEAK position (so one repetition = start -> peak -> start).
 */
class BodyRead(
    val valid: Boolean,
    val pose: Pose = Pose.UNKNOWN,
    val poseL: Pose = Pose.UNKNOWN,
    val poseR: Pose = Pose.UNKNOWN,
    val frontLeft: Boolean? = null,
    val good: Boolean = false,
    val hint: String? = null,
    /** Squat: knee angle. Push-up: elbow angle. (Smaller = deeper.) */
    val depth: Float = 180f,
    /** Hip height against the shoulder-ankle line as a share of body length: + = hips sag, - = hips too high. */
    val sag: Float = 0f,
    /** How far the movement went: jumping jack = hands above shoulders (share of torso), crunch = shoulder lift, bridge = hip angle. */
    val reach: Float = 0f,
    /** High knees: knee drop below the hip as a share of torso (small = high knee). */
    val ratioL: Float = 1f,
    val ratioR: Float = 1f,
    /** Side leg raise: how far each leg is lifted away from straight down, in degrees. */
    val tiltL: Float = 0f,
    val tiltR: Float = 0f,
    /** Motion exercises: the position being followed (jump rope: hip height, hops: side position, twist: hand side, kicks: leg height gap) in body-size units. */
    val sig: Float = 0f,
)

object BodyClassifier {
    private const val IN_VIEW = "Step back so your whole body is in view."

    fun read(type: ExerciseType, pts: List<BodyPoint>, w: Float, h: Float): BodyRead {
        if (pts.size < 33 || w <= 0f || h <= 0f) return BodyRead(false, hint = IN_VIEW)
        val g = Geo(pts, w, h)
        return when (type) {
            ExerciseType.SQUATS -> squat(g)
            ExerciseType.PUSH_UPS -> pushUp(g)
            ExerciseType.JUMPING_JACKS -> jumpingJack(g)
            ExerciseType.HIGH_KNEES -> highKnees(g)
            ExerciseType.LUNGES -> lunge(g)
            ExerciseType.CRUNCHES -> crunch(g)
            ExerciseType.GLUTE_BRIDGES -> bridge(g)
            ExerciseType.PLANK -> plank(g)
            ExerciseType.SIT_TO_STAND -> sitToStand(g)
            ExerciseType.CALF_RAISES -> calfRaise(g)
            ExerciseType.SIDE_LEG_RAISES -> sideLeg(g)
            ExerciseType.INCLINE_PUSHUPS, ExerciseType.DECLINE_PUSHUPS -> pushUp(g)
            ExerciseType.BICEPS_CURL -> curl(g)
            ExerciseType.TRICEPS_EXTENSION -> tricepsExt(g)
            ExerciseType.FRONT_RAISE, ExerciseType.LATERAL_RAISE -> armRaise(g)
            ExerciseType.BUTT_KICKS -> buttKicks(g)
            ExerciseType.GOOD_MORNING -> goodMorning(g)
            ExerciseType.LEG_RAISE -> legRaise(g)
            ExerciseType.PIKE_PUSHUPS -> pikePushUp(g)
            ExerciseType.BULGARIAN_SPLIT_SQUAT -> bulgarian(g)
            ExerciseType.SQUAT_PULSES -> squatPulse(g)
            ExerciseType.BURPEE, ExerciseType.SQUAT_THRUST, ExerciseType.INCHWORM -> burpee(g)
            ExerciseType.JUMP_ROPE, ExerciseType.SKATER_HOPS, ExerciseType.SIDE_SHUFFLE,
            ExerciseType.RUSSIAN_TWIST, ExerciseType.FLUTTER_KICKS, ExerciseType.SCISSOR_KICKS -> motion(type, g)
            ExerciseType.SL_RDL -> singleLegHinge(g)
            ExerciseType.WALKING_TOE_TOUCH -> toeTouch(g)
            ExerciseType.V_UPS -> vUp(g)
            ExerciseType.TIBIALIS_RAISE -> tibialis(g)
            ExerciseType.DOWNWARD_DOG -> downwardDog(g)
            ExerciseType.HOLLOW_BODY_HOLD -> hollowHold(g)
            ExerciseType.CHILD_POSE -> childPose(g)
            ExerciseType.COBRA_STRETCH -> cobra(g)
        }
    }

    private fun invalid(hint: String) = BodyRead(false, hint = hint)

    private fun curl(g: Geo): BodyRead {
        val hint = "Stand facing the camera with your whole body in view."
        val s = bestSide(g, Joint.L_SH, Joint.L_EL, Joint.L_WR, Joint.R_SH, Joint.R_EL, Joint.R_WR) ?: return invalid(hint)
        val a = g.angle(s[0], s[1], s[2])
        val pose = when {
            a >= 150f -> Pose.OPEN
            a <= 60f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a)
    }

    private fun tricepsExt(g: Geo): BodyRead {
        val hint = "Hold the weight overhead, side view, whole body in view."
        val s = bestSide(g, Joint.L_SH, Joint.L_EL, Joint.L_WR, Joint.R_SH, Joint.R_EL, Joint.R_WR) ?: return invalid(hint)
        val ref = g.dist(s[0], s[1])
        if (ref < 10f) return invalid(hint)
        val a = g.angle(s[0], s[1], s[2])
        val wristUp = g.y(s[2]) < g.y(s[0]) - 0.5f * ref
        val elbowUp = g.y(s[1]) < g.y(s[0]) - 0.3f * ref
        val pose = when {
            a >= 150f && wristUp && elbowUp -> Pose.OPEN
            a <= 90f && elbowUp -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a)
    }

    /** Front and lateral arm raises: how high the hands are against the shoulders, as a share of the torso. */
    private fun armRaise(g: Geo): BodyRead {
        val hint = "Stand with your whole body and both arms in view."
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP)) return invalid(hint)
        val torso = g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_SH, Joint.R_SH)
        if (torso < 10f) return invalid(hint)
        val lOk = g.ok(Joint.L_WR)
        val rOk = g.ok(Joint.R_WR)
        if (!lOk && !rOk) return invalid(hint)
        var sum = 0f
        var n = 0
        if (lOk) { sum += (g.y(Joint.L_SH) - g.y(Joint.L_WR)) / torso; n++ }
        if (rOk) { sum += (g.y(Joint.R_SH) - g.y(Joint.R_WR)) / torso; n++ }
        val reach = sum / n
        val pose = when {
            reach >= -0.15f -> Pose.CLOSED
            reach <= -0.55f -> Pose.OPEN
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, reach = reach)
    }

    private fun buttKicks(g: Geo): BodyRead {
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP, Joint.L_KN, Joint.R_KN, Joint.L_AN, Joint.R_AN)) return invalid(IN_VIEW)
        val torso = g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_SH, Joint.R_SH)
        if (torso < 10f) return invalid("Stand upright, whole body in view.")
        fun ratio(knee: Int, ankle: Int) = (g.y(ankle) - g.y(knee)) / torso
        fun leg(knee: Int, ankle: Int): Pose {
            val r = ratio(knee, ankle)
            return when {
                r <= 0.2f -> Pose.CLOSED // heel kicked up to knee height or higher
                r >= 0.55f -> Pose.OPEN
                else -> Pose.UNKNOWN
            }
        }
        return BodyRead(
            true,
            poseL = leg(Joint.L_KN, Joint.L_AN), poseR = leg(Joint.R_KN, Joint.R_AN),
            ratioL = ratio(Joint.L_KN, Joint.L_AN), ratioR = ratio(Joint.R_KN, Joint.R_AN),
        )
    }

    private fun goodMorning(g: Geo): BodyRead {
        val hint = "Stand sideways to the camera, whole body in view."
        val s = bestSide(g, Joint.L_SH, Joint.L_HIP, Joint.L_KN, Joint.R_SH, Joint.R_HIP, Joint.R_KN) ?: return invalid(hint)
        val a = g.angle(s[0], s[1], s[2])
        val pose = when {
            a >= 165f -> Pose.OPEN
            a <= 135f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a)
    }

    private fun legRaise(g: Geo): BodyRead {
        val hint = "Lie on your back, side view, with your feet in the picture."
        val s = bestSide(g, Joint.L_SH, Joint.L_HIP, Joint.L_AN, Joint.R_SH, Joint.R_HIP, Joint.R_AN) ?: return invalid(hint)
        if (g.horizontalness(s[0], s[1]) < 0.7f) return invalid(hint)
        val a = g.angle(s[0], s[1], s[2])
        val pose = when {
            a >= 155f -> Pose.OPEN
            a <= 115f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a)
    }

    /** Shoulder index (L_SH or R_SH) of the side whose joints (offsets from the shoulder index) are all visible, or -1. */
    private fun sideSh(g: Geo, vararg off: Int): Int {
        val l = IntArray(off.size) { Joint.L_SH + off[it] }
        val r = IntArray(off.size) { Joint.R_SH + off[it] }
        val lOk = g.ok(*l)
        val rOk = g.ok(*r)
        return when {
            lOk && rOk -> if (g.minVis(*l) >= g.minVis(*r)) Joint.L_SH else Joint.R_SH
            lOk -> Joint.L_SH
            rOk -> Joint.R_SH
            else -> -1
        }
    }

    // Offsets from the shoulder index: elbow +2, wrist +4, hip +12, knee +14, ankle +16, heel +18, toe +20.

    private fun pikePushUp(g: Geo): BodyRead {
        val hint = "Get into an upside-down V, hips high, side view."
        val sh = sideSh(g, 0, 2, 4, 12)
        if (sh < 0) return invalid(hint)
        val len = g.dist(sh, sh + 12)
        if (len < 10f) return invalid(hint)
        val up = (g.y(sh) - g.y(sh + 12)) / len // hips above the shoulders
        if (up < 0.25f) return invalid(hint)
        val a = g.angle(sh, sh + 2, sh + 4)
        val pose = when {
            a >= 150f -> Pose.OPEN
            a <= 115f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a, reach = up)
    }

    private fun bulgarian(g: Geo): BodyRead {
        val hint = "Stand sideways to the camera with your back foot on the bench."
        if (!g.ok(Joint.NOSE, Joint.L_HIP, Joint.R_HIP, Joint.L_KN, Joint.R_KN, Joint.L_AN, Joint.R_AN)) return invalid(hint)
        val hipX = g.midX(Joint.L_HIP, Joint.R_HIP)
        if (abs(g.x(Joint.NOSE) - hipX) < 8f) return invalid(hint)
        val facing = if (g.x(Joint.NOSE) >= hipX) 1f else -1f
        val frontLeft = (g.x(Joint.L_AN) - hipX) * facing >= (g.x(Joint.R_AN) - hipX) * facing
        val front = if (frontLeft) g.angle(Joint.L_HIP, Joint.L_KN, Joint.L_AN) else g.angle(Joint.R_HIP, Joint.R_KN, Joint.R_AN)
        val pose = when {
            front >= 155f -> Pose.OPEN
            front <= 110f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, frontLeft = frontLeft, depth = front)
    }

    private fun squatPulse(g: Geo): BodyRead {
        val hint = "Squat down low, side view, then pulse up and down."
        val s = bestSide(g, Joint.L_HIP, Joint.L_KN, Joint.L_AN, Joint.R_HIP, Joint.R_KN, Joint.R_AN)
            ?: return invalid(IN_VIEW)
        if (facingCamera(g)) return invalid(hint)
        val a = g.angle(s[0], s[1], s[2])
        val pose = when {
            a >= 118f -> Pose.OPEN
            a <= 106f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a, reach = 180f - a)
    }

    /** Burpee and squat thrust: START = standing, PEAK = a straight plank on the floor (a toe touch or a plain squat does not count). */
    private fun burpee(g: Geo): BodyRead {
        val hint = "Stand or lie sideways to the camera, whole body in view."
        val sh = sideSh(g, 0, 12, 16)
        if (sh < 0) return invalid(hint)
        if (g.dist(sh, sh + 12) < 10f) return invalid(hint)
        val torso = g.horizontalness(sh, sh + 12)
        val straight = g.angle(sh, sh + 12, sh + 16) >= 150f && g.horizontalness(sh, sh + 16) >= 0.7f
        val pose = when {
            torso <= 0.4f -> Pose.OPEN
            torso >= 0.75f && straight -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose)
    }

    private fun vUp(g: Geo): BodyRead {
        val hint = "Lie on your back, side view, with your feet in the picture."
        val sh = sideSh(g, 0, 12, 16)
        if (sh < 0) return invalid(hint)
        val len = g.dist(sh + 12, sh + 16)
        if (len < 10f || g.dist(sh, sh + 12) < 10f) return invalid(hint)
        val a = g.angle(sh, sh + 12, sh + 16)
        val flat = g.horizontalness(sh, sh + 12) >= 0.7f
        val legsUp = g.y(sh + 12) - g.y(sh + 16) >= 0.2f * len
        val pose = when {
            a >= 150f && flat -> Pose.OPEN
            a <= 95f && legsUp -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a)
    }

    /** Tibialis raise: toes lift up (the mirror of a calf raise). reach = how many degrees the toes are above the heel. */
    private fun tibialis(g: Geo): BodyRead {
        val hint = "Stand sideways to the camera, with your whole body and feet in view."
        val sh = sideSh(g, 12, 14, 16, 18, 20)
        if (sh < 0) return invalid(hint)
        if (facingCamera(g)) return invalid(hint)
        val run = abs(g.x(sh + 20) - g.x(sh + 18))
        if (run < 4f) return invalid(hint)
        val rise = g.y(sh + 20) - g.y(sh + 18) // negative when the toes are higher than the heel
        val lift = -Math.toDegrees(atan2(rise.toDouble(), run.toDouble())).toFloat()
        val pose = when {
            lift <= 6f -> Pose.OPEN
            lift >= 14f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = g.angle(sh + 12, sh + 14, sh + 16), reach = lift)
    }

    private fun torsoLen(g: Geo) = hypot(
        g.midX(Joint.L_SH, Joint.R_SH) - g.midX(Joint.L_HIP, Joint.R_HIP),
        g.midY(Joint.L_SH, Joint.R_SH) - g.midY(Joint.L_HIP, Joint.R_HIP),
    )

    /** Motion exercises: gives the engine one number to follow, in body-size units (see BodyRead.sig). */
    private fun motion(type: ExerciseType, g: Geo): BodyRead {
        when (type) {
            ExerciseType.RUSSIAN_TWIST -> {
                val hint = "Sit facing the camera, hands together in front, whole body in view."
                if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP, Joint.L_WR, Joint.R_WR)) return invalid(hint)
                val tl = torsoLen(g)
                if (tl < 10f) return invalid(hint)
                return BodyRead(true, sig = (g.midX(Joint.L_WR, Joint.R_WR) - g.midX(Joint.L_HIP, Joint.R_HIP)) / tl)
            }
            ExerciseType.FLUTTER_KICKS, ExerciseType.SCISSOR_KICKS -> {
                val hint = "Lie on your back, side view, with both feet in the picture."
                val sh = sideSh(g, 0, 12)
                if (sh < 0 || !g.ok(Joint.L_AN, Joint.R_AN, Joint.L_HIP, Joint.R_HIP)) return invalid(hint)
                if (g.horizontalness(sh, sh + 12) < 0.5f) return invalid(hint)
                val len = hypot(
                    g.midX(Joint.L_HIP, Joint.R_HIP) - g.midX(Joint.L_AN, Joint.R_AN),
                    g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_AN, Joint.R_AN),
                )
                if (len < 10f) return invalid(hint)
                return BodyRead(true, sig = (g.y(Joint.L_AN) - g.y(Joint.R_AN)) / len)
            }
            else -> {
                val hint = "Face the camera, whole body in view."
                if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP)) return invalid(hint)
                val tl = torsoLen(g)
                if (tl < 10f) return invalid(hint)
                val sig = if (type == ExerciseType.JUMP_ROPE) g.midY(Joint.L_HIP, Joint.R_HIP) / tl else g.midX(Joint.L_HIP, Joint.R_HIP) / tl
                return BodyRead(true, sig = sig)
            }
        }
    }

    /** Single-leg Romanian deadlift: the hip hinge of the leg that stays on the floor (the lower ankle). */
    private fun singleLegHinge(g: Geo): BodyRead {
        val hint = "Stand on one leg, side view, whole body in view."
        if (!g.ok(Joint.L_AN, Joint.R_AN)) return invalid(hint)
        val sh = if (g.y(Joint.L_AN) >= g.y(Joint.R_AN)) Joint.L_SH else Joint.R_SH
        if (!g.ok(sh, sh + 12, sh + 14)) return invalid(hint)
        val a = g.angle(sh, sh + 12, sh + 14)
        val pose = when {
            a >= 165f -> Pose.OPEN
            a <= 135f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a)
    }

    /** Walking toe touch: each hand against the opposite foot, left and right counted on their own. */
    private fun toeTouch(g: Geo): BodyRead {
        val hint = "Stand with your hands and both feet in view."
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP, Joint.L_WR, Joint.R_WR, Joint.L_AN, Joint.R_AN)) return invalid(hint)
        val tl = torsoLen(g)
        if (tl < 10f) return invalid(hint)
        val a = g.dist(Joint.L_WR, Joint.R_AN) / tl
        val b = g.dist(Joint.R_WR, Joint.L_AN) / tl
        fun leg(r: Float) = when {
            r <= 0.5f -> Pose.CLOSED
            r >= 0.9f -> Pose.OPEN
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, poseL = leg(a), poseR = leg(b), ratioL = a, ratioR = b)
    }

    private fun held(hint: String?) = BodyRead(true, good = hint == null, hint = hint)

    private fun downwardDog(g: Geo): BodyRead {
        val sh = sideSh(g, 0, 2, 4, 12, 14, 16)
        if (sh < 0) return invalid("Get into an upside-down V, hips high, side view.")
        val len = g.dist(sh, sh + 12)
        if (len < 10f) return invalid("Get into an upside-down V, hips high, side view.")
        val up = (g.y(sh) - g.y(sh + 12)) / len
        val arms = g.angle(sh, sh + 2, sh + 4)
        val legs = g.angle(sh + 12, sh + 14, sh + 16)
        val body = g.angle(sh, sh + 12, sh + 16)
        return held(
            when {
                up < 0.25f || body > 125f -> "Lift your hips up high, like an upside-down V."
                arms < 145f -> "Straighten your arms."
                legs < 140f -> "Straighten your legs."
                else -> null
            },
        )
    }

    private fun hollowHold(g: Geo): BodyRead {
        val hint = "Lie on your back, side view, whole body in view."
        val sh = sideSh(g, 0, 12, 16)
        if (sh < 0) return invalid(hint)
        val len = g.dist(sh, sh + 16)
        if (len < 10f) return invalid(hint)
        val shUp = (g.y(sh + 12) - g.y(sh)) / len
        val anUp = (g.y(sh + 12) - g.y(sh + 16)) / len
        return held(
            when {
                g.horizontalness(sh, sh + 16) < 0.8f -> hint
                shUp < 0.07f -> "Lift your shoulders off the floor."
                anUp < 0.07f -> "Lift your legs off the floor."
                else -> null
            },
        )
    }

    private fun childPose(g: Geo): BodyRead {
        val sh = sideSh(g, 0, 12, 14, 16)
        if (sh < 0) return invalid("Kneel and sit back on your heels, side view.")
        val knee = g.angle(sh + 12, sh + 14, sh + 16)
        val torso = g.horizontalness(sh, sh + 12)
        return held(
            when {
                knee > 100f -> "Kneel and sit back on your heels, side view."
                knee > 70f || torso < 0.7f -> "Sit back toward your heels and rest your chest on your thighs."
                else -> null
            },
        )
    }

    private fun cobra(g: Geo): BodyRead {
        val hint = "Lie face down, side view, whole body in view."
        val sh = sideSh(g, 0, 12, 16)
        if (sh < 0) return invalid(hint)
        val len = g.dist(sh, sh + 12)
        if (len < 10f) return invalid(hint)
        val up = (g.y(sh + 12) - g.y(sh)) / len
        return held(
            when {
                g.horizontalness(sh + 12, sh + 16) < 0.75f -> hint
                up < 0.3f -> "Press your hands down and lift your chest."
                up > 0.85f -> "Lower your chest a little, keep your hips on the floor."
                else -> null
            },
        )
    }

    /** The left or right triple of joints that is fully visible (best visibility wins). */
    private fun bestSide(g: Geo, l1: Int, l2: Int, l3: Int, r1: Int, r2: Int, r3: Int): IntArray? {
        val lOk = g.ok(l1, l2, l3)
        val rOk = g.ok(r1, r2, r3)
        return when {
            lOk && rOk ->
                if (g.minVis(l1, l2, l3) >= g.minVis(r1, r2, r3)) intArrayOf(l1, l2, l3) else intArrayOf(r1, r2, r3)
            lOk -> intArrayOf(l1, l2, l3)
            rOk -> intArrayOf(r1, r2, r3)
            else -> null
        }
    }

    private fun squat(g: Geo): BodyRead {
        val s = bestSide(g, Joint.L_HIP, Joint.L_KN, Joint.L_AN, Joint.R_HIP, Joint.R_KN, Joint.R_AN)
            ?: return invalid(IN_VIEW)
        val a = g.angle(s[0], s[1], s[2])
        val pose = when {
            a >= 155f -> Pose.OPEN
            a <= 120f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a)
    }

    private fun pushUp(g: Geo): BodyRead {
        val hint = "Get into push-up position, side view."
        val s = bestSide(g, Joint.L_SH, Joint.L_EL, Joint.L_WR, Joint.R_SH, Joint.R_EL, Joint.R_WR)
            ?: return invalid(hint)
        val hip = s[0] + 12 // shoulder index + 12 = hip index on the same side
        if (!g.ok(hip) || g.horizontalness(s[0], hip) < 0.77f) return invalid(hint)
        val a = g.angle(s[0], s[1], s[2])
        val pose = when {
            a >= 150f -> Pose.OPEN
            a <= 110f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        val ankle = if (g.ok(hip + 4)) hip + 4 else -1 // same side ankle
        val sag = if (ankle >= 0) g.hipSag(s[0], hip, ankle) else 0f
        return BodyRead(true, pose, depth = a, sag = sag)
    }

    private fun jumpingJack(g: Geo): BodyRead {
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP, Joint.L_WR, Joint.R_WR, Joint.L_AN, Joint.R_AN)) {
            return invalid(IN_VIEW)
        }
        val sw = abs(g.x(Joint.L_SH) - g.x(Joint.R_SH))
        val torso = g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_SH, Joint.R_SH)
        if (sw < 10f || torso < 10f) return invalid("Face the camera, standing upright.")
        val ankles = abs(g.x(Joint.L_AN) - g.x(Joint.R_AN)) / sw
        val up = g.y(Joint.L_WR) < g.y(Joint.L_SH) && g.y(Joint.R_WR) < g.y(Joint.R_SH)
        val down = g.y(Joint.L_WR) > g.y(Joint.L_SH) + 0.4f * torso &&
            g.y(Joint.R_WR) > g.y(Joint.R_SH) + 0.4f * torso
        val pose = when {
            up && ankles >= 1.5f -> Pose.CLOSED
            down && ankles <= 1.0f -> Pose.OPEN
            else -> Pose.UNKNOWN
        }
        val reach = minOf(
            (g.y(Joint.L_SH) - g.y(Joint.L_WR)) / torso,
            (g.y(Joint.R_SH) - g.y(Joint.R_WR)) / torso,
        )
        return BodyRead(true, pose, reach = reach)
    }

    private fun highKnees(g: Geo): BodyRead {
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP, Joint.L_KN, Joint.R_KN)) return invalid(IN_VIEW)
        val torso = g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_SH, Joint.R_SH)
        if (torso < 10f) return invalid("Face the camera, standing upright.")
        fun ratio(hip: Int, knee: Int) = (g.y(knee) - g.y(hip)) / torso
        fun leg(hip: Int, knee: Int): Pose {
            val r = ratio(hip, knee)
            return when {
                r <= 0.25f -> Pose.CLOSED // knee lifted to hip level
                r >= 0.5f -> Pose.OPEN
                else -> Pose.UNKNOWN
            }
        }
        return BodyRead(
            true,
            poseL = leg(Joint.L_HIP, Joint.L_KN), poseR = leg(Joint.R_HIP, Joint.R_KN),
            ratioL = ratio(Joint.L_HIP, Joint.L_KN), ratioR = ratio(Joint.R_HIP, Joint.R_KN),
        )
    }

    private fun lunge(g: Geo): BodyRead {
        val hint = "Stand sideways to the camera, whole body in view."
        if (!g.ok(Joint.NOSE, Joint.L_HIP, Joint.R_HIP, Joint.L_KN, Joint.R_KN, Joint.L_AN, Joint.R_AN)) return invalid(hint)
        val hipX = g.midX(Joint.L_HIP, Joint.R_HIP)
        if (abs(g.x(Joint.NOSE) - hipX) < 8f) return invalid(hint)
        val facing = if (g.x(Joint.NOSE) >= hipX) 1f else -1f
        val kL = g.angle(Joint.L_HIP, Joint.L_KN, Joint.L_AN)
        val kR = g.angle(Joint.R_HIP, Joint.R_KN, Joint.R_AN)
        val frontLeft = (g.x(Joint.L_AN) - hipX) * facing >= (g.x(Joint.R_AN) - hipX) * facing
        val front = if (frontLeft) kL else kR
        val pose = when {
            kL >= 155f && kR >= 155f -> Pose.OPEN
            front <= 110f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, frontLeft = frontLeft, depth = front)
    }

    private fun crunch(g: Geo): BodyRead {
        val hint = "Lie on your back with the camera at your side."
        val s = bestSide(g, Joint.L_SH, Joint.L_HIP, Joint.L_KN, Joint.R_SH, Joint.R_HIP, Joint.R_KN)
            ?: return invalid(hint)
        val len = g.dist(s[0], s[1])
        if (len < 10f || g.horizontalness(s[0], s[1]) < 0.5f) return invalid(hint)
        val lift = (g.y(s[1]) - g.y(s[0])) / len // shoulders rising above the hips
        val pose = when {
            lift <= 0.15f -> Pose.OPEN
            lift >= 0.33f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, reach = lift)
    }

    private fun bridge(g: Geo): BodyRead {
        val hint = "Lie on your back with the camera at your side."
        val s = bestSide(g, Joint.L_SH, Joint.L_HIP, Joint.L_KN, Joint.R_SH, Joint.R_HIP, Joint.R_KN)
            ?: return invalid(hint)
        if (g.horizontalness(s[0], s[1]) < 0.6f) return invalid(hint)
        val a = g.angle(s[0], s[1], s[2]) // shoulder-hip-knee: ~120-150 flat, ~175 at the top
        val pose = when {
            a <= 150f -> Pose.OPEN
            a >= 163f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, reach = a)
    }

    /** True when the person faces the camera (wide shoulders in the picture), so the knee angle cannot be read. */
    private fun facingCamera(g: Geo): Boolean {
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP)) return false
        val torso = g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_SH, Joint.R_SH)
        if (torso < 10f) return false
        return abs(g.x(Joint.L_SH) - g.x(Joint.R_SH)) > 0.6f * torso
    }

    private fun sitToStand(g: Geo): BodyRead {
        val hint = "Sit sideways to the camera, whole body in view."
        val s = bestSide(g, Joint.L_HIP, Joint.L_KN, Joint.L_AN, Joint.R_HIP, Joint.R_KN, Joint.R_AN)
            ?: return invalid(hint)
        if (facingCamera(g)) return invalid(hint)
        val a = g.angle(s[0], s[1], s[2]) // knee angle: about 90 seated, about 170 standing
        // START = seated, PEAK = standing, so one repetition = stand up and sit back down
        val pose = when {
            a <= 112f -> Pose.OPEN
            a >= 160f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = a, reach = a)
    }

    private fun calfRaise(g: Geo): BodyRead {
        val hint = "Stand sideways to the camera, with your whole body and feet in view."
        val l = intArrayOf(Joint.L_HIP, Joint.L_KN, Joint.L_AN, Joint.L_HEEL, Joint.L_FOOT)
        val r = intArrayOf(Joint.R_HIP, Joint.R_KN, Joint.R_AN, Joint.R_HEEL, Joint.R_FOOT)
        val lOk = g.ok(*l)
        val rOk = g.ok(*r)
        val s = when {
            lOk && rOk -> if (g.minVis(*l) >= g.minVis(*r)) l else r
            lOk -> l
            rOk -> r
            else -> return invalid(hint)
        }
        if (facingCamera(g)) return invalid(hint)
        val run = abs(g.x(s[4]) - g.x(s[3]))
        if (run < 4f) return invalid(hint)
        val rise = g.y(s[4]) - g.y(s[3]) // positive when the heel is higher than the toes
        val pitch = Math.toDegrees(atan2(rise.toDouble(), run.toDouble())).toFloat() // foot tilt: about 0 flat, 20 to 30 raised
        val pose = when {
            pitch <= 9f -> Pose.OPEN
            pitch >= 18f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        return BodyRead(true, pose, depth = g.angle(s[0], s[1], s[2]), reach = pitch)
    }

    private fun sideLeg(g: Geo): BodyRead {
        if (!g.ok(Joint.L_SH, Joint.R_SH, Joint.L_HIP, Joint.R_HIP, Joint.L_KN, Joint.R_KN, Joint.L_AN, Joint.R_AN)) return invalid(IN_VIEW)
        val torso = g.midY(Joint.L_HIP, Joint.R_HIP) - g.midY(Joint.L_SH, Joint.R_SH)
        if (torso < 10f) return invalid("Face the camera, standing upright.")
        if (abs(g.x(Joint.L_SH) - g.x(Joint.R_SH)) < 0.35f * torso) return invalid("Face the camera, standing upright.")
        fun leg(t: Float) = when {
            t <= 11f -> Pose.OPEN
            t >= 26f -> Pose.CLOSED
            else -> Pose.UNKNOWN
        }
        val tL = g.tiltFromVertical(Joint.L_HIP, Joint.L_AN)
        val tR = g.tiltFromVertical(Joint.R_HIP, Joint.R_AN)
        val lean = abs(g.midX(Joint.L_SH, Joint.R_SH) - g.midX(Joint.L_HIP, Joint.R_HIP)) / torso
        return BodyRead(true, poseL = leg(tL), poseR = leg(tR), tiltL = tL, tiltR = tR, reach = lean)
    }

    private fun plank(g: Geo): BodyRead {
        val hint = "Get into plank position, side view."
        val s = bestSide(g, Joint.L_SH, Joint.L_HIP, Joint.L_AN, Joint.R_SH, Joint.R_HIP, Joint.R_AN)
            ?: return invalid(hint)
        val straight = g.angle(s[0], s[1], s[2]) >= 155f
        val flat = g.horizontalness(s[0], s[2]) >= 0.8f
        if (!flat) return invalid(hint)
        return BodyRead(true, good = straight, hint = if (straight) null else "Keep your body in a straight line.", sag = g.hipSag(s[0], s[1], s[2]))
    }
}

/** Turns a stream of pose frames into repetitions (or hold time for the plank). */
class ExerciseEngine(val type: ExerciseType) {

    class Out(
        val detected: Boolean,
        val reliable: Boolean,
        val repDone: Boolean,
        val pose: Pose,
        val phase: RepCounter.Phase,
        val hint: String?,
        /** A form fix to say aloud (found while doing the repetition / while holding). */
        val form: FormTip? = null,
    )

    var leftReps = 0
        private set
    var rightReps = 0
        private set
    var holdMs = 0L
        private set

    private val counter = RepCounter(cfg(type))
    private val counterL = RepCounter(cfg(type))
    private val counterR = RepCounter(cfg(type))
    private var bottomFrontLeft: Boolean? = null

    // plank state
    private var lastT = -1L
    private var goodStreak = 0
    private var lastGoodT = 0L
    private var holding = false

    // motion state (jump rope, hops, shuffles, twists, kicks): the followed value, its recent low / high, and which side it is on
    private var motionCount = 0
    private var lo = Float.NaN
    private var hi = Float.NaN
    private var side = 0
    private var lastMotionT = -10_000L

    /** Repetitions, or whole seconds held for the plank. */
    val reps: Int
        get() = when {
            type.isHold -> (holdMs / 1000).toInt()
            type.isTwoLeg -> counterL.count + counterR.count
            type.isMotion -> motionCount
            else -> counter.count
        }

    fun update(pts: List<BodyPoint>?, w: Float, h: Float, t: Long, mirrored: Boolean): Out {
        if (pts == null) {
            lose(t)
            return Out(false, false, false, Pose.UNKNOWN, phase(), "Step back so your whole body is in view.")
        }
        val r = BodyClassifier.read(type, pts, w, h)
        if (!r.valid) {
            lose(t)
            return Out(true, false, false, Pose.UNKNOWN, phase(), r.hint)
        }
        return when {
            type.isHold -> plank(r, t)
            type == ExerciseType.HIGH_KNEES -> knees(r, t, mirrored)
            type == ExerciseType.SIDE_LEG_RAISES -> sideLegs(r, t, mirrored)
            type == ExerciseType.BUTT_KICKS || type == ExerciseType.WALKING_TOE_TOUCH -> kicks(r, t, mirrored)
            type.isMotion -> swing(r, t)
            else -> single(r, t, mirrored)
        }
    }

    // form tracking for the repetition in progress
    private var repMinDepth = 180f
    private var repMaxSag = 0f
    private var repMinSag = 0f

    private var repMaxReach = -9f
    private var attemptMax = 0f // best reach of a crunch / bridge that has not (yet) counted

    private fun formOfRep(): FormTip? {
        val tip = when (type) {
            ExerciseType.LUNGES -> if (repMinDepth > LUNGE_DEEP) FormTip.LUNGE_SHALLOW else null
            ExerciseType.JUMPING_JACKS -> if (repMaxReach < ARMS_HIGH) FormTip.ARMS_LOW else null
            ExerciseType.PUSH_UPS, ExerciseType.INCLINE_PUSHUPS, ExerciseType.DECLINE_PUSHUPS -> when {
                repMaxSag > SAG_LIMIT -> FormTip.HIPS_SAG
                repMinSag < -SAG_LIMIT -> FormTip.HIPS_HIGH
                repMinDepth > PUSHUP_DEEP -> FormTip.PUSHUP_SHALLOW
                else -> null
            }
            ExerciseType.SQUATS -> if (repMinDepth > SQUAT_DEEP) FormTip.SQUAT_SHALLOW else null
            ExerciseType.CALF_RAISES -> if (repMinDepth < KNEES_BENT) FormTip.KNEES_BENT else null
            ExerciseType.BICEPS_CURL -> if (repMinDepth > CURL_DEEP) FormTip.CURL_SHALLOW else null
            ExerciseType.FRONT_RAISE, ExerciseType.LATERAL_RAISE -> if (repMaxReach < RAISE_HIGH) FormTip.RAISE_LOW else null
            ExerciseType.GOOD_MORNING -> if (repMinDepth > HINGE_DEEP) FormTip.HINGE_SHALLOW else null
            ExerciseType.LEG_RAISE -> if (repMinDepth > LEGRAISE_DEEP) FormTip.LEGRAISE_LOW else null
            ExerciseType.PIKE_PUSHUPS -> if (repMinDepth > PIKE_DEEP) FormTip.PUSHUP_SHALLOW else null
            ExerciseType.BULGARIAN_SPLIT_SQUAT -> if (repMinDepth > LUNGE_DEEP) FormTip.LUNGE_SHALLOW else null
            ExerciseType.SL_RDL -> if (repMinDepth > HINGE_DEEP) FormTip.HINGE_SHALLOW else null
            else -> null
        }
        repMinDepth = 180f; repMaxSag = 0f; repMinSag = 0f; repMaxReach = -9f
        return tip
    }

    private fun single(r: BodyRead, t: Long, mirrored: Boolean): Out {
        if (r.pose != Pose.OPEN) {
            if (r.depth < repMinDepth) repMinDepth = r.depth
            if (r.sag > repMaxSag) repMaxSag = r.sag
            if (r.sag < repMinSag) repMinSag = r.sag
            if (r.reach > repMaxReach) repMaxReach = r.reach
            if (r.reach > attemptMax) attemptMax = r.reach
        }
        val e = counter.update(Observation(t, true, true, r.pose))
        if (e == RepCounter.Event.CLOSED_CONFIRMED) bottomFrontLeft = r.frontLeft
        val done = e == RepCounter.Event.REP_COMPLETED
        if (done && type == ExerciseType.LUNGES) {
            val indexLeft = bottomFrontLeft
            if (indexLeft != null) {
                if (indexLeft != mirrored) leftReps++ else rightReps++
            }
        }
        var tip = if (done) formOfRep() else null
        if (done) attemptMax = 0f
        if (!done && counter.phase == RepCounter.Phase.WAIT_CLOSE) {
            repMinDepth = 180f; repMaxSag = 0f; repMinSag = 0f; repMaxReach = -9f
            // back at the start without reaching the top: tell the person to go further
            if (r.pose == Pose.OPEN) {
                if (type == ExerciseType.CRUNCHES && attemptMax >= CRUNCH_TRY) tip = FormTip.CRUNCH_SHALLOW
                if (type == ExerciseType.GLUTE_BRIDGES && attemptMax >= BRIDGE_TRY) tip = FormTip.BRIDGE_LOW
                if (type == ExerciseType.SIT_TO_STAND && attemptMax >= STAND_TRY) tip = FormTip.STAND_SHORT
                if (type == ExerciseType.CALF_RAISES && attemptMax >= CALF_TRY) tip = FormTip.CALF_LOW
                if (type == ExerciseType.TIBIALIS_RAISE && attemptMax >= TIB_TRY) tip = FormTip.TOES_LOW
                if (type == ExerciseType.SQUAT_PULSES && attemptMax >= PULSE_TRY) tip = FormTip.SQUAT_SHALLOW
                attemptMax = 0f
            }
        }
        return Out(true, true, done, r.pose, counter.phase, null, tip)
    }

    /** Heel-to-butt kicks: each leg is counted on its own, like high knees but without a height tip. */
    private fun kicks(r: BodyRead, t: Long, mirrored: Boolean): Out {
        val eL = counterL.update(Observation(t, true, true, r.poseL))
        val eR = counterR.update(Observation(t, true, true, r.poseR))
        var done = false
        if (eL == RepCounter.Event.REP_COMPLETED) {
            done = true
            if (true != mirrored) leftReps++ else rightReps++
        }
        if (eR == RepCounter.Event.REP_COMPLETED) {
            done = true
            if (false != mirrored) leftReps++ else rightReps++
        }
        return Out(true, true, done, Pose.UNKNOWN, phase(), null, null)
    }

    private var kneeMinL = 9f
    private var kneeMinR = 9f

    private fun knees(r: BodyRead, t: Long, mirrored: Boolean): Out {
        var tip: FormTip? = null
        if (r.ratioL < kneeMinL) kneeMinL = r.ratioL
        if (r.ratioR < kneeMinR) kneeMinR = r.ratioR
        if (r.poseL == Pose.OPEN) { if (kneeMinL > KNEE_HIP && kneeMinL < KNEE_TRY) tip = FormTip.KNEES_LOW; kneeMinL = 9f }
        if (r.poseR == Pose.OPEN) { if (kneeMinR > KNEE_HIP && kneeMinR < KNEE_TRY) tip = FormTip.KNEES_LOW; kneeMinR = 9f }
        val eL = counterL.update(Observation(t, true, true, r.poseL))
        val eR = counterR.update(Observation(t, true, true, r.poseR))
        var done = false
        if (eL == RepCounter.Event.REP_COMPLETED) {
            done = true
            if (true != mirrored) leftReps++ else rightReps++ // model-left leg
        }
        if (eR == RepCounter.Event.REP_COMPLETED) {
            done = true
            if (false != mirrored) leftReps++ else rightReps++ // model-right leg
        }
        return Out(true, true, done, Pose.UNKNOWN, phase(), null, tip)
    }

    private var tiltMaxL = 0f
    private var tiltMaxR = 0f
    private var leanMax = 0f

    private fun sideLegs(r: BodyRead, t: Long, mirrored: Boolean): Out {
        var tip: FormTip? = null
        if (r.tiltL > tiltMaxL) tiltMaxL = r.tiltL
        if (r.tiltR > tiltMaxR) tiltMaxR = r.tiltR
        if (r.poseL != Pose.OPEN || r.poseR != Pose.OPEN) {
            if (r.reach > leanMax) leanMax = r.reach
        } else {
            leanMax = 0f
        }
        // a leg went up but not high enough to count, and is now back down
        if (r.poseL == Pose.OPEN) { if (tiltMaxL > LEG_TRY && tiltMaxL < LEG_UP) tip = FormTip.LEG_LOW; tiltMaxL = 0f }
        if (r.poseR == Pose.OPEN) { if (tiltMaxR > LEG_TRY && tiltMaxR < LEG_UP) tip = FormTip.LEG_LOW; tiltMaxR = 0f }
        val eL = counterL.update(Observation(t, true, true, r.poseL))
        val eR = counterR.update(Observation(t, true, true, r.poseR))
        var done = false
        if (eL == RepCounter.Event.REP_COMPLETED) {
            done = true
            if (true != mirrored) leftReps++ else rightReps++ // model-left leg
        }
        if (eR == RepCounter.Event.REP_COMPLETED) {
            done = true
            if (false != mirrored) leftReps++ else rightReps++ // model-right leg
        }
        if (done) {
            if (tip == null && leanMax > LEAN_LIMIT) tip = FormTip.LEANING
            leanMax = 0f
        }
        return Out(true, true, done, Pose.UNKNOWN, phase(), null, tip)
    }

    /**
     * Counts back-and-forth movement. The followed value keeps a slowly fading low and high mark; it counts as being on the
     * low side or the high side once it is clearly past the middle, and each change of side is one repetition
     * (jump rope: one landing). Movement smaller than a minimum swing is ignored, so standing still counts nothing.
     */
    private fun swing(r: BodyRead, t: Long): Out {
        val v = r.sig
        if (lo.isNaN()) { lo = v; hi = v }
        lo = if (v < lo) v else lo + (v - lo) * 0.03f
        hi = if (v > hi) v else hi + (v - hi) * 0.03f
        val amp = hi - lo
        val mid = (hi + lo) / 2f
        val minAmp = when (type) {
            ExerciseType.JUMP_ROPE -> JUMP_AMP
            ExerciseType.FLUTTER_KICKS, ExerciseType.SCISSOR_KICKS -> KICK_AMP
            ExerciseType.RUSSIAN_TWIST -> TWIST_AMP
            else -> HOP_AMP
        }
        var ns = side
        if (amp >= minAmp) {
            if (v >= mid + 0.25f * amp) ns = 1 else if (v <= mid - 0.25f * amp) ns = -1
        }
        var done = false
        if (side != 0 && ns != side && t - lastMotionT >= MOTION_GAP) {
            // jump rope counts only the landing (from the air back to the ground side)
            if (type != ExerciseType.JUMP_ROPE || ns == 1) {
                motionCount++
                lastMotionT = t
                done = true
            }
        }
        side = ns
        return Out(true, true, done, Pose.UNKNOWN, phase(), null, null)
    }

    private fun plank(r: BodyRead, t: Long): Out {
        val dt = if (lastT >= 0) (t - lastT).coerceIn(0L, 250L) else 0L
        lastT = t
        if (r.good) {
            goodStreak++
            lastGoodT = t
            if (goodStreak >= 3) holding = true
        } else {
            goodStreak = 0
            if (t - lastGoodT > 600) holding = false
        }
        if (holding) holdMs += dt
        val tip = if (r.good) null else when {
            r.sag > PLANK_SAG -> FormTip.HIPS_SAG
            r.sag < -PLANK_SAG -> FormTip.HIPS_HIGH
            else -> null
        }
        return Out(true, true, false, Pose.UNKNOWN, phase(), if (holding) null else r.hint, tip)
    }

    private fun lose(t: Long) {
        attemptMax = 0f; kneeMinL = 9f; kneeMinR = 9f; tiltMaxL = 0f; tiltMaxR = 0f; leanMax = 0f; side = 0; lo = Float.NaN; hi = Float.NaN
        if (type.isHold) {
            lastT = t
            goodStreak = 0
            if (t - lastGoodT > 600) holding = false
            return
        }
        val o = Observation(t, false, false, Pose.UNKNOWN)
        if (type.isTwoLeg) {
            counterL.update(o)
            counterR.update(o)
        } else {
            counter.update(o)
        }
    }

    private fun phase(): RepCounter.Phase {
        if (!type.isTwoLeg) return counter.phase
        val a = counterL.phase
        val b = counterR.phase
        return when {
            a == RepCounter.Phase.WAIT_CLOSE || b == RepCounter.Phase.WAIT_CLOSE -> RepCounter.Phase.WAIT_CLOSE
            a == RepCounter.Phase.WAIT_REOPEN || b == RepCounter.Phase.WAIT_REOPEN -> RepCounter.Phase.WAIT_REOPEN
            a == RepCounter.Phase.NO_HAND && b == RepCounter.Phase.NO_HAND -> RepCounter.Phase.NO_HAND
            else -> RepCounter.Phase.WAIT_OPEN
        }
    }

    /** Forget the movement in progress but keep the totals (used on pause / resume). */
    fun restartCycle() {
        counter.resetCycle()
        counterL.resetCycle()
        counterR.resetCycle()
        holding = false
        goodStreak = 0
        lastT = -1L
        attemptMax = 0f; kneeMinL = 9f; kneeMinR = 9f; tiltMaxL = 0f; tiltMaxR = 0f; leanMax = 0f; side = 0; lo = Float.NaN; hi = Float.NaN
    }

    val isHolding: Boolean get() = holding

    private companion object {
        const val SAG_LIMIT = 0.08f
        const val PLANK_SAG = 0.05f
        const val SQUAT_DEEP = 105f
        const val PUSHUP_DEEP = 95f
        const val LUNGE_DEEP = 100f   // front knee angle: at or below = deep enough
        const val ARMS_HIGH = 0.6f    // jumping jack: hands at least this far above the shoulders (head height)
        const val CRUNCH_TRY = 0.22f  // shoulder lift that shows a real attempt (counts at 0.33)
        const val BRIDGE_TRY = 156f   // hip angle that shows a real attempt (counts at 163)
        const val KNEE_HIP = 0.25f    // knee at hip level (counts)
        const val KNEE_TRY = 0.42f    // knee lifted well past half way but not to the hip
        const val STAND_TRY = 140f    // knee angle that shows a real try at standing up (counts at 160)
        const val CALF_TRY = 14f      // foot tilt that shows a real try at rising (counts at 18)
        const val KNEES_BENT = 150f   // calf raise: knee angle below this = knees bent too much
        const val LEG_TRY = 17f       // side leg raise: leg tilt that shows a real try (counts at 26)
        const val LEG_UP = 26f
        const val CURL_DEEP = 75f      // biceps curl: elbow angle at or below = curled high enough
        const val RAISE_HIGH = -0.05f  // arm raise: hands at least this near the shoulder line (share of torso)
        const val HINGE_DEEP = 140f    // good morning: hip angle at or below = bent far enough
        const val LEGRAISE_DEEP = 105f // leg raise: hip angle at or below = legs high enough
        const val PIKE_DEEP = 100f     // pike push-up: elbow angle at or below = lowered far enough
        const val TIB_TRY = 9f         // tibialis raise: toe lift (degrees) that shows a real try (counts at 14)
        const val PULSE_TRY = 66f      // squat pulse: 180 - knee angle that shows a real try (counts at 74)
        const val JUMP_AMP = 0.07f     // jump rope: smallest body rise (share of torso length) that counts as a jump
        const val HOP_AMP = 0.45f      // hops and shuffles: smallest side-to-side travel (share of torso length)
        const val TWIST_AMP = 0.5f     // russian twist: smallest hand swing (share of torso length)
        const val KICK_AMP = 0.12f     // flutter and scissor kicks: smallest gap between the feet (share of leg length)
        const val MOTION_GAP = 120L    // fastest possible repetition, in milliseconds
        const val LEAN_LIMIT = 0.22f  // side leg raise: body leaning sideways more than this share of the torso

        fun cfg(t: ExerciseType) = when (t) {
            // One confirming frame is enough: a Wi-Fi camera gives only 6 to 10 pictures a second, so a
            // quick repetition may show its lowest point in a single picture. The wide gap between the
            // START and PEAK angles already keeps noise from counting.
            ExerciseType.JUMPING_JACKS -> RepCounter.Config(1, 0, 1000, 300)
            ExerciseType.HIGH_KNEES, ExerciseType.BUTT_KICKS -> RepCounter.Config(1, 0, 1000, 200)
            ExerciseType.BURPEE, ExerciseType.SQUAT_THRUST, ExerciseType.INCHWORM -> RepCounter.Config(1, 0, 2500, 800)
            ExerciseType.WALKING_TOE_TOUCH -> RepCounter.Config(1, 0, 1000, 300)
            ExerciseType.SQUAT_PULSES -> RepCounter.Config(1, 0, 1500, 300)
            else -> RepCounter.Config(1, 0, 1500, 400)
        }
    }
}
