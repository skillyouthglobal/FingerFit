package com.fingerfit.logic

import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime

/** The personal notifications Kinetro sends. */
enum class NudgeKind { MORNING, EVENING, WEIGHT, SLEEP }

/** What the app knows when it writes a notification. */
class NudgeFacts(
    val name: String,
    val bn: Boolean,
    val streak: Int,
    val minutesToday: Int,
    val goalMinutes: Int,
    /** Days since the weight was last written down; null = never. */
    val daysSinceWeight: Int?,
    val today: LocalDate,
)

class NudgeText(val title: String, val body: String)

/**
 * Writes the notification texts. Every text says the person's first name, in Bengali or English.
 * Several wordings are kept for each case and one is chosen by the day, so it never sounds like a robot repeating itself.
 */
object Nudges {
    fun num(v: Int, bn: Boolean): String =
        if (!bn) v.toString() else v.toString().map { if (it in '0'..'9') '০' + (it - '0') else it }.joinToString("")

    fun firstName(name: String, bn: Boolean): String {
        val f = name.trim().split(Regex("\\s+")).firstOrNull().orEmpty()
        return if (f.isEmpty()) (if (bn) "বন্ধু" else "friend") else f
    }

    private fun pick(list: List<NudgeText>, day: LocalDate): NudgeText = list[day.dayOfYear % list.size]

    fun build(kind: NudgeKind, f: NudgeFacts): NudgeText? {
        val n = firstName(f.name, f.bn)
        val raw = when (kind) {
            NudgeKind.MORNING -> morning(f, n)
            NudgeKind.EVENING -> evening(f, n)
            NudgeKind.WEIGHT -> weight(f, n) ?: return null
            NudgeKind.SLEEP -> sleep(f, n)
        }
        return raw
    }

    private fun morning(f: NudgeFacts, n: String): NudgeText {
        val s = num(f.streak, f.bn)
        return if (f.bn) {
            if (f.streak >= 2) NudgeText("সুপ্রভাত, $n! 🌅", "$n, আপনার $s দিনের ধারা চলছে। আজকের ব্যায়ামের সময় হয়েছে, ক্যামেরার সামনে এসে শুরু করুন।")
            else pick(
                listOf(
                    NudgeText("সুপ্রভাত, $n! 🌅", "$n, নতুন দিন, নতুন শক্তি। আজকের পরিকল্পনা তৈরি আছে, মাত্র কয়েক মিনিটের ব্যায়াম দিয়ে শুরু করুন।"),
                    NudgeText("$n, আজকের দিনটা শুরু হোক ব্যায়ামে 💪", "আপনার জন্য আজকের পরিকল্পনা তৈরি, $n। অ্যাপ খুলে ক্যামেরার সামনে দাঁড়ান, গোনার কাজ আমরা করব।"),
                    NudgeText("শুভ সকাল, $n! ☀️", "$n, সকালের একটু নড়াচড়া সারাদিন তরতাজা রাখে। আজ কোন ব্যায়ামটা করবেন?"),
                ),
                f.today,
            )
        } else {
            if (f.streak >= 2) NudgeText("Good morning, $n! 🌅", "$n, you are on a $s-day streak. Time for today's exercise. Step in front of the camera and begin.")
            else pick(
                listOf(
                    NudgeText("Good morning, $n! 🌅", "$n, a new day, new energy. Today's plan is ready. Start with just a few minutes of exercise."),
                    NudgeText("$n, let's start the day with exercise 💪", "Your plan for today is ready, $n. Open the app, stand in front of the camera, and we will do the counting."),
                    NudgeText("Rise and shine, $n! ☀️", "$n, a little movement in the morning keeps you fresh all day. Which exercise will you do today?"),
                ),
                f.today,
            )
        }
    }

    private fun evening(f: NudgeFacts, n: String): NudgeText {
        val m = num(f.minutesToday, f.bn)
        val left = num((f.goalMinutes - f.minutesToday).coerceAtLeast(0), f.bn)
        val s = num(f.streak, f.bn)
        val reached = f.goalMinutes in 1..f.minutesToday
        return if (f.bn) {
            when {
                f.minutesToday > 0 && reached -> NudgeText("অভিনন্দন, $n! 🎉", "$n, আজ আপনি $m মিনিট সক্রিয় ছিলেন, আজকের লক্ষ্য পূর্ণ। এভাবেই চালিয়ে যান।")
                f.minutesToday > 0 -> NudgeText("দারুণ হচ্ছে, $n! 👏", "$n, আজ $m মিনিট করেছেন। লক্ষ্য পূর্ণ করতে আর $left মিনিট বাকি, একটু চেষ্টা করবেন?")
                f.streak >= 2 -> NudgeText("$n, আপনার $s দিনের ধারা ভাঙবেন না 🔥", "আজ এখনো ব্যায়াম হয়নি, $n। মাত্র ১০ মিনিটেই ধারা বজায় থাকবে।")
                else -> pick(
                    listOf(
                        NudgeText("$n, আজ এখনো ব্যায়াম হয়নি", "ঘুমানোর আগে ১০ মিনিট ব্যায়াম করলে শরীর ও মন দুটোই ভালো থাকে, $n। চলুন শুরু করি।"),
                        NudgeText("$n, দিনটা শেষ হওয়ার আগে একটু নড়ুন 🌙", "আজকের ব্যায়াম বাকি আছে, $n। ছোট একটা সেশনই যথেষ্ট।"),
                    ),
                    f.today,
                )
            }
        } else {
            when {
                f.minutesToday > 0 && reached -> NudgeText("Congratulations, $n! 🎉", "$n, you were active for $m minutes today and reached your goal. Keep it up.")
                f.minutesToday > 0 -> NudgeText("Great going, $n! 👏", "$n, you did $m minutes today. Only $left minutes to reach your goal. Want to give it a try?")
                f.streak >= 2 -> NudgeText("$n, don't break your $s-day streak 🔥", "No exercise yet today, $n. Just 10 minutes keeps your streak alive.")
                else -> pick(
                    listOf(
                        NudgeText("$n, no exercise yet today", "Ten minutes before bed is good for body and mind, $n. Let's begin."),
                        NudgeText("$n, move a little before the day ends 🌙", "Today's exercise is still waiting, $n. One short session is enough."),
                    ),
                    f.today,
                )
            }
        }
    }

    private fun weight(f: NudgeFacts, n: String): NudgeText? {
        val d = f.daysSinceWeight
        if (d != null && d < 7) return null
        return if (f.bn) NudgeText("$n, ওজন মাপার সময় ⚖️", "$n, সপ্তাহে একবার ওজন লিখে রাখলে আপনার অগ্রগতি চার্টে সুন্দর করে দেখা যাবে। অ্যাপের \"অগ্রগতি\" পেজে লিখে রাখুন।")
        else NudgeText("$n, time to weigh in ⚖️", "$n, writing your weight down once a week shows your progress clearly on the chart. Add it on the Progress page.")
    }

    private fun sleep(f: NudgeFacts, n: String): NudgeText =
        if (f.bn) NudgeText("$n, গত রাতে কেমন ঘুমালেন? 😴", "$n, ঘুমানো ও ওঠার সময় লিখে রাখুন। সুস্থ থাকতে ঘুম খুব জরুরি।")
        else NudgeText("$n, how did you sleep last night? 😴", "$n, note your bedtime and wake-up time. Good sleep is key to staying healthy.")

    /** The next time the clock shows [minuteOfDay] (strictly after [now]). */
    fun nextTime(now: LocalDateTime, minuteOfDay: Int): LocalDateTime {
        var t = now.withHour((minuteOfDay / 60).coerceIn(0, 23)).withMinute((minuteOfDay % 60).coerceIn(0, 59)).withSecond(0).withNano(0)
        if (!t.isAfter(now)) t = t.plusDays(1)
        return t
    }

    fun delayMillis(now: LocalDateTime, minuteOfDay: Int): Long = Duration.between(now, nextTime(now, minuteOfDay)).toMillis()
}

/** One written-down weight. */
class WeightEntry(val date: LocalDate, val kg: Float)

/** The weight history: one value per day, oldest first. */
object WeightLog {
    fun upsert(list: List<WeightEntry>, e: WeightEntry): List<WeightEntry> =
        (list.filter { it.date != e.date } + e).sortedBy { it.date }.takeLast(365)

    fun daysSinceLast(list: List<WeightEntry>, today: LocalDate): Int? =
        list.maxByOrNull { it.date }?.let { Duration.between(it.date.atStartOfDay(), today.atStartOfDay()).toDays().toInt().coerceAtLeast(0) }

    /** Change from the oldest entry inside the last [days] days to the newest, or null when fewer than two entries. */
    fun change(list: List<WeightEntry>, days: Int, today: LocalDate): Float? {
        val win = list.filter { !it.date.isBefore(today.minusDays(days.toLong())) && !it.date.isAfter(today) }.sortedBy { it.date }
        if (win.size < 2) return null
        return win.last().kg - win.first().kg
    }

    fun encode(list: List<WeightEntry>): String = list.joinToString(";") { "${it.date}:${it.kg}" }

    fun decode(raw: String?): List<WeightEntry> {
        if (raw.isNullOrBlank()) return emptyList()
        val out = ArrayList<WeightEntry>()
        for (part in raw.split(';')) {
            val p = part.split(':')
            if (p.size != 2) continue
            val d = try { LocalDate.parse(p[0]) } catch (e: Exception) { continue }
            val kg = p[1].toFloatOrNull() ?: continue
            if (kg in 15f..300f) out.add(WeightEntry(d, kg))
        }
        return out.sortedBy { it.date }
    }
}
