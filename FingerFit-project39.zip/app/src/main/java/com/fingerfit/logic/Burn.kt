package com.fingerfit.logic

import kotlin.math.roundToInt

/** Rough calories burned from active minutes: a general MET average for mixed bodyweight exercise and walking. */
object Burn {
    const val MET = 4.5

    fun kcal(weightKg: Float, minutes: Int): Int = (MET * weightKg * minutes.coerceAtLeast(0) / 60.0).roundToInt()

    /** The daily burn target: what the daily active-minutes goal is worth, in steps of 10 kcal. */
    fun target(weightKg: Float, goalMinutes: Int): Int =
        (((MET * weightKg * goalMinutes / 60.0) / 10.0).roundToInt() * 10).coerceAtLeast(10)
}
