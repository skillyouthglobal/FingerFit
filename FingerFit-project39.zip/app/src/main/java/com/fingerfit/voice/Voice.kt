package com.fingerfit.voice

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice as SysVoice
import android.os.SystemClock
import android.speech.tts.UtteranceProgressListener
import com.fingerfit.data.AppPrefs
import com.fingerfit.logic.Say
import com.fingerfit.logic.SayKind
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class VoiceStatus { STARTING, READY, NO_ENGINE, NO_LANGUAGE }

/**
 * The coach's voice: the phone's own text-to-speech (works offline once the voice is installed).
 * It picks the best installed voice for the app language and lets the person choose another.
 */
object Voice {
    private var tts: TextToSpeech? = null
    private var app: Context? = null
    private var bn = false
    private var voices: List<SysVoice> = emptyList()

    private val _status = MutableStateFlow(VoiceStatus.STARTING)
    val status: StateFlow<VoiceStatus> = _status.asStateFlow()
    private val _count = MutableStateFlow(0)
    /** How many voices of the current language are installed. */
    val voiceCount: StateFlow<Int> = _count.asStateFlow()
    private val _picked = MutableStateFlow(0)
    val pickedIndex: StateFlow<Int> = _picked.asStateFlow()

    fun init(ctx: Context) {
        if (tts != null) return
        val c = ctx.applicationContext
        app = c
        bn = AppPrefs.lang(c) == "bn"
        try {
            tts = TextToSpeech(c) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    try {
                        tts?.setAudioAttributes(
                            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
                        )
                    } catch (e: Exception) {
                    }
                    try {
                        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(id: String?) {}
                            override fun onDone(id: String?) { finished(id) }
                            @Deprecated("old callback")
                            override fun onError(id: String?) { finished(id) }
                            override fun onError(id: String?, code: Int) { finished(id) }
                        })
                    } catch (e: Exception) {
                    }
                    apply()
                } else {
                    _status.value = VoiceStatus.NO_ENGINE
                }
            }
        } catch (e: Exception) {
            _status.value = VoiceStatus.NO_ENGINE
        }
    }

    /** The app language changed: use a voice of that language. */
    fun setLang(isBn: Boolean) {
        bn = isBn
        if (tts != null && _status.value != VoiceStatus.STARTING && _status.value != VoiceStatus.NO_ENGINE) apply()
    }

    private fun quality(v: SysVoice): Int {
        var q = v.quality * 10
        if (v.features?.contains("notInstalled") == true) q -= 10_000
        if (v.isNetworkConnectionRequired) q -= 50
        return q
    }

    private fun apply() {
        val t = tts ?: return
        val c = app ?: return
        var r = if (bn) t.setLanguage(Locale("bn", "BD")) else t.setLanguage(Locale.US)
        if (bn && (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)) r = t.setLanguage(Locale("bn", "IN"))
        if (!bn && (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)) r = t.setLanguage(Locale.ENGLISH)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            voices = emptyList(); _count.value = 0
            _status.value = VoiceStatus.NO_LANGUAGE
            return
        }
        val lang = if (bn) "bn" else "en"
        voices = try {
            (t.voices ?: emptySet()).filter { it.locale.language == lang }.sortedByDescending { quality(it) }
        } catch (e: Exception) {
            emptyList()
        }
        _count.value = voices.size
        if (voices.isNotEmpty()) {
            val saved = AppPrefs.voiceName(c, lang)
            val idx = voices.indexOfFirst { it.name == saved }.let { if (it < 0) 0 else it }
            _picked.value = idx
            try { t.voice = voices[idx] } catch (e: Exception) { }
        }
        t.setPitch(1.0f)
        t.setSpeechRate(rateFor(AppPrefs.voiceSpeed(c)))
        _status.value = VoiceStatus.READY
    }

    private fun rateFor(level: Int) = when (level) { 0 -> 0.82f; 2 -> 1.12f; else -> 0.96f }

    fun setSpeed(level: Int) {
        val c = app ?: return
        AppPrefs.setVoiceSpeed(c, level)
        tts?.setSpeechRate(rateFor(level))
    }

    fun choose(index: Int) {
        val c = app ?: return
        val t = tts ?: return
        if (index !in voices.indices) return
        try { t.voice = voices[index] } catch (e: Exception) { return }
        _picked.value = index
        AppPrefs.setVoiceName(c, if (bn) "bn" else "en", voices[index].name)
    }

    fun enabled(): Boolean = app?.let { AppPrefs.voiceOn(it) } ?: false

    fun setEnabled(on: Boolean) {
        val c = app ?: return
        AppPrefs.setVoiceOn(c, on)
        if (!on) stop()
    }

    // ---- speaking without stutter -------------------------------------------------
    // A number is never allowed to cut off or pile up behind other speech: while the voice is busy, only the
    // newest number waits, and it is dropped if it has become old by the time the voice is free.
    private val gate = Any()
    private var busy = 0
    private var pendingCount: String? = null
    private var pendingAt = 0L
    private var seq = 0

    private fun finished(id: String?) {
        if (id == null || !id.startsWith("k")) return
        var next: String? = null
        synchronized(gate) {
            if (busy > 0) busy--
            if (busy == 0) {
                val p = pendingCount
                pendingCount = null
                if (p != null && SystemClock.uptimeMillis() - pendingAt < 2500) next = p
            }
        }
        next?.let { speakNow(it, false, true) }
    }

    private fun speakNow(text: String, flush: Boolean, count: Boolean) {
        synchronized(gate) {
            if (flush) busy = 0
            busy++
            seq++
        }
        try {
            val r = tts?.speak(text, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "k" + (if (count) "c" else "t") + seq)
            if (r != TextToSpeech.SUCCESS) synchronized(gate) { if (busy > 0) busy-- }
        } catch (e: Exception) {
            synchronized(gate) { if (busy > 0) busy-- }
        }
    }

    /** The one way the coach speaks. Counts wait their turn; sentences are never cut off by a number. */
    fun say(s: Say) {
        if (s.text.isBlank() || !enabled() || _status.value != VoiceStatus.READY) return
        if (s.kind == SayKind.COUNT) {
            val wait: Boolean
            synchronized(gate) {
                wait = busy > 0
                if (wait) { pendingCount = s.text; pendingAt = SystemClock.uptimeMillis() }
            }
            if (!wait) speakNow(s.text, false, true)
        } else {
            synchronized(gate) { pendingCount = null }
            speakNow(s.text, s.flush, false)
        }
    }

    /** Say [text]. [flush] cuts off what is being said now (used for the count). */
    fun speak(text: String, flush: Boolean) {
        if (text.isBlank() || !enabled() || _status.value != VoiceStatus.READY) return
        try {
            tts?.speak(text, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "kinetro")
        } catch (e: Exception) {
        }
    }

    /** Speak even if the coach is switched off (the Test button). */
    fun test(text: String) {
        if (_status.value != VoiceStatus.READY) return
        try { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kinetro-test") } catch (e: Exception) { }
    }

    fun stop() {
        synchronized(gate) { busy = 0; pendingCount = null }
        try { tts?.stop() } catch (e: Exception) { }
    }

    /** Opens the phone's voice settings so the Bengali voice can be downloaded. */
    fun openSettings(ctx: Context) {
        val intents = listOf(Intent("com.android.settings.TTS_SETTINGS"), Intent(android.provider.Settings.ACTION_SETTINGS))
        for (i in intents) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                return
            } catch (e: Exception) {
            }
        }
    }
}
