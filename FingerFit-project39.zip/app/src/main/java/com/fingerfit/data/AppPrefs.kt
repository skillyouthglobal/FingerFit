package com.fingerfit.data

import android.content.Context
import com.fingerfit.logic.Bn

/** Small first-run settings kept in plain SharedPreferences (read instantly at start). */
object AppPrefs {
    private fun sp(c: Context) = c.getSharedPreferences("kinetro_app", Context.MODE_PRIVATE)

    /** "" = not chosen yet, otherwise "bn" or "en". */
    fun lang(c: Context): String = sp(c).getString("lang", "") ?: ""
    fun setLang(c: Context, v: String) { sp(c).edit().putString("lang", v).apply(); Bn.bn = v == "bn" }

    fun termsAccepted(c: Context): Boolean = sp(c).getBoolean("terms_v1", false)
    fun setTermsAccepted(c: Context) { sp(c).edit().putBoolean("terms_v1", true).apply() }

    fun permsAsked(c: Context): Boolean = sp(c).getBoolean("perms_asked", false)
    fun setPermsAsked(c: Context) { sp(c).edit().putBoolean("perms_asked", true).apply() }

    fun lastCamUrl(c: Context): String = sp(c).getString("last_cam_url", "") ?: ""
    fun lastCamLabel(c: Context): String = sp(c).getString("last_cam_label", "") ?: ""
    fun setLastCamera(c: Context, url: String, label: String) { sp(c).edit().putString("last_cam_url", url).putString("last_cam_label", label).apply() }
    fun clearLastCamera(c: Context) { sp(c).edit().remove("last_cam_url").remove("last_cam_label").apply() }

    fun water(c: Context, date: String): Int = sp(c).getInt("water_$date", 0)
    fun setWater(c: Context, date: String, glasses: Int) { sp(c).edit().putInt("water_$date", glasses.coerceIn(0, 30)).apply() }

    fun voiceOn(c: Context): Boolean = sp(c).getBoolean("voice_on", true)
    fun setVoiceOn(c: Context, v: Boolean) { sp(c).edit().putBoolean("voice_on", v).apply() }
    /** 0 = slow, 1 = normal, 2 = fast. */
    fun voiceSpeed(c: Context): Int = sp(c).getInt("voice_speed", 1)
    fun setVoiceSpeed(c: Context, v: Int) { sp(c).edit().putInt("voice_speed", v).apply() }
    fun voiceName(c: Context, lang: String): String = sp(c).getString("voice_name_$lang", "") ?: ""
    fun setVoiceName(c: Context, lang: String, v: String) { sp(c).edit().putString("voice_name_$lang", v).apply() }

    // ---- personal reminders (kind = MORNING, EVENING, WEIGHT) ----
    fun nudgeDefaultMinute(kind: String): Int = when (kind) { "MORNING" -> 7 * 60 + 30; "EVENING" -> 19 * 60; else -> 8 * 60 + 30 }
    fun nudgeOn(c: Context, kind: String): Boolean = sp(c).getBoolean("nudge_on_$kind", true)
    fun setNudgeOn(c: Context, kind: String, v: Boolean) { sp(c).edit().putBoolean("nudge_on_$kind", v).apply() }
    fun nudgeMinute(c: Context, kind: String): Int = sp(c).getInt("nudge_min_$kind", nudgeDefaultMinute(kind)).coerceIn(0, 1439)
    fun setNudgeMinute(c: Context, kind: String, v: Int) { sp(c).edit().putInt("nudge_min_$kind", v.coerceIn(0, 1439)).apply() }
    /** The day the weight reminder was last shown (epoch day), so it is not repeated every day. */
    fun lastWeightNudge(c: Context): Long = sp(c).getLong("nudge_last_weight", -100L)
    fun setLastWeightNudge(c: Context, epochDay: Long) { sp(c).edit().putLong("nudge_last_weight", epochDay).apply() }

    /** Call once at start so non-UI code (notifications) also knows the language. */
    fun apply(c: Context) { Bn.bn = lang(c) == "bn" }
}
