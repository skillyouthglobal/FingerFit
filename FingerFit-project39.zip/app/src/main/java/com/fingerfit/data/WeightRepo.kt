package com.fingerfit.data

import android.content.Context
import android.content.SharedPreferences
import com.fingerfit.logic.WeightEntry
import com.fingerfit.logic.WeightLog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate

/** The weight history, one value per day. Stored only on this phone. */
object WeightRepo {
    private var prefs: SharedPreferences? = null
    private val _list = MutableStateFlow<List<WeightEntry>>(emptyList())
    val list: StateFlow<List<WeightEntry>> = _list.asStateFlow()

    @Synchronized
    fun init(context: Context) {
        if (prefs == null) {
            val p = context.applicationContext.getSharedPreferences("kinetro_weight", Context.MODE_PRIVATE)
            prefs = p
            _list.value = WeightLog.decode(p.getString("log", null))
        }
    }

    @Synchronized
    fun add(date: LocalDate, kg: Float) {
        if (kg !in 15f..300f) return
        val next = WeightLog.upsert(_list.value, WeightEntry(date, kg))
        _list.value = next
        prefs?.edit()?.putString("log", WeightLog.encode(next))?.apply()
    }

    /** The first time: start the history with the weight from the profile. */
    @Synchronized
    fun seedIfEmpty(kg: Float) {
        if (_list.value.isEmpty()) add(LocalDate.now(), kg)
    }
}
