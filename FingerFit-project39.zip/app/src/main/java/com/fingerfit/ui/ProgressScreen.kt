package com.fingerfit.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import com.fingerfit.logic.WeightLog
import com.fingerfit.logic.Nudges
import com.fingerfit.logic.Health
import com.fingerfit.data.WeightRepo
import com.fingerfit.data.ProfileRepo
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.data.Repo
import com.fingerfit.logic.Progress
import java.time.LocalDate

/** The "Progress" tab: what you did this week or this month, a streak, and small rewards. */
@Composable
fun ProgressScreen(vm: AppViewModel) {
    val workouts by Repo.workouts.collectAsStateWithLifecycle()
    val walks by Repo.walks.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    var month by rememberSaveable { mutableStateOf(false) }
    val settings by vm.settings.collectAsStateWithLifecycle()
    val profile by ProfileRepo.profile.collectAsStateWithLifecycle()
    val weights by WeightRepo.list.collectAsStateWithLifecycle()
    var logWeight by remember { mutableStateOf(false) }
    val today = LocalDate.now()
    val acts = remember(workouts, walks, history) { allActs(workouts, walks, history) }
    val days = if (month) 30 else 7
    val stats = remember(acts, days) { Progress.perDay(acts, today, days) }
    val streak = remember(acts) { Progress.streak(acts, today) }
    val todayMin = remember(acts) { Progress.perDay(acts, today, 1).last().minutes }
    val goal = settings.walkGoalMin
    val ring = Progress.ring(todayMin, goal)
    val fortnight = remember(acts) { Progress.weekCompare(Progress.perDay(acts, today, 14)) }
    val activeDays = stats.count { it.active }
    val totalMin = stats.sumOf { it.minutes }
    val totalReps = stats.sumOf { it.reps }
    val sessions = workouts.size + walks.size + history.size
    val km = walks.sumOf { it.meters.toDouble() } / 1000.0

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.statusBarsPadding()) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("Progress", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            val me = profile
            if (me != null) {
                Text(
                    "${Nudges.firstName(me.name, LangState.bn)}, here is how you are doing",
                    fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = HeroTint),
            ) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    val track = MaterialTheme.colorScheme.surface
                    val bar = MaterialTheme.colorScheme.tertiary
                    Box(Modifier.size(104.dp), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.size(104.dp)) {
                            val stroke = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                            val inset = 6.dp.toPx()
                            val arc = Size(size.width - 2 * inset, size.height - 2 * inset)
                            drawArc(track, -90f, 360f, false, Offset(inset, inset), arc, style = stroke)
                            if (ring > 0f) drawArc(bar, -90f, 360f * ring, false, Offset(inset, inset), arc, style = stroke)
                        }
                        Text("${(ring * 100).toInt()}%", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF12203F))
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Today", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF12203F))
                        Text("$todayMin of $goal min", fontSize = 15.sp, color = Color(0xFF12203F))
                        Text(
                            if (streak == 1) "🔥 1 day in a row" else "🔥 $streak days in a row",
                            fontSize = 14.sp, color = Color(0xFF3F4F70),
                        )
                        Text(
                            "This week ${fortnight.first} min · last week ${fortnight.second} min",
                            fontSize = 12.sp, color = Color(0xFF3F4F70),
                        )
                        if (fortnight.first > 0 || fortnight.second > 0) {
                            Text(
                                when {
                                    fortnight.first > fortnight.second -> "You did more than last week. Great!"
                                    fortnight.first < fortnight.second -> "A bit less than last week. You can catch up."
                                    else -> "Same as last week."
                                },
                                fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF12203F),
                            )
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !month, onClick = { month = false }, label = { Text("Week") })
                FilterChip(selected = month, onClick = { month = true }, label = { Text("Month") })
            }

            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            ) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Active minutes each day", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    BarChart(stats.map { it.minutes })
                    if (!month) {
                        Row(Modifier.fillMaxWidth()) {
                            stats.forEach { d ->
                                Text(
                                    dayName(d.date.dayOfWeek.value), fontSize = 11.sp, textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                    } else {
                        Text("Last 30 days", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SumTile("📅", "$activeDays of $days", "active days", Color(0xFFD8F5E6), Modifier.weight(1f))
                SumTile("⏱️", "$totalMin", "minutes", Color(0xFFE3ECFF), Modifier.weight(1f))
                SumTile("🔥", "$totalReps", "reps", Color(0xFFFFEFD9), Modifier.weight(1f))
            }

            if (me != null) {
                val latest = weights.lastOrNull()?.kg ?: me.weightKg
                val bmi = Health.bmi(latest, me.heightCm)
                val change = WeightLog.change(weights, 30, today)
                val range = Health.healthyRangeKg(me.heightCm)
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("⚖️ Weight", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                            Text(
                                String.format(java.util.Locale.US, "%.1f kg", latest),
                                fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = MaterialTheme.colorScheme.tertiary,
                            )
                        }
                        WeightChart(weights.takeLast(12).map { it.kg })
                        if (weights.size < 2) {
                            Text(
                                "Add your weight each week. The chart will show your progress.",
                                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        } else if (change != null) {
                            val c = String.format(java.util.Locale.US, "%.1f", kotlin.math.abs(change))
                            Text(
                                if (kotlin.math.abs(change) < 0.05f) "No change in the last 30 days"
                                else if (change < 0) "Down $c kg in the last 30 days"
                                else "Up $c kg in the last 30 days",
                                fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                            )
                        }
                        Text(
                            "BMI " + String.format(java.util.Locale.US, "%.1f", bmi) + " · " + Health.bmiCategory(bmi),
                            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            "Healthy range for your height: " + String.format(java.util.Locale.US, "%.0f to %.0f kg", range.first, range.second),
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        OutlinedButton(onClick = { logWeight = true }) { Text("Add today's weight") }
                    }
                }
            }

            Text("Your rewards", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SumTile("🏆", "$streak", if (streak == 1) "day in a row" else "days in a row", Color(0xFFFFF4D6), Modifier.weight(1f))
                SumTile("✅", "$sessions", "workouts and walks", Color(0xFFE3F1FF), Modifier.weight(1f))
                SumTile("👟", String.format(java.util.Locale.US, "%.1f", km), "km walked", Color(0xFFEDE7FF), Modifier.weight(1f))
            }

            Text(
                if (sessions == 0) "Your first workout will start your chart. Open the Exercise tab and begin."
                else if (streak >= 3) "Great! You are on a streak. Keep going."
                else "Every session counts. A little each day is the best habit.",
                fontSize = 14.sp, color = Color(0xFF3F4F70),
                modifier = Modifier.fillMaxWidth().background(Color(0xFFFFF4E0), RoundedCornerShape(18.dp)).padding(16.dp),
            )
        }
    }
    val p = profile
    if (logWeight && p != null) {
        WeightDialog(
            initial = weights.lastOrNull()?.kg ?: p.weightKg,
            onDismiss = { logWeight = false },
            onSave = { kg -> ProfileRepo.save(p.copy(weightKg = kg)); logWeight = false },
        )
    }
}

@Composable
private fun WeightChart(values: List<Float>) {
    val line = MaterialTheme.colorScheme.tertiary
    val dot = MaterialTheme.colorScheme.primary
    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
        if (values.size < 2) return@Canvas
        val mn = values.minOrNull() ?: 0f
        val mx = values.maxOrNull() ?: 0f
        val span = (mx - mn).coerceAtLeast(1f)
        val pad = 10.dp.toPx()
        fun px(i: Int) = pad + i * (size.width - 2 * pad) / (values.size - 1)
        fun py(v: Float) = size.height - pad - (v - mn) / span * (size.height - 2 * pad)
        for (i in 1 until values.size) {
            drawLine(line, Offset(px(i - 1), py(values[i - 1])), Offset(px(i), py(values[i])), 4.dp.toPx(), StrokeCap.Round)
        }
        values.forEachIndexed { i, v ->
            drawCircle(if (i == values.size - 1) dot else line, 5.dp.toPx(), Offset(px(i), py(v)))
        }
    }
}

@Composable
private fun WeightDialog(initial: Float, onDismiss: () -> Unit, onSave: (Float) -> Unit) {
    var text by remember { mutableStateOf(String.format(java.util.Locale.US, "%.1f", initial)) }
    val kg = text.replace(',', '.').toFloatOrNull()
    val ok = kg != null && kg in 15f..300f
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add today's weight") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    label = { Text("Weight (kg)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                )
                if (!ok) Text("Weight must be between 15 and 300 kg.", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { TextButton(onClick = { if (kg != null && ok) onSave(kg) }, enabled = ok) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

private fun dayName(isoDay: Int): String = when (isoDay) {
    1 -> "Mon"
    2 -> "Tue"
    3 -> "Wed"
    4 -> "Thu"
    5 -> "Fri"
    6 -> "Sat"
    else -> "Sun"
}

@Composable
private fun BarChart(values: List<Int>) {
    val bar = MaterialTheme.colorScheme.tertiary
    val last = MaterialTheme.colorScheme.primary
    val empty = MaterialTheme.colorScheme.surfaceVariant
    Canvas(Modifier.fillMaxWidth().height(140.dp)) {
        val n = values.size.coerceAtLeast(1)
        val top = (values.maxOrNull() ?: 0).coerceAtLeast(10).toFloat()
        val slot = size.width / n
        val w = slot * 0.62f
        values.forEachIndexed { i, v ->
            val h = if (v == 0) 6.dp.toPx() else (v / top) * (size.height - 8.dp.toPx()) + 6.dp.toPx()
            val x = i * slot + (slot - w) / 2f
            drawRoundRect(
                color = if (v == 0) empty else if (i == values.size - 1) last else bar,
                topLeft = Offset(x, size.height - h),
                size = Size(w, h),
                cornerRadius = CornerRadius(w / 2.5f, w / 2.5f),
            )
        }
    }
}

@Composable
private fun SumTile(emoji: String, value: String, label: String, tint: Color, modifier: Modifier) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = tint), modifier = modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 24.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = Color(0xFF12203F), maxLines = 1)
            Text(label, fontSize = 11.sp, color = Color(0xFF3F4F70), textAlign = TextAlign.Center, maxLines = 2, minLines = 2)
        }
    }
}
