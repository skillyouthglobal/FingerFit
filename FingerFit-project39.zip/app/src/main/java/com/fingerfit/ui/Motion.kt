package com.fingerfit.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay

/** Small motions that make the app feel alive: cards press in softly, and Home settles in once per launch. */
internal object Motion {
    var homePlayed = false
}

/** A click that shrinks the thing a little while it is held down. */
internal fun Modifier.bounceClick(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.96f else 1f, tween(120), label = "bounce")
    this
        .graphicsLayer { scaleX = sc; scaleY = sc }
        .clickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick)
}

/** Fades and slides a block up shortly after the screen opens, one after another by [index]. */
@Composable
internal fun Reveal(index: Int, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(Motion.homePlayed) }
    LaunchedEffect(Unit) {
        if (!shown) {
            delay(index * 80L)
            shown = true
        }
    }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(500), label = "reveal")
    Box(Modifier.graphicsLayer { alpha = a; translationY = (1f - a) * 36f }) { content() }
}

internal fun LazyListScope.revealItem(index: Int, content: @Composable () -> Unit) {
    item { Reveal(index, content) }
}
