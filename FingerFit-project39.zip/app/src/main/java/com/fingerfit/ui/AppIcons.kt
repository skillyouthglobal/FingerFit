package com.fingerfit.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

private class IconPart(val d: String, val fillAlpha: Float, val stroke: Boolean, val scaled: Boolean = false)

private fun svg(name: String, width: Float, vararg parts: IconPart): ImageVector {
    val b = ImageVector.Builder(name = name, defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f)
    parts.forEach { p ->
        val nodes = PathParser().parsePathString(p.d).toNodes()
        if (p.scaled) b.addGroup(scaleX = 0.92f, scaleY = 0.92f, translationX = 1f, translationY = 1f)
        b.addPath(
            pathData = nodes,
            fill = if (p.fillAlpha > 0f) SolidColor(Color.Black) else null,
            fillAlpha = if (p.fillAlpha > 0f) p.fillAlpha else 1f,
            stroke = if (p.stroke) SolidColor(Color.Black) else null,
            strokeLineWidth = width,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round,
        )
        if (p.scaled) b.clearGroup()
    }
    return b.build()
}

/** One consistent set of line icons from the brand designer. The colour comes from where they are used. */
internal object KIcon {
    val ArrowLeft: ImageVector = svg("arrow_left", 1.8f,
        IconPart("M20 12H4m6-6-6 6 6 6", 0f, true),
    )
    val ArrowRight: ImageVector = svg("arrow_right", 1.8f,
        IconPart("M4 12h16m-6-6 6 6-6 6", 0f, true),
    )
    val Bell: ImageVector = svg("bell", 1.8f,
        IconPart("M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9Z", 0.13f, false),
        IconPart("M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9Z", 0f, true),
        IconPart("M10 21h4", 0f, true),
    )
    val BellOff: ImageVector = svg("bell_off", 1.8f,
        IconPart("M18 9a6 6 0 0 0-10.8-3.6", 0f, true),
        IconPart("M6 9c0 7-3 7-3 9h14", 0f, true),
        IconPart("M14 21h-4", 0f, true),
        IconPart("m3 3 18 18", 0f, true),
        IconPart("M18 14c.4 2.2 2 2.5 3 4", 0f, true),
    )
    val Bulb: ImageVector = svg("bulb", 1.8f,
        IconPart("M8.2 14.5A7 7 0 1 1 15.8 14.5c-.8.7-1.2 1.4-1.3 2.5h-5c-.1-1.1-.5-1.8-1.3-2.5Z", 0.13f, false),
        IconPart("M9 18h6M10 21h4", 0f, true),
        IconPart("M8.2 14.5A7 7 0 1 1 15.8 14.5c-.8.7-1.2 1.4-1.3 2.5h-5c-.1-1.1-.5-1.8-1.3-2.5Z", 0f, true),
    )
    val Calendar: ImageVector = svg("calendar", 1.8f,
        IconPart("M5 5h14a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2z", 0.13f, false),
        IconPart("M5 5h14a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2z", 0f, true),
        IconPart("M7 3v4M17 3v4M3 10h18M7 14h2m3 0h2m-7 4h2m3 0h2", 0f, true),
    )
    val Camera: ImageVector = svg("camera", 1.8f,
        IconPart("M3 8h4l2-3h6l2 3h4v12H3Z", 0.13f, false),
        IconPart("M8 14a4 4 0 1 0 8 0a4 4 0 1 0 -8 0z", 0.13f, false),
        IconPart("M3 8h4l2-3h6l2 3h4v12H3Z", 0f, true),
        IconPart("M8 14a4 4 0 1 0 8 0a4 4 0 1 0 -8 0z", 0f, true),
    )
    val CameraFlip: ImageVector = svg("camera_flip", 1.8f,
        IconPart("M3 8h4l2-3h6l2 3h4v11H3Z", 0.13f, false),
        IconPart("M8.5 13.5a3.5 3.5 0 1 0 7 0a3.5 3.5 0 1 0 -7 0z", 0.13f, false),
        IconPart("M3 8h4l2-3h6l2 3h4v11H3Z", 0f, true),
        IconPart("M8.5 13.5a3.5 3.5 0 1 0 7 0a3.5 3.5 0 1 0 -7 0z", 0f, true),
        IconPart("M7 3 4 5l3 2M17 21l3-2-3-2", 0f, true),
    )
    val Cctv: ImageVector = svg("cctv", 1.8f,
        IconPart("m3 9 13-4 3 7-13 4Z", 0.13f, false),
        IconPart("m3 9 13-4 3 7-13 4Z", 0f, true),
        IconPart("m7 15-2 5M16 12l4 7M19 7l2-2", 0f, true),
        IconPart("M3 9 2 6l13-4 1 3", 0f, true),
    )
    val Check: ImageVector = svg("check", 1.8f,
        IconPart("m4 12 5 5L20 6", 0f, true),
    )
    val ChevronDown: ImageVector = svg("chevron_down", 1.8f,
        IconPart("m6 9 6 6 6-6", 0f, true),
    )
    val ChevronLeft: ImageVector = svg("chevron_left", 1.8f,
        IconPart("m15 18-6-6 6-6", 0f, true),
    )
    val ChevronRight: ImageVector = svg("chevron_right", 1.8f,
        IconPart("m9 18 6-6-6-6", 0f, true),
    )
    val Clipboard: ImageVector = svg("clipboard", 1.8f,
        IconPart("M7 4h10a2 2 0 0 1 2 2v13a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-13a2 2 0 0 1 2 -2z", 0.13f, false),
        IconPart("M7 4h10a2 2 0 0 1 2 2v13a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-13a2 2 0 0 1 2 -2z", 0f, true),
        IconPart("M9 4.5V3h6v1.5M8 9h8M8 13h8M8 17h5", 0f, true),
    )
    val Clock: ImageVector = svg("clock", 1.8f,
        IconPart("M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0z", 0.13f, false),
        IconPart("M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0z", 0f, true),
        IconPart("M12 7v5l3.5 2", 0f, true),
    )
    val Close: ImageVector = svg("close", 1.8f,
        IconPart("m5 5 14 14M19 5 5 19", 0f, true),
    )
    val Diet: ImageVector = svg("diet", 1.8f,
        IconPart("M17 9c-1.5-1-3.2-1-4.6 0-2.4 1.7-2.7 5-.9 7.8 1 1.6 2.2 2.6 3.8 2.1.8-.3 1.5-.3 2.3 0 1.6.5 2.9-.5 3.8-2.1 1.8-2.8 1.5-6.1-.9-7.8-1.4-1-3.1-1-4.6 0Z", 0.13f, false),
        IconPart("M4 3v7M7 3v7M10 3v7M7 10v11", 0f, true),
        IconPart("M17 9c-1.5-1-3.2-1-4.6 0-2.4 1.7-2.7 5-.9 7.8 1 1.6 2.2 2.6 3.8 2.1.8-.3 1.5-.3 2.3 0 1.6.5 2.9-.5 3.8-2.1 1.8-2.8 1.5-6.1-.9-7.8-1.4-1-3.1-1-4.6 0Z", 0f, true),
        IconPart("M16 8c0-2 1.1-3.5 3.2-4.5M18 5c1.2-1.3 2.8-1.5 4-1", 0f, true),
    )
    val Download: ImageVector = svg("download", 1.8f,
        IconPart("M12 3v12m-5-5 5 5 5-5", 0f, true),
        IconPart("M4 17v4h16v-4", 0f, true),
    )
    val Drop: ImageVector = svg("drop", 1.8f,
        IconPart("M12 2.5S5 10 5 14.5a7 7 0 0 0 14 0C19 10 12 2.5 12 2.5Z", 0.13f, false),
        IconPart("M12 2.5S5 10 5 14.5a7 7 0 0 0 14 0C19 10 12 2.5 12 2.5Z", 0f, true),
        IconPart("M9 15a3 3 0 0 0 3 3", 0f, true),
    )
    val Edit: ImageVector = svg("edit", 1.8f,
        IconPart("m4 16.5-.8 4.3 4.3-.8L19 8.5 15.5 5Z", 0.13f, false),
        IconPart("m4 16.5-.8 4.3 4.3-.8L19 8.5 15.5 5Z", 0f, true),
        IconPart("m13.8 6.7 3.5 3.5M4 21h16", 0f, true),
    )
    val Exercise: ImageVector = svg("exercise", 1.8f,
        IconPart("M6 5v14M18 5v14M3.5 8v8M20.5 8v8M6 12h12", 0f, true),
        IconPart("M3.5 10h2.5M3.5 14h2.5M18 10h2.5M18 14h2.5", 0f, true),
    )
    val Filter: ImageVector = svg("filter", 1.8f,
        IconPart("M6.5 5a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0 -3 0z", 0.13f, false),
        IconPart("M13.5 12a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0 -3 0z", 0.13f, false),
        IconPart("M9.5 19a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0 -3 0z", 0.13f, false),
        IconPart("M3 5h18M6 12h12m-9 7h6", 0f, true),
        IconPart("M6.5 5a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0 -3 0z", 0f, true),
        IconPart("M13.5 12a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0 -3 0z", 0f, true),
        IconPart("M9.5 19a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0 -3 0z", 0f, true),
    )
    val Flame: ImageVector = svg("flame", 1.8f,
        IconPart("M12 22c4.2 0 7-2.8 7-6.7 0-3-1.7-5.2-4.2-7.8.1 2.3-1 3.4-2 4.1C12.6 7.2 10.6 4 8 2c.2 4.4-3 7-3 12.1C5 18.5 7.8 22 12 22Z", 0.13f, false),
        IconPart("M12 22c-1.7 0-2.8-1.2-2.8-2.8 0-1.5 1-2.8 2.8-4.2 1.8 1.4 2.8 2.7 2.8 4.2 0 1.6-1.1 2.8-2.8 2.8Z", 0.13f, false),
        IconPart("M12 22c4.2 0 7-2.8 7-6.7 0-3-1.7-5.2-4.2-7.8.1 2.3-1 3.4-2 4.1C12.6 7.2 10.6 4 8 2c.2 4.4-3 7-3 12.1C5 18.5 7.8 22 12 22Z", 0f, true),
        IconPart("M12 22c-1.7 0-2.8-1.2-2.8-2.8 0-1.5 1-2.8 2.8-4.2 1.8 1.4 2.8 2.7 2.8 4.2 0 1.6-1.1 2.8-2.8 2.8Z", 0f, true),
    )
    val Heart: ImageVector = svg("heart", 1.8f,
        IconPart("M20.8 8.8c0 5.2-8.8 11-8.8 11S3.2 14 3.2 8.8A4.8 4.8 0 0 1 12 6.1a4.8 4.8 0 0 1 8.8 2.7Z", 0.13f, false),
        IconPart("M20.8 8.8c0 5.2-8.8 11-8.8 11S3.2 14 3.2 8.8A4.8 4.8 0 0 1 12 6.1a4.8 4.8 0 0 1 8.8 2.7Z", 0f, true),
    )
    val HeartFilled: ImageVector = svg("heart_filled", 1.8f,
        IconPart("M20.8 8.8c0 5.2-8.8 11-8.8 11S3.2 14 3.2 8.8A4.8 4.8 0 0 1 12 6.1a4.8 4.8 0 0 1 8.8 2.7Z", 0.9f, true),
    )
    val Home: ImageVector = svg("home", 1.8f,
        IconPart("M3 10.5 12 3l9 7.5", 0f, true),
        IconPart("M5 9.5V21h14V9.5", 0f, true),
        IconPart("M9 21v-7h6v7", 0f, true),
    )
    val Info: ImageVector = svg("info", 1.8f,
        IconPart("M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0z", 0.13f, false),
        IconPart("M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0z", 0f, true),
        IconPart("M12 11v5M12 7h.01", 0f, true),
    )
    val Language: ImageVector = svg("language", 1.8f,
        IconPart("M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0z", 0.13f, false),
        IconPart("M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0z", 0f, true),
        IconPart("M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18M7 7h10M7 17h10", 0f, true),
    )
    val Lock: ImageVector = svg("lock", 1.8f,
        IconPart("M6 10h12a2 2 0 0 1 2 2v7a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-7a2 2 0 0 1 2 -2z", 0.13f, false),
        IconPart("M6 10h12a2 2 0 0 1 2 2v7a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-7a2 2 0 0 1 2 -2z", 0f, true),
        IconPart("M8 10V7a4 4 0 0 1 8 0v3M12 14v3", 0f, true),
    )
    val Medal: ImageVector = svg("medal", 1.8f,
        IconPart("M7 9a5 5 0 1 0 10 0a5 5 0 1 0 -10 0z", 0.13f, false),
        IconPart("M7 9a5 5 0 1 0 10 0a5 5 0 1 0 -10 0z", 0f, true),
        IconPart("m8.5 13-2 8 5.5-3 5.5 3-2-8", 0f, true),
        IconPart("m10 9 1.3 1.3L14 7.5", 0f, true),
    )
    val Mic: ImageVector = svg("mic", 1.8f,
        IconPart("M12 2h0a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-0a3 3 0 0 1 -3 -3v-6a3 3 0 0 1 3 -3z", 0.13f, false),
        IconPart("M12 2h0a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-0a3 3 0 0 1 -3 -3v-6a3 3 0 0 1 3 -3z", 0f, true),
        IconPart("M5 11a7 7 0 0 0 14 0M12 18v4m-4 0h8", 0f, true),
    )
    val Minus: ImageVector = svg("minus", 1.8f,
        IconPart("M5 12h14", 0f, true),
    )
    val Moon: ImageVector = svg("moon", 1.8f,
        IconPart("M20.5 15.5A8.5 8.5 0 0 1 8.5 3.5 9 9 0 1 0 20.5 15.5Z", 0.13f, false),
        IconPart("M20.5 15.5A8.5 8.5 0 0 1 8.5 3.5 9 9 0 1 0 20.5 15.5Z", 0f, true),
    )
    val Pause: ImageVector = svg("pause", 1.8f,
        IconPart("M7 4h3v16H7zM14 4h3v16h-3z", 0.13f, false),
        IconPart("M7 4h3v16H7zM14 4h3v16h-3z", 0f, true),
    )
    val PhoneCamera: ImageVector = svg("phone_camera", 1.8f,
        IconPart("M8 2h8a2 2 0 0 1 2 2v16a2 2 0 0 1 -2 2h-8a2 2 0 0 1 -2 -2v-16a2 2 0 0 1 2 -2z", 0.13f, false),
        IconPart("M9.5 17a2.5 2.5 0 1 0 5 0a2.5 2.5 0 1 0 -5 0z", 0.13f, false),
        IconPart("M8 2h8a2 2 0 0 1 2 2v16a2 2 0 0 1 -2 2h-8a2 2 0 0 1 -2 -2v-16a2 2 0 0 1 2 -2z", 0f, true),
        IconPart("M10 5h4", 0f, true),
        IconPart("M9.5 17a2.5 2.5 0 1 0 5 0a2.5 2.5 0 1 0 -5 0z", 0f, true),
    )
    val Play: ImageVector = svg("play", 1.8f,
        IconPart("m7 4 13 8-13 8Z", 0.13f, false),
        IconPart("m7 4 13 8-13 8Z", 0f, true),
    )
    val Plus: ImageVector = svg("plus", 1.8f,
        IconPart("M12 5v14M5 12h14", 0f, true),
    )
    val Profile: ImageVector = svg("profile", 1.8f,
        IconPart("M8 8a4 4 0 1 0 8 0a4 4 0 1 0 -8 0z", 0.13f, false),
        IconPart("M8 8a4 4 0 1 0 8 0a4 4 0 1 0 -8 0z", 0f, true),
        IconPart("M4 21c.7-4 3.4-6 8-6s7.3 2 8 6", 0f, true),
    )
    val Progress: ImageVector = svg("progress", 1.8f,
        IconPart("M4 20V11M10 20V7M16 20V4M22 20H2", 0f, true),
        IconPart("m3 8 5-3 5 1 7-4", 0f, true),
    )
    val Refresh: ImageVector = svg("refresh", 1.8f,
        IconPart("M20 7v5h-5M4 17v-5h5", 0f, true),
        IconPart("M5.5 9A7 7 0 0 1 18 6l2 2M4 16l2 2a7 7 0 0 0 12.5-3", 0f, true),
    )
    val Repeat: ImageVector = svg("repeat", 1.8f,
        IconPart("M17 2l4 4-4 4M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4m14-1v2a3 3 0 0 1-3 3H3", 0f, true),
    )
    val Ruler: ImageVector = svg("ruler", 1.8f,
        IconPart("M4 20V4M20 20V4M4 20h16M4 16h4m-4-4h3m-3-4h4m-4-4h3m9 16h4", 0f, true),
        IconPart("m9 7 3-3 3 3M12 4v12", 0f, true),
    )
    val Run: ImageVector = svg("run", 1.8f,
        IconPart("M13 4a2 2 0 1 0 4 0a2 2 0 1 0 -4 0z", 0.13f, false),
        IconPart("M13 4a2 2 0 1 0 4 0a2 2 0 1 0 -4 0z", 0f, true),
        IconPart("m12 8 3 2 3 4M12 8l-3 5 4 2-2 6M9 13l-5 2M15 10l-2 5 5 2", 0f, true),
    )
    val Scale: ImageVector = svg("scale", 1.8f,
        IconPart("M6 4h12a3 3 0 0 1 3 3v11a3 3 0 0 1 -3 3h-12a3 3 0 0 1 -3 -3v-11a3 3 0 0 1 3 -3z", 0.13f, false),
        IconPart("M8 8h8l1 4H7Z", 0.13f, false),
        IconPart("M6 4h12a3 3 0 0 1 3 3v11a3 3 0 0 1 -3 3h-12a3 3 0 0 1 -3 -3v-11a3 3 0 0 1 3 -3z", 0f, true),
        IconPart("M8 8h8l1 4H7Z", 0f, true),
        IconPart("m12 8 1.5 2", 0f, true),
    )
    val Search: ImageVector = svg("search", 1.8f,
        IconPart("M3.8 10.8a7 7 0 1 0 14 0a7 7 0 1 0 -14 0z", 0.13f, false),
        IconPart("M3.8 10.8a7 7 0 1 0 14 0a7 7 0 1 0 -14 0z", 0f, true),
        IconPart("m16 16 5 5", 0f, true),
    )
    val Settings: ImageVector = svg("settings", 1.8f,
        IconPart("M9 12a3 3 0 1 0 6 0a3 3 0 1 0 -6 0z", 0.13f, false),
        IconPart("m19.4 15 .1.1 1.2 2.1-2 2-2.2-1.2-.2-.1a7.8 7.8 0 0 1-2 .8l-.1.1L13.8 21h-3.6l-.4-2.3-.2-.1a7.8 7.8 0 0 1-2-.8l-.2.1-2.2 1.2-2-2 1.2-2.1.1-.2a7.8 7.8 0 0 1-.8-2l-.1-.1L1.5 12l.3-3.5 2.3-.4.1-.2a7.8 7.8 0 0 1 .8-2l-.1-.2-1.2-2.2 2-2 2.1 1.2.2.1a7.8 7.8 0 0 1 2-.8l.1-.1L10.5 0h3.6l.4 2.3.2.1a7.8 7.8 0 0 1 2 .8l.2-.1L19 1.9l2 2-1.2 2.1-.1.2a7.8 7.8 0 0 1 .8 2l.1.1 2.3.4-.3 3.5-2.3.4-.1.2a7.8 7.8 0 0 1-.8 2Z", 0.13f, false, true),
        IconPart("M9 12a3 3 0 1 0 6 0a3 3 0 1 0 -6 0z", 0f, true),
        IconPart("m19.4 15 .1.1 1.2 2.1-2 2-2.2-1.2-.2-.1a7.8 7.8 0 0 1-2 .8l-.1.1L13.8 21h-3.6l-.4-2.3-.2-.1a7.8 7.8 0 0 1-2-.8l-.2.1-2.2 1.2-2-2 1.2-2.1.1-.2a7.8 7.8 0 0 1-.8-2l-.1-.1L1.5 12l.3-3.5 2.3-.4.1-.2a7.8 7.8 0 0 1 .8-2l-.1-.2-1.2-2.2 2-2 2.1 1.2.2.1a7.8 7.8 0 0 1 2-.8l.1-.1L10.5 0h3.6l.4 2.3.2.1a7.8 7.8 0 0 1 2 .8l.2-.1L19 1.9l2 2-1.2 2.1-.1.2a7.8 7.8 0 0 1 .8 2l.1.1 2.3.4-.3 3.5-2.3.4-.1.2a7.8 7.8 0 0 1-.8 2Z", 0f, true, true),
    )
    val Share: ImageVector = svg("share", 1.8f,
        IconPart("M15 5a3 3 0 1 0 6 0a3 3 0 1 0 -6 0z", 0.13f, false),
        IconPart("M3 12a3 3 0 1 0 6 0a3 3 0 1 0 -6 0z", 0.13f, false),
        IconPart("M15 19a3 3 0 1 0 6 0a3 3 0 1 0 -6 0z", 0.13f, false),
        IconPart("M15 5a3 3 0 1 0 6 0a3 3 0 1 0 -6 0z", 0f, true),
        IconPart("M3 12a3 3 0 1 0 6 0a3 3 0 1 0 -6 0z", 0f, true),
        IconPart("M15 19a3 3 0 1 0 6 0a3 3 0 1 0 -6 0z", 0f, true),
        IconPart("m8.7 10.7 6.6-4.4m-6.6 7 6.6 4.1", 0f, true),
    )
    val Shield: ImageVector = svg("shield", 1.8f,
        IconPart("M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z", 0.13f, false),
        IconPart("M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z", 0f, true),
        IconPart("m9 12 2 2 4-4", 0f, true),
    )
    val Sound: ImageVector = svg("sound", 1.8f,
        IconPart("M4 10v4h4l5 4V6l-5 4Z", 0.13f, false),
        IconPart("M4 10v4h4l5 4V6l-5 4Z", 0f, true),
        IconPart("M17 9a5 5 0 0 1 0 6m2-9a9 9 0 0 1 0 12", 0f, true),
    )
    val Star: ImageVector = svg("star", 1.8f,
        IconPart("m12 3 2.7 5.5 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1-4.4-4.3 6.1-.9Z", 0.13f, false),
        IconPart("m12 3 2.7 5.5 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1-4.4-4.3 6.1-.9Z", 0f, true),
    )
    val Stop: ImageVector = svg("stop", 1.8f,
        IconPart("M6 5h12a1 1 0 0 1 1 1v12a1 1 0 0 1 -1 1h-12a1 1 0 0 1 -1 -1v-12a1 1 0 0 1 1 -1z", 0.13f, false),
        IconPart("M6 5h12a1 1 0 0 1 1 1v12a1 1 0 0 1 -1 1h-12a1 1 0 0 1 -1 -1v-12a1 1 0 0 1 1 -1z", 0f, true),
    )
    val Stopwatch: ImageVector = svg("stopwatch", 1.8f,
        IconPart("M4 13a8 8 0 1 0 16 0a8 8 0 1 0 -16 0z", 0.13f, false),
        IconPart("M4 13a8 8 0 1 0 16 0a8 8 0 1 0 -16 0z", 0f, true),
        IconPart("M12 13 15 10M9 2h6M12 2v3M19 6l1.5-1.5", 0f, true),
    )
    val Target: ImageVector = svg("target", 1.8f,
        IconPart("M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0z", 0.13f, false),
        IconPart("M7 12a5 5 0 1 0 10 0a5 5 0 1 0 -10 0z", 0.13f, false),
        IconPart("M11 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0z", 0.13f, false),
        IconPart("M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0z", 0f, true),
        IconPart("M7 12a5 5 0 1 0 10 0a5 5 0 1 0 -10 0z", 0f, true),
        IconPart("M11 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0z", 0f, true),
        IconPart("m13 11 7-7m-3 0h3v3", 0f, true),
    )
    val Theme: ImageVector = svg("theme", 1.8f,
        IconPart("M4.5 8a3.5 3.5 0 1 0 7 0a3.5 3.5 0 1 0 -7 0z", 0.13f, false),
        IconPart("M21 15.5A6.5 6.5 0 0 1 12.5 7a7 7 0 1 0 8.5 8.5Z", 0.13f, false),
        IconPart("M4.5 8a3.5 3.5 0 1 0 7 0a3.5 3.5 0 1 0 -7 0z", 0f, true),
        IconPart("M8 1v2M8 13v2M1 8h2m10 0h2M3 3l1.5 1.5m7 7L13 13M3 13l1.5-1.5", 0f, true),
        IconPart("M21 15.5A6.5 6.5 0 0 1 12.5 7a7 7 0 1 0 8.5 8.5Z", 0f, true),
    )
    val Trash: ImageVector = svg("trash", 1.8f,
        IconPart("M3 6h18M8 6V4h8v2M6 6l1 15h10l1-15M10 10v7M14 10v7", 0f, true),
    )
    val Trophy: ImageVector = svg("trophy", 1.8f,
        IconPart("M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0Z", 0.13f, false),
        IconPart("M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0Z", 0f, true),
        IconPart("M7 6H4v2a4 4 0 0 0 4 4M17 6h3v2a4 4 0 0 1-4 4", 0f, true),
    )
    val Walk: ImageVector = svg("walk", 1.8f,
        IconPart("M11 4a2 2 0 1 0 4 0a2 2 0 1 0 -4 0z", 0.13f, false),
        IconPart("M11 4a2 2 0 1 0 4 0a2 2 0 1 0 -4 0z", 0f, true),
        IconPart("m11 8-2 5 3 2 1 6M11 10l4 2 3 4M9 13l-4 5M14 7l3 3", 0f, true),
    )
    val Wifi: ImageVector = svg("wifi", 1.8f,
        IconPart("M2 8.5a16 16 0 0 1 20 0M5 12a11 11 0 0 1 14 0M8.5 15.5a6 6 0 0 1 7 0", 0f, true),
        IconPart("M12 20h.01", 0f, true),
    )
    val Chevron: ImageVector get() = ChevronRight
    val Arrow: ImageVector get() = ArrowRight
}
