package com.fingerfit.ui

import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

internal fun strokeIcon(name: String, vararg paths: String): ImageVector {
    val b = ImageVector.Builder(
        name = name, defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f,
    )
    paths.forEach { d ->
        b.addPath(
            pathData = PathParser().parsePathString(d).toNodes(),
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round,
        )
    }
    return b.build()
}

internal val HomeIcon: ImageVector get() = KIcon.Home
internal val WorkoutIcon: ImageVector get() = KIcon.Exercise
internal val DietIcon: ImageVector get() = KIcon.Diet
internal val ProgressIcon: ImageVector get() = KIcon.Progress
internal val ProfileIcon: ImageVector get() = KIcon.Profile

object Tabs {
    const val HOME = 0
    const val WORKOUTS = 1
    const val DIET = 2
    const val PROGRESS = 3
    const val PROFILE = 4
}

private class TabItem(val label: String, val icon: ImageVector)

private val ITEMS = listOf(
    TabItem("Home", HomeIcon),
    TabItem("Exercise", WorkoutIcon),
    TabItem("Diet", DietIcon),
    TabItem("Progress", ProgressIcon),
    TabItem("Profile", ProfileIcon),
)

/** The bottom bar with the five main sections. */
@Composable
fun KinetroNavBar(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        ITEMS.forEachIndexed { i, item ->
            NavigationBarItem(
                selected = selected == i,
                onClick = { onSelect(i) },
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { com.fingerfit.ui.Text(item.label, fontSize = 11.sp, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.tertiary,
                    selectedTextColor = MaterialTheme.colorScheme.tertiary,
                    indicatorColor = HeroTint,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                ),
            )
        }
    }
}
