package com.fingerfit.ui

import com.fingerfit.R

/** Real photos of each exercise. A missing photo simply shows a line icon instead. */
internal object ExerciseImages {
    private val map: Map<String, Int> = mapOf(
        "BICEPS_CURL" to R.drawable.ex_biceps_curl,
        "BULGARIAN_SPLIT_SQUAT" to R.drawable.ex_bulgarian_split_squat,
        "BURPEE" to R.drawable.ex_burpee,
        "BUTT_KICKS" to R.drawable.ex_butt_kicks,
        "CALF_RAISES" to R.drawable.ex_calf_raises,
        "CHILD_POSE" to R.drawable.ex_child_pose,
        "COBRA_STRETCH" to R.drawable.ex_cobra_stretch,
        "CRUNCHES" to R.drawable.ex_crunches,
        "DECLINE_PUSHUPS" to R.drawable.ex_decline_pushups,
        "DOWNWARD_DOG" to R.drawable.ex_downward_dog,
        "FINGER_EXERCISE" to R.drawable.ex_finger_exercise,
        "FLUTTER_KICKS" to R.drawable.ex_flutter_kicks,
        "FRONT_RAISE" to R.drawable.ex_front_raise,
        "GLUTE_BRIDGES" to R.drawable.ex_glute_bridges,
        "GOOD_MORNING" to R.drawable.ex_good_morning,
        "HIGH_KNEES" to R.drawable.ex_high_knees,
        "HOLLOW_BODY_HOLD" to R.drawable.ex_hollow_body_hold,
        "INCHWORM" to R.drawable.ex_inchworm,
        "INCLINE_PUSHUPS" to R.drawable.ex_incline_pushups,
        "JUMP_ROPE" to R.drawable.ex_jump_rope,
        "JUMPING_JACKS" to R.drawable.ex_jumping_jacks,
        "LATERAL_RAISE" to R.drawable.ex_lateral_raise,
        "LEG_RAISE" to R.drawable.ex_leg_raise,
        "LUNGES" to R.drawable.ex_lunges,
        "PIKE_PUSHUPS" to R.drawable.ex_pike_pushups,
        "PLANK" to R.drawable.ex_plank,
        "PUSH_UPS" to R.drawable.ex_push_ups,
        "RUSSIAN_TWIST" to R.drawable.ex_russian_twist,
        "SCISSOR_KICKS" to R.drawable.ex_scissor_kicks,
        "SIDE_LEG_RAISES" to R.drawable.ex_side_leg_raises,
        "SIDE_SHUFFLE" to R.drawable.ex_side_shuffle,
        "SIT_TO_STAND" to R.drawable.ex_sit_to_stand,
        "SKATER_HOPS" to R.drawable.ex_skater_hops,
        "SL_RDL" to R.drawable.ex_sl_rdl,
        "SQUAT_PULSES" to R.drawable.ex_squat_pulses,
        "SQUAT_THRUST" to R.drawable.ex_squat_thrust,
        "SQUATS" to R.drawable.ex_squats,
        "TIBIALIS_RAISE" to R.drawable.ex_tibialis_raise,
        "TRICEPS_EXTENSION" to R.drawable.ex_triceps_extension,
        "V_UPS" to R.drawable.ex_v_ups,
        "WALKING_TOE_TOUCH" to R.drawable.ex_walking_toe_touch,
    )

    fun of(typeName: String?): Int? = if (typeName == null) null else map[typeName]
}
