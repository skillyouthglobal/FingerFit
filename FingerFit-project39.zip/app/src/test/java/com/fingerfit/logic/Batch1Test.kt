package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private const val BW = 480f
private const val BH = 640f

private fun bpts(vararg parts: Triple<Int, Float, Float>): List<BodyPoint> {
    val a = Array(33) { BodyPoint(0f, 0f, 0f) }
    parts.forEach { a[it.first] = BodyPoint(it.second, it.third, 1f) }
    return a.toList()
}

private fun bp(i: Int, x: Float, y: Float) = Triple(i, x, y)

private class Bn1(type: ExerciseType) {
    val engine = ExerciseEngine(type)
    var t = 1_000L
    var last: ExerciseEngine.Out? = null
    fun feed(p: List<BodyPoint>?, frames: Int) { repeat(frames) { last = engine.update(p, BW, BH, t, false); t += 33L } }
}

/** Front view: shoulders, hips, both arms with elbow and wrist given. */
private fun arms(ey: Float, ex: Float, wy: Float, wx: Float) = bpts(
    bp(11, 0.43f, 0.30f), bp(12, 0.57f, 0.30f), bp(23, 0.45f, 0.50f), bp(24, 0.55f, 0.50f),
    bp(13, 0.43f + ex, ey), bp(14, 0.57f - ex, ey), bp(15, 0.43f + wx, wy), bp(16, 0.57f - wx, wy),
)

private fun kick(l: Boolean, r: Boolean) = bpts(
    bp(11, 0.43f, 0.30f), bp(12, 0.57f, 0.30f), bp(23, 0.45f, 0.50f), bp(24, 0.55f, 0.50f),
    bp(25, 0.45f, 0.69f), bp(26, 0.55f, 0.69f),
    bp(27, 0.45f, if (l) 0.71f else 0.88f), bp(28, 0.55f, if (r) 0.71f else 0.88f),
)

private fun hinge(bent: Boolean) = bpts(
    bp(11, if (bent) 0.72f else 0.50f, if (bent) 0.42f else 0.30f), bp(12, if (bent) 0.72f else 0.50f, if (bent) 0.42f else 0.30f),
    bp(23, 0.5f, 0.50f), bp(24, 0.5f, 0.50f), bp(25, 0.5f, 0.69f), bp(26, 0.5f, 0.69f),
)

private fun lying(up: Boolean) = bpts(
    bp(11, 0.20f, 0.70f), bp(12, 0.20f, 0.70f), bp(23, 0.42f, 0.70f), bp(24, 0.42f, 0.70f),
    bp(25, if (up) 0.42f else 0.62f, if (up) 0.52f else 0.70f), bp(26, if (up) 0.42f else 0.62f, if (up) 0.52f else 0.70f),
    bp(27, if (up) 0.42f else 0.82f, if (up) 0.34f else 0.70f), bp(28, if (up) 0.42f else 0.82f, if (up) 0.34f else 0.70f),
)

private fun incline(bottom: Boolean) = bpts(
    bp(11, 0.70f, 0.45f), bp(12, 0.70f, 0.45f), bp(23, 0.40f, 0.60f), bp(24, 0.40f, 0.60f),
    bp(27, 0.12f, 0.75f), bp(28, 0.12f, 0.75f),
    bp(13, if (bottom) 0.60f else 0.71f, if (bottom) 0.55f else 0.54f), bp(14, if (bottom) 0.60f else 0.71f, if (bottom) 0.55f else 0.54f),
    bp(15, 0.72f, 0.63f), bp(16, 0.72f, 0.63f),
)

class Batch1Test {
    private fun read(t: ExerciseType, p: List<BodyPoint>) = BodyClassifier.read(t, p, BW, BH)

    @Test fun curlStatesAndCount() {
        val down = arms(0.42f, 0f, 0.54f, 0f)
        val up = arms(0.42f, 0f, 0.31f, 0f)
        assertEquals(Pose.OPEN, read(ExerciseType.BICEPS_CURL, down).pose)
        assertEquals(Pose.CLOSED, read(ExerciseType.BICEPS_CURL, up).pose)
        val r = Bn1(ExerciseType.BICEPS_CURL)
        r.feed(down, 10)
        repeat(5) { r.feed(up, 8); r.feed(down, 8) }
        assertEquals(5, r.engine.reps)
    }

    @Test fun halfCurlIsNotCounted() {
        val down = arms(0.42f, 0f, 0.54f, 0f)
        val half = arms(0.42f, 0.06f, 0.46f, 0.12f)
        val r = Bn1(ExerciseType.BICEPS_CURL)
        r.feed(down, 10); r.feed(half, 10); r.feed(down, 10)
        assertEquals(0, r.engine.reps)
    }

    @Test fun tricepsStatesAndCount() {
        val up = arms(0.18f, 0f, 0.06f, 0f)
        val bent = arms(0.18f, 0f, 0.27f, 0.02f)
        val armsDown = arms(0.42f, 0f, 0.54f, 0f)
        assertEquals(Pose.OPEN, read(ExerciseType.TRICEPS_EXTENSION, up).pose)
        assertEquals(Pose.CLOSED, read(ExerciseType.TRICEPS_EXTENSION, bent).pose)
        assertEquals(Pose.UNKNOWN, read(ExerciseType.TRICEPS_EXTENSION, armsDown).pose)
        val r = Bn1(ExerciseType.TRICEPS_EXTENSION)
        r.feed(up, 10)
        repeat(4) { r.feed(bent, 8); r.feed(up, 8) }
        assertEquals(4, r.engine.reps)
    }

    @Test fun armRaisesCountAndLowOnesDoNot() {
        val down = arms(0.40f, 0f, 0.52f, 0f)
        val high = arms(0.30f, 0.06f, 0.30f, 0.14f)
        val low = arms(0.38f, 0.03f, 0.42f, 0.06f)
        for (t in listOf(ExerciseType.FRONT_RAISE, ExerciseType.LATERAL_RAISE)) {
            assertEquals(Pose.OPEN, read(t, down).pose)
            assertEquals(Pose.CLOSED, read(t, high).pose)
            val r = Bn1(t)
            r.feed(down, 10)
            repeat(6) { r.feed(high, 8); r.feed(down, 8) }
            assertEquals(6, r.engine.reps)
            val q = Bn1(t)
            q.feed(down, 10); q.feed(low, 10); q.feed(down, 10)
            assertEquals(0, q.engine.reps)
        }
    }

    @Test fun buttKicksCountEachLeg() {
        val stand = kick(false, false)
        val r = Bn1(ExerciseType.BUTT_KICKS)
        r.feed(stand, 8)
        repeat(5) { r.feed(kick(true, false), 6); r.feed(stand, 6); r.feed(kick(false, true), 6); r.feed(stand, 6) }
        assertEquals(10, r.engine.reps)
        assertEquals(10, r.engine.leftReps + r.engine.rightReps)
    }

    @Test fun goodMorningStatesAndCount() {
        assertEquals(Pose.OPEN, read(ExerciseType.GOOD_MORNING, hinge(false)).pose)
        assertEquals(Pose.CLOSED, read(ExerciseType.GOOD_MORNING, hinge(true)).pose)
        val r = Bn1(ExerciseType.GOOD_MORNING)
        r.feed(hinge(false), 10)
        repeat(4) { r.feed(hinge(true), 8); r.feed(hinge(false), 8) }
        assertEquals(4, r.engine.reps)
    }

    @Test fun legRaiseStatesAndCount() {
        assertEquals(Pose.OPEN, read(ExerciseType.LEG_RAISE, lying(false)).pose)
        assertEquals(Pose.CLOSED, read(ExerciseType.LEG_RAISE, lying(true)).pose)
        val r = Bn1(ExerciseType.LEG_RAISE)
        r.feed(lying(false), 10)
        repeat(4) { r.feed(lying(true), 8); r.feed(lying(false), 8) }
        assertEquals(4, r.engine.reps)
    }

    @Test fun legRaiseNeedsLyingDown() {
        // a standing person is not a leg raise
        val standing = bpts(bp(11, 0.5f, 0.30f), bp(12, 0.5f, 0.30f), bp(23, 0.5f, 0.5f), bp(24, 0.5f, 0.5f), bp(27, 0.5f, 0.88f), bp(28, 0.5f, 0.88f))
        assertTrue(!read(ExerciseType.LEG_RAISE, standing).valid)
    }

    @Test fun inclineAndDeclinePushUps() {
        for (t in listOf(ExerciseType.INCLINE_PUSHUPS, ExerciseType.DECLINE_PUSHUPS)) {
            assertEquals(Pose.OPEN, read(t, incline(false)).pose)
            assertEquals(Pose.CLOSED, read(t, incline(true)).pose)
            val r = Bn1(t)
            r.feed(incline(false), 10)
            repeat(5) { r.feed(incline(true), 8); r.feed(incline(false), 8) }
            assertEquals(5, r.engine.reps)
        }
    }

    @Test fun lostBodyDoesNotCrash() {
        for (t in ExerciseType.values()) {
            val r = Bn1(t)
            r.feed(null, 5)
            assertTrue(!r.last!!.detected)
            assertEquals(0, r.engine.reps)
        }
    }

    @Test fun everyExerciseHasAGuideASimAndACoachSentence() {
        for (t in ExerciseType.values()) {
            val g = Guides.of(t)
            assertTrue(t.name, g.steps.size == 4 && g.benefits.isNotEmpty())
            val sp = Sims.of(t)
            assertTrue(t.name, sp.steps.all { it.step in g.steps.indices })
            assertTrue(t.name, Coach(true, "রাহিম").intro(t, 10).text.contains("রাহিম"))
            assertTrue(t.name, Coach(false, "Sam").intro(t, 10).text.contains(t.title))
            assertTrue(t.name, Plans.groupOf(t) != null)
        }
    }

    @Test fun simFiguresStayAboveTheFloor() {
        for (t in ExerciseType.values()) {
            val sp = Sims.of(t)
            for (st in sp.steps) {
                val f = SimMath.figure(st.pose, sp.view)
                assertTrue(t.name, f.all().all { it.y > -0.001f })
            }
        }
    }

    private fun bengali(s: String) = Bn.toBn(s).any { it in '\u0980'..'\u09FF' }

    @Test fun everyExerciseStringIsTranslated() {
        for (t in ExerciseType.values()) {
            val g = Guides.of(t)
            val all = listOf(t.title, t.benefit, t.setup, t.startCue, t.peakCue, t.backCue, g.camera, g.counting, g.safety) + g.steps + g.benefits
            for (x in all) if (x.isNotBlank()) assertTrue(t.name + ": " + x, bengali(x))
        }
    }
}
