package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private const val W2 = 480f
private const val H2 = 640f

private fun tri(i: Int, x: Float, y: Float) = Triple(i, x / W2, y / H2)

/** The same point for the left (index) and the right (index + 1) body side, in pixels. */
private fun both(i: Int, x: Float, y: Float) = arrayOf(tri(i, x, y), tri(i + 1, x, y))

private fun pts2(vararg v: Triple<Int, Float, Float>): List<BodyPoint> {
    val a = Array(33) { BodyPoint(0f, 0f, 0f) }
    v.forEach { a[it.first] = BodyPoint(it.second, it.third, 1f) }
    return a.toList()
}

private class Run2(type: ExerciseType) {
    val engine = ExerciseEngine(type)
    var t = 1_000L
    var last: ExerciseEngine.Out? = null
    var sawForm: FormTip? = null
    fun feed(p: List<BodyPoint>?, frames: Int) {
        repeat(frames) {
            last = engine.update(p, W2, H2, t, false)
            if (last!!.form != null) sawForm = last!!.form
            t += 33L
        }
    }
}

/** A leg with the given knee angle (hip above, ankle roughly under the hip), side view. */
private fun legK(hx: Float, hy: Float, k: Float): Pair<Pair<Float, Float>, Pair<Float, Float>> {
    val a = Math.toRadians(((180f - k) / 2f).toDouble())
    val kx = hx + 100f * Math.sin(a).toFloat()
    val ky = hy + 100f * Math.cos(a).toFloat()
    val b = -a
    return Pair(Pair(kx, ky), Pair(kx + 100f * Math.sin(b).toFloat(), ky + 100f * Math.cos(b).toFloat()))
}

private fun pike(down: Boolean) = pts2(
    *both(11, if (down) 330f else 330f, if (down) 460f else 380f),
    *both(13, if (down) 380f else 350f, if (down) 480f else 440f),
    *both(15, if (down) 370f else 370f, if (down) 520f else 500f),
    *both(23, 240f, if (down) 280f else 230f),
    *both(25, 160f, 365f), *both(27, 90f, 500f),
)

private fun plankPose() = pts2(
    *both(11, 400f, 400f), *both(13, 400f, 450f), *both(15, 400f, 500f),
    *both(23, 250f, 420f), *both(25, 170f, 440f), *both(27, 90f, 460f),
)

private fun bulgarian(down: Boolean) = pts2(
    tri(0, 260f, 150f),
    tri(23, 240f, if (down) 420f else 330f), tri(24, 240f, if (down) 420f else 330f),
    tri(25, if (down) 330f else 255f, if (down) 470f else 445f), tri(27, 270f, 560f),
    tri(26, 170f, 450f), tri(28, 110f, 480f),
)

private fun squatK(k: Float): List<BodyPoint> {
    val (kn, an) = legK(240f, 400f, k)
    return pts2(*both(11, 230f, 220f), *both(23, 240f, 400f), *both(25, kn.first, kn.second), *both(27, an.first, an.second))
}

private fun burpeeStand() = pts2(*both(11, 240f, 200f), *both(23, 240f, 340f), *both(27, 240f, 560f))
private fun burpeePlank() = pts2(*both(11, 400f, 420f), *both(23, 250f, 440f), *both(27, 90f, 460f))
private fun burpeeSquatHands() = pts2(*both(11, 300f, 420f), *both(23, 220f, 430f), *both(27, 200f, 560f))
private fun toeTouch() = pts2(*both(11, 330f, 440f), *both(23, 240f, 340f), *both(27, 240f, 560f))

private fun vup(up: Boolean) = if (up)
    pts2(*both(11, 150f, 360f), *both(23, 250f, 500f), *both(27, 400f, 400f))
else
    pts2(*both(11, 100f, 500f), *both(23, 250f, 500f), *both(27, 420f, 500f))

private fun tib(footY: Float) = pts2(
    *both(11, 240f, 200f), *both(23, 240f, 340f), *both(25, 240f, 460f), *both(27, 240f, 560f),
    *both(29, 230f, 580f), *both(31, 275f, footY),
)

private fun hollow(good: Boolean) = pts2(
    *both(11, 110f, if (good) 520f else 560f), *both(23, 250f, 560f), *both(27, 420f, if (good) 510f else 560f),
)

private fun child(good: Boolean) = if (good)
    pts2(*both(11, 300f, 470f), *both(23, 160f, 480f), *both(25, 260f, 545f), *both(27, 110f, 545f))
else
    pts2(*both(11, 240f, 200f), *both(23, 240f, 340f), *both(25, 240f, 450f), *both(27, 240f, 560f))

private fun cobra(high: Boolean) = pts2(
    *both(11, 300f, if (high) 430f else 520f), *both(23, 200f, 540f), *both(27, 40f, 545f),
)

class Batch2Test {
    private fun read(t: ExerciseType, p: List<BodyPoint>) = BodyClassifier.read(t, p, W2, H2)

    @Test fun pikePushUpCounts() {
        assertEquals(Pose.OPEN, read(ExerciseType.PIKE_PUSHUPS, pike(false)).pose)
        assertEquals(Pose.CLOSED, read(ExerciseType.PIKE_PUSHUPS, pike(true)).pose)
        assertTrue(!read(ExerciseType.PIKE_PUSHUPS, plankPose()).valid)
        val r = Run2(ExerciseType.PIKE_PUSHUPS)
        r.feed(pike(false), 10)
        repeat(5) { r.feed(pike(true), 8); r.feed(pike(false), 8) }
        assertEquals(5, r.engine.reps)
    }

    @Test fun bulgarianCountsFrontLegOnly() {
        assertEquals(Pose.OPEN, read(ExerciseType.BULGARIAN_SPLIT_SQUAT, bulgarian(false)).pose)
        assertEquals(Pose.CLOSED, read(ExerciseType.BULGARIAN_SPLIT_SQUAT, bulgarian(true)).pose)
        val r = Run2(ExerciseType.BULGARIAN_SPLIT_SQUAT)
        r.feed(bulgarian(false), 10)
        repeat(4) { r.feed(bulgarian(true), 8); r.feed(bulgarian(false), 8) }
        assertEquals(4, r.engine.reps)
    }

    @Test fun squatPulsesCountSmallBouncesAndIgnoreShallowOnes() {
        val low = squatK(95f)
        val top = squatK(130f)
        assertEquals(Pose.CLOSED, read(ExerciseType.SQUAT_PULSES, low).pose)
        assertEquals(Pose.OPEN, read(ExerciseType.SQUAT_PULSES, top).pose)
        val r = Run2(ExerciseType.SQUAT_PULSES)
        r.feed(top, 6)
        repeat(6) { r.feed(low, 5); r.feed(top, 5) }
        assertEquals(6, r.engine.reps)
        val q = Run2(ExerciseType.SQUAT_PULSES)
        q.feed(top, 6)
        repeat(4) { q.feed(squatK(112f), 5); q.feed(top, 5) }
        assertEquals(0, q.engine.reps)
    }

    @Test fun burpeeNeedsThePlank() {
        for (t in listOf(ExerciseType.BURPEE, ExerciseType.SQUAT_THRUST)) {
            assertEquals(Pose.OPEN, read(t, burpeeStand()).pose)
            assertEquals(Pose.CLOSED, read(t, burpeePlank()).pose)
            assertEquals(Pose.UNKNOWN, read(t, burpeeSquatHands()).pose)
            assertTrue(read(t, toeTouch()).pose != Pose.CLOSED)
            val r = Run2(t)
            r.feed(burpeeStand(), 15)
            repeat(3) { r.feed(burpeeSquatHands(), 8); r.feed(burpeePlank(), 15); r.feed(burpeeSquatHands(), 8); r.feed(burpeeStand(), 20) }
            assertEquals(3, r.engine.reps)
            val q = Run2(t)
            q.feed(burpeeStand(), 15)
            repeat(3) { q.feed(burpeeSquatHands(), 15); q.feed(burpeeStand(), 20); q.feed(toeTouch(), 15); q.feed(burpeeStand(), 20) }
            assertEquals(0, q.engine.reps)
        }
    }

    @Test fun vUpsCount() {
        assertEquals(Pose.OPEN, read(ExerciseType.V_UPS, vup(false)).pose)
        assertEquals(Pose.CLOSED, read(ExerciseType.V_UPS, vup(true)).pose)
        val r = Run2(ExerciseType.V_UPS)
        r.feed(vup(false), 10)
        repeat(4) { r.feed(vup(true), 8); r.feed(vup(false), 8) }
        assertEquals(4, r.engine.reps)
    }

    @Test fun tibialisRaiseCountsAndCoachesLowToes() {
        assertEquals(Pose.OPEN, read(ExerciseType.TIBIALIS_RAISE, tib(580f)).pose)
        assertEquals(Pose.CLOSED, read(ExerciseType.TIBIALIS_RAISE, tib(555f)).pose)
        val r = Run2(ExerciseType.TIBIALIS_RAISE)
        r.feed(tib(580f), 10)
        repeat(5) { r.feed(tib(555f), 8); r.feed(tib(580f), 8) }
        assertEquals(5, r.engine.reps)
        val q = Run2(ExerciseType.TIBIALIS_RAISE)
        q.feed(tib(580f), 10)
        repeat(3) { q.feed(tib(570f), 8); q.feed(tib(580f), 8) }
        assertEquals(0, q.engine.reps)
        assertEquals(FormTip.TOES_LOW, q.sawForm)
    }

    @Test fun holdsRunOnlyInThePosition() {
        val cases = listOf(
            Triple(ExerciseType.DOWNWARD_DOG, pike(false), plankPose()),
            Triple(ExerciseType.HOLLOW_BODY_HOLD, hollow(true), hollow(false)),
            Triple(ExerciseType.CHILD_POSE, child(true), child(false)),
            Triple(ExerciseType.COBRA_STRETCH, cobra(true), cobra(false)),
        )
        for ((t, good, bad) in cases) {
            assertTrue(t.name, t.isHold && t.unit == "sec")
            val r = Run2(t)
            r.feed(good, 120)
            assertTrue(t.name + " held " + r.engine.reps, r.engine.reps >= 3)
            assertTrue(t.name, r.engine.isHolding)
            val q = Run2(t)
            q.feed(bad, 120)
            assertTrue(t.name, q.engine.reps == 0)
            assertTrue(t.name, q.last!!.hint != null)
        }
    }

    @Test fun everyNewExerciseIsInTheLibrary() {
        val ids = listOf("pike_pushup", "bulgarian_squat", "squat_pulses", "burpee", "squat_thrust", "v_ups", "tibialis_raise",
            "downward_dog", "hollow_hold", "childs_pose", "cobra_stretch")
        for (id in ids) {
            val it = Library.byId(id)
            assertTrue(id, it != null && it.type != null && it.camera)
        }
    }
}
