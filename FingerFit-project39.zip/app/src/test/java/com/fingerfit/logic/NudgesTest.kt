package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime

class NudgesTest {
    private val today = LocalDate.of(2026, 11, 15)
    private fun facts(bn: Boolean, streak: Int = 0, min: Int = 0, goal: Int = 30, weightDays: Int? = null, name: String = "Abir Hasan") =
        NudgeFacts(name, bn, streak, min, goal, weightDays, today)

    @Test fun every_text_says_the_first_name_in_both_languages() {
        for (bn in listOf(true, false)) for (kind in NudgeKind.values()) for (streak in listOf(0, 3)) for (min in listOf(0, 10, 40)) {
            val t = Nudges.build(kind, facts(bn, streak, min))!!
            assertTrue("$kind bn=$bn title", t.title.contains("Abir") || t.body.contains("Abir"))
            assertTrue("$kind bn=$bn body", t.body.contains("Abir"))
            assertTrue(!t.title.contains("{") && !t.body.contains("{") && !t.body.contains("$"))
            assertTrue(!t.title.contains("Hasan"))
        }
    }

    @Test fun different_days_give_different_wording() {
        val a = Nudges.build(NudgeKind.MORNING, NudgeFacts("Abir", false, 0, 0, 30, null, LocalDate.of(2026, 11, 15)))!!
        val b = Nudges.build(NudgeKind.MORNING, NudgeFacts("Abir", false, 0, 0, 30, null, LocalDate.of(2026, 11, 16)))!!
        assertTrue(a.body != b.body)
    }

    @Test fun evening_follows_what_was_done_today() {
        val none = Nudges.build(NudgeKind.EVENING, facts(false, 0, 0))!!
        val some = Nudges.build(NudgeKind.EVENING, facts(false, 0, 12))!!
        val full = Nudges.build(NudgeKind.EVENING, facts(false, 0, 35))!!
        val risk = Nudges.build(NudgeKind.EVENING, facts(false, 4, 0))!!
        assertTrue(some.body.contains("18 minutes"))
        assertTrue(full.body.contains("reached your goal"))
        assertTrue(risk.title.contains("4-day"))
        assertTrue(!none.body.contains("minutes today"))
    }

    @Test fun bengali_uses_bengali_digits() {
        val t = Nudges.build(NudgeKind.EVENING, facts(true, 0, 12))!!
        assertTrue(t.body.contains("১২"))
        assertTrue(t.body.contains("১৮"))
        assertEquals("১০৫", Nudges.num(105, true))
        assertEquals("105", Nudges.num(105, false))
    }

    @Test fun weight_reminder_only_when_due() {
        assertTrue(Nudges.build(NudgeKind.WEIGHT, facts(true, weightDays = null)) != null)
        assertTrue(Nudges.build(NudgeKind.WEIGHT, facts(true, weightDays = 7)) != null)
        assertTrue(Nudges.build(NudgeKind.WEIGHT, facts(true, weightDays = 3)) == null)
    }

    @Test fun blank_name_still_gets_a_friendly_word() {
        assertTrue(Nudges.build(NudgeKind.MORNING, facts(false, name = " "))!!.body.contains("friend"))
        assertTrue(Nudges.build(NudgeKind.MORNING, facts(true, name = ""))!!.body.contains("বন্ধু"))
    }

    @Test fun next_time_is_today_or_tomorrow() {
        val now = LocalDateTime.of(2026, 11, 15, 9, 0)
        assertEquals(LocalDateTime.of(2026, 11, 15, 19, 0), Nudges.nextTime(now, 19 * 60))
        assertEquals(LocalDateTime.of(2026, 11, 16, 7, 30), Nudges.nextTime(now, 7 * 60 + 30))
        assertEquals(LocalDateTime.of(2026, 11, 16, 9, 0), Nudges.nextTime(now, 9 * 60))
        assertEquals(10L * 60 * 60 * 1000, Nudges.delayMillis(now, 19 * 60))
    }

    @Test fun weight_log_keeps_one_entry_per_day_oldest_first() {
        var l = emptyList<WeightEntry>()
        l = WeightLog.upsert(l, WeightEntry(today.minusDays(10), 80f))
        l = WeightLog.upsert(l, WeightEntry(today, 78.5f))
        l = WeightLog.upsert(l, WeightEntry(today, 78f))
        l = WeightLog.upsert(l, WeightEntry(today.minusDays(3), 79f))
        assertEquals(3, l.size)
        assertEquals(today.minusDays(10), l.first().date)
        assertTrue(kotlin.math.abs((78f) - (l.last().kg)) < 0.001f)
        assertEquals(0, WeightLog.daysSinceLast(l, today))
        assertTrue(kotlin.math.abs((-2f) - (WeightLog.change(l, 30, today)!!)) < 0.001f)
        assertTrue(WeightLog.change(l.takeLast(1), 30, today) == null)
        assertTrue(kotlin.math.abs((-1f) - (WeightLog.change(l, 5, today)!!)) < 0.001f)
    }

    @Test fun weight_log_saves_and_ignores_bad_pieces() {
        val l = listOf(WeightEntry(today.minusDays(1), 70.5f), WeightEntry(today, 70f))
        val back = WeightLog.decode(WeightLog.encode(l) + ";junk;2026-13-40:70;2026-11-01:5")
        assertEquals(2, back.size)
        assertTrue(kotlin.math.abs((70.5f) - (back[0].kg)) < 0.001f)
        assertEquals(emptyList<WeightEntry>(), WeightLog.decode(null))
    }

    @Test fun week_compare_splits_the_fortnight() {
        val days = (0 until 14).map { DayStat(today.minusDays((13 - it).toLong()), if (it < 7) 10 else 20, 0, 1) }
        val (now, prev) = Progress.weekCompare(days)
        assertEquals(140, now)
        assertEquals(70, prev)
    }
}
