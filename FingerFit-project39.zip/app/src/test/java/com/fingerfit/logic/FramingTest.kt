package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FramingTest {
    private fun body(): MutableList<BodyPoint> {
        val l = MutableList(33) { BodyPoint(0.5f, 0.5f, 0.99f) }
        fun s(i: Int, x: Float, y: Float) { l[i] = BodyPoint(x, y, 0.99f) }
        s(Joint.NOSE, 0.5f, 0.15f)
        s(Joint.L_SH, 0.43f, 0.28f); s(Joint.R_SH, 0.57f, 0.28f)
        s(Joint.L_HIP, 0.45f, 0.52f); s(Joint.R_HIP, 0.55f, 0.52f)
        s(Joint.L_KN, 0.45f, 0.72f); s(Joint.R_KN, 0.55f, 0.72f)
        s(Joint.L_AN, 0.45f, 0.9f); s(Joint.R_AN, 0.55f, 0.9f)
        s(Joint.L_HEEL, 0.45f, 0.93f); s(Joint.R_HEEL, 0.55f, 0.93f)
        s(Joint.L_FOOT, 0.45f, 0.95f); s(Joint.R_FOOT, 0.55f, 0.95f)
        return l
    }
    private fun gone(l: MutableList<BodyPoint>, vararg ids: Int, y: Float = 1.2f) { for (i in ids) l[i] = BodyPoint(l[i].x, y, 0.1f) }

    @Test fun goodFrontView() {
        assertTrue(Framing.check(ExerciseType.JUMPING_JACKS, body(), 640f, 480f, true) == null)
    }
    @Test fun dark() { assertEquals(FrameIssue.DARK, Framing.check(ExerciseType.SQUATS, body(), 640f, 480f, false)) }
    @Test fun nobody() { assertEquals(FrameIssue.NO_BODY, Framing.check(ExerciseType.SQUATS, null, 640f, 480f, true)) }
    @Test fun upperOnly() {
        val b = body(); gone(b, Joint.L_KN, Joint.R_KN, Joint.L_AN, Joint.R_AN, Joint.L_HEEL, Joint.R_HEEL, Joint.L_FOOT, Joint.R_FOOT)
        assertEquals(FrameIssue.UPPER_ONLY, Framing.check(ExerciseType.SQUATS, b, 640f, 480f, true))
    }
    @Test fun feetCut() {
        val b = body(); gone(b, Joint.L_AN, Joint.R_AN, Joint.L_HEEL, Joint.R_HEEL, Joint.L_FOOT, Joint.R_FOOT)
        assertEquals(FrameIssue.FEET_CUT, Framing.check(ExerciseType.SQUATS, b, 640f, 480f, true))
    }
    @Test fun headCut() {
        val b = body(); gone(b, Joint.NOSE, y = -0.2f)
        assertEquals(FrameIssue.HEAD_CUT, Framing.check(ExerciseType.SQUATS, b, 640f, 480f, true))
    }
    @Test fun tooFar() {
        val b = body()
        for (i in b.indices) b[i] = BodyPoint(0.5f + (b[i].x - 0.5f) * 0.3f, 0.4f + (b[i].y - 0.5f) * 0.3f, 0.99f)
        assertEquals(FrameIssue.TOO_FAR, Framing.check(ExerciseType.SQUATS, b, 640f, 480f, true))
    }
    @Test fun tilted() {
        val b = body()
        // body lying across the picture while standing exercise
        for (i in b.indices) b[i] = BodyPoint(0.1f + b[i].y * 0.8f, 0.4f + (b[i].x - 0.5f) * 0.4f, 0.99f)
        assertEquals(FrameIssue.TILTED, Framing.check(ExerciseType.SQUATS, b, 640f, 480f, true))
    }
    @Test fun lyingNotTilted() {
        val b = body()
        for (i in b.indices) b[i] = BodyPoint(0.1f + b[i].y * 0.8f, 0.4f + (b[i].x - 0.5f) * 0.1f, 0.99f)
        assertTrue(Framing.check(ExerciseType.PLANK, b, 640f, 480f, true) != FrameIssue.TILTED)
    }
    @Test fun faceFront() {
        val b = body(); b[Joint.L_SH] = BodyPoint(0.49f, 0.28f, 0.99f); b[Joint.R_SH] = BodyPoint(0.51f, 0.28f, 0.99f)
        assertEquals(FrameIssue.FACE_FRONT, Framing.check(ExerciseType.JUMPING_JACKS, b, 640f, 480f, true))
    }
    @Test fun coachWaitsThenSpeaksOnceAndPraises() {
        val c = FramingCoach(true, "রাহিম")
        assertTrue(c.update(FrameIssue.FEET_CUT, 0, true) == null)
        val s = c.update(FrameIssue.FEET_CUT, 2000, true)
        assertTrue(s != null && s.text.contains("রাহিম") && !s.text.contains("{n}"))
        assertTrue(c.update(FrameIssue.FEET_CUT, 4000, true) == null)
        assertTrue(c.update(null, 5000, true) == null)
        val ok = c.update(null, 6500, true)
        assertTrue(ok != null && ok.text.contains("রাহিম"))
        assertTrue(c.update(null, 9000, true) == null)
    }
    @Test fun coachWorksWithoutName() {
        val c = FramingCoach(false, "")
        c.update(FrameIssue.UPPER_ONLY, 0, true)
        val s = c.update(FrameIssue.UPPER_ONLY, 2000, true)
        assertTrue(s != null && !s.text.contains("{n}") && !s.text.contains(" ,"))
    }
    @Test fun noNagAfterThree() {
        val c = FramingCoach(false, "Sam")
        var n = 0
        var t = 0L
        while (t < 200_000) { if (c.update(FrameIssue.TOO_FAR, t, true) != null) n++; t += 500 }
        assertTrue(n == 3)
    }
    @Test fun fastRepsAreThinned() {
        val c = Coach(false, "Sam")
        var said = 0
        var t = 10_000L
        for (r in 1..19) { if (c.rep(ExerciseType.SQUATS, r, 30, t) != null) said++; t += 700 }
        assertTrue(said in 2..6)
    }
    @Test fun slowRepsAllCounted() {
        val c = Coach(false, "Sam")
        var said = 0
        var t = 10_000L
        for (r in 1..9) { if (c.rep(ExerciseType.SQUATS, r, 30, t) != null) said++; t += 3000 }
        assertEquals(9, said)
    }
}
