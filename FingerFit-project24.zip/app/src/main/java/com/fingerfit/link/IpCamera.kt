package com.fingerfit.link

import android.util.Base64
import android.content.Context
import android.net.wifi.WifiManager
import com.fingerfit.data.AppPrefs
import com.fingerfit.logic.IpCams
import com.fingerfit.logic.JpegSplitter
import com.fingerfit.logic.Onvif
import com.fingerfit.logic.RtspClient
import com.fingerfit.logic.RtspException
import com.fingerfit.logic.RtspFail
import com.fingerfit.logic.RtspPaths
import com.fingerfit.logic.RtspTarget
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.IOException
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLDecoder
import java.net.HttpURLConnection
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/** One camera found on the Wi-Fi. [url] is the address to open; [needsLogin] cameras ask for a user name and password first. */
data class IpFound(val host: String, val label: String, val url: String, val needsLogin: Boolean)

data class IpUi(
    val scanning: Boolean = false,
    val scanDone: Int = 0,
    val scanTotal: Int = 0,
    val found: List<IpFound> = emptyList(),
    val scanMessage: String = "",
    val connecting: Boolean = false,
    val running: Boolean = false,
    val name: String = "",
    val error: String? = null,
)

/**
 * Finds Wi-Fi / IP cameras on the same network (no internet needed) and reads their live picture.
 * Supported: Motion-JPEG streams and still-picture (snapshot) addresses over http/https, and H.264 RTSP cameras.
 * Pictures are handed to [onJpeg] on a background thread; only the newest one is kept, so a slow
 * analysis never makes the picture lag behind.
 */
class IpCamera(private val ctx: Context, private val onJpeg: (ByteArray, Long) -> Unit) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _ui = MutableStateFlow(IpUi())
    val ui: StateFlow<IpUi> = _ui.asStateFlow()

    private var scanJob: Job? = null
    private var streamJob: Job? = null
    private var workerJob: Job? = null
    private val latest = AtomicReference<ByteArray?>(null)
    @Volatile private var latestAt = 0L
    @Volatile private var currentConn: HttpURLConnection? = null
    @Volatile private var currentRtsp: RtspClient? = null
    @Volatile private var hints: Map<String, String> = emptyMap()

    // ---------------------------------------------------------------- scanning

    fun scan() {
        if (_ui.value.scanning) return
        scanJob = scope.launch {
            val net = localNetwork()
            if (net == null) {
                _ui.update {
                    it.copy(scanMessage = "This phone is not on a Wi-Fi network. Join the same Wi-Fi as the camera first.")
                }
                return@launch
            }
            val hosts = IpCams.subnetHosts(net.first, net.second)
            _ui.update {
                it.copy(scanning = true, scanDone = 0, scanTotal = hosts.size, found = emptyList(), scanMessage = "")
            }
            hints = onvifHints()
            val found = CopyOnWriteArrayList<IpFound>()
            val done = AtomicInteger(0)
            val gate = Semaphore(48)
            coroutineScope {
                for (h in hosts) {
                    launch {
                        gate.withPermit {
                            val hit = probeHost(h)
                            if (hit != null) {
                                found.add(hit)
                                _ui.update { s -> s.copy(found = found.toList()) }
                            }
                            val n = done.incrementAndGet()
                            if (n % 8 == 0) _ui.update { s -> s.copy(scanDone = n) }
                        }
                    }
                }
            }
            _ui.update {
                it.copy(
                    scanning = false,
                    scanDone = hosts.size,
                    scanMessage = if (found.isEmpty()) {
                        "No camera answered. Check that the camera is on and on this Wi-Fi, or type its address below."
                    } else "",
                )
            }
        }
    }

    fun stopScan() {
        scanJob?.cancel()
        scanJob = null
        _ui.update { it.copy(scanning = false) }
    }

    /** This phone's own Wi-Fi address and network size, or null when it is not on Wi-Fi. */
    private fun localNetwork(): Pair<String, Int>? {
        try {
            val all = NetworkInterface.getNetworkInterfaces() ?: return null
            for (ni in java.util.Collections.list(all)) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name.lowercase()
                if (!(n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("eth"))) continue
                for (ia in ni.interfaceAddresses) {
                    val a = ia.address
                    if (a is Inet4Address && a.isSiteLocalAddress) {
                        val host = a.hostAddress ?: continue
                        return Pair(host, ia.networkPrefixLength.toInt())
                    }
                }
            }
        } catch (e: Exception) {
        }
        return null
    }

    /** 0 = open, 1 = closed (the device is there), 2 = no answer (nothing there). */
    private fun portState(host: String, port: Int): Int {
        val s = Socket()
        return try {
            s.connect(InetSocketAddress(host, port), 350)
            0
        } catch (e: SocketTimeoutException) {
            2
        } catch (e: IOException) {
            1
        } finally {
            try {
                s.close()
            } catch (e: Exception) {
            }
        }
    }

    private fun probeHost(host: String): IpFound? {
        val openWeb = ArrayList<Int>()
        val openRtsp = ArrayList<Int>()
        var first = true
        for (p in IpCams.webPorts + IpCams.rtspPorts) {
            val st = portState(host, p)
            if (st == 2 && first) return null // nothing at this address
            first = false
            if (st == 0) {
                if (p in IpCams.rtspPorts) openRtsp.add(p) else openWeb.add(p)
            }
        }
        for (p in openWeb) {
            val base = "http://$host:$p"
            for (path in IpCams.streamPaths + IpCams.snapshotPaths) {
                if (looksLikePicture(base + path)) return IpFound(host, "Camera at $host", base + path, false)
            }
        }
        val hint = hints[host] ?: ""
        val name = if (hint.isNotEmpty()) "$hint ($host)" else "Camera at $host"
        for (p in openRtsp) {
            val base = RtspTarget(host, p, "/")
            var needLogin = false
            for (path in RtspPaths.candidates(hint)) {
                val r = RtspClient(base.withPath(path), 1200, 2500).probe()
                if (r.ok) return IpFound(host, name, base.withPath(path).plainUrl(), false)
                if (r.fail == RtspFail.LOGIN) {
                    needLogin = true
                    break
                }
                if (r.fail == RtspFail.NETWORK) break
            }
            if (needLogin) return IpFound(host, name, base.plainUrl(), true)
        }
        return null
    }

    /** Asks the whole network "who is a camera?" (ONVIF). Returns address -> maker/model text. Never fails. */
    private fun onvifHints(): Map<String, String> {
        val out = HashMap<String, String>()
        var lock: WifiManager.MulticastLock? = null
        var sock: DatagramSocket? = null
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            lock = wm?.createMulticastLock("kinetro-onvif")
            lock?.setReferenceCounted(false)
            lock?.acquire()
            sock = DatagramSocket()
            sock.soTimeout = 300
            val msg = Onvif.probeMessage(java.util.UUID.randomUUID().toString()).toByteArray()
            sock.send(DatagramPacket(msg, msg.size, InetAddress.getByName("239.255.255.250"), 3702))
            val end = System.currentTimeMillis() + 1500
            val buf = ByteArray(16384)
            while (System.currentTimeMillis() < end) {
                try {
                    val pk = DatagramPacket(buf, buf.size)
                    sock.receive(pk)
                    val hit = Onvif.parse(String(pk.data, 0, pk.length, Charsets.UTF_8))
                    if (hit != null) out[hit.host] = hit.hint
                } catch (e: SocketTimeoutException) {
                }
            }
        } catch (e: Exception) {
            // no discovery on this network: the port search below still works
        } finally {
            try {
                sock?.close()
            } catch (e: Exception) {
            }
            try {
                lock?.release()
            } catch (e: Exception) {
            }
        }
        return out
    }

    private fun looksLikePicture(url: String): Boolean {
        var c: HttpURLConnection? = null
        return try {
            c = open(url, 800, 1200)
            val type = (c.contentType ?: "").lowercase()
            c.responseCode == 200 && (type.contains("image/jp") || type.contains("multipart/x-mixed-replace"))
        } catch (e: Exception) {
            false
        } finally {
            try {
                c?.disconnect()
            } catch (e: Exception) {
            }
        }
    }

    // --------------------------------------------------------------- streaming

    fun connect(url: String, label: String) {
        stop()
        if (IpCams.isRtsp(url)) {
            connectRtsp(url, label)
            return
        }
        _ui.update { it.copy(connecting = true, running = false, error = null, name = label) }
        startWorker()
        streamJob = scope.launch {
            var everWorked = false
            while (isActive) {
                try {
                    readOnce(url) {
                        if (!everWorked) {
                            everWorked = true
                            _ui.update { s -> s.copy(connecting = false, running = true, error = null) }
                            AppPrefs.setLastCamera(ctx, url, label)
                        }
                    }
                } catch (e: CameraRefused) {
                    if (!everWorked) {
                        _ui.update { it.copy(connecting = false, running = false, error = e.message) }
                        break
                    }
                } catch (e: Exception) {
                    if (!everWorked) {
                        _ui.update {
                            it.copy(
                                connecting = false, running = false,
                                error = "Could not open the camera. Check the address, and that this phone and the camera are on the same Wi-Fi.",
                            )
                        }
                        break
                    }
                }
                if (isActive) delay(1500) // the camera blinked: try again
            }
        }
    }

    private fun startWorker() {
        workerJob = scope.launch {
            while (isActive) {
                val f = latest.getAndSet(null)
                if (f == null) {
                    delay(3)
                    continue
                }
                try {
                    onJpeg(f, latestAt)
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun failMessage(k: RtspFail): String = when (k) {
        RtspFail.LOGIN -> "The camera needs a user name and password, or the ones typed are wrong."
        RtspFail.NOT_FOUND -> "The camera has no picture at this address. Remove the part after the camera address and Kinetro will try the usual ones."
        RtspFail.CODEC -> "This camera sends video in a type (H.265) that Kinetro cannot read yet. In the camera settings choose H.264 as the video type, then connect again."
        RtspFail.NETWORK -> "Could not reach the camera. Check that the camera is on and this phone is on the same Wi-Fi."
        RtspFail.PROTOCOL -> "The camera did not accept the connection. Try another picture address."
    }

    private class Picked(val target: RtspTarget?, val fail: RtspFail?)

    /** Tries the usual picture addresses of cameras until one gives an H.264 picture. */
    private fun pickPath(t: RtspTarget): Picked {
        var last = RtspFail.NOT_FOUND
        for (p in RtspPaths.candidates(hints[t.host] ?: "")) {
            if (streamJob?.isActive != true) return Picked(null, RtspFail.NETWORK)
            val c = RtspClient(t.withPath(p), 1500, 3000)
            currentRtsp = c
            val r = c.probe()
            if (r.ok) return Picked(t.withPath(p), null)
            val f = r.fail ?: RtspFail.PROTOCOL
            if (f == RtspFail.LOGIN || f == RtspFail.NETWORK) return Picked(null, f)
            if (f == RtspFail.CODEC || last != RtspFail.CODEC) last = f
        }
        return Picked(null, last)
    }

    private fun connectRtsp(url: String, label: String) {
        val parsed = RtspTarget.parse(url)
        if (parsed == null) {
            _ui.update { it.copy(error = failMessage(RtspFail.PROTOCOL)) }
            return
        }
        _ui.update { it.copy(connecting = true, running = false, error = null, name = label) }
        startWorker()
        streamJob = scope.launch {
            var everWorked = false
            var target: RtspTarget = parsed
            fun fail(msg: String) {
                _ui.update { it.copy(connecting = false, running = false, error = msg) }
            }
            while (isActive) {
                if (target.path == "/") {
                    val pk = pickPath(target)
                    val chosen = pk.target
                    if (chosen == null) {
                        if (isActive) fail(failMessage(pk.fail ?: RtspFail.NOT_FOUND))
                        break
                    }
                    target = chosen
                }
                val decoder = H264Decoder { jpeg, at ->
                    latestAt = at
                    latest.set(jpeg)
                    if (!everWorked) {
                        everWorked = true
                        _ui.update { s -> s.copy(connecting = false, running = true, error = null) }
                        AppPrefs.setLastCamera(ctx, target.fullUrl(), label)
                    }
                }
                val client = RtspClient(target)
                currentRtsp = client
                var decodeFailed = false
                try {
                    client.run(object : RtspClient.Listener {
                        override fun onStream(sps: ByteArray?, pps: ByteArray?, width: Int, height: Int) {
                            try {
                                decoder.start(sps, pps, width, height)
                            } catch (e: Exception) {
                                decodeFailed = true
                                client.close()
                            }
                        }

                        override fun onUnit(data: ByteArray, key: Boolean) {
                            decoder.feed(data, key)
                        }
                    })
                } catch (e: RtspException) {
                    if (!everWorked && isActive) {
                        fail(failMessage(e.kind))
                        decoder.stop()
                        break
                    }
                } catch (e: Exception) {
                    if (!everWorked && isActive) {
                        fail(failMessage(RtspFail.NETWORK))
                        decoder.stop()
                        break
                    }
                } finally {
                    decoder.stop()
                }
                if (decodeFailed) {
                    fail("This phone could not play the camera video. Try a lower picture size or H.264 in the camera settings.")
                    break
                }
                if (isActive) delay(1500) // the camera blinked: try again
            }
        }
    }

    fun stop() {
        currentRtsp?.close()
        currentRtsp = null
        streamJob?.cancel()
        workerJob?.cancel()
        streamJob = null
        workerJob = null
        latest.set(null)
        val c = currentConn
        currentConn = null
        if (c != null) {
            // Closing the connection wakes up a read that is waiting for the camera.
            scope.launch {
                try {
                    c.disconnect()
                } catch (e: Exception) {
                }
            }
        }
        _ui.update { it.copy(connecting = false, running = false, error = null) }
    }

    fun release() {
        scope.cancel()
    }

    private class CameraRefused(message: String) : IOException(message)

    private fun readOnce(url: String, onFirstFrame: () -> Unit) {
        var conn = open(url, 4000, 6000)
        currentConn = conn
        try {
            val code = conn.responseCode
            if (code == 401) throw CameraRefused("The camera asks for a username and password. Type it in the address like http://user:password@192.168.0.5/video")
            if (code != 200) throw CameraRefused("The camera answered with error $code. Check the picture address.")
            val type = (conn.contentType ?: "").lowercase()
            if (type.contains("multipart")) {
                val ins = conn.inputStream
                val splitter = JpegSplitter()
                val buf = ByteArray(16384)
                while (streamJob?.isActive == true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    for (f in splitter.feed(buf, n)) {
                        latestAt = android.os.SystemClock.uptimeMillis()
                        latest.set(f)
                        onFirstFrame()
                    }
                }
            } else if (type.contains("image")) {
                while (streamJob?.isActive == true) {
                    val bytes = conn.inputStream.use { it.readBytes() }
                    if (bytes.size > 1000) {
                        latestAt = android.os.SystemClock.uptimeMillis()
                        latest.set(bytes)
                        onFirstFrame()
                    }
                    conn.disconnect()
                    Thread.sleep(30)
                    conn = open(url, 4000, 6000)
                    currentConn = conn
                    if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
                }
            } else {
                throw CameraRefused("This address does not give a picture. Try another picture address of the camera.")
            }
        } finally {
            try {
                conn.disconnect()
            } catch (e: Exception) {
            }
        }
    }

    /** Opens the address. A user name and password written in it (http://user:pass@host/...) are sent as Basic login. */
    private fun open(url: String, connectMs: Int, readMs: Int): HttpURLConnection {
        val u = URL(url)
        val clean = URL(u.protocol, u.host, u.port, u.file)
        val c = clean.openConnection() as HttpURLConnection
        c.connectTimeout = connectMs
        c.readTimeout = readMs
        c.instanceFollowRedirects = false
        val info = u.userInfo
        if (info != null) {
            val decoded = URLDecoder.decode(info.replace("+", "%2B"), "UTF-8")
            c.setRequestProperty("Authorization", "Basic " + Base64.encodeToString(decoded.toByteArray(), Base64.NO_WRAP))
        }
        return c
    }
}
