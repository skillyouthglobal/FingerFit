package com.fingerfit.logic

import kotlin.random.Random

/** Something the person should fix in their form (found from the body points). */
enum class FormTip { SQUAT_SHALLOW, PUSHUP_SHALLOW, HIPS_SAG, HIPS_HIGH, LUNGE_SHALLOW, ARMS_LOW, KNEES_LOW, CRUNCH_SHALLOW, BRIDGE_LOW, STAND_SHORT, CALF_LOW, KNEES_BENT, LEG_LOW, LEANING }

/** A sentence for the voice. [flush] = cut off whatever is being said (used for the count). */
class Say(val text: String, val flush: Boolean)

/**
 * The voice coach: decides WHAT to say, in plain spoken Bengali or English, using the person's name.
 * It does not speak itself; the phone's text-to-speech reads what it returns.
 */
class Coach(private val bn: Boolean, name: String, private val rnd: Random = Random.Default) {
    private val nm: String = name.trim().substringBefore(' ')
    private val lastIdx = HashMap<String, Int>()
    private var lastTipAt = -100_000L
    private var lastTipKind: FormTip? = null
    private var lastTipRep = -10
    private var goodStreak = 0
    private var lostSince = -1L
    private var countsSaid = 0
    private var warnedLost = false
    private var lastLostWarnAt = -100_000L

    private fun pick(key: String, l: List<String>): String {
        if (l.size == 1) return l[0]
        var i = rnd.nextInt(l.size)
        if (i == lastIdx[key]) i = (i + 1) % l.size
        lastIdx[key] = i
        return l[i]
    }

    /** Replace {n} (name), {c} (a number) and clean up when no name is known. */
    private fun fill(t: String, c: Int? = null, k: Int? = null): String {
        var s = t
        s = if (nm.isEmpty()) s.replace("{n}, ", "").replace(", {n}", "").replace("{n}", "") else s.replace("{n}", nm)
        if (c != null) s = s.replace("{c}", num(c))
        if (k != null) s = s.replace("{k}", num(k))
        s = s.replace(Regex("\\s+([!,।?.])"), "$1").replace(Regex("^[!,।?.\\s]+"), "").replace(Regex("\\s{2,}"), " ")
        return s.trim()
    }

    /** A number as it is said aloud. */
    fun num(v: Int): String = if (bn && v in 0..100) BN_NUM[v] else v.toString()

    private fun type(t: ExerciseType): String = if (bn) when (t) {
        ExerciseType.JUMPING_JACKS -> "জাম্পিং জ্যাক"; ExerciseType.SQUATS -> "স্কোয়াট"; ExerciseType.PUSH_UPS -> "পুশ-আপ"
        ExerciseType.LUNGES -> "লাঞ্জ"; ExerciseType.HIGH_KNEES -> "হাই নিজ"; ExerciseType.CRUNCHES -> "ক্রাঞ্চ"
        ExerciseType.GLUTE_BRIDGES -> "গ্লুট ব্রিজ"; ExerciseType.PLANK -> "প্ল্যাঙ্ক"
        ExerciseType.SIT_TO_STAND -> "বসা থেকে ওঠা"; ExerciseType.CALF_RAISES -> "ক্যাফ রেইজ"
        ExerciseType.SIDE_LEG_RAISES -> "সাইড লেগ রেইজ"
    } else t.title

    private fun howTo(t: ExerciseType): String = if (bn) when (t) {
        ExerciseType.JUMPING_JACKS -> "সোজা হয়ে দাঁড়ান, তারপর লাফ দিয়ে হাত মাথার ওপরে আর পা দুই পাশে ছড়ান।"
        ExerciseType.SQUATS -> "পা কাঁধ-সমান চওড়া করুন, কোমর পেছনে ঠেলে চেয়ারে বসার মতো করে নামুন।"
        ExerciseType.PUSH_UPS -> "হাত কাঁধের একটু বাইরে রাখুন, শরীর সোজা রেখে বুক নিচে নামান।"
        ExerciseType.LUNGES -> "সোজা হয়ে দাঁড়ান, এক পা সামনে বাড়িয়ে নিচে নামুন, তারপর উঠে অন্য পা।"
        ExerciseType.HIGH_KNEES -> "জায়গায় দাঁড়িয়ে দৌড়ানোর মতো করে হাঁটু কোমর পর্যন্ত তুলুন।"
        ExerciseType.CRUNCHES -> "চিত হয়ে শুয়ে হাঁটু ভাঁজ করুন, পেটের পেশি শক্ত করে কাঁধ ওপরে তুলুন।"
        ExerciseType.GLUTE_BRIDGES -> "চিত হয়ে শুয়ে হাঁটু ভাঁজ করুন, গোড়ালিতে চাপ দিয়ে কোমর ওপরে তুলুন।"
        ExerciseType.PLANK -> "কনুইয়ের ওপর ভর দিন, মাথা থেকে গোড়ালি এক সরলরেখায় রাখুন।"
        ExerciseType.SIT_TO_STAND -> "চেয়ারে সোজা হয়ে বসুন, পা মেঝেতে রাখুন, তারপর হাত না ধরে পুরোটা উঠে দাঁড়ান আর ধীরে বসুন।"
        ExerciseType.CALF_RAISES -> "সোজা দাঁড়ান, ধীরে ধীরে পায়ের আঙুলের ওপর ভর দিয়ে গোড়ালি তুলুন, তারপর ধীরে নামান।"
        ExerciseType.SIDE_LEG_RAISES -> "সোজা দাঁড়ান, এক পা পাশে তুলুন, শরীর সোজা রাখুন, তারপর নামিয়ে অন্য পা তুলুন।"
    } else when (t) {
        ExerciseType.JUMPING_JACKS -> "Stand tall, then jump, arms overhead and feet wide."
        ExerciseType.SQUATS -> "Feet shoulder-width apart. Push your hips back and sit down like you are sitting on a chair."
        ExerciseType.PUSH_UPS -> "Hands just outside your shoulders. Keep your body straight and lower your chest."
        ExerciseType.LUNGES -> "Stand tall, step one foot forward and go down, then come up and switch legs."
        ExerciseType.HIGH_KNEES -> "Run on the spot and lift your knees up to hip height."
        ExerciseType.CRUNCHES -> "Lie on your back with knees bent. Tighten your tummy and curl your shoulders up."
        ExerciseType.GLUTE_BRIDGES -> "Lie on your back, knees bent. Press through your heels and lift your hips."
        ExerciseType.PLANK -> "Rest on your forearms and keep a straight line from head to heels."
        ExerciseType.SIT_TO_STAND -> "Sit tall on the chair, feet flat. Stand all the way up without using your hands, then sit down slowly."
        ExerciseType.CALF_RAISES -> "Stand tall, slowly rise onto your toes, then lower your heels slowly."
        ExerciseType.SIDE_LEG_RAISES -> "Stand tall, lift one leg out to the side, keep your body straight, then lower it and switch legs."
    }

    fun intro(t: ExerciseType, target: Int): Say {
        val s = if (bn) pick("intro", listOf(
            "{n}, চলুন শুরু করি! আজ ${type(t)}, লক্ষ্য ${num(target)} ${unitBn(t)}। ${howTo(t)}",
            "ঠিক আছে {n}, ${type(t)} শুরু করছি। ${howTo(t)} লক্ষ্য ${num(target)} ${unitBn(t)}, আমি গুনছি।",
        )) else pick("intro", listOf(
            "Alright {n}, let's go! Today it's ${type(t)}, target $target ${t.unit}. ${howTo(t)}",
            "Okay {n}, starting ${type(t)}. ${howTo(t)} Target is $target ${t.unit}, and I'll count for you.",
        ))
        return Say(fill(s), true)
    }

    /** A short sample for the Test voice button. */
    fun sample(): Say = Say(fill(if (bn) "হ্যালো {n}! আমি আপনার ব্যায়ামের সঙ্গী। আমি গুনব, উৎসাহ দেব আর ভুল হলে ঠিক করে দেব। এক, দুই, তিন! চলুন শুরু করি!" else "Hello {n}! I'm your workout coach. I'll count for you, cheer you on, and help fix your form. One, two, three! Let's get started!"), true)

    private fun unitBn(t: ExerciseType) = if (t.isHold) "সেকেন্ড" else "বার"

    /** Called after a repetition; null when there is nothing to say. */
    fun rep(t: ExerciseType, reps: Int, target: Int): Say? {
        if (reps <= 0) return null
        val left = target - reps
        val every = if (t == ExerciseType.JUMPING_JACKS || t == ExerciseType.HIGH_KNEES) 5 else 1
        val s: String = when {
            reps >= target -> return null // finish() speaks
            left in 1..3 && reps >= 4 -> if (bn) pick("last", listOf("আর ${num(left)}টা, {n}!", "{c}! আর ${num(left)}টা, হয়ে এসেছে {n}!")) else pick("last", listOf("Just $left more, {n}!", "{c}! Only $left to go, {n}!"))
            target >= 6 && reps == (target + 1) / 2 -> if (bn) pick("half", listOf("{c}! {n}, অর্ধেক হয়ে গেছে, দারুণ!", "{c}! অর্ধেক পার, {n}, এভাবেই চালিয়ে যান!")) else pick("half", listOf("{c}! Halfway there, {n}, great work!", "{c}! That's half done, {n}. Keep it up!"))
            reps % 5 == 0 -> if (bn) pick("five", listOf("{c}! দারুণ হচ্ছে, {n}!", "{c}! খুব ভালো {n}, থামবেন না!", "{c}! চমৎকার {n}, আপনি পারছেন!")) else pick("five", listOf("{c}! Nice one, {n}!", "{c}! You're doing great, {n}. Keep going!", "{c}! Strong work, {n}!"))
            reps % every == 0 -> { countsSaid++; if (countsSaid % 2 == 0) (if (bn) "{c}, {n}!" else "{c}, {n}!") else "{c}" }
            else -> return null
        }
        return Say(fill(s, reps), true)
    }

    /** Plank: called when the held seconds go up. */
    fun hold(sec: Int, target: Int): Say? {
        if (sec <= 0 || sec >= target) return null
        val left = target - sec
        val s = when {
            left in 1..3 -> if (bn) "${num(left)}" else "$left"
            sec == target / 2 && target >= 20 -> if (bn) pick("hhalf", listOf("{n}, অর্ধেক সময় হয়ে গেছে, ধরে থাকুন!", "অর্ধেক পার, {n}! শ্বাস নিতে ভুলবেন না।")) else pick("hhalf", listOf("{n}, you're halfway, hold on!", "Halfway there, {n}! Keep breathing."))
            sec % 10 == 0 -> if (bn) pick("hten", listOf("{c} সেকেন্ড, {n}! শরীর সোজা রাখুন।", "{c} সেকেন্ড হয়ে গেছে, দারুণ {n}!")) else pick("hten", listOf("{c} seconds, {n}! Keep that body straight.", "{c} seconds. Looking strong, {n}!"))
            else -> return null
        }
        return Say(fill(s, sec), left in 1..3)
    }

    /** A form fix, at most one every 7 seconds and not the same fix again within 3 repetitions. */
    fun tip(tip: FormTip?, reps: Int, nowMs: Long): Say? {
        if (tip == null) { goodStreak++; return null }
        goodStreak = 0
        if (nowMs - lastTipAt < 7000) return null
        if (tip == lastTipKind && reps - lastTipRep < 3 && reps > 0) return null
        lastTipAt = nowMs; lastTipKind = tip; lastTipRep = reps
        val s = if (bn) when (tip) {
            FormTip.SQUAT_SHALLOW -> pick("t1", listOf("{n}, আরেকটু নিচে নামুন, উরু মেঝের সমান্তরাল হওয়া পর্যন্ত।", "আরও একটু নিচে যান {n}, তাহলে পুরো উপকার পাবেন।"))
            FormTip.PUSHUP_SHALLOW -> pick("t2", listOf("{n}, বুকটা আরেকটু নিচে নামান, কনুই ভালো করে ভাঁজ করুন।", "{n}, আরও একটু নিচে নামুন।"))
            FormTip.HIPS_SAG -> pick("t3", listOf("{n}, কোমর ঝুলে যাচ্ছে, পেট শক্ত করে কোমর ওপরে তুলুন।", "{n}, কোমরটা একটু ওপরে তুলুন, শরীর সোজা রাখুন।"))
            FormTip.HIPS_HIGH -> pick("t4", listOf("{n}, কোমর বেশি উঁচু হয়ে গেছে, একটু নামান, শরীর এক লাইনে রাখুন।", "{n}, কোমরটা একটু নামান।"))
            FormTip.LUNGE_SHALLOW -> pick("t5", listOf("{n}, সামনের হাঁটু আরেকটু ভাঁজ করে নিচে নামুন, প্রায় সমকোণ হওয়া পর্যন্ত।", "আরও একটু নিচে নামুন {n}, তাহলে পায়ে ভালো কাজ হবে।"))
            FormTip.ARMS_LOW -> pick("t6", listOf("{n}, দুই হাত মাথার ওপরে পুরোটা তুলুন।", "{n}, হাত আরেকটু ওপরে তুলুন, মাথার ওপরে পৌঁছে দিন।"))
            FormTip.KNEES_LOW -> pick("t7", listOf("{n}, হাঁটু আরেকটু ওপরে তুলুন, কোমর পর্যন্ত।", "{n}, হাঁটু আরও উঁচুতে তুলুন, তাহলে গোনা হবে।"))
            FormTip.CRUNCH_SHALLOW -> pick("t8", listOf("{n}, কাঁধ আরেকটু ওপরে তুলুন, পেটের পেশি দিয়ে টানুন।", "{n}, আরও একটু ওপরে উঠুন, ঘাড় নয়, পেট দিয়ে তুলুন।"))
            FormTip.BRIDGE_LOW -> pick("t9", listOf("{n}, কোমর আরেকটু ওপরে তুলুন, হাঁটু থেকে কাঁধ এক লাইনে আসা পর্যন্ত।", "{n}, কোমর আরও উঁচু করুন, নিতম্ব শক্ত করে চেপে ধরুন।"))
            FormTip.STAND_SHORT -> pick("t10", listOf("{n}, পুরোপুরি সোজা হয়ে দাঁড়ান, হাঁটু আর কোমর সোজা করুন।", "{n}, আরও একটু ওপরে উঠুন, পুরো দাঁড়িয়ে যান, তাহলে গোনা হবে।"))
            FormTip.CALF_LOW -> pick("t11", listOf("{n}, আরও উঁচুতে উঠুন, পায়ের আঙুলের ওপর ভর দিয়ে গোড়ালি পুরো তুলুন।", "{n}, গোড়ালি আরেকটু ওপরে তুলুন, তাহলে গোনা হবে।"))
            FormTip.KNEES_BENT -> pick("t12", listOf("{n}, হাঁটু সোজা রাখুন, শুধু গোড়ালি ওঠানামা করবে।", "{n}, হাঁটু ভাঁজ করবেন না, পা সোজা রাখুন।"))
            FormTip.LEG_LOW -> pick("t13", listOf("{n}, পা আরেকটু পাশে তুলুন, তাহলে গোনা হবে।", "{n}, পা আরও উঁচুতে পাশে তুলুন।"))
            FormTip.LEANING -> pick("t14", listOf("{n}, শরীর সোজা রাখুন, পাশে হেলে যাবেন না।", "{n}, শরীরটা একদম সোজা রাখুন, শুধু পা তুলুন।"))
        } else when (tip) {
            FormTip.SQUAT_SHALLOW -> pick("t1", listOf("{n}, go a little lower, until your thighs are level with the floor.", "A bit deeper, {n}, you'll get the full benefit."))
            FormTip.PUSHUP_SHALLOW -> pick("t2", listOf("{n}, lower your chest a little more, bend those elbows.", "{n}, go a bit deeper."))
            FormTip.HIPS_SAG -> pick("t3", listOf("{n}, your hips are dropping, tighten your tummy and lift them.", "{n}, lift your hips a little, keep your body straight."))
            FormTip.HIPS_HIGH -> pick("t4", listOf("{n}, your hips are too high, lower them, keep one straight line.", "{n}, bring your hips down a little."))
            FormTip.LUNGE_SHALLOW -> pick("t5", listOf("{n}, bend your front knee a bit more, down to about a right angle.", "A little lower, {n}, so your legs get the full work."))
            FormTip.ARMS_LOW -> pick("t6", listOf("{n}, reach both arms all the way over your head.", "{n}, arms a bit higher, send them overhead."))
            FormTip.KNEES_LOW -> pick("t7", listOf("{n}, lift your knee higher, up to your hip.", "{n}, knees a bit higher, then it will count."))
            FormTip.CRUNCH_SHALLOW -> pick("t8", listOf("{n}, curl your shoulders a little higher, pull with your tummy.", "{n}, come up a bit more, use your abs, not your neck."))
            FormTip.BRIDGE_LOW -> pick("t9", listOf("{n}, lift your hips higher, until knees, hips and shoulders make one line.", "{n}, hips a little higher, squeeze your glutes."))
            FormTip.STAND_SHORT -> pick("t10", listOf("{n}, stand all the way up, straighten your knees and hips.", "{n}, rise a little more until you are fully standing, then it will count."))
            FormTip.CALF_LOW -> pick("t11", listOf("{n}, rise higher onto your toes, lift your heels all the way.", "{n}, heels a bit higher, then it will count."))
            FormTip.KNEES_BENT -> pick("t12", listOf("{n}, keep your knees straight, only your heels should move.", "{n}, don't bend your knees, keep your legs straight."))
            FormTip.LEG_LOW -> pick("t13", listOf("{n}, lift your leg a little further out to the side.", "{n}, a bit higher out to the side, then it will count."))
            FormTip.LEANING -> pick("t14", listOf("{n}, keep your body straight, don't lean sideways.", "{n}, stay upright and lift only your leg."))
        }
        return Say(fill(s), false)
    }

    /** Good-form praise after a streak of clean repetitions. */
    fun praise(): Say? {
        if (goodStreak < 6) return null
        goodStreak = 0
        val s = if (bn) pick("pr", listOf("{n}, আপনার ভঙ্গি একদম ঠিক আছে!", "চমৎকার ভঙ্গি {n}, এভাবেই করুন!")) else pick("pr", listOf("{n}, your form looks perfect!", "Beautiful form, {n}, keep it up!"))
        return Say(fill(s), false)
    }

    /** Called every frame while running; speaks when the body has been out of view for a while. */
    fun visibility(visible: Boolean, nowMs: Long): Say? {
        if (visible) {
            val wasLost = warnedLost
            lostSince = -1L; warnedLost = false
            if (wasLost) return Say(fill(if (bn) pick("found", listOf("ঠিক আছে {n}, আপনাকে দেখতে পাচ্ছি। চালিয়ে যান!", "এই তো, আবার দেখা যাচ্ছে, চালিয়ে যান {n}!")) else pick("found", listOf("Got you again, {n}, keep going!", "There you are, {n}. Carry on!"))), false)
            return null
        }
        if (lostSince < 0) lostSince = nowMs
        if (!warnedLost && nowMs - lostSince >= 3000 && nowMs - lastLostWarnAt >= 12_000) {
            warnedLost = true; lastLostWarnAt = nowMs
            val s = if (bn) pick("lost", listOf("{n}, আপনাকে দেখতে পাচ্ছি না। একটু পিছিয়ে দাঁড়ান, যাতে পুরো শরীর ছবিতে আসে।", "পুরো শরীর দেখা যাচ্ছে না, {n}। ক্যামেরা থেকে একটু দূরে সরে যান।")) else pick("lost", listOf("{n}, I can't see you. Step back so your whole body is in the picture.", "I've lost you, {n}. Move a little further from the camera."))
            return Say(fill(s), false)
        }
        return null
    }

    fun pause(): Say = Say(fill(if (bn) pick("pa", listOf("বিরতি নিন, {n}। প্রস্তুত হলে আবার শুরু করবেন।", "ঠিক আছে {n}, একটু জিরিয়ে নিন।")) else pick("pa", listOf("Take a break, {n}. Start again when you're ready.", "Okay {n}, catch your breath."))), true)
    fun resume(): Say = Say(fill(if (bn) pick("re", listOf("চলুন আবার শুরু করি, {n}!", "ঠিক আছে {n}, এবার আবার!")) else pick("re", listOf("Let's go again, {n}!", "Okay {n}, back to it!"))), true)

    fun finish(t: ExerciseType, reps: Int, reached: Boolean): Say {
        val u = if (bn) unitBn(t) else t.unit
        val s = if (bn) {
            if (reached) pick("fin", listOf("শাবাশ {n}! লক্ষ্য পূরণ হয়েছে, ${num(reps)} $u করেছেন। এবার একটু বিশ্রাম নিন, পানি খান।", "দারুণ কাজ, {n}! ${num(reps)} $u শেষ। আপনাকে নিয়ে গর্ব হচ্ছে!"))
            else if (reps > 0) "ঠিক আছে {n}, আজ ${num(reps)} $u করেছেন। ভালো চেষ্টা, কাল আরও একটু বেশি করবেন!" else "ঠিক আছে {n}, আজ আর হলো না। কাল আবার চেষ্টা করবেন!"
        } else {
            if (reached) pick("fin", listOf("Well done, {n}! Target reached, $reps $u. Take a rest and drink some water.", "Great job, {n}! $reps $u done. I'm proud of you!"))
            else if (reps > 0) "Okay {n}, you did $reps $u today. Good effort, a little more tomorrow!" else "Okay {n}, not today. Let's try again tomorrow!"
        }
        return Say(fill(s), true)
    }

    private companion object {
        val BN_NUM = listOf(
            "শূন্য", "এক", "দুই", "তিন", "চার", "পাঁচ", "ছয়", "সাত", "আট", "নয়", "দশ", "এগারো", "বারো", "তেরো", "চৌদ্দ", "পনেরো", "ষোল", "সতেরো", "আঠারো", "উনিশ", "বিশ",
            "একুশ", "বাইশ", "তেইশ", "চব্বিশ", "পঁচিশ", "ছাব্বিশ", "সাতাশ", "আঠাশ", "ঊনত্রিশ", "ত্রিশ", "একত্রিশ", "বত্রিশ", "তেত্রিশ", "চৌত্রিশ", "পঁয়ত্রিশ", "ছত্রিশ", "সাঁইত্রিশ", "আটত্রিশ", "ঊনচল্লিশ", "চল্লিশ",
            "একচল্লিশ", "বিয়াল্লিশ", "তেতাল্লিশ", "চুয়াল্লিশ", "পঁয়তাল্লিশ", "ছেচল্লিশ", "সাতচল্লিশ", "আটচল্লিশ", "ঊনপঞ্চাশ", "পঞ্চাশ",
            "একান্ন", "বাহান্ন", "তিপ্পান্ন", "চুয়ান্ন", "পঞ্চান্ন", "ছাপ্পান্ন", "সাতান্ন", "আটান্ন", "ঊনষাট", "ষাট",
            "একষট্টি", "বাষট্টি", "তেষট্টি", "চৌষট্টি", "পঁয়ষট্টি", "ছেষট্টি", "সাতষট্টি", "আটষট্টি", "ঊনসত্তর", "সত্তর",
            "একাত্তর", "বাহাত্তর", "তিয়াত্তর", "চুয়াত্তর", "পঁচাত্তর", "ছিয়াত্তর", "সাতাত্তর", "আটাত্তর", "ঊনআশি", "আশি",
            "একাশি", "বিরাশি", "তিরাশি", "চুরাশি", "পঁচাশি", "ছিয়াশি", "সাতাশি", "আটাশি", "ঊননব্বই", "নব্বই",
            "একানব্বই", "বিরানব্বই", "তিরানব্বই", "চুরানব্বই", "পঁচানব্বই", "ছিয়ানব্বই", "সাতানব্বই", "আটানব্বই", "নিরানব্বই", "একশ",
        )
    }
}
