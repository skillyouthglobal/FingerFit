package com.fingerfit.logic

import kotlin.math.roundToInt

enum class PlanGroup(val title: String, val chip: String) {
    HEART("For your heart", "Heart"),
    MUSCLE("For your muscles", "Muscle"),
    CORE("For your core", "Core"),
}

/** One line of the daily exercise plan. [type] is null for activities outside the camera list (a brisk walk). */
class PlanItem(val type: ExerciseType?, val label: String, val amount: String, val group: PlanGroup)

/** A daily food-energy suggestion. */
class CalorieAdvice(val kcal: Int, val low: Int, val high: Int)

/**
 * Simple offline planning rules. These are general suggestions only, not medical advice.
 * Physical activity follows the WHO adult guidance: 150 to 300 minutes of moderate activity a week
 * plus muscle-strengthening on at least 2 days.
 */
object Plans {

    fun groupOf(type: ExerciseType): PlanGroup = when (type) {
        ExerciseType.JUMPING_JACKS, ExerciseType.HIGH_KNEES -> PlanGroup.HEART
        ExerciseType.SQUATS, ExerciseType.LUNGES, ExerciseType.PUSH_UPS,
        ExerciseType.SIT_TO_STAND, ExerciseType.CALF_RAISES, ExerciseType.SIDE_LEG_RAISES -> PlanGroup.MUSCLE
        ExerciseType.CRUNCHES, ExerciseType.GLUTE_BRIDGES, ExerciseType.PLANK -> PlanGroup.CORE
    }

    /** Mifflin-St Jeor resting energy use (kcal per day). */
    fun bmr(gender: Gender, weightKg: Float, heightCm: Float, age: Int): Double {
        val base = 10.0 * weightKg + 6.25 * heightCm - 5.0 * age
        return base + when (gender) {
            Gender.MALE -> 5.0
            Gender.FEMALE -> -161.0
            Gender.OTHER -> -78.0
        }
    }

    /** Null for people under 18: they should ask a doctor or parent instead of using a calorie number. */
    fun calories(gender: Gender, weightKg: Float, heightCm: Float, age: Int, goal: Goal): CalorieAdvice? {
        if (age < 18) return null
        val maintain = bmr(gender, weightKg, heightCm, age) * 1.375 // light activity
        val raw = when (goal) {
            Goal.LOSE -> maintain - 400.0
            Goal.MAINTAIN -> maintain
            Goal.GAIN -> maintain + 300.0
        }
        val floor = when (gender) {
            Gender.MALE -> 1500
            Gender.FEMALE -> 1200
            Gender.OTHER -> 1350
        }
        val kcal = ((raw / 50.0).roundToInt() * 50).coerceAtLeast(floor)
        return CalorieAdvice(kcal, (kcal - 100).coerceAtLeast(floor), kcal + 100)
    }

    fun isLowImpact(age: Int, bmi: Float): Boolean = age >= 60 || bmi >= 27.5f

    private fun amount(type: ExerciseType, lowImpact: Boolean): String {
        val scaled = if (lowImpact) type.defaultTarget * 0.7f else type.defaultTarget.toFloat()
        val n = ((scaled / type.step).roundToInt() * type.step).coerceAtLeast(type.step)
        return "$n ${type.unit}"
    }

    private fun item(type: ExerciseType, lowImpact: Boolean) =
        PlanItem(type, type.title, amount(type, lowImpact), groupOf(type))

    fun exercisePlan(age: Int, bmi: Float, goal: Goal): List<PlanItem> {
        val low = isLowImpact(age, bmi)
        val out = mutableListOf<PlanItem>()
        if (low) {
            out += PlanItem(null, "Brisk walk", "30 min", PlanGroup.HEART)
        } else {
            out += item(ExerciseType.JUMPING_JACKS, false)
            if (goal != Goal.GAIN) out += item(ExerciseType.HIGH_KNEES, false)
        }
        out += item(ExerciseType.SQUATS, low)
        if (low) out += item(ExerciseType.SIT_TO_STAND, true) // gentle strength and balance work for older or heavier people
        out += item(ExerciseType.PUSH_UPS, low)
        if (goal == Goal.GAIN) out += item(ExerciseType.LUNGES, low)
        out += item(ExerciseType.PLANK, low)
        if (goal == Goal.GAIN) out += item(ExerciseType.CRUNCHES, low)
        return out
    }
}
