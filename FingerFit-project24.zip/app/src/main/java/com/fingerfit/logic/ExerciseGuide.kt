package com.fingerfit.logic

/** Plain-language instructions shown before each workout. */
class Guide(
    val steps: List<String>,
    val benefits: List<String>,
    val camera: String,
    val counting: String,
    val safety: String,
)

object Guides {
    fun of(type: ExerciseType): Guide = when (type) {
        ExerciseType.JUMPING_JACKS -> Guide(
            steps = listOf(
                "Stand straight with feet together and arms down by your sides.",
                "Jump and spread your feet wider than your shoulders while raising both arms overhead.",
                "Jump again, bringing your feet together and arms back down.",
                "Keep a steady rhythm and breathe normally.",
            ),
            benefits = listOf(
                "Raises your heart rate quickly: good warm-up and cardio",
                "Burns calories and improves stamina",
                "Improves coordination between arms and legs",
                "Needs no equipment and little space",
            ),
            camera = "Face the camera, 2 to 3 metres away. Your whole body, from head to feet, must be inside the picture. Raise your arms fully so the camera can see them.",
            counting = "One repetition is counted when your arms go up and feet spread, then you return to the start position.",
            safety = "Land softly on the balls of your feet. Skip this one if you have knee, ankle or back pain.",
        )
        ExerciseType.SQUATS -> Guide(
            steps = listOf(
                "Stand with feet shoulder-width apart, toes slightly outward.",
                "Push your hips back and bend your knees as if sitting on a chair.",
                "Go down until your thighs are about parallel to the floor, chest up, back straight.",
                "Push through your heels to stand up fully.",
            ),
            benefits = listOf(
                "Strengthens thighs, glutes and core",
                "Makes everyday movements like standing up and climbing stairs easier",
                "Supports healthy bones and joints",
                "Burns many calories because large muscles work together",
            ),
            camera = "Stand SIDEWAYS to the camera, 2 to 3 metres away, phone at about hip height. Keep your whole body in view.",
            counting = "A repetition is counted when your knees bend deeply enough and you stand back up.",
            safety = "Keep your knees in line with your toes and your heels on the floor. Stop if you feel sharp knee pain.",
        )
        ExerciseType.PUSH_UPS -> Guide(
            steps = listOf(
                "Place your hands slightly wider than your shoulders. Body in one straight line from head to heels.",
                "Lower your chest toward the floor by bending your elbows.",
                "Stop just above the floor, then push back up until your arms are straight.",
                "If this is too hard, do it with your knees on the floor.",
            ),
            benefits = listOf(
                "Builds chest, shoulder and arm strength",
                "Strengthens your core",
                "Improves upper-body endurance",
                "Needs no equipment",
            ),
            camera = "Put the phone on the floor beside you (SIDE view), about 1.5 to 2 metres away, so your whole body from head to feet is visible.",
            counting = "A repetition is counted when your elbows bend as your chest goes down and you push back up. Standing up will not count.",
            safety = "Do not let your hips sag or rise. Stop if you feel wrist or shoulder pain.",
        )
        ExerciseType.LUNGES -> Guide(
            steps = listOf(
                "Stand tall with feet hip-width apart.",
                "Step one foot forward and lower your hips until both knees bend to about 90 degrees.",
                "Push through the front foot to return to standing.",
                "Repeat with the other leg, alternating sides.",
            ),
            benefits = listOf(
                "Strengthens thighs and glutes",
                "Improves balance and leg control",
                "Works each leg separately to even out strength",
                "Good for walking and running ability",
            ),
            camera = "Stand SIDEWAYS to the camera, 2 to 3 metres away, whole body in view.",
            counting = "Each step into a lunge counts once. Kinetro shows left and right separately.",
            safety = "Keep the front knee above the ankle, not past your toes. Hold a wall for balance if needed.",
        )
        ExerciseType.HIGH_KNEES -> Guide(
            steps = listOf(
                "Stand tall with feet hip-width apart.",
                "Run in place, lifting each knee up toward hip height.",
                "Swing your arms naturally and stay on the balls of your feet.",
                "Keep a quick, steady pace.",
            ),
            benefits = listOf(
                "Strong cardio workout that burns calories",
                "Improves speed, coordination and leg strength",
                "Works the core and hip flexors",
                "Great as a warm-up",
            ),
            camera = "Face the camera, 2 to 3 metres away, whole body from head to feet in view.",
            counting = "Each knee lifted to hip height counts once. Kinetro shows left and right separately.",
            safety = "Land softly and keep your chest up. Slow down if you feel dizzy or short of breath.",
        )
        ExerciseType.CRUNCHES -> Guide(
            steps = listOf(
                "Lie on your back with knees bent and feet flat on the floor.",
                "Place your hands lightly behind your head or cross them on your chest.",
                "Curl your shoulders up off the floor by tightening your stomach muscles.",
                "Lower back down slowly. Do not pull on your neck.",
            ),
            benefits = listOf(
                "Strengthens the abdominal muscles",
                "Improves core stability and posture",
                "Supports your lower back",
                "Needs only a mat or soft floor",
            ),
            camera = "Lie down with the phone on the floor at your SIDE, 1.5 to 2 metres away, so your whole body is in view.",
            counting = "A repetition is counted when your shoulders lift toward your knees and you lower back down.",
            safety = "Move slowly and keep your neck relaxed. Stop if your back or neck hurts.",
        )
        ExerciseType.GLUTE_BRIDGES -> Guide(
            steps = listOf(
                "Lie on your back with knees bent and feet flat, hip-width apart.",
                "Press through your heels and lift your hips until shoulders, hips and knees form a straight line.",
                "Squeeze your glutes at the top for a moment.",
                "Lower your hips slowly to the floor.",
            ),
            benefits = listOf(
                "Strengthens glutes and hamstrings",
                "Improves hip control and stability",
                "Helps reduce lower-back stiffness from sitting",
                "Gentle and suitable for beginners",
            ),
            camera = "Lie down with the phone on the floor at your SIDE, 1.5 to 2 metres away, whole body in view.",
            counting = "A repetition is counted when your hips rise high enough and come back down.",
            safety = "Do not arch your lower back too much. Stop if you feel pain in your back.",
        )
        ExerciseType.PLANK -> Guide(
            steps = listOf(
                "Rest on your forearms and toes, elbows under your shoulders.",
                "Keep your body in one straight line from head to heels.",
                "Tighten your stomach and glutes. Look at the floor.",
                "Hold the position and breathe normally.",
            ),
            benefits = listOf(
                "Strengthens abs, back and shoulders",
                "Builds muscular endurance",
                "Improves posture and balance",
                "No movement, so it is easy on the joints",
            ),
            camera = "Put the phone on the floor beside you (SIDE view), 1.5 to 2 metres away, so your whole body is in view.",
            counting = "Time is counted only while your body stays in a straight plank line. The timer pauses if your hips sag or rise.",
            safety = "Stop when your form breaks down. Do not hold your breath.",
        )
        ExerciseType.SIT_TO_STAND -> Guide(
            steps = listOf(
                "Sit near the front of a sturdy chair, back straight, feet flat on the floor about hip-width apart.",
                "Lean your chest forward a little and keep your arms crossed on your chest.",
                "Push through your feet and stand all the way up, straightening your knees and hips.",
                "Sit back down slowly and with control. Do not drop into the chair.",
            ),
            benefits = listOf(
                "Builds the leg and hip strength you need to get up from a chair or bed",
                "Makes climbing stairs and walking easier",
                "Supports balance and helps prevent falls",
                "Safe and gentle, a good start for beginners and older adults",
            ),
            camera = "Put the chair against a wall so it cannot slide. Sit SIDEWAYS to the camera, 2 to 3 metres away, phone at about hip height, whole body in view.",
            counting = "A repetition is counted when you stand up fully and sit back down. Standing only part of the way does not count.",
            safety = "Use a firm chair that will not move. Keep a wall or table within reach. Stop if you feel dizzy or have knee pain.",
        )
        ExerciseType.CALF_RAISES -> Guide(
            steps = listOf(
                "Stand tall with feet hip-width apart. Rest your fingertips on a wall or chair for balance.",
                "Keep your knees straight and your body upright.",
                "Slowly rise up onto the balls of your feet as high as you can.",
                "Lower your heels slowly back to the floor.",
            ),
            benefits = listOf(
                "Strengthens the calf muscles and ankles",
                "Improves balance and steady walking",
                "Helps the legs push blood back to the heart",
                "Needs no equipment and very little space",
            ),
            camera = "Stand SIDEWAYS to the camera, 2 to 3 metres away. Your whole body AND both feet must be inside the picture. Bare feet or flat shoes work best.",
            counting = "A repetition is counted when your heels rise clearly off the floor and come back down. Small lifts do not count.",
            safety = "Hold a wall or chair if you feel unsteady. Stop if you feel pain in your calves, ankles or feet.",
        )
        ExerciseType.SIDE_LEG_RAISES -> Guide(
            steps = listOf(
                "Stand tall facing the camera, feet together, hands on your hips or holding a chair.",
                "Keep your body straight and your toes pointing forward.",
                "Lift one leg out to the side, as high as you can without leaning.",
                "Lower it slowly, then lift the other leg. Keep alternating.",
            ),
            benefits = listOf(
                "Strengthens the hips and outer thighs",
                "Improves balance on one leg",
                "Supports stable walking and standing",
                "Needs no equipment",
            ),
            camera = "FACE the camera, 2 to 3 metres away, whole body from head to feet in view. Stand with a little space on both sides of you.",
            counting = "Each leg lifted clearly out to the side and lowered counts once. Kinetro shows left and right separately.",
            safety = "Hold a chair or wall for balance. Do not lean your body sideways. Stop if you feel hip or back pain.",
        )
    }
}
