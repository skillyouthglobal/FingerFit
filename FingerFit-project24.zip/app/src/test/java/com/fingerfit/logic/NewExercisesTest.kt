package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private const val NW = 480f
private const val NH = 640f

private fun pts(vararg parts: Triple<Int, Float, Float>): List<BodyPoint> {
    val a = Array(33) { BodyPoint(0f, 0f, 0f) }
    parts.forEach { a[it.first] = BodyPoint(it.second, it.third, 1f) }
    return a.toList()
}

private fun pt(i: Int, x: Float, y: Float) = Triple(i, x, y)
private fun duo(l: Int, r: Int, x: Float, y: Float) = arrayOf(pt(l, x, y), pt(r, x, y))

private class Rn(type: ExerciseType) {
    val engine = ExerciseEngine(type)
    var t = 1_000L
    var last: ExerciseEngine.Out? = null
    fun feed(p: List<BodyPoint>?, frames: Int) {
        repeat(frames) { last = engine.update(p, NW, NH, t, false); t += 33L }
    }
}

// side view, seated: knee bent 90 degrees
private val seated = pts(*duo(11, 12, 0.5f, 0.30f), *duo(23, 24, 0.5f, 0.50f), *duo(25, 26, 0.62f, 0.50f), *duo(27, 28, 0.62f, 0.68f))
private val standing = pts(*duo(11, 12, 0.5f, 0.30f), *duo(23, 24, 0.5f, 0.50f), *duo(25, 26, 0.5f, 0.69f), *duo(27, 28, 0.5f, 0.88f))
private val halfUp = pts(*duo(11, 12, 0.5f, 0.30f), *duo(23, 24, 0.5f, 0.50f), *duo(25, 26, 0.56f, 0.69f), *duo(27, 28, 0.5f, 0.88f))

private fun calf(up: Boolean) = pts(
    *duo(11, 12, 0.5f, 0.30f),
    pt(23, 0.5f, 0.50f), pt(25, 0.5f, 0.69f), pt(27, 0.5f, 0.86f),
    pt(29, 0.47f, if (up) 0.80f else 0.88f), pt(31, 0.58f, 0.88f),
)

private fun sideLeg(left: Boolean, right: Boolean, lean: Float = 0f): List<BodyPoint> {
    val la = if (left) pt(27, 0.16f, 0.80f) else pt(27, 0.44f, 0.88f)
    val lk = if (left) pt(25, 0.30f, 0.65f) else pt(25, 0.44f, 0.70f)
    val ra = if (right) pt(28, 0.84f, 0.80f) else pt(28, 0.56f, 0.88f)
    val rk = if (right) pt(26, 0.70f, 0.65f) else pt(26, 0.56f, 0.70f)
    return pts(pt(11, 0.4f + lean, 0.30f), pt(12, 0.6f + lean, 0.30f), pt(23, 0.44f, 0.50f), pt(24, 0.56f, 0.50f), lk, rk, la, ra)
}

class NewExercisesTest {
    private fun read(t: ExerciseType, p: List<BodyPoint>) = BodyClassifier.read(t, p, NW, NH)

    @Test fun sitToStandStates() {
        assertEquals(Pose.OPEN, read(ExerciseType.SIT_TO_STAND, seated).pose)
        assertEquals(Pose.CLOSED, read(ExerciseType.SIT_TO_STAND, standing).pose)
        assertEquals(Pose.UNKNOWN, read(ExerciseType.SIT_TO_STAND, halfUp).pose)
    }

    @Test fun sitToStandCountsThree() {
        val r = Rn(ExerciseType.SIT_TO_STAND)
        r.feed(seated, 12)
        repeat(3) { r.feed(standing, 12); r.feed(seated, 12) }
        assertEquals(3, r.engine.reps)
    }

    @Test fun halfStandDoesNotCountAndGivesATip() {
        val r = Rn(ExerciseType.SIT_TO_STAND)
        r.feed(seated, 12)
        r.feed(halfUp, 12); r.feed(seated, 12)
        assertEquals(0, r.engine.reps)
    }

    @Test fun calfStates() {
        assertEquals(Pose.OPEN, read(ExerciseType.CALF_RAISES, calf(false)).pose)
        assertEquals(Pose.CLOSED, read(ExerciseType.CALF_RAISES, calf(true)).pose)
    }

    @Test fun calfRaisesCountFour() {
        val r = Rn(ExerciseType.CALF_RAISES)
        r.feed(calf(false), 12)
        repeat(4) { r.feed(calf(true), 12); r.feed(calf(false), 12) }
        assertEquals(4, r.engine.reps)
    }

    @Test fun calfWithoutFeetInViewIsInvalid() {
        val noFeet = pts(*duo(11, 12, 0.5f, 0.30f), pt(23, 0.5f, 0.50f), pt(25, 0.5f, 0.69f), pt(27, 0.5f, 0.86f))
        assertTrue(!read(ExerciseType.CALF_RAISES, noFeet).valid)
    }

    @Test fun sideLegsCountEachLegSeparately() {
        val r = Rn(ExerciseType.SIDE_LEG_RAISES)
        r.feed(sideLeg(false, false), 8)
        repeat(3) { r.feed(sideLeg(true, false), 8); r.feed(sideLeg(false, false), 8) }
        repeat(2) { r.feed(sideLeg(false, true), 8); r.feed(sideLeg(false, false), 8) }
        assertEquals(5, r.engine.reps)
        assertEquals(3, r.engine.leftReps)
        assertEquals(2, r.engine.rightReps)
    }

    @Test fun sideLegSittingBackToCameraIsNotRead() {
        val narrow = pts(pt(11, 0.49f, 0.30f), pt(12, 0.51f, 0.30f), pt(23, 0.49f, 0.50f), pt(24, 0.51f, 0.50f),
            pt(25, 0.49f, 0.70f), pt(26, 0.51f, 0.70f), pt(27, 0.49f, 0.88f), pt(28, 0.51f, 0.88f))
        assertTrue(!read(ExerciseType.SIDE_LEG_RAISES, narrow).valid)
    }

    @Test fun newExercisesHaveEverythingTheScreensNeed() {
        listOf(ExerciseType.SIT_TO_STAND, ExerciseType.CALF_RAISES, ExerciseType.SIDE_LEG_RAISES).forEach { t ->
            val g = Guides.of(t)
            assertEquals(4, g.steps.size); assertEquals(4, g.benefits.size)
            val sim = Sims.of(t)
            assertTrue(sim.cycleMs > 1000)
            assertTrue(sim.steps.all { it.step in 0..3 })
            assertEquals(PlanGroup.MUSCLE, Plans.groupOf(t))
        }
        assertTrue(Sims.of(ExerciseType.SIT_TO_STAND).chair)
    }
}
