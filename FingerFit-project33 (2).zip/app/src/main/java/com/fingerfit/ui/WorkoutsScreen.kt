package com.fingerfit.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.data.Repo
import com.fingerfit.data.todayReps
import com.fingerfit.data.toLocalDate
import com.fingerfit.logic.Bn
import com.fingerfit.logic.ExerciseType
import com.fingerfit.logic.LibCat
import com.fingerfit.logic.LibItem
import com.fingerfit.logic.LibPart
import com.fingerfit.logic.LibSearch
import com.fingerfit.logic.Library
import androidx.compose.foundation.lazy.items as rowItems
import java.time.LocalDate

internal fun pick(isBn: Boolean, en: String, bn: String): String = if (isBn) bn else en

/** A number in Bengali or English digits. */
internal fun num(isBn: Boolean, n: Int): String = if (isBn) Bn.toBn(n.toString()) else n.toString()

private fun catColor(c: LibCat): Color = when (c) {
    LibCat.HEART -> Color(0xFFFFE1E1)
    LibCat.CHEST -> Color(0xFFDCE8FF)
    LibCat.ARMS -> Color(0xFFFFEFD0)
    LibCat.BACK -> Color(0xFFE6E0FF)
    LibCat.CORE -> Color(0xFFD9F7E8)
    LibCat.LEGS -> Color(0xFFD6F2FA)
    LibCat.FLEX -> Color(0xFFF6E1F7)
    LibCat.FULL -> Color(0xFFFFE9D6)
}

private fun catEmoji(c: LibCat): String = when (c) {
    LibCat.HEART -> "❤️"
    LibCat.CHEST -> "💪"
    LibCat.ARMS -> "🏋️"
    LibCat.BACK -> "🧍"
    LibCat.CORE -> "🔥"
    LibCat.LEGS -> "🦵"
    LibCat.FLEX -> "🧘"
    LibCat.FULL -> "⚡"
}

private val POPULAR = listOf(
    ExerciseType.JUMPING_JACKS, ExerciseType.SQUATS, ExerciseType.PUSH_UPS, ExerciseType.PLANK,
    ExerciseType.HIGH_KNEES, ExerciseType.LUNGES, ExerciseType.CRUNCHES, ExerciseType.JUMP_ROPE,
)

@Composable
private fun ExerciseCard(item: LibItem, done: Int, isBn: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val unit = if (item.timed) pick(isBn, "sec", "সেকেন্ড") else pick(isBn, "reps", "বার")
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.clickable(onClick = onClick),
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.fillMaxWidth().height(76.dp).background(catColor(item.cat), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center,
            ) { Text(item.emoji, fontSize = 40.sp) }
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().height(40.dp), contentAlignment = Alignment.Center) {
                Text(
                    item.name(isBn), fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 2,
                    textAlign = TextAlign.Center, lineHeight = 18.sp, color = MaterialTheme.colorScheme.onSurface,
                )
            }
            Text(
                "${pick(isBn, item.cat.en, item.cat.bn)} · ${num(isBn, item.target)} $unit",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
            )
            Text(
                when {
                    done > 0 -> pick(isBn, "Today: $done", "আজ: ${num(true, done)}")
                    item.camera -> pick(isBn, "📷 Camera counts", "📷 ক্যামেরা গোনে")
                    else -> pick(isBn, "Guided", "নির্দেশনা সহ")
                },
                fontSize = 12.sp, color = MaterialTheme.colorScheme.tertiary,
                fontWeight = FontWeight.SemiBold, maxLines = 1,
            )
        }
    }
}

/** The "Exercise" tab: popular exercises and body-area cards first, then a filtered list with search. */
@Composable
fun BodyListScreen(
    vm: AppViewModel,
    onBack: () -> Unit,
    onPick: (ExerciseType) -> Unit,
    onFinger: () -> Unit,
    onLib: (LibItem) -> Unit,
) {
    val workouts by Repo.workouts.collectAsStateWithLifecycle()
    val today = LocalDate.now()
    val history by vm.history.collectAsStateWithLifecycle()
    val fingerToday = history.todayReps()
    val isBn = LangState.bn
    var query by rememberSaveable { mutableStateOf("") }
    var catName by rememberSaveable { mutableStateOf("") }
    var partName by rememberSaveable { mutableStateOf("") }
    var noEquip by rememberSaveable { mutableStateOf(false) }
    var camOnly by rememberSaveable { mutableStateOf(false) }
    var showAll by rememberSaveable { mutableStateOf(false) }
    val shown: List<LibItem> = remember(query, catName, partName, noEquip, camOnly) {
        val cat = LibCat.values().firstOrNull { it.name == catName }
        val part = LibPart.values().firstOrNull { it.name == partName }
        LibSearch.search(Library.filter(Library.all, cat, part, noEquip, camOnly), query)
    }
    val popular: List<LibItem> = remember { POPULAR.mapNotNull { t -> Library.all.firstOrNull { it.type == t } } }
    val filtering = query.isNotBlank() || catName.isNotEmpty() || partName.isNotEmpty() || noEquip || camOnly || showAll
    val clearAll = { query = ""; catName = ""; partName = ""; noEquip = false; camOnly = false; showAll = false }
    BackHandler { if (filtering) clearAll() else onBack() }

    fun doneOf(item: LibItem): Int =
        if (item.finger) fingerToday else item.type?.let { t ->
            workouts.filter { it.type == t.name && it.t.toLocalDate() == today }.sumOf { it.reps }
        } ?: 0

    fun open(item: LibItem) {
        val t = item.type
        if (t != null) onPick(t) else if (item.finger) onFinger() else onLib(item)
    }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.statusBarsPadding()) {
        Column {
            Box(
                Modifier.fillMaxWidth()
                    .background(Brush.horizontalGradient(listOf(Color(0xFF1FBF92), Color(0xFF2F6BFF))))
                    .padding(horizontal = 22.dp, vertical = 16.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (filtering) {
                        Box(
                            Modifier.height(40.dp).width(40.dp).background(Color(0x33FFFFFF), RoundedCornerShape(14.dp))
                                .clickable { clearAll() },
                            contentAlignment = Alignment.Center,
                        ) { Text("←", fontSize = 22.sp, color = Color.White, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(12.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (catName.isNotEmpty()) {
                                LibCat.values().firstOrNull { it.name == catName }?.let { pick(isBn, it.en, it.bn) } ?: "Exercise"
                            } else "Exercise",
                            fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Color.White,
                        )
                        Text(
                            pick(isBn, "Pick an exercise. The camera counts for you.", "একটি ব্যায়াম বেছে নিন। ক্যামেরা আপনার হয়ে গুনবে।"),
                            color = Color(0xFFE8F4FF), fontSize = 13.sp,
                        )
                    }
                }
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it.take(60) },
                singleLine = true,
                placeholder = { Text("Search exercises, e.g. belly, push-up") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, contentDescription = "Clear") }
                    }
                },
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp),
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 22.dp, end = 22.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (!filtering) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text(pick(isBn, "🔥 Popular", "🔥 জনপ্রিয়"), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            rowItems(popular, key = { it.id }) { p ->
                                ExerciseCard(p, doneOf(p), isBn, Modifier.width(150.dp)) { open(p) }
                            }
                        }
                    }
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text(pick(isBn, "Choose by body area", "শরীরের অংশ অনুযায়ী বেছে নিন"), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    items(LibCat.values().toList(), key = { it.name }) { c ->
                        Card(
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = catColor(c)),
                            modifier = Modifier.fillMaxWidth().clickable { catName = c.name },
                        ) {
                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                Text(catEmoji(c), fontSize = 32.sp)
                                Spacer(Modifier.height(6.dp))
                                Text(pick(isBn, c.en, c.bn), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF12203F), maxLines = 2)
                                Text(
                                    pick(isBn, "${Library.all.count { it.cat == c }} exercises", "${num(true, Library.all.count { it.cat == c })}টি ব্যায়াম"),
                                    fontSize = 12.sp, color = Color(0xFF3F4F70),
                                )
                            }
                        }
                    }
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = false, onClick = { noEquip = true }, label = { Text(pick(isBn, "No equipment", "সরঞ্জাম ছাড়া")) })
                            FilterChip(selected = false, onClick = { camOnly = true }, label = { Text(pick(isBn, "Camera counts", "ক্যামেরা গোনে")) })
                            FilterChip(selected = false, onClick = { showAll = true }, label = { Text(pick(isBn, "Show all exercises", "সব ব্যায়াম দেখুন")) })
                        }
                    }
                } else {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = partName.isEmpty(), onClick = { partName = "" }, label = { Text(pick(isBn, "Any part", "সব অংশ")) })
                                LibPart.values().forEach { p ->
                                    FilterChip(
                                        selected = partName == p.name,
                                        onClick = { partName = if (partName == p.name) "" else p.name },
                                        label = { Text(pick(isBn, p.en, p.bn)) },
                                    )
                                }
                            }
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = noEquip, onClick = { noEquip = !noEquip }, label = { Text(pick(isBn, "No equipment", "সরঞ্জাম ছাড়া")) })
                                FilterChip(selected = camOnly, onClick = { camOnly = !camOnly }, label = { Text(pick(isBn, "Camera counts", "ক্যামেরা গোনে")) })
                            }
                            Text(
                                pick(isBn, "${shown.size} exercises", "${num(true, shown.size)}টি ব্যায়াম"),
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    if (shown.isEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Column(Modifier.fillMaxWidth().padding(vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("🔍", fontSize = 40.sp)
                                Text(
                                    pick(isBn, "No exercise found. Try another word or go back.", "কোনো ব্যায়াম পাওয়া যায়নি। অন্য শব্দ লিখুন বা পেছনে যান।"),
                                    textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    items(shown, key = { it.id }) { item ->
                        ExerciseCard(item, doneOf(item), isBn, Modifier.fillMaxWidth()) { open(item) }
                    }
                }
            }
        }
    }
}
