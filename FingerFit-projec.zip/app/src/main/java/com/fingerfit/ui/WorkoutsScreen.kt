package com.fingerfit.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.data.Repo
import com.fingerfit.data.toLocalDate
import com.fingerfit.logic.ExerciseType
import com.fingerfit.logic.PlanGroup
import com.fingerfit.logic.Plans
import java.time.LocalDate

/** The "Workouts" tab: all camera-tracked exercises, filtered by purpose. */
@Composable
fun BodyListScreen(onBack: () -> Unit, onPick: (ExerciseType) -> Unit) {
    BackHandler(onBack = onBack)
    val workouts by Repo.workouts.collectAsStateWithLifecycle()
    val today = LocalDate.now()
    var filter by rememberSaveable { mutableStateOf("ALL") }
    val shown = ExerciseType.values().filter { filter == "ALL" || Plans.groupOf(it).name == filter }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.statusBarsPadding()) {
        Column {
            Column(Modifier.padding(start = 22.dp, end = 22.dp, top = 16.dp)) {
                Text("Workouts", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "The camera counts every rep. Keep your whole body in view.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp,
                )
            }
            Row(
                Modifier.padding(horizontal = 22.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(selected = filter == "ALL", onClick = { filter = "ALL" }, label = { Text("All") })
                PlanGroup.values().forEach { g ->
                    FilterChip(selected = filter == g.name, onClick = { filter = g.name }, label = { Text(g.chip) })
                }
            }
            LazyColumn(
                contentPadding = PaddingValues(start = 22.dp, end = 22.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(shown) { type ->
                    val done = workouts
                        .filter { it.type == type.name && it.t.toLocalDate() == today }
                        .sumOf { it.reps }
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth().clickable { onPick(type) },
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(52.dp).background(HeroTint, RoundedCornerShape(16.dp)),
                                contentAlignment = Alignment.Center,
                            ) { Text(type.emoji, fontSize = 28.sp) }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(type.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text(
                                    "${Plans.groupOf(type).chip} · target ${type.defaultTarget} ${type.unit}",
                                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                if (done > 0) {
                                    Text(
                                        "Today: $done ${type.unit}", fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold,
                                    )
                                }
                            }
                            Text("›", fontSize = 28.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
