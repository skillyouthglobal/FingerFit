import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Every GitHub build passes its run number (-PversionCode=N), so each new APK has a higher version
// and installs directly over the old one.
val appVersionCode = (project.findProperty("versionCode") as String?)?.toIntOrNull() ?: 1

android {
    namespace = "com.fingerfit"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.fingerfit"
        minSdk = 26
        targetSdk = 35
        versionCode = appVersionCode
        versionName = "1.0.$appVersionCode"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    // One fixed signing key for every build. Without it each GitHub build is signed with a new random
    // key and Android refuses to update the installed app (you would have to uninstall first).
    signingConfigs {
        getByName("debug") {
            storeFile = file("kinetro.keystore")
            storePassword = "kinetro-key-2026"
            keyAlias = "kinetro"
            keyPassword = "kinetro-key-2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Signed with the standard debug key so the release APK installs
            // directly on a phone (sideloading). Not suitable for Play Store.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { compose = true }

    androidResources { noCompress += "task" }

    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.core:core-ktx:1.13.1")

    val camerax = "1.4.0"
    implementation("androidx.camera:camera-core:$camerax")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")
    implementation("androidx.camera:camera-view:$camerax")

    implementation("com.google.mediapipe:tasks-vision:0.10.14")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("com.google.android.gms:play-services-nearby:19.3.0")
    // Browser-camera mode: tiny local web server (works over Wi-Fi/hotspot, no internet) and QR code.
    implementation("org.nanohttpd:nanohttpd:2.3.1")
    implementation("com.google.zxing:core:3.5.3")

    testImplementation("junit:junit:4.13.2")
}

// ---------------------------------------------------------------------------
// The MediaPipe hand model is fetched ONCE at build time and packaged inside
// the APK (src/main/assets/hand_landmarker.task). The installed app never
// downloads anything and works fully offline.
// ---------------------------------------------------------------------------
val modelFile = layout.projectDirectory.file("src/main/assets/hand_landmarker.task").asFile
val downloadHandModel by tasks.registering {
    outputs.file(modelFile)
    onlyIf { !modelFile.exists() || modelFile.length() < 1_000_000L }
    doLast {
        modelFile.parentFile.mkdirs()
        val url = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
        URL(url).openStream().use { input -> modelFile.outputStream().use { input.copyTo(it) } }
        check(modelFile.length() > 1_000_000L) { "hand_landmarker.task download looks incomplete" }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(downloadHandModel) }

// Same idea for the full-body pose model used by the body workouts.
val poseFile = layout.projectDirectory.file("src/main/assets/pose_landmarker_lite.task").asFile
val downloadPoseModel by tasks.registering {
    outputs.file(poseFile)
    onlyIf { !poseFile.exists() || poseFile.length() < 1_000_000L }
    doLast {
        poseFile.parentFile.mkdirs()
        val url = "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task"
        URL(url).openStream().use { input -> poseFile.outputStream().use { input.copyTo(it) } }
        check(poseFile.length() > 1_000_000L) { "pose_landmarker_lite.task download looks incomplete" }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(downloadPoseModel) }
