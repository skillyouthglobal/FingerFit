package com.fingerfit

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fingerfit.link.LinkRole
import com.fingerfit.link.LinkService
import com.fingerfit.link.LinkState
import com.fingerfit.link.LinkUi
import com.fingerfit.link.NearbyLink
import com.fingerfit.link.Peer
import com.fingerfit.link.WebCamServer
import com.fingerfit.link.WebUi
import com.fingerfit.logic.Wire
import com.fingerfit.vision.PoseFrame
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

/**
 * Two-phone mode. The link stays alive until the user taps Disconnect (or the app is closed
 * completely); leaving the screen or the app does not drop it.
 */
class LinkViewModel(private val app: Application) : AndroidViewModel(app) {

    private val link = NearbyLink(app) { bytes -> onBytes(bytes) }
    val ui: StateFlow<LinkUi> = link.ui

    private val web = WebCamServer(app, { f -> onWebFrame(f) }, { jpeg -> showPreview(jpeg) })
    /** Browser-camera mode (the other phone needs no app). */
    val webUi: StateFlow<WebUi> = web.ui

    private val _streamOk = MutableStateFlow(false)
    /** True while body data keeps arriving from the camera phone. */
    val streamOk: StateFlow<Boolean> = _streamOk.asStateFlow()

    private val _preview = MutableStateFlow<Bitmap?>(null)
    /** Latest small picture from the camera phone (shown behind the skeleton). */
    val preview: StateFlow<Bitmap?> = _preview.asStateFlow()

    private val _useRemote = MutableStateFlow(true)
    /** The workout screen uses the other phone's camera while this is true and a phone is linked. */
    val useRemote: StateFlow<Boolean> = _useRemote.asStateFlow()

    @Volatile private var sink: ((PoseFrame) -> Unit)? = null
    @Volatile private var lastFrameAt = 0L
    @Volatile private var lastSentAt = 0L
    @Volatile private var lastPreviewSentAt = 0L
    @Volatile private var lastPreviewShownAt = 0L
    private var wasAvailable = false
    private var serviceOn = false

    init {
        viewModelScope.launch {
            while (true) {
                val l = link.ui.value
                val webOn = web.ui.value.running
                val linked = l.state == LinkState.CONNECTED || webOn
                val ok = linked && SystemClock.uptimeMillis() - lastFrameAt < 2000
                if (_streamOk.value != ok) _streamOk.value = ok
                if (!ok && _preview.value != null) _preview.value = null

                // A newly linked phone becomes the camera automatically.
                val available = (l.state == LinkState.CONNECTED && l.role == LinkRole.DISPLAY) || webOn
                if (available && !wasAvailable) _useRemote.value = true
                wasAvailable = available

                // Keep the link alive in the background while linked.
                if (linked != serviceOn) {
                    serviceOn = linked
                    try {
                        val i = Intent(app, LinkService::class.java)
                        if (linked) ContextCompat.startForegroundService(app, i) else app.stopService(i)
                    } catch (e: Exception) {
                    }
                }
                delay(500)
            }
        }
    }

    fun setSink(s: ((PoseFrame) -> Unit)?) {
        sink = s
    }

    fun setUseRemote(v: Boolean) {
        _useRemote.value = v
    }

    fun startDisplay() {
        web.stop()
        link.startDisplay()
    }

    fun startCamera() {
        web.stop()
        link.startCamera()
    }

    fun connect(peer: Peer) = link.connect(peer)
    fun accept() = link.accept()
    fun reject() = link.reject()

    fun startWeb() {
        link.stop()
        web.start()
    }

    fun refreshWeb() = web.refresh()

    /** Disconnect everything. */
    fun stop() {
        link.stop()
        web.stop()
        lastFrameAt = 0L
        _preview.value = null
    }

    fun isConnected(): Boolean = link.isConnected()

    /** Camera phone: send one analysed frame (about 14 per second at most). */
    fun sendPose(f: PoseFrame?) {
        if (f == null || !link.isConnected()) return
        val now = SystemClock.uptimeMillis()
        if (now - lastSentAt < MIN_SEND_GAP_MS) return
        lastSentAt = now
        link.send(Wire.encodePose(f.points, f.width, f.height, f.lightingOk, f.mirrored, f.timeMs))
    }

    /** Camera phone: send a small picture (about 6 per second) so the main phone can show the view. */
    fun sendPicture(upright: Bitmap) {
        if (!link.isConnected()) return
        val now = SystemClock.uptimeMillis()
        if (now - lastPreviewSentAt < PREVIEW_GAP_MS) return
        lastPreviewSentAt = now
        val k = PREVIEW_SIDE.toFloat() / maxOf(upright.width, upright.height)
        val small = if (k < 1f) {
            Bitmap.createScaledBitmap(upright, (upright.width * k).toInt().coerceAtLeast(1), (upright.height * k).toInt().coerceAtLeast(1), true)
        } else upright
        val os = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 55, os)
        if (small !== upright) small.recycle()
        val msg = Wire.encodePreview(os.toByteArray()) ?: return
        link.send(msg)
    }

    private fun onBytes(bytes: ByteArray) {
        if (Wire.isPreview(bytes)) {
            Wire.previewBytes(bytes)?.let { showPreview(it) }
            return
        }
        val d = Wire.decodePose(bytes) ?: return
        lastFrameAt = SystemClock.uptimeMillis()
        sink?.invoke(PoseFrame(d.points, d.width, d.height, d.lightingOk, d.mirrored, d.timeMs))
    }

    private fun showPreview(jpeg: ByteArray) {
        val now = SystemClock.uptimeMillis()
        if (now - lastPreviewShownAt < 60) return
        lastPreviewShownAt = now
        try {
            val bmp = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return
            _preview.value = bmp
        } catch (e: Exception) {
        }
    }

    private fun onWebFrame(f: PoseFrame) {
        lastFrameAt = SystemClock.uptimeMillis()
        sink?.invoke(f)
    }

    override fun onCleared() {
        web.stop()
        link.release()
        try {
            app.stopService(Intent(app, LinkService::class.java))
        } catch (e: Exception) {
        }
    }

    private companion object {
        const val MIN_SEND_GAP_MS = 70L
        const val PREVIEW_GAP_MS = 160L
        const val PREVIEW_SIDE = 256
    }
}
