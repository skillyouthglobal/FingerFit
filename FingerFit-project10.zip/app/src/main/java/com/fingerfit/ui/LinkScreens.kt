package com.fingerfit.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.LinkViewModel
import com.fingerfit.link.LinkPermissions
import com.fingerfit.link.LinkRole
import com.fingerfit.link.LinkState
import com.fingerfit.link.WebUi
import com.fingerfit.logic.ExerciseType
import com.fingerfit.vision.PoseAnalyzer
import com.fingerfit.vision.PoseTracker
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

private fun missing(context: Context, perms: List<String>): List<String> =
    perms.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }

/**
 * Two-phone mode. One phone (the camera phone) watches the exercise; the other (the main phone)
 * counts and shows everything. The link stays connected until the user taps Disconnect.
 * No internet is needed.
 */
@Composable
fun LinkScreen(link: LinkViewModel, onBack: () -> Unit, onWorkout: (ExerciseType) -> Unit) {
    val context = LocalContext.current
    val ui by link.ui.collectAsStateWithLifecycle()
    val webUi by link.webUi.collectAsStateWithLifecycle()
    var permissionDenied by remember { mutableStateOf(false) }
    var pendingRole by rememberSaveable { mutableStateOf("") }

    fun begin(role: String) {
        permissionDenied = false
        if (role == "display") link.startDisplay() else link.startCamera()
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.all { it }) begin(pendingRole) else permissionDenied = true
    }

    fun choose(role: String) {
        pendingRole = role
        val need = LinkPermissions.nearby() + if (role == "camera") listOf(Manifest.permission.CAMERA) else emptyList()
        val miss = missing(context, need)
        if (miss.isEmpty()) begin(role) else launcher.launch(miss.toTypedArray())
    }

    // Going back never drops the connection; use the Disconnect button for that.
    BackHandler(onBack = onBack)

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                Text("Two-Phone Mode", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            when {
                ui.role == LinkRole.DISPLAY || webUi.running ->
                    DisplaySide(link = link, web = webUi.running && ui.role == LinkRole.NONE, webUi = webUi, onWorkout = onWorkout)
                ui.role == LinkRole.CAMERA -> CameraSide(link = link)
                else -> RoleChooser(
                    denied = permissionDenied,
                    webError = webUi.error,
                    onDisplay = { choose("display") },
                    onCamera = { choose("camera") },
                    onWeb = { link.startWeb() },
                    onOpenSettings = {
                        context.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)),
                        )
                    },
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Choose what this phone does
// ---------------------------------------------------------------------------

@Composable
private fun RoleChooser(
    denied: Boolean,
    webError: String?,
    onDisplay: () -> Unit,
    onCamera: () -> Unit,
    onWeb: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(
            "Use a second phone as the camera. You will see its camera view on this phone, and the app counts " +
                "your exercise. Only a small picture and body-position data are sent over your own Wi-Fi/Bluetooth. " +
                "Nothing is saved and nothing goes to the internet.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 14.sp,
        )
        Text("Both phones have Kinetro", fontWeight = FontWeight.SemiBold)
        RoleCard("📱", "This is the MAIN phone", "Shows the camera view, counter, timer and controls.", onDisplay)
        RoleCard("📷", "This is the CAMERA phone", "Prop it up so it sees your whole body. Keep Kinetro open on it.", onCamera)

        Text("The other phone has NO app", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
        RoleCard(
            "🌐", "Use the other phone's browser",
            "This phone is the MAIN phone. The other phone just opens a link. Works over Wi-Fi or hotspot, no internet.",
            onWeb,
        )
        webError?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 14.sp) }

        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("How to connect (both phones have Kinetro)", fontWeight = FontWeight.SemiBold)
                Text(
                    "1. Open Two-Phone Mode on both phones.\n" +
                        "2. On the first phone tap MAIN, on the second tap CAMERA.\n" +
                        "3. On the camera phone tap the name of the main phone.\n" +
                        "4. Check that both phones show the same code, then tap Accept on the main phone.\n" +
                        "5. You stay connected until you tap Disconnect.",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text("Works without internet", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                Text(
                    "The phones find each other automatically over Wi-Fi (same router or one phone's hotspot), " +
                        "Wi-Fi Direct or Bluetooth, whichever works best. Just turn on Bluetooth and Wi-Fi on both phones " +
                        "(no internet needed). On older phones also turn on Location. Google Play Services must be installed.",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        if (denied) {
            Text(
                "Permission was denied. Allow \"Nearby devices\" (and Camera) to use Two-Phone Mode.",
                color = MaterialTheme.colorScheme.error,
                fontSize = 14.sp,
            )
            OutlinedButton(onClick = onOpenSettings, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) {
                Text("Open app settings")
            }
        }
    }
}

@Composable
private fun RoleCard(emoji: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 34.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("›", fontSize = 28.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---------------------------------------------------------------------------
// MAIN phone: pairing, then pick an exercise (the workout screen shows the camera view)
// ---------------------------------------------------------------------------

@Composable
private fun DisplaySide(link: LinkViewModel, web: Boolean, webUi: WebUi, onWorkout: (ExerciseType) -> Unit) {
    val ui by link.ui.collectAsStateWithLifecycle()
    val streamOk by link.streamOk.collectAsStateWithLifecycle()
    val preview by link.preview.collectAsStateWithLifecycle()
    val connected = if (web) streamOk else ui.state == LinkState.CONNECTED

    if (web && !connected) {
        WebWaiting(webUi, onRefresh = link::refreshWeb, onCancel = link::stop)
        return
    }

    if (!connected) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text("📱", fontSize = 48.sp)
            Spacer(Modifier.height(12.dp))
            Text("MAIN phone", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(ui.message, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(10.dp))
            Text(
                "Now open Two-Phone Mode on the other phone, tap CAMERA, and choose this phone.",
                textAlign = TextAlign.Center,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = link::startDisplay, shape = RoundedCornerShape(16.dp)) { Text("Search again") }
                OutlinedButton(onClick = link::stop, shape = RoundedCornerShape(16.dp)) { Text("Cancel") }
            }
        }
        if (ui.needsAccept) {
            AlertDialog(
                onDismissRequest = {},
                title = { Text("Connect camera phone?") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${ui.peerName ?: "A phone"} wants to be your camera.")
                        Text("Code on both phones must be the same:")
                        Text(ui.code ?: "----", fontSize = 34.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                    }
                },
                confirmButton = { TextButton(onClick = link::accept) { Text("Accept") } },
                dismissButton = { TextButton(onClick = link::reject) { Text("Reject") } },
            )
        }
        return
    }

    val name = if (web) "Browser camera" else (ui.peerName ?: "Camera phone")
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x3316A34A)).padding(start = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "✅ Connected: $name",
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                modifier = Modifier.weight(1f).padding(vertical = 12.dp),
            )
            TextButton(onClick = link::stop) { Text("Disconnect", color = MaterialTheme.colorScheme.error) }
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(16.dp)).background(Color.Black), contentAlignment = Alignment.Center) {
            val bmp = preview
            if (bmp != null) {
                Image(bitmap = bmp.asImageBitmap(), contentDescription = "Camera view", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            } else {
                Text("Waiting for the camera view…", color = Color.White, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Choose an exercise", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(
            "The connected phone is used as the camera. You can disconnect any time.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(6.dp))
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ExerciseType.values().forEach { type ->
                RoleCard(type.emoji, type.title, type.benefit) { onWorkout(type) }
            }
        }
    }
}

@Composable
private fun WebWaiting(webUi: WebUi, onRefresh: () -> Unit, onCancel: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("🌐 Browser camera", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (webUi.checking) {
            Text("Starting and checking… (a few seconds)", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            Text(
                "On the OTHER phone (no app needed) scan this QR code with its camera, or type the link into its browser.",
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 14.sp,
            )
            val first = webUi.urls.firstOrNull()
            if (first != null) {
                QrCode(first, 220.dp)
                webUi.urls.forEach { Text(it, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary) }
            }
        }
        webUi.error?.let { Text(it, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center, fontSize = 14.sp) }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onRefresh, shape = RoundedCornerShape(16.dp)) { Text("Refresh address") }
            OutlinedButton(onClick = onCancel, shape = RoundedCornerShape(16.dp)) { Text("Cancel") }
        }

        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Steps", fontWeight = FontWeight.SemiBold)
                Text(
                    "1. Put both phones on the same Wi-Fi, OR turn on THIS phone's hotspot and join it from the other " +
                        "phone. Internet is not needed. (If the other phone asks \"no internet, stay connected?\" say yes.)\n" +
                        "2. On the other phone scan the QR code, or open the link above in its browser.\n" +
                        "3. A page opens. If the browser shows \"Not secure\" / \"not private\", tap Advanced, then Continue. " +
                        "This is normal because the link is on your own phone. Browsers insist on this step before they " +
                        "let a camera start.\n" +
                        "4. Tap \"Start camera\" and allow the camera.\n" +
                        "5. This screen then shows the camera view and the exercise list.",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun QrCode(text: String, size: Dp) {
    val matrix = remember(text) {
        try {
            QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0)
        } catch (e: Exception) {
            null
        }
    }
    Canvas(Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(Color.White)) {
        val m = matrix ?: return@Canvas
        val cell = this.size.width / m.width
        for (y in 0 until m.height) for (x in 0 until m.width) {
            if (m.get(x, y)) drawRect(Color.Black, Offset(x * cell, y * cell), Size(cell + 0.6f, cell + 0.6f))
        }
    }
}

// ---------------------------------------------------------------------------
// CAMERA phone: find the main phone, then stream the view and body positions
// ---------------------------------------------------------------------------

@Composable
private fun CameraSide(link: LinkViewModel) {
    val ui by link.ui.collectAsStateWithLifecycle()

    if (ui.state != LinkState.CONNECTED) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("📷 CAMERA phone", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(ui.message, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (ui.state == LinkState.CONNECTING) {
                Text("Code (must match the main phone):", fontSize = 14.sp)
                Text(ui.code ?: "----", fontSize = 34.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                Text("Waiting for the main phone to tap Accept…", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text("Main phones found nearby", fontWeight = FontWeight.SemiBold)
                if (ui.peers.isEmpty()) {
                    Text(
                        "Nothing found yet. On the main phone open Two-Phone Mode and tap MAIN. " +
                            "Keep both phones close and Bluetooth/Wi-Fi turned on.",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                ui.peers.forEach { peer ->
                    Button(
                        onClick = { link.connect(peer) },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                    ) { Text("Connect to ${peer.name}", fontWeight = FontWeight.Bold) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = link::startCamera, shape = RoundedCornerShape(16.dp)) { Text("Search again") }
                OutlinedButton(onClick = link::stop, shape = RoundedCornerShape(16.dp)) { Text("Cancel") }
            }
        }
        return
    }

    val context = LocalContext.current
    val view = LocalView.current
    var front by rememberSaveable { mutableStateOf(false) }
    var tracker by remember { mutableStateOf<PoseTracker?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var retry by remember { mutableIntStateOf(0) }

    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    DisposableEffect(retry) {
        var t: PoseTracker? = null
        try {
            t = PoseTracker(context.applicationContext)
            error = null
        } catch (e: Throwable) {
            error = "The body-tracking model could not be loaded (${e.localizedMessage ?: "unknown error"}). Reinstall the app."
        }
        tracker = t
        onDispose {
            tracker = null
            t?.close()
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color.Black)) {
            val t = tracker
            if (t != null && error == null) {
                val analyzer = remember(t, front) { PoseAnalyzer(t, front, link::isConnected, link::sendPose, link::sendPicture) }
                CameraView(
                    front = front,
                    analyzer = analyzer,
                    onError = { error = it },
                    modifier = Modifier.fillMaxSize(),
                )
            }
            Text(
                "● Connected to ${ui.peerName ?: "main phone"}",
                color = Color.White,
                fontSize = 13.sp,
                modifier = Modifier.align(Alignment.TopStart).padding(12.dp).clip(RoundedCornerShape(50))
                    .background(Color(0x9916A34A)).padding(horizontal = 12.dp, vertical = 6.dp),
            )
            IconButton(
                onClick = { front = !front },
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).clip(CircleShape).background(Color(0x99000000)),
            ) { Icon(Icons.Default.Refresh, contentDescription = "Switch camera", tint = Color.White) }
            error?.let {
                Column(
                    Modifier.align(Alignment.Center).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(it, color = Color.White, textAlign = TextAlign.Center)
                    OutlinedButton(onClick = { error = null; retry++ }) { Text("Try again", color = Color.White) }
                }
            }
        }
        Text(
            "Prop this phone up so your whole body is in view, then use the main phone to start. " +
                "Keep Kinetro open on this screen. The phones stay connected until you tap Disconnect.",
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedButton(onClick = link::stop, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) {
            Text("Disconnect")
        }
    }
}
