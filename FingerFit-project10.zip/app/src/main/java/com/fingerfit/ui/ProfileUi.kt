package com.fingerfit.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fingerfit.data.Profile
import com.fingerfit.logic.Gender
import com.fingerfit.logic.Goal
import com.fingerfit.logic.Health
import java.time.LocalDate
import java.util.Locale

private fun fmt(v: Float): String = String.format(Locale.US, "%.1f", v)

/** First-launch questions (name, date of birth, gender, height, weight, goal). Also used to edit them later. */
@Composable
fun OnboardingScreen(initial: Profile?, onDone: (Profile) -> Unit, onBack: (() -> Unit)?) {
    if (onBack != null) BackHandler(onBack = onBack)

    var name by rememberSaveable { mutableStateOf(initial?.name ?: "") }
    var day by rememberSaveable { mutableStateOf(initial?.birth?.dayOfMonth?.toString() ?: "") }
    var month by rememberSaveable { mutableStateOf(initial?.birth?.monthValue?.toString() ?: "") }
    var year by rememberSaveable { mutableStateOf(initial?.birth?.year?.toString() ?: "") }
    var gender by rememberSaveable { mutableStateOf(initial?.gender?.name ?: "") }
    var height by rememberSaveable { mutableStateOf(initial?.heightCm?.let { fmt(it) } ?: "") }
    var weight by rememberSaveable { mutableStateOf(initial?.weightKg?.let { fmt(it) } ?: "") }
    var goal by rememberSaveable { mutableStateOf(initial?.goal?.name ?: Goal.MAINTAIN.name) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    val today = LocalDate.now()
    val birth = Health.parseDate(day.toIntOrNull() ?: 0, month.toIntOrNull() ?: 0, year.toIntOrNull() ?: 0, today)
    val h = height.replace(',', '.').toFloatOrNull()
    val w = weight.replace(',', '.').toFloatOrNull()

    fun submit() {
        error = when {
            name.isBlank() -> "Please enter your name."
            birth == null -> "Please enter a valid date of birth (day, month, year)."
            Health.age(birth, today) !in 5..110 -> "Please check your date of birth."
            gender.isEmpty() -> "Please choose your gender."
            h == null || h !in 90f..250f -> "Height must be between 90 and 250 cm."
            w == null || w !in 15f..300f -> "Weight must be between 15 and 300 kg."
            else -> null
        }
        if (error == null && birth != null && h != null && w != null) {
            onDone(Profile(name.trim(), birth, Gender.valueOf(gender), h, w, Goal.valueOf(goal)))
        }
    }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.systemBarsPadding()) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp)) {
                if (onBack != null) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                } else {
                    Spacer(Modifier.padding(start = 16.dp))
                }
                Text(if (initial == null) "Welcome to Kinetro" else "Edit profile", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                if (initial == null) {
                    Text(
                        "Tell us a little about you. Your exercise and food plan will be built around these details. " +
                            "Everything stays on this phone.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 14.sp,
                    )
                }
                OutlinedTextField(
                    value = name, onValueChange = { name = it.take(40) }, label = { Text("Your name") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )

                Text("Date of birth", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = day, onValueChange = { day = it.filter(Char::isDigit).take(2) }, label = { Text("Day") },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = month, onValueChange = { month = it.filter(Char::isDigit).take(2) }, label = { Text("Month") },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = year, onValueChange = { year = it.filter(Char::isDigit).take(4) }, label = { Text("Year") },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1.4f),
                    )
                }

                Text("Gender", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Gender.values().forEach { g ->
                        FilterChip(selected = gender == g.name, onClick = { gender = g.name }, label = { Text(g.label) })
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = height, onValueChange = { height = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.take(5) },
                        label = { Text("Height (cm)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = weight, onValueChange = { weight = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.take(5) },
                        label = { Text("Weight (kg)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f),
                    )
                }

                Text("Your goal", fontWeight = FontWeight.SemiBold)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Goal.values().forEach { g ->
                        FilterChip(selected = goal == g.name, onClick = { goal = g.name }, label = { Text(g.label) })
                    }
                }

                if (birth != null && h != null && w != null && h in 90f..250f && w in 15f..300f) {
                    val bmi = Health.bmi(w, h)
                    val range = Health.healthyRangeKg(h)
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Age ${Health.age(birth, today)} years", fontWeight = FontWeight.SemiBold)
                            Text("BMI ${fmt(bmi)}  ·  ${Health.bmiCategory(bmi)}")
                            Text(
                                "Healthy weight for your height: ${fmt(range.first)} to ${fmt(range.second)} kg",
                                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }

                error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 14.sp) }
                Button(onClick = { submit() }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) {
                    Text(if (initial == null) "Save and continue" else "Save", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

/** Greeting and health summary shown at the top of the home screen. Tap to edit. */
@Composable
fun ProfileSummaryCard(profile: Profile, onEdit: () -> Unit) {
    val bmi = profile.bmi()
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onEdit),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Hello, ${profile.name} 👋", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                "Age ${profile.age()}  ·  ${fmt(profile.heightCm)} cm  ·  ${fmt(profile.weightKg)} kg",
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp,
            )
            Text(
                "BMI ${fmt(bmi)}  ·  ${com.fingerfit.logic.Health.bmiCategory(bmi)}  ·  Goal: ${profile.goal.label}",
                color = MaterialTheme.colorScheme.primary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            )
            Text("Tap to edit your profile", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
