package com.fingerfit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.data.ProfileRepo
import com.fingerfit.data.Repo
import com.fingerfit.link.LinkState
import com.fingerfit.logic.ExerciseType
import com.fingerfit.ui.BodyListScreen
import com.fingerfit.ui.ExerciseScreen
import com.fingerfit.ui.FingerFitTheme
import com.fingerfit.ui.HomeScreen
import com.fingerfit.ui.InboxScreen
import com.fingerfit.ui.LinkScreen
import com.fingerfit.ui.OnboardingScreen
import com.fingerfit.ui.SettingsScreen
import com.fingerfit.ui.SleepScreen
import com.fingerfit.ui.WalkScreen
import com.fingerfit.ui.WorkoutScreen

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    private val workoutVm: WorkoutViewModel by viewModels()
    private val linkVm: LinkViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(this)
        ProfileRepo.init(this)
        Notify.ensureChannels(this)
        val s = vm.settings.value
        Reminders.scheduleSleep(this, s.sleepReminder, s.sleepHour, s.sleepMinute)
        // Frames from a linked phone drive the workout whenever it is used as the camera.
        linkVm.setSink { frame -> if (linkVm.useRemote.value) workoutVm.onFrame(frame) }
        enableEdgeToEdge()
        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            FingerFitTheme(settings.theme) { FingerFitApp(vm, workoutVm, linkVm) }
        }
    }
}

private const val HOME = "home"
private const val EXERCISE = "exercise"
private const val SETTINGS = "settings"
private const val BODY = "body"
private const val WORKOUT = "workout"
private const val WALK = "walk"
private const val SLEEP = "sleep"
private const val INBOX = "inbox"
private const val LINK = "link"
private const val ONBOARDING = "onboarding"

@Composable
private fun FingerFitApp(vm: AppViewModel, workoutVm: WorkoutViewModel, linkVm: LinkViewModel) {
    val profile by ProfileRepo.profile.collectAsStateWithLifecycle()
    var screen by rememberSaveable { mutableStateOf(if (ProfileRepo.profile.value == null) ONBOARDING else HOME) }
    var workoutFrom by rememberSaveable { mutableStateOf(BODY) }
    val linkState by linkVm.ui.collectAsStateWithLifecycle()
    val webState by linkVm.webUi.collectAsStateWithLifecycle()
    val linkStatus = when {
        linkState.state == LinkState.CONNECTED -> "● Connected: ${linkState.peerName ?: "phone"}. Tap to manage"
        webState.running -> "● Browser camera is on. Tap to manage"
        else -> null
    }
    val goHome = { screen = HOME }
    when (screen) {
        ONBOARDING -> OnboardingScreen(
            initial = profile,
            onDone = { p ->
                ProfileRepo.save(p)
                screen = HOME
            },
            onBack = if (profile != null) goHome else null,
        )
        EXERCISE -> ExerciseScreen(vm, onExit = goHome)
        SETTINGS -> SettingsScreen(vm, onBack = goHome)
        BODY -> BodyListScreen(
            onBack = goHome,
            onPick = { type: ExerciseType ->
                workoutVm.select(type)
                workoutFrom = BODY
                screen = WORKOUT
            },
        )
        WORKOUT -> WorkoutScreen(workoutVm, vm, linkVm, onExit = { screen = workoutFrom })
        WALK -> WalkScreen(vm, onBack = goHome)
        SLEEP -> SleepScreen(vm, onBack = goHome)
        INBOX -> InboxScreen(onBack = goHome)
        LINK -> LinkScreen(
            linkVm,
            onBack = goHome,
            onWorkout = { type: ExerciseType ->
                workoutVm.select(type)
                linkVm.setUseRemote(true)
                workoutFrom = LINK
                screen = WORKOUT
            },
        )
        else -> HomeScreen(
            vm,
            onStart = { vm.prepareSession(); screen = EXERCISE },
            onSettings = { screen = SETTINGS },
            onBody = { screen = BODY },
            onWalk = { screen = WALK },
            onSleep = { screen = SLEEP },
            onInbox = { screen = INBOX },
            onLink = { screen = LINK },
            linkStatus = linkStatus,
            profile = profile,
            onProfile = { screen = ONBOARDING },
        )
    }
}
