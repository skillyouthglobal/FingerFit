package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class HealthTest {
    private val today = LocalDate.of(2026, 11, 1)

    @Test fun ageBeforeAndAfterBirthday() {
        assertEquals(30, Health.age(LocalDate.of(1996, 11, 1), today))
        assertEquals(29, Health.age(LocalDate.of(1996, 11, 2), today))
        assertEquals(0, Health.age(LocalDate.of(2026, 12, 1), today))
    }

    @Test fun bmiAndCategories() {
        assertTrue(kotlin.math.abs(Health.bmi(70f, 175f) - 22.86f) < 0.05f)
        assertEquals("Underweight", Health.bmiCategory(Health.bmi(50f, 175f)))
        assertEquals("Healthy weight", Health.bmiCategory(Health.bmi(70f, 175f)))
        assertEquals("Overweight", Health.bmiCategory(Health.bmi(80f, 175f)))
        assertEquals("Obese", Health.bmiCategory(Health.bmi(95f, 175f)))
        assertEquals(0f, Health.bmi(70f, 0f))
    }

    @Test fun healthyRange() {
        val r = Health.healthyRangeKg(170f)
        assertTrue(kotlin.math.abs(r.first - 53.5f) < 0.1f)
        assertTrue(kotlin.math.abs(r.second - 66.2f) < 0.1f)
    }

    @Test fun dateParsing() {
        assertEquals(LocalDate.of(1995, 2, 28), Health.parseDate(28, 2, 1995, today))
        assertTrue(Health.parseDate(30, 2, 1995, today) == null)
        assertTrue(Health.parseDate(1, 13, 1995, today) == null)
        assertTrue(Health.parseDate(1, 1, 2030, today) == null)
        assertTrue(Health.parseDate(1, 1, 1800, today) == null)
    }
}
