package com.fingerfit.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.data.Repo
import com.fingerfit.data.todayReps
import com.fingerfit.data.toLocalDate
import com.fingerfit.logic.Bn
import com.fingerfit.logic.ExerciseType
import com.fingerfit.logic.LibCat
import com.fingerfit.logic.LibItem
import com.fingerfit.logic.LibPart
import com.fingerfit.logic.LibSearch
import com.fingerfit.logic.Library
import java.time.LocalDate

internal fun pick(isBn: Boolean, en: String, bn: String): String = if (isBn) bn else en

/** A number in Bengali or English digits. */
internal fun num(isBn: Boolean, n: Int): String = if (isBn) Bn.toBn(n.toString()) else n.toString()

/** The "Exercise" tab: every exercise, with search and filters by purpose and body part. */
@Composable
fun BodyListScreen(
    vm: AppViewModel,
    onBack: () -> Unit,
    onPick: (ExerciseType) -> Unit,
    onFinger: () -> Unit,
    onLib: (LibItem) -> Unit,
) {
    BackHandler(onBack = onBack)
    val workouts by Repo.workouts.collectAsStateWithLifecycle()
    val today = LocalDate.now()
    val history by vm.history.collectAsStateWithLifecycle()
    val fingerToday = history.todayReps()
    val isBn = LangState.bn
    var query by rememberSaveable { mutableStateOf("") }
    var catName by rememberSaveable { mutableStateOf("") }
    var partName by rememberSaveable { mutableStateOf("") }
    var noEquip by rememberSaveable { mutableStateOf(false) }
    var camOnly by rememberSaveable { mutableStateOf(false) }
    val shown: List<LibItem> = remember(query, catName, partName, noEquip, camOnly) {
        val cat = LibCat.values().firstOrNull { it.name == catName }
        val part = LibPart.values().firstOrNull { it.name == partName }
        LibSearch.search(Library.filter(Library.all, cat, part, noEquip, camOnly), query)
    }
    val filtering = query.isNotBlank() || catName.isNotEmpty() || partName.isNotEmpty() || noEquip || camOnly

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.statusBarsPadding()) {
        Column {
            Column(Modifier.padding(start = 22.dp, end = 22.dp, top = 16.dp)) {
                Text("Exercise", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    pick(isBn, "Search by name or body part, or filter below.", "নাম বা শরীরের অংশ লিখে খুঁজুন, অথবা নিচে ফিল্টার করুন।"),
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp,
                )
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it.take(60) },
                singleLine = true,
                placeholder = { Text("Search exercises, e.g. belly, push-up") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, contentDescription = "Clear") }
                    }
                },
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp),
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 22.dp, end = 22.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            pick(isBn, "What is it for?", "কীসের জন্য?"),
                            fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = catName.isEmpty(), onClick = { catName = "" }, label = { Text(pick(isBn, "All", "সব")) })
                            LibCat.values().forEach { c ->
                                FilterChip(
                                    selected = catName == c.name,
                                    onClick = { catName = if (catName == c.name) "" else c.name },
                                    label = { Text(pick(isBn, c.en, c.bn)) },
                                )
                            }
                        }
                        Text(
                            pick(isBn, "Body part", "শরীরের অংশ"),
                            fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = partName.isEmpty(), onClick = { partName = "" }, label = { Text(pick(isBn, "All", "সব")) })
                            LibPart.values().forEach { p ->
                                FilterChip(
                                    selected = partName == p.name,
                                    onClick = { partName = if (partName == p.name) "" else p.name },
                                    label = { Text(pick(isBn, p.en, p.bn)) },
                                )
                            }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = noEquip, onClick = { noEquip = !noEquip },
                                label = { Text(pick(isBn, "No equipment", "সরঞ্জাম ছাড়া")) },
                            )
                            FilterChip(
                                selected = camOnly, onClick = { camOnly = !camOnly },
                                label = { Text(pick(isBn, "Camera counts", "ক্যামেরা গোনে")) },
                            )
                            if (filtering) {
                                FilterChip(
                                    selected = false,
                                    onClick = { query = ""; catName = ""; partName = ""; noEquip = false; camOnly = false },
                                    label = { Text(pick(isBn, "Clear all", "সব মুছুন")) },
                                )
                            }
                        }
                        Text(
                            pick(isBn, "${shown.size} exercises", "${num(true, shown.size)}টি ব্যায়াম"),
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                if (shown.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Column(Modifier.fillMaxWidth().padding(vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🔍", fontSize = 40.sp)
                            Text(
                                pick(isBn, "No exercise found. Try another word or clear the filters.", "কোনো ব্যায়াম পাওয়া যায়নি। অন্য শব্দ লিখুন বা ফিল্টার মুছুন।"),
                                textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                items(shown, key = { it.id }) { item ->
                    val done = if (item.finger) fingerToday else item.type?.let { t ->
                        workouts.filter { it.type == t.name && it.t.toLocalDate() == today }.sumOf { it.reps }
                    } ?: 0
                    val unit = if (item.timed) pick(isBn, "sec", "সেকেন্ড") else pick(isBn, "reps", "বার")
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth().clickable {
                            val t = item.type
                            if (t != null) onPick(t) else if (item.finger) onFinger() else onLib(item)
                        },
                    ) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.fillMaxWidth().height(80.dp).background(HeroTint, RoundedCornerShape(18.dp)),
                                contentAlignment = Alignment.Center,
                            ) { Text(item.emoji, fontSize = 42.sp) }
                            Spacer(Modifier.height(8.dp))
                            Box(Modifier.fillMaxWidth().height(40.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    item.name(isBn), fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 2,
                                    textAlign = TextAlign.Center, lineHeight = 18.sp,
                                )
                            }
                            Text(
                                "${pick(isBn, item.cat.en, item.cat.bn)} · ${num(isBn, item.target)} $unit",
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                            )
                            Text(
                                when {
                                    done > 0 -> pick(isBn, "Today: $done", "আজ: ${num(true, done)}")
                                    item.camera -> pick(isBn, "📷 Camera counts", "📷 ক্যামেরা গোনে")
                                    else -> pick(isBn, "Guided", "নির্দেশনা সহ")
                                },
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.tertiary,
                                fontWeight = FontWeight.SemiBold, maxLines = 1,
                            )
                        }
                    }
                }
            }
        }
    }
}
