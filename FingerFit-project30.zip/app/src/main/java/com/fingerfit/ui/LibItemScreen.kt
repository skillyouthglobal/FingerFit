package com.fingerfit.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.data.ProfileRepo
import com.fingerfit.logic.LibItem
import com.fingerfit.logic.Say
import com.fingerfit.logic.SayKind
import com.fingerfit.voice.Voice
import kotlinx.coroutines.delay

/** An exercise from the library: what it is, how to do it, benefits, and a guided timer or counter. */
@Composable
fun LibItemScreen(item: LibItem, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val isBn = LangState.bn
    val profile by ProfileRepo.profile.collectAsStateWithLifecycle()
    val nm = profile?.name?.trim()?.substringBefore(' ') ?: ""
    DisposableEffect(item.id) { onDispose { Voice.stop() } }

    val levelText = when (item.level) {
        1 -> pick(isBn, "Beginner", "শুরুর স্তর")
        2 -> pick(isBn, "Medium", "মাঝারি")
        else -> pick(isBn, "Advanced", "কঠিন")
    }
    val posText = if (item.floor) pick(isBn, "On the floor", "মেঝেতে") else pick(isBn, "Standing", "দাঁড়িয়ে")
    val tags = listOf(levelText, posText, pick(isBn, item.equip.en, item.equip.bn)).joinToString("  ·  ")

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.systemBarsPadding()) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp)) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                Text(item.emoji, fontSize = 22.sp)
            }
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Card(
                    shape = RoundedCornerShape(26.dp),
                    colors = CardDefaults.cardColors(containerColor = HeroTint),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            pick(isBn, item.cat.en, item.cat.bn).uppercase(), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp, color = MaterialTheme.colorScheme.tertiary,
                        )
                        Text(item.name(isBn), fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                        Text(tags, fontSize = 13.sp, color = androidx.compose.ui.graphics.Color(0xFF3F4F70))
                    }
                }
                LibCard(pick(isBn, "Works these muscles", "শরীরের যে অংশ কাজ করে")) {
                    Text(item.body(isBn), fontSize = 14.sp)
                }
                LibCard(pick(isBn, "How to do it", "যেভাবে করতে হবে")) {
                    Text(item.how(isBn), fontSize = 14.sp, lineHeight = 21.sp)
                }
                LibCard(pick(isBn, "Benefits", "উপকারিতা")) {
                    item.benefits(isBn).forEach { Text("•  $it", fontSize = 14.sp) }
                }
                LibCard(pick(isBn, "Do it with Kinetro", "Kinetro-র সঙ্গে করুন")) {
                    GuidedSession(item, nm, isBn)
                }
                LibCard(pick(isBn, "⚠️ Stay safe", "⚠️ সতর্কতা")) {
                    Text(
                        pick(
                            isBn,
                            "Warm up first. Stop at once if you feel sharp pain, dizziness or chest pain. Use a sturdy table, bench or wall, and a clear floor. If you have a health condition or an injury, ask your doctor before starting.",
                            "আগে হালকা গা গরম করুন। তীব্র ব্যথা, মাথা ঘোরা বা বুকে ব্যথা হলে সঙ্গে সঙ্গে থামুন। শক্ত টেবিল, বেঞ্চ বা দেয়াল ব্যবহার করুন এবং মেঝে ফাঁকা রাখুন। কোনো রোগ বা আঘাত থাকলে শুরুর আগে ডাক্তারের পরামর্শ নিন।",
                        ),
                        fontSize = 14.sp,
                    )
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun LibCard(title: String, content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.tertiary)
            content()
        }
    }
}

/** A timer for holds and a tap counter for repetitions, with the voice coach calling out the time or the count. */
@Composable
private fun GuidedSession(item: LibItem, nm: String, isBn: Boolean) {
    val step = if (item.timed) 5 else 2
    var target by remember(item.id) { mutableStateOf(item.target) }
    var left by remember(item.id) { mutableStateOf(item.target) }
    var count by remember(item.id) { mutableStateOf(0) }
    var running by remember(item.id) { mutableStateOf(false) }
    var finished by remember(item.id) { mutableStateOf(false) }
    val enN = if (nm.isEmpty()) "" else ", $nm"
    val bnN = if (nm.isEmpty()) "" else " $nm"

    LaunchedEffect(running) {
        if (running) {
            Voice.speak(if (isBn) "প্রস্তুত হোন$bnN, শুরু করুন!" else "Ready$enN? Go!", true)
            while (left > 0) {
                delay(1000L)
                left -= 1
                if (left in 1..3) {
                    Voice.say(Say(if (isBn) num(true, left) else left.toString(), true, SayKind.COUNT))
                } else if (target >= 20 && left == target / 2) {
                    Voice.speak(if (isBn) "অর্ধেক সময় হয়ে গেছে$bnN, চালিয়ে যান!" else "Halfway$enN, keep going!", false)
                }
            }
            running = false
            finished = true
            Voice.speak(if (isBn) "দারুণ$bnN, শেষ হয়েছে!" else "Well done$enN, that's it!", true)
        }
    }

    Text(
        if (item.camera) "" else pick(
            isBn,
            "Camera tracking for this exercise is being added. For now, follow the guide above and use the " +
                (if (item.timed) "timer" else "counter") + " below.",
            "এই ব্যায়ামের ক্যামেরা ট্র্যাকিং যোগ করা হচ্ছে। আপাতত ওপরের নির্দেশনা দেখে নিচের " +
                (if (item.timed) "টাইমার" else "কাউন্টার") + " ব্যবহার করুন।",
        ),
        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    val unit = if (item.timed) pick(isBn, "seconds", "সেকেন্ড") else pick(isBn, "reps", "বার")
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(pick(isBn, "Target", "লক্ষ্য") + ": " + num(isBn, target) + " " + unit, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                if (!running) {
                    target = (target - step).coerceAtLeast(step)
                    left = target; count = 0; finished = false
                }
            }) { Text("−") }
            OutlinedButton(onClick = {
                if (!running) {
                    target = (target + step).coerceAtMost(999)
                    left = target; count = 0; finished = false
                }
            }) { Text("+") }
        }
    }
    val shown = if (item.timed) left else count
    Text(
        num(isBn, shown), fontSize = 64.sp, fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.tertiary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
    )
    LinearProgressIndicator(
        progress = {
            if (item.timed) ((target - left).toFloat() / target).coerceIn(0f, 1f) else (count.toFloat() / target).coerceIn(0f, 1f)
        },
        modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)),
        trackColor = MaterialTheme.colorScheme.surfaceVariant,
    )
    if (finished) {
        Text(
            pick(isBn, "Finished. Well done!", "শেষ হয়েছে। দারুণ!"),
            color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold,
        )
    }
    if (item.timed) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = {
                    if (finished || left <= 0) { left = target; finished = false; running = true } else running = !running
                },
                modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp),
            ) {
                Text(
                    when {
                        running -> pick(isBn, "Pause", "বিরতি")
                        finished -> pick(isBn, "Again", "আবার")
                        left < target -> pick(isBn, "Resume", "চালু করুন")
                        else -> pick(isBn, "Start", "শুরু")
                    },
                    fontWeight = FontWeight.Bold,
                )
            }
            OutlinedButton(
                onClick = { running = false; left = target; finished = false; Voice.stop() },
                modifier = Modifier.height(52.dp), shape = RoundedCornerShape(16.dp),
            ) { Text(pick(isBn, "Reset", "রিসেট")) }
        }
    } else {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = {
                    if (finished) { count = 0; finished = false }
                    count += 1
                    if (count >= target) {
                        finished = true
                        Voice.speak(if (isBn) "দারুণ$bnN, লক্ষ্য পূরণ হয়েছে!" else "Well done$enN, target reached!", true)
                    } else if (target >= 6 && count == (target + 1) / 2) {
                        Voice.speak(if (isBn) "${num(true, count)}! অর্ধেক হয়ে গেছে$bnN!" else "$count! Halfway$enN!", true)
                    } else {
                        Voice.say(Say(if (isBn) num(true, count) else count.toString(), true, SayKind.COUNT))
                    }
                },
                modifier = Modifier.weight(1f).height(60.dp), shape = RoundedCornerShape(18.dp),
            ) { Text(pick(isBn, "+1  Count", "+১  গুনুন"), fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            OutlinedButton(
                onClick = { if (count > 0) { count -= 1; finished = false } },
                modifier = Modifier.height(60.dp), shape = RoundedCornerShape(18.dp),
            ) { Text("−1") }
            OutlinedButton(
                onClick = { count = 0; finished = false; Voice.stop() },
                modifier = Modifier.height(60.dp), shape = RoundedCornerShape(18.dp),
            ) { Text(pick(isBn, "Reset", "রিসেট")) }
        }
    }
}
