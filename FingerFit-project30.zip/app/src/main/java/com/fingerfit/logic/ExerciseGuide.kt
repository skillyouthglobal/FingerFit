package com.fingerfit.logic

/** Plain-language instructions shown before each workout. */
class Guide(
    val steps: List<String>,
    val benefits: List<String>,
    val camera: String,
    val counting: String,
    val safety: String,
)

object Guides {
    fun of(type: ExerciseType): Guide = when (type) {
        ExerciseType.JUMPING_JACKS -> Guide(
            steps = listOf(
                "Stand straight with feet together and arms down by your sides.",
                "Jump and spread your feet wider than your shoulders while raising both arms overhead.",
                "Jump again, bringing your feet together and arms back down.",
                "Keep a steady rhythm and breathe normally.",
            ),
            benefits = listOf(
                "Raises your heart rate quickly: good warm-up and cardio",
                "Burns calories and improves stamina",
                "Improves coordination between arms and legs",
                "Needs no equipment and little space",
            ),
            camera = "Face the camera, 2 to 3 metres away. Your whole body, from head to feet, must be inside the picture. Raise your arms fully so the camera can see them.",
            counting = "One repetition is counted when your arms go up and feet spread, then you return to the start position.",
            safety = "Land softly on the balls of your feet. Skip this one if you have knee, ankle or back pain.",
        )
        ExerciseType.SQUATS -> Guide(
            steps = listOf(
                "Stand with feet shoulder-width apart, toes slightly outward.",
                "Push your hips back and bend your knees as if sitting on a chair.",
                "Go down until your thighs are about parallel to the floor, chest up, back straight.",
                "Push through your heels to stand up fully.",
            ),
            benefits = listOf(
                "Strengthens thighs, glutes and core",
                "Makes everyday movements like standing up and climbing stairs easier",
                "Supports healthy bones and joints",
                "Burns many calories because large muscles work together",
            ),
            camera = "Stand SIDEWAYS to the camera, 2 to 3 metres away, phone at about hip height. Keep your whole body in view.",
            counting = "A repetition is counted when your knees bend deeply enough and you stand back up.",
            safety = "Keep your knees in line with your toes and your heels on the floor. Stop if you feel sharp knee pain.",
        )
        ExerciseType.PUSH_UPS -> Guide(
            steps = listOf(
                "Place your hands slightly wider than your shoulders. Body in one straight line from head to heels.",
                "Lower your chest toward the floor by bending your elbows.",
                "Stop just above the floor, then push back up until your arms are straight.",
                "If this is too hard, do it with your knees on the floor.",
            ),
            benefits = listOf(
                "Builds chest, shoulder and arm strength",
                "Strengthens your core",
                "Improves upper-body endurance",
                "Needs no equipment",
            ),
            camera = "Put the phone on the floor beside you (SIDE view), about 1.5 to 2 metres away, so your whole body from head to feet is visible.",
            counting = "A repetition is counted when your elbows bend as your chest goes down and you push back up. Standing up will not count.",
            safety = "Do not let your hips sag or rise. Stop if you feel wrist or shoulder pain.",
        )
        ExerciseType.LUNGES -> Guide(
            steps = listOf(
                "Stand tall with feet hip-width apart.",
                "Step one foot forward and lower your hips until both knees bend to about 90 degrees.",
                "Push through the front foot to return to standing.",
                "Repeat with the other leg, alternating sides.",
            ),
            benefits = listOf(
                "Strengthens thighs and glutes",
                "Improves balance and leg control",
                "Works each leg separately to even out strength",
                "Good for walking and running ability",
            ),
            camera = "Stand SIDEWAYS to the camera, 2 to 3 metres away, whole body in view.",
            counting = "Each step into a lunge counts once. Kinetro shows left and right separately.",
            safety = "Keep the front knee above the ankle, not past your toes. Hold a wall for balance if needed.",
        )
        ExerciseType.HIGH_KNEES -> Guide(
            steps = listOf(
                "Stand tall with feet hip-width apart.",
                "Run in place, lifting each knee up toward hip height.",
                "Swing your arms naturally and stay on the balls of your feet.",
                "Keep a quick, steady pace.",
            ),
            benefits = listOf(
                "Strong cardio workout that burns calories",
                "Improves speed, coordination and leg strength",
                "Works the core and hip flexors",
                "Great as a warm-up",
            ),
            camera = "Face the camera, 2 to 3 metres away, whole body from head to feet in view.",
            counting = "Each knee lifted to hip height counts once. Kinetro shows left and right separately.",
            safety = "Land softly and keep your chest up. Slow down if you feel dizzy or short of breath.",
        )
        ExerciseType.CRUNCHES -> Guide(
            steps = listOf(
                "Lie on your back with knees bent and feet flat on the floor.",
                "Place your hands lightly behind your head or cross them on your chest.",
                "Curl your shoulders up off the floor by tightening your stomach muscles.",
                "Lower back down slowly. Do not pull on your neck.",
            ),
            benefits = listOf(
                "Strengthens the abdominal muscles",
                "Improves core stability and posture",
                "Supports your lower back",
                "Needs only a mat or soft floor",
            ),
            camera = "Lie down with the phone on the floor at your SIDE, 1.5 to 2 metres away, so your whole body is in view.",
            counting = "A repetition is counted when your shoulders lift toward your knees and you lower back down.",
            safety = "Move slowly and keep your neck relaxed. Stop if your back or neck hurts.",
        )
        ExerciseType.GLUTE_BRIDGES -> Guide(
            steps = listOf(
                "Lie on your back with knees bent and feet flat, hip-width apart.",
                "Press through your heels and lift your hips until shoulders, hips and knees form a straight line.",
                "Squeeze your glutes at the top for a moment.",
                "Lower your hips slowly to the floor.",
            ),
            benefits = listOf(
                "Strengthens glutes and hamstrings",
                "Improves hip control and stability",
                "Helps reduce lower-back stiffness from sitting",
                "Gentle and suitable for beginners",
            ),
            camera = "Lie down with the phone on the floor at your SIDE, 1.5 to 2 metres away, whole body in view.",
            counting = "A repetition is counted when your hips rise high enough and come back down.",
            safety = "Do not arch your lower back too much. Stop if you feel pain in your back.",
        )
        ExerciseType.PLANK -> Guide(
            steps = listOf(
                "Rest on your forearms and toes, elbows under your shoulders.",
                "Keep your body in one straight line from head to heels.",
                "Tighten your stomach and glutes. Look at the floor.",
                "Hold the position and breathe normally.",
            ),
            benefits = listOf(
                "Strengthens abs, back and shoulders",
                "Builds muscular endurance",
                "Improves posture and balance",
                "No movement, so it is easy on the joints",
            ),
            camera = "Put the phone on the floor beside you (SIDE view), 1.5 to 2 metres away, so your whole body is in view.",
            counting = "Time is counted only while your body stays in a straight plank line. The timer pauses if your hips sag or rise.",
            safety = "Stop when your form breaks down. Do not hold your breath.",
        )
        ExerciseType.SIT_TO_STAND -> Guide(
            steps = listOf(
                "Sit near the front of a sturdy chair, back straight, feet flat on the floor about hip-width apart.",
                "Lean your chest forward a little and keep your arms crossed on your chest.",
                "Push through your feet and stand all the way up, straightening your knees and hips.",
                "Sit back down slowly and with control. Do not drop into the chair.",
            ),
            benefits = listOf(
                "Builds the leg and hip strength you need to get up from a chair or bed",
                "Makes climbing stairs and walking easier",
                "Supports balance and helps prevent falls",
                "Safe and gentle, a good start for beginners and older adults",
            ),
            camera = "Put the chair against a wall so it cannot slide. Sit SIDEWAYS to the camera, 2 to 3 metres away, phone at about hip height, whole body in view.",
            counting = "A repetition is counted when you stand up fully and sit back down. Standing only part of the way does not count.",
            safety = "Use a firm chair that will not move. Keep a wall or table within reach. Stop if you feel dizzy or have knee pain.",
        )
        ExerciseType.CALF_RAISES -> Guide(
            steps = listOf(
                "Stand tall with feet hip-width apart. Rest your fingertips on a wall or chair for balance.",
                "Keep your knees straight and your body upright.",
                "Slowly rise up onto the balls of your feet as high as you can.",
                "Lower your heels slowly back to the floor.",
            ),
            benefits = listOf(
                "Strengthens the calf muscles and ankles",
                "Improves balance and steady walking",
                "Helps the legs push blood back to the heart",
                "Needs no equipment and very little space",
            ),
            camera = "Stand SIDEWAYS to the camera, 2 to 3 metres away. Your whole body AND both feet must be inside the picture. Bare feet or flat shoes work best.",
            counting = "A repetition is counted when your heels rise clearly off the floor and come back down. Small lifts do not count.",
            safety = "Hold a wall or chair if you feel unsteady. Stop if you feel pain in your calves, ankles or feet.",
        )
        ExerciseType.SIDE_LEG_RAISES -> Guide(
            steps = listOf(
                "Stand tall facing the camera, feet together, hands on your hips or holding a chair.",
                "Keep your body straight and your toes pointing forward.",
                "Lift one leg out to the side, as high as you can without leaning.",
                "Lower it slowly, then lift the other leg. Keep alternating.",
            ),
            benefits = listOf(
                "Strengthens the hips and outer thighs",
                "Improves balance on one leg",
                "Supports stable walking and standing",
                "Needs no equipment",
            ),
            camera = "FACE the camera, 2 to 3 metres away, whole body from head to feet in view. Stand with a little space on both sides of you.",
            counting = "Each leg lifted clearly out to the side and lowered counts once. Kinetro shows left and right separately.",
            safety = "Hold a chair or wall for balance. Do not lean your body sideways. Stop if you feel hip or back pain.",
        )
        ExerciseType.INCLINE_PUSHUPS -> Guide(
            steps = listOf("Put both hands on a sturdy table or bench, a little wider than your shoulders.", "Walk your feet back until your body is one straight line from head to heels.", "Bend your elbows and lower your chest toward the bench.", "Push the bench away and straighten your arms. Keep your tummy tight."),
            benefits = listOf("Strengthens the chest muscles.", "Builds shoulder and arm strength.", "Improves upper-body control.", "Helps beginners build up to a full push-up."),
            camera = "Put the phone on the floor or a stand beside you, SIDEWAYS to your body, 2 to 3 metres away. Head to feet must be in the picture, together with the bench.",
            counting = "A repetition is counted when your elbows bend clearly and you push back up straight. Half-way bends do not count.",
            safety = "Warm up first. Move slowly and with control. Stop if you feel sharp pain, dizziness or chest pain. Use a sturdy bench or table.",
        )
        ExerciseType.DECLINE_PUSHUPS -> Guide(
            steps = listOf("Put both feet on a stable raised surface and both hands on the floor, a little wider than your shoulders.", "Keep your body in one straight line from head to heels.", "Bend your elbows and lower your chest toward the floor.", "Push the floor away and straighten your arms. Do not let your hips sag."),
            benefits = listOf("Strengthens chest and shoulder muscles.", "Builds upper-body strength.", "Improves muscle control."),
            camera = "Put the phone on the floor beside you, SIDEWAYS to your body, 2 to 3 metres away. Head to feet, with the bench, must be in the picture.",
            counting = "A repetition is counted when your elbows bend clearly and you push back up straight. Half-way bends do not count.",
            safety = "Warm up first. Move slowly and with control. Stop if you feel sharp pain, dizziness or chest pain. Use a sturdy bench or table.",
        )
        ExerciseType.BICEPS_CURL -> Guide(
            steps = listOf("Stand tall with a bottle or light weight in each hand, arms down by your sides.", "Keep your elbows still against your body.", "Curl both hands up toward your shoulders.", "Lower them slowly until your arms are straight again."),
            benefits = listOf("Strengthens the front arm muscles.", "Builds arm strength and control.", "Makes everyday carrying easier."),
            camera = "FACE the camera, 2 to 3 metres away, with your whole body and both arms in the picture. Wear a top that does not hide your elbows.",
            counting = "A repetition is counted when you bend your elbow up close to your shoulder and lower it until your arm is nearly straight.",
            safety = "Warm up first. Move slowly and with control. Stop if you feel sharp pain, dizziness or chest pain. Use a sturdy bench or table.",
        )
        ExerciseType.TRICEPS_EXTENSION -> Guide(
            steps = listOf("Hold one light weight with both hands and raise it overhead, arms straight.", "Keep your upper arms close to your ears and your elbows pointing forward.", "Bend your elbows and lower the weight behind your head.", "Straighten your arms and lift the weight back up."),
            benefits = listOf("Strengthens the back arm muscles.", "Improves the ability to straighten the elbow.", "Builds overall arm strength."),
            camera = "Stand SIDEWAYS to the camera, 2 to 3 metres away, with your whole body in the picture and your arms clear of any wall or shelf.",
            counting = "A repetition is counted when the weight goes down behind your head with your elbows clearly bent, and your arms straighten overhead again.",
            safety = "Warm up first. Move slowly and with control. Stop if you feel sharp pain, dizziness or chest pain. Use a sturdy bench or table.",
        )
        ExerciseType.FRONT_RAISE -> Guide(
            steps = listOf("Stand tall with both arms down in front of your thighs.", "Keep your arms straight and your body still.", "Slowly raise both arms forward up to shoulder height.", "Lower them slowly back down."),
            benefits = listOf("Builds shoulder strength.", "Improves the ability to lift the arms forward.", "Improves shoulder control."),
            camera = "Stand SIDEWAYS to the camera, 2 to 3 metres away, whole body in the picture. The arm nearest the camera must not be hidden by your body.",
            counting = "A repetition is counted when your hands rise to about shoulder height and come back down. Low lifts do not count.",
            safety = "Warm up first. Move slowly and with control. Stop if you feel sharp pain, dizziness or chest pain. Use a sturdy bench or table.",
        )
        ExerciseType.LATERAL_RAISE -> Guide(
            steps = listOf("Stand tall with a light weight in each hand, arms by your sides.", "Keep a slight bend in your elbows.", "Raise both arms out to the sides up to shoulder height.", "Lower them slowly back to your sides."),
            benefits = listOf("Strengthens the side shoulder muscles.", "Improves shoulder shape and strength.", "Improves the ability to lift the arms sideways."),
            camera = "FACE the camera, 2 to 3 metres away, with your whole body and both arms in the picture. Leave space on both sides of you.",
            counting = "A repetition is counted when your hands rise to about shoulder height and come back down. Low lifts do not count.",
            safety = "Warm up first. Move slowly and with control. Stop if you feel sharp pain, dizziness or chest pain. Use a sturdy bench or table.",
        )
        ExerciseType.BUTT_KICKS -> Guide(
            steps = listOf("Stand tall and start jogging gently on the spot.", "Keep your body upright and your arms swinging.", "With each step, bend your leg back and bring your heel up toward your glutes.", "Switch legs quickly and keep a steady rhythm."),
            benefits = listOf("Improves leg speed.", "Improves cardio fitness.", "Improves coordination of leg movement."),
            camera = "Face the camera, 2 to 3 metres away, whole body from head to feet in the picture. Keep space around you.",
            counting = "Each heel kicked clearly up toward your glutes counts once. Left and right are counted separately and added together.",
            safety = "Warm up first. Move slowly and with control. Stop if you feel sharp pain, dizziness or chest pain. Use a sturdy bench or table.",
        )
        ExerciseType.GOOD_MORNING -> Guide(
            steps = listOf("Stand tall with your feet hip-width apart and your hands on your chest.", "Keep your knees slightly bent and your back straight.", "Push your hips back and lean your body forward from the hips.", "Squeeze your glutes and stand back up straight."),
            benefits = listOf("Improves the hip-hinge movement.", "Strengthens the back of the thighs.", "Improves hip and lower-back coordination."),
            camera = "Stand SIDEWAYS to the camera, 2 to 3 metres away, whole body in the picture, shoulders, hips and knees clearly visible.",
            counting = "A repetition is counted when you lean forward from the hips clearly and stand all the way back up.",
            safety = "Warm up first. Move slowly and with control. Stop if you feel sharp pain, dizziness or chest pain. Use a sturdy bench or table.",
        )
        ExerciseType.LEG_RAISE -> Guide(
            steps = listOf("Lie on your back with both legs straight and your arms by your sides.", "Press your lower back gently into the floor.", "Lift both legs together until they point to the ceiling.", "Lower them slowly, stopping just above the floor."),
            benefits = listOf("Strengthens the abdominal muscles.", "Improves core control.", "Improves coordination of legs and hips."),
            camera = "Lie on a mat with the phone on the floor beside your hips, SIDE view, 2 to 3 metres away. Your shoulders, hips and feet must all be in the picture.",
            counting = "A repetition is counted when your legs lift clearly toward the ceiling and come back down.",
            safety = "Warm up first. Move slowly and with control. Stop if you feel sharp pain, dizziness or chest pain. Use a sturdy bench or table.",
        )
        ExerciseType.PIKE_PUSHUPS -> Guide(
            steps = listOf("Start on your hands and feet and lift your hips high so your body makes an upside-down V.", "Keep your arms and legs almost straight and your head between your arms.", "Bend your elbows and lower the top of your head toward the floor.", "Push the floor away and straighten your arms, keeping your hips high."),
            benefits = listOf("Builds shoulder strength.", "Strengthens the arm muscles.", "Improves upper-body balance."),
            camera = "Put the phone on the floor beside you, SIDEWAYS to your body, 2 to 3 metres away. Your hands, hips and feet must all be in the picture.",
            counting = "A repetition is counted when your elbows bend clearly and you push back up straight, with your hips staying high.",
            safety = "Warm up your wrists and shoulders first. Do not rest your weight on your head. Stop if you feel sharp pain in the shoulders, wrists or neck.",
        )
        ExerciseType.BULGARIAN_SPLIT_SQUAT -> Guide(
            steps = listOf("Stand about one big step in front of a bench and put the top of one foot on it behind you.", "Keep your chest up and most of your weight on your front leg.", "Bend your front knee and lower straight down until the thigh is nearly level with the floor.", "Push through your front heel to stand up. Finish all repetitions, then switch legs."),
            benefits = listOf("Builds single-leg strength.", "Strengthens glutes and thighs.", "Improves balance between both legs."),
            camera = "Stand SIDEWAYS to the camera, 2 to 3 metres away, with the bench behind you. Your head, both knees and both feet must be in the picture.",
            counting = "A repetition is counted when your front knee bends to about a right angle and you stand back up. Do one leg first, then the other.",
            safety = "Use a stable bench. Keep your front knee over your foot. Hold a wall for balance if needed. Stop if you feel knee pain.",
        )
        ExerciseType.SQUAT_PULSES -> Guide(
            steps = listOf("Stand with feet shoulder-width apart and squat down until your thighs are nearly level with the floor.", "Stay low. Do not stand up between repetitions.", "Rise a few inches, then sink back down in a small bouncing movement.", "Keep your chest up and your weight on your heels. Breathe steadily."),
            benefits = listOf("Builds leg muscle endurance.", "Keeps the thigh muscles working.", "Improves muscle control."),
            camera = "Stand SIDEWAYS to the camera, 2 to 3 metres away. Your hips, knees and feet must be clearly in the picture.",
            counting = "Counting starts once you are in a low squat. A repetition is one small rise and one drop back down low. Standing fully up pauses the count.",
            safety = "Keep your knees in line with your toes. Stop if you feel knee pain. Skip this one if squats hurt your knees.",
        )
        ExerciseType.BURPEE -> Guide(
            steps = listOf("Stand tall with your feet shoulder-width apart.", "Squat down and put both hands on the floor.", "Jump or step both feet back into a straight plank.", "Bring your feet back in and jump up with your arms overhead."),
            benefits = listOf("Works the whole body.", "Improves heart and lung endurance.", "Improves fitness and coordination."),
            camera = "Put the phone on the floor, SIDE view, 2 to 3 metres away, so your whole body fits even when you lie out flat in the plank.",
            counting = "A repetition is counted when you stand, go down into a straight plank and stand back up. Skipping the plank does not count.",
            safety = "Warm up first. Land softly. Step instead of jumping if you have knee, wrist, back or heart concerns. Stop if you feel dizzy.",
        )
        ExerciseType.SQUAT_THRUST -> Guide(
            steps = listOf("Stand tall with your feet shoulder-width apart.", "Squat down and put both hands on the floor.", "Kick both feet back together into a straight plank.", "Jump your feet back in and stand up."),
            benefits = listOf("Works the whole body.", "Improves cardio fitness.", "Builds strength and coordination."),
            camera = "Put the phone on the floor, SIDE view, 2 to 3 metres away, so your whole body fits even when you lie out flat in the plank.",
            counting = "A repetition is counted when you stand, go down into a straight plank and stand back up. Skipping the plank does not count.",
            safety = "Warm up first. Move with control. Stop if you feel wrist or back pain, dizziness or chest pain.",
        )
        ExerciseType.V_UPS -> Guide(
            steps = listOf("Lie on your back with your legs straight and your arms stretched overhead.", "Tighten your tummy and press your lower back toward the floor.", "Lift your legs and your chest at the same time, reaching your hands toward your toes.", "Lower back down slowly with control."),
            benefits = listOf("Strengthens the abdominal muscles.", "Builds core strength.", "Improves hand and leg coordination."),
            camera = "Lie on a mat with the phone on the floor beside you, SIDE view, 2 to 3 metres away. Your head, hips and feet must be in the picture.",
            counting = "A repetition is counted when you lie flat, fold up into a V with your legs lifted, and lower back down.",
            safety = "Warm up first. Move slowly. Skip this one if you have back or neck pain. Stop if you feel sharp pain.",
        )
        ExerciseType.TIBIALIS_RAISE -> Guide(
            steps = listOf("Stand with your back against a wall and your feet about a foot in front of it.", "Keep your legs straight and your heels on the floor.", "Lift the front of your feet and toes up toward your shins.", "Lower them slowly back to the floor."),
            benefits = listOf("Strengthens the front of the lower leg.", "Improves ankle control.", "Helps lift the toes when walking."),
            camera = "Stand SIDEWAYS to the camera, 2 to 3 metres away, in bare feet or flat shoes. Your whole foot, from heel to toes, must be clearly in the picture.",
            counting = "A repetition is counted when your toes lift clearly off the floor and come back down. Small movements do not count.",
            safety = "Keep your back against the wall for balance. Stop if you feel pain in the shins or ankles.",
        )
        ExerciseType.DOWNWARD_DOG -> Guide(
            steps = listOf("Start on your hands and knees, hands a little wider than your shoulders.", "Tuck your toes and lift your hips up and back.", "Straighten your arms and legs as far as is comfortable, head between your arms.", "Hold steady and breathe slowly."),
            benefits = listOf("Improves flexibility.", "Stretches the back and leg muscles.", "Improves shoulder and ankle movement."),
            camera = "Put the phone on the floor beside you, SIDE view, 2 to 3 metres away. Your hands, hips and feet must be in the picture.",
            counting = "The timer runs while your hips are high and your arms and legs are straight. It pauses if you drop out of the position.",
            safety = "Bend your knees a little if your legs feel tight. Skip this one if you have wrist or shoulder pain. Come out slowly.",
        )
        ExerciseType.HOLLOW_BODY_HOLD -> Guide(
            steps = listOf("Lie on your back with your arms stretched overhead and your legs straight.", "Press your lower back into the floor and tighten your tummy.", "Lift your shoulders and your straight legs a few inches off the floor.", "Hold steady and keep breathing."),
            benefits = listOf("Builds core stability.", "Builds abdominal endurance.", "Improves body control."),
            camera = "Lie on a mat with the phone on the floor beside you, SIDE view, 2 to 3 metres away. Your head, hips and feet must be in the picture.",
            counting = "The timer runs while your shoulders and legs are both lifted off the floor in a long, flat shape. It pauses if you rest down.",
            safety = "Make it easier by bending your knees. Stop if your lower back lifts off the floor painfully or you feel neck strain.",
        )
        ExerciseType.CHILD_POSE -> Guide(
            steps = listOf("Kneel on a mat with your knees about hip-width apart.", "Sit back toward your heels.", "Fold forward and rest your chest on your thighs, arms stretched out in front.", "Relax your neck and shoulders and breathe slowly."),
            benefits = listOf("Stretches the back and lower back.", "Improves flexibility.", "Helps the body relax after exercise."),
            camera = "Put the phone on the floor beside you, SIDE view, 2 to 3 metres away. Your hips, knees and feet must be in the picture.",
            counting = "The timer runs while you are folded forward over your thighs with your knees bent. It pauses if you come up.",
            safety = "Put a pillow under your knees or hips if it is uncomfortable. Skip this one if you have a knee injury. Come out slowly.",
        )
        ExerciseType.COBRA_STRETCH -> Guide(
            steps = listOf("Lie face down with your hands under your shoulders and your legs straight.", "Keep your hips and legs on the floor.", "Press your hands down and slowly lift your chest, keeping your elbows slightly bent.", "Look forward, relax your shoulders and breathe slowly."),
            benefits = listOf("Stretches the front abdominal muscles.", "Improves back movement.", "Stretches the chest and the front of the body."),
            camera = "Lie on a mat with the phone on the floor beside you, SIDE view, 2 to 3 metres away. Your head, hips and feet must be in the picture.",
            counting = "The timer runs while your chest is lifted and your legs and hips stay on the floor. It pauses if you lower down.",
            safety = "Lift only as far as is comfortable. Skip this one if you have back pain or are pregnant. Stop if you feel pinching in your lower back.",
        )
    }
}
