package com.fingerfit.logic

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Exercise demo engine. A person is a skeleton described by joint ANGLES (degrees), so bones never
 * stretch while moving. 0 = pointing down, 90 = pointing right, 180 = up, -90 = left.
 * FRONT view: arm/leg angles are "outward from the body" (mirrored for the left side).
 * SIDE view: the person faces right; limbs 1 = near side, limbs 2 = far side.
 * a1/a2 = upper/lower arm (near), b1/b2 = far arm, l1/l2 = thigh/shin (near), r1/r2 = far leg,
 * lf/rf = feet, lift = height above the floor (hops).
 *
 * To add an exercise later: write a few SimPose values and a SimSpec; no drawing code changes.
 */
class SimPose(
    val t: Float = 180f, val h: Float = 180f,
    val a1: Float = 8f, val a2: Float = 8f, val b1: Float = 8f, val b2: Float = 8f,
    val l1: Float = 3f, val l2: Float = 3f, val r1: Float = 3f, val r2: Float = 3f,
    val lf: Float = 90f, val rf: Float = 90f, val lift: Float = 0f,
) {
    fun hop(l: Float) = SimPose(t, h, a1, a2, b1, b2, l1, l2, r1, r2, lf, rf, l)
    fun mix(o: SimPose, f: Float): SimPose = SimPose(
        lerp(t, o.t, f), lerp(h, o.h, f), lerp(a1, o.a1, f), lerp(a2, o.a2, f), lerp(b1, o.b1, f), lerp(b2, o.b2, f),
        lerp(l1, o.l1, f), lerp(l2, o.l2, f), lerp(r1, o.r1, f), lerp(r2, o.r2, f), lerp(lf, o.lf, f), lerp(rf, o.rf, f),
        lerp(lift, o.lift, f),
    )
}

private fun lerp(a: Float, b: Float, f: Float) = a + (b - a) * f

enum class SimView { FRONT, SIDE }

/** Move to [pose] in [moveMs], then stay [holdMs]. [step] = which written step is being shown. */
class SimStep(val pose: SimPose, val moveMs: Int, val holdMs: Int, val step: Int)

class SimSpec(
    val view: SimView,
    val steps: List<SimStep>,
    val hotArms: Boolean = false,
    val hotLegs: Boolean = false,
    val hotCore: Boolean = false,
    val mat: Boolean = false,
    val ghost: SimPose? = null,
    val chair: Boolean = false,
    /** A bench or step: x0, x1 and top height in figure units (same scale as the figure). */
    val block: FloatArray? = null,
) {
    val cycleMs: Int = steps.sumOf { it.moveMs + it.holdMs }
}

class SimPt(val x: Float, val y: Float)

/** Joint positions in metres-ish units, floor at y = 0, y grows upward, x = 0 at the feet. */
class SimFigure(
    val head: SimPt, val neck: SimPt, val hip: SimPt,
    val shoulderNear: SimPt, val shoulderFar: SimPt, val hipNear: SimPt, val hipFar: SimPt,
    val elbowNear: SimPt, val wristNear: SimPt, val elbowFar: SimPt, val wristFar: SimPt,
    val kneeNear: SimPt, val ankleNear: SimPt, val toeNear: SimPt,
    val kneeFar: SimPt, val ankleFar: SimPt, val toeFar: SimPt,
) {
    fun all(): List<SimPt> = listOf(
        head, neck, hip, shoulderNear, shoulderFar, hipNear, hipFar, elbowNear, wristNear, elbowFar, wristFar,
        kneeNear, ankleNear, toeNear, kneeFar, ankleFar, toeFar,
    )
}

object SimMath {
    /** A chair for the sit-to-stand demo, in the same units as the figure (feet at x = 0, floor at y = 0). */
    const val CHAIR_X0 = -0.40f; const val CHAIR_X1 = -0.07f; const val CHAIR_SEAT = 0.235f; const val CHAIR_TOP = 0.62f

    const val TORSO = 0.30f; const val HEAD = 0.115f; const val UA = 0.17f; const val FA = 0.16f
    const val TH = 0.24f; const val SH = 0.23f; const val FT = 0.09f; const val SW = 0.095f; const val HW = 0.06f
    const val HEAD_R = 0.065f

    private fun dx(a: Float) = sin(a * PI / 180.0).toFloat()
    private fun dy(a: Float) = -cos(a * PI / 180.0).toFloat() // up is positive here

    fun figure(p: SimPose, view: SimView): SimFigure {
        val front = view == SimView.FRONT
        fun pt(x: Float, y: Float) = SimPt(x, y)
        val tx = dx(p.t); val ty = dy(p.t)
        val hipX = 0f; val hipY = 0f
        val neckX = hipX + tx * TORSO; val neckY = hipY + ty * TORSO
        val headX = neckX + dx(p.h) * HEAD; val headY = neckY + dy(p.h) * HEAD
        // "left" perpendicular of the torso for the front view
        val lx = -ty; val ly = tx
        val sNear = if (front) pt(neckX + lx * SW, neckY + ly * SW) else pt(neckX, neckY)
        val sFar = if (front) pt(neckX - lx * SW, neckY - ly * SW) else pt(neckX, neckY)
        val hNear = if (front) pt(hipX + lx * HW, hipY + ly * HW) else pt(hipX, hipY)
        val hFar = if (front) pt(hipX - lx * HW, hipY - ly * HW) else pt(hipX, hipY)
        fun ang(a: Float, near: Boolean) = if (front && near) -a else a
        fun arm(s: SimPt, u: Float, f: Float, near: Boolean): Pair<SimPt, SimPt> {
            val e = pt(s.x + dx(ang(u, near)) * UA, s.y + dy(ang(u, near)) * UA)
            return e to pt(e.x + dx(ang(f, near)) * FA, e.y + dy(ang(f, near)) * FA)
        }
        fun leg(h: SimPt, th: Float, sh: Float, ft: Float, near: Boolean): Triple<SimPt, SimPt, SimPt> {
            val k = pt(h.x + dx(ang(th, near)) * TH, h.y + dy(ang(th, near)) * TH)
            val a = pt(k.x + dx(ang(sh, near)) * SH, k.y + dy(ang(sh, near)) * SH)
            return Triple(k, a, pt(a.x + dx(ang(ft, near)) * FT, a.y + dy(ang(ft, near)) * FT))
        }
        val (eN, wN) = arm(sNear, p.a1, p.a2, true)
        val (eF, wF) = arm(sFar, p.b1, p.b2, false)
        val (kN, aN, tN) = leg(hNear, p.l1, p.l2, p.lf, true)
        val (kF, aF, tF) = leg(hFar, p.r1, p.r2, p.rf, false)
        val pts = listOf(headX to headY - HEAD_R, neckX to neckY, hipX to hipY, sNear.x to sNear.y, sFar.x to sFar.y,
            wN.x to wN.y, wF.x to wF.y, eN.x to eN.y, eF.x to eF.y, kN.x to kN.y, kF.x to kF.y,
            aN.x to aN.y, aF.x to aF.y, tN.x to tN.y, tF.x to tF.y, hipX to hipY)
        val minY = pts.minOf { it.second }
        val cx = if (front) hipX else (aN.x + aF.x) / 2f // keep planted feet in place
        val oy = -minY + max(0f, p.lift)
        fun s(q: SimPt) = SimPt(q.x - cx, q.y + oy)
        return SimFigure(
            s(pt(headX, headY)), s(pt(neckX, neckY)), s(pt(hipX, hipY)), s(sNear), s(sFar), s(hNear), s(hFar),
            s(eN), s(wN), s(eF), s(wF), s(kN), s(aN), s(tN), s(kF), s(aF), s(tF),
        )
    }

    private fun ease(f: Float): Float { val c = min(1f, max(0f, f)); return c * c * c * (c * (c * 6f - 15f) + 10f) }

    class Frame(val pose: SimPose, val step: Int, val cycle: Int)

    /** Pose of the demo at [timeMs] since start (loops forever). */
    fun frameAt(spec: SimSpec, timeMs: Long): Frame {
        val f = frameRaw(spec, timeMs)
        val br = (sin(timeMs / 3200.0 * 2.0 * PI) * 0.9).toFloat()   // gentle breathing so the person never looks frozen
        val p = f.pose
        return Frame(SimPose(p.t + br, p.h + br * 0.6f, p.a1, p.a2, p.b1, p.b2, p.l1, p.l2, p.r1, p.r2, p.lf, p.rf, p.lift), f.step, f.cycle)
    }

    private fun frameRaw(spec: SimSpec, timeMs: Long): Frame {
        val total = spec.cycleMs.toLong()
        val cycle = (timeMs / total).toInt()
        var t = (timeMs % total).toInt()
        val n = spec.steps.size
        for (i in 0 until n) {
            val s = spec.steps[i]
            val prev = spec.steps[(i + n - 1) % n].pose
            if (t < s.moveMs) return Frame(prev.mix(s.pose, ease(t.toFloat() / s.moveMs)), s.step, cycle)
            t -= s.moveMs
            if (t < s.holdMs) return Frame(s.pose, s.step, cycle)
            t -= s.holdMs
        }
        return Frame(spec.steps.last().pose, spec.steps.last().step, cycle)
    }

    /** Fixed drawing window for a spec so the picture never changes size while playing: minX, maxX, maxY. */
    fun bounds(spec: SimSpec): FloatArray {
        var mnx = 0f; var mxx = 0f; var mxy = 0f
        val n = 48
        for (i in 0 until n) {
            val f = frameAt(spec, (spec.cycleMs.toLong() * i) / n)
            for (q in figure(f.pose, spec.view).all()) {
                mnx = min(mnx, q.x - 0.07f); mxx = max(mxx, q.x + 0.07f); mxy = max(mxy, q.y + 0.07f)
            }
        }
        if (spec.chair) { mnx = min(mnx, CHAIR_X0 - 0.07f); mxy = max(mxy, CHAIR_TOP + 0.04f) }
        spec.block?.let { b -> mnx = min(mnx, b[0] - 0.03f); mxx = max(mxx, b[1] + 0.03f); mxy = max(mxy, b[2] + 0.04f) }
        return floatArrayOf(mnx, mxx, mxy)
    }
}

object Sims {
    private val P = SimPoses
    private fun s(p: SimPose, move: Int, hold: Int, step: Int) = SimStep(p, move, hold, step)

    fun of(type: ExerciseType): SimSpec = when (type) {
        ExerciseType.JUMPING_JACKS -> SimSpec(SimView.FRONT, listOf(
            s(P.JJ_A, 350, 700, 0), s(P.JJ_B, 380, 650, 1), s(P.JJ_A, 380, 300, 2),
        ), hotArms = true, hotLegs = true, ghost = P.JJ_B)
        ExerciseType.SQUATS -> SimSpec(SimView.SIDE, listOf(
            s(P.SQ_A, 400, 900, 0), s(P.SQ_A.mix(P.SQ_B, 0.55f), 700, 150, 1),
            s(P.SQ_B, 600, 900, 2), s(P.SQ_A, 1100, 500, 3),
        ), hotLegs = true, ghost = P.SQ_B)
        ExerciseType.PUSH_UPS -> SimSpec(SimView.SIDE, listOf(
            s(P.PU_A, 500, 900, 0), s(P.PU_A.mix(P.PU_B, 0.55f), 900, 100, 1),
            s(P.PU_B, 700, 700, 2), s(P.PU_A, 1100, 400, 2),
        ), hotArms = true, hotCore = true, mat = true, ghost = P.PU_B)
        ExerciseType.LUNGES -> SimSpec(SimView.SIDE, listOf(
            s(P.LU_STAND, 500, 700, 0), s(P.LU_L, 900, 800, 1), s(P.LU_STAND, 900, 300, 2),
            s(P.LU_R, 900, 800, 3), s(P.LU_STAND, 900, 300, 2),
        ), hotLegs = true)
        ExerciseType.HIGH_KNEES -> SimSpec(SimView.SIDE, listOf(
            s(P.HK_UP, 420, 150, 0), s(P.HK_MID.hop(0.025f), 320, 10, 1), s(P.HK_UP2, 420, 150, 0), s(P.HK_MID.hop(0.025f), 320, 10, 2),
        ), hotLegs = true, hotCore = true)
        ExerciseType.CRUNCHES -> SimSpec(SimView.SIDE, listOf(
            s(P.CR_A, 500, 700, 0), s(P.CR_A, 1, 800, 1), s(P.CR_B, 1000, 600, 2), s(P.CR_A, 1500, 400, 3),
        ), hotCore = true, mat = true, ghost = P.CR_B)
        ExerciseType.GLUTE_BRIDGES -> SimSpec(SimView.SIDE, listOf(
            s(P.GB_A, 500, 800, 0), s(P.GB_B, 1100, 200, 1), s(P.GB_B, 1, 1000, 2), s(P.GB_A, 1400, 400, 3),
        ), hotLegs = true, hotCore = true, mat = true, ghost = P.GB_B)
        ExerciseType.PLANK -> SimSpec(SimView.SIDE, listOf(
            s(P.PL_A, 500, 900, 0), s(P.PL_A, 1, 900, 1), s(P.PL_A, 1, 900, 2),
            s(P.PL_B, 1500, 200, 3), s(P.PL_A, 1500, 200, 3),
        ), hotCore = true, hotArms = true, mat = true)
        ExerciseType.SIT_TO_STAND -> SimSpec(SimView.SIDE, listOf(
            s(P.STS_SIT, 400, 900, 0), s(P.STS_LEAN, 800, 150, 1),
            s(P.STS_STAND, 800, 900, 2), s(P.STS_SIT, 1500, 600, 3),
        ), hotLegs = true, chair = true, ghost = P.STS_STAND)
        ExerciseType.CALF_RAISES -> SimSpec(SimView.SIDE, listOf(
            s(P.CALF_A, 400, 800, 0), s(P.CALF_A, 1, 500, 1), s(P.CALF_B, 900, 900, 2), s(P.CALF_A, 1300, 500, 3),
        ), hotLegs = true, ghost = P.CALF_B)
        ExerciseType.SIDE_LEG_RAISES -> SimSpec(SimView.FRONT, listOf(
            s(P.SL_A, 400, 700, 0), s(P.SL_L, 900, 700, 1), s(P.SL_A, 900, 300, 2),
            s(P.SL_R, 900, 700, 1), s(P.SL_A, 900, 300, 3),
        ), hotLegs = true)
        ExerciseType.INCLINE_PUSHUPS -> SimSpec(SimView.SIDE, listOf(
            s(P.IP_A, 500, 900, 0), s(P.IP_A, 1, 700, 1), s(P.IP_A.mix(P.IP_B, 0.55f), 900, 100, 2),
            s(P.IP_B, 700, 700, 2), s(P.IP_A, 1100, 400, 3),
        ), hotArms = true, hotCore = true, block = floatArrayOf(0.50f, 0.80f, 0.19f), ghost = P.IP_B)
        ExerciseType.DECLINE_PUSHUPS -> SimSpec(SimView.SIDE, listOf(
            s(P.DP_A, 500, 900, 0), s(P.DP_A, 1, 700, 1), s(P.DP_A.mix(P.DP_B, 0.55f), 900, 100, 2),
            s(P.DP_B, 700, 700, 2), s(P.DP_A, 1100, 400, 3),
        ), hotArms = true, hotCore = true, block = floatArrayOf(-0.30f, 0.10f, 0.29f), ghost = P.DP_B)
        ExerciseType.BICEPS_CURL -> SimSpec(SimView.SIDE, listOf(
            s(P.BC_A, 400, 900, 0), s(P.BC_A, 1, 400, 1), s(P.BC_B, 900, 800, 2), s(P.BC_A, 1200, 500, 3),
        ), hotArms = true, ghost = P.BC_B)
        ExerciseType.TRICEPS_EXTENSION -> SimSpec(SimView.SIDE, listOf(
            s(P.TE_A, 400, 900, 0), s(P.TE_A, 1, 400, 1), s(P.TE_B, 1000, 800, 2), s(P.TE_A, 1000, 500, 3),
        ), hotArms = true, ghost = P.TE_B)
        ExerciseType.FRONT_RAISE -> SimSpec(SimView.SIDE, listOf(
            s(P.FR_A, 400, 900, 0), s(P.FR_A, 1, 400, 1), s(P.FR_B, 1000, 800, 2), s(P.FR_A, 1200, 500, 3),
        ), hotArms = true, ghost = P.FR_B)
        ExerciseType.LATERAL_RAISE -> SimSpec(SimView.FRONT, listOf(
            s(P.LR_A, 400, 900, 0), s(P.LR_A, 1, 400, 1), s(P.LR_B, 1000, 800, 2), s(P.LR_A, 1200, 500, 3),
        ), hotArms = true, ghost = P.LR_B)
        ExerciseType.BUTT_KICKS -> SimSpec(SimView.SIDE, listOf(
            s(P.BK_L, 380, 150, 2), s(P.BK_M.hop(0.03f), 300, 10, 3), s(P.BK_R, 380, 150, 2), s(P.BK_M.hop(0.03f), 300, 10, 3),
        ), hotLegs = true)
        ExerciseType.GOOD_MORNING -> SimSpec(SimView.SIDE, listOf(
            s(P.GM_A, 400, 900, 0), s(P.GM_A, 1, 500, 1), s(P.GM_A.mix(P.GM_B, 0.55f), 900, 150, 2),
            s(P.GM_B, 700, 800, 2), s(P.GM_A, 1100, 500, 3),
        ), hotLegs = true, hotCore = true, ghost = P.GM_B)
        ExerciseType.LEG_RAISE -> SimSpec(SimView.SIDE, listOf(
            s(P.LRZ_A, 500, 900, 0), s(P.LRZ_A, 1, 500, 1), s(P.LRZ_B, 1300, 800, 2), s(P.LRZ_A, 1500, 500, 3),
        ), hotCore = true, hotLegs = true, mat = true, ghost = P.LRZ_B)
        ExerciseType.PIKE_PUSHUPS -> SimSpec(SimView.SIDE, listOf(
            s(P.PK_A, 500, 900, 0), s(P.PK_A, 1, 700, 1), s(P.PK_A.mix(P.PK_B, 0.55f), 900, 100, 2),
            s(P.PK_B, 700, 700, 2), s(P.PK_A, 1100, 400, 3),
        ), hotArms = true, hotCore = true, ghost = P.PK_B)
        ExerciseType.BULGARIAN_SPLIT_SQUAT -> SimSpec(SimView.SIDE, listOf(
            s(P.BS_A, 500, 900, 0), s(P.BS_A, 1, 600, 1), s(P.BS_A.mix(P.BS_B, 0.55f), 900, 100, 2),
            s(P.BS_B, 700, 700, 2), s(P.BS_A, 1100, 400, 3),
        ), hotLegs = true, block = floatArrayOf(-0.38f, -0.05f, 0.225f), ghost = P.BS_B)
        ExerciseType.SQUAT_PULSES -> SimSpec(SimView.SIDE, listOf(
            s(P.SQ_A, 500, 700, 0), s(P.SQ_B, 1000, 600, 1), s(P.SQ_A.mix(P.SQ_B, 0.7f), 350, 100, 2),
            s(P.SQ_B, 350, 100, 3), s(P.SQ_A.mix(P.SQ_B, 0.7f), 350, 100, 2), s(P.SQ_B, 350, 500, 3),
        ), hotLegs = true, ghost = P.SQ_B)
        ExerciseType.BURPEE -> SimSpec(SimView.SIDE, listOf(
            s(P.SQ_A, 500, 800, 0), s(P.BP_SH, 900, 600, 1), s(P.BP_PL, 700, 800, 2),
            s(P.BP_SH, 600, 100, 3), s(P.BP_JMP.hop(0.12f), 400, 100, 3), s(P.SQ_A, 400, 500, 0),
        ), hotLegs = true, hotArms = true, hotCore = true)
        ExerciseType.SQUAT_THRUST -> SimSpec(SimView.SIDE, listOf(
            s(P.SQ_A, 500, 800, 0), s(P.BP_SH, 800, 600, 1), s(P.BP_PL, 500, 900, 2),
            s(P.BP_SH, 500, 300, 3), s(P.SQ_A, 700, 500, 3),
        ), hotLegs = true, hotArms = true, hotCore = true)
        ExerciseType.V_UPS -> SimSpec(SimView.SIDE, listOf(
            s(P.VU_A, 500, 900, 0), s(P.VU_A, 1, 500, 1), s(P.VU_B, 1100, 800, 2), s(P.VU_A, 1500, 500, 3),
        ), hotCore = true, hotLegs = true, mat = true, ghost = P.VU_B)
        ExerciseType.TIBIALIS_RAISE -> SimSpec(SimView.SIDE, listOf(
            s(P.TB_A, 500, 900, 0), s(P.TB_A, 1, 500, 1), s(P.TB_B, 700, 700, 2), s(P.TB_A, 900, 400, 3),
        ), hotLegs = true, block = floatArrayOf(-0.20f, -0.12f, 1.0f), ghost = P.TB_B)
        ExerciseType.DOWNWARD_DOG -> SimSpec(SimView.SIDE, listOf(
            s(P.PU_A, 500, 900, 0), s(P.PK_A, 1200, 500, 1), s(P.PK_A, 1, 900, 2), s(P.PK_A, 1, 1200, 3),
        ), hotArms = true, hotLegs = true, hotCore = true, mat = true)
        ExerciseType.HOLLOW_BODY_HOLD -> SimSpec(SimView.SIDE, listOf(
            s(P.HB_A, 500, 900, 0), s(P.HB_A, 1, 500, 1), s(P.HB_B, 1200, 700, 2), s(P.HB_B, 1, 1500, 3), s(P.HB_A, 1200, 400, 0),
        ), hotCore = true, mat = true, ghost = P.HB_B)
        ExerciseType.CHILD_POSE -> SimSpec(SimView.SIDE, listOf(
            s(P.CH_A, 500, 900, 0), s(P.CH_A.mix(P.CH_B, 0.4f), 900, 300, 1), s(P.CH_B, 1100, 600, 2),
            s(P.CH_B, 1, 1500, 3), s(P.CH_A, 1300, 300, 0),
        ), hotCore = true, mat = true)
        ExerciseType.COBRA_STRETCH -> SimSpec(SimView.SIDE, listOf(
            s(P.CB_A, 500, 900, 0), s(P.CB_A, 1, 500, 1), s(P.CB_B, 1300, 800, 2), s(P.CB_B, 1, 1500, 3), s(P.CB_A, 1300, 300, 0),
        ), hotCore = true, mat = true)
    }
}
