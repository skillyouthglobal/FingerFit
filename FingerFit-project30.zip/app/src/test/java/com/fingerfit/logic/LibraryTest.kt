package com.fingerfit.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LibraryTest {
    private fun ids(q: String) = LibSearch.search(Library.all, q).map { it.id }

    @Test fun hasAllExercises() {
        assertEquals(ExerciseType.values().size - Library.promoted.size + 1 + 42, Library.all.size)
        for (t in ExerciseType.values()) assertEquals(1, Library.all.count { it.type == t })
        assertEquals(Library.all.size, Library.all.map { it.id }.toSet().size)
    }
    @Test fun everyItemHasBothLanguages() {
        for (i in Library.all) {
            assertTrue(i.id, i.name(true).isNotBlank() && i.name(false).isNotBlank())
            assertTrue(i.id, i.benefits(true).isNotEmpty() && i.benefits(false).isNotEmpty())
            assertTrue(i.id, i.how(true).isNotBlank() && i.how(false).isNotBlank())
            assertTrue(i.id, i.parts.isNotEmpty() && i.target > 0)
        }
    }
    @Test fun emptyQueryKeepsAll() { assertEquals(Library.all.size, LibSearch.search(Library.all, "  ").size) }
    @Test fun pushupSpellings() {
        assertTrue("incline_pushup" in ids("pushup"))
        assertTrue("incline_pushup" in ids("push-up"))
        assertTrue("incline_pushup" in ids("push up"))
        assertTrue("pike_pushup" in ids("pushups"))
        assertTrue("incline_pushup" in ids("পুশ আপ"))
        assertTrue("incline_pushup" in ids("পুশআপ"))
    }
    @Test fun typoTolerated() {
        assertTrue("burpee" in ids("burpe"))
        assertTrue("russian_twist" in ids("rusian twist"))
        assertTrue("plank" == ids("plnk").firstOrNull()?.removePrefix("t_")?.lowercase())
    }
    @Test fun bodyPartWords() {
        assertTrue("russian_twist" in ids("পেট"))
        assertTrue("good_morning" in ids("কোমর"))
        assertTrue("childs_pose" in ids("কোমর"))
        assertTrue("downward_dog" in ids("stretch"))
        assertTrue("jump_rope" in ids("heart"))
        assertTrue("t_JUMPING_JACKS" in ids("হার্ট"))
        assertTrue("biceps_curl" in ids("biceps"))
    }
    @Test fun noMatchGivesEmpty() {
        assertTrue(ids("zzzzqqqq").isEmpty())
        assertTrue(ids("%%% ###").size == Library.all.size)
    }
    @Test fun nameMatchesRankFirst() {
        assertEquals("bear_crawl", ids("bear").first())
    }
    @Test fun filters() {
        val core = Library.filter(Library.all, LibCat.CORE, null, false, false)
        assertTrue(core.isNotEmpty() && core.all { it.cat == LibCat.CORE })
        val cam = Library.filter(Library.all, null, null, false, true)
        assertEquals(ExerciseType.values().size + 1, cam.size)
        val noEq = Library.filter(Library.all, null, LibPart.CHEST, true, false)
        assertTrue(noEq.all { it.equip == LibEquip.NONE && LibPart.CHEST in it.parts })
        for (c in LibCat.values()) assertTrue(c.name, Library.filter(Library.all, c, null, false, false).isNotEmpty())
        for (p in LibPart.values()) assertTrue(p.name, Library.filter(Library.all, null, p, false, false).isNotEmpty())
    }
    @Test fun timedItemsHaveSeconds() {
        val hold = Library.byId("hollow_hold")!!
        assertTrue(hold.timed && hold.unitEn == "sec")
        assertTrue(!Library.byId("biceps_curl")!!.timed)
    }
}
