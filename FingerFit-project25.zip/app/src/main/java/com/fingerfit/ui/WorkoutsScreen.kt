package com.fingerfit.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.remember
import com.fingerfit.AppViewModel
import com.fingerfit.data.todayReps
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.data.Repo
import com.fingerfit.data.toLocalDate
import com.fingerfit.logic.ExerciseType
import com.fingerfit.logic.PlanGroup
import com.fingerfit.logic.Plans
import java.time.LocalDate

/** The "Workouts" tab: all camera-tracked exercises, filtered by purpose. */
@Composable
fun BodyListScreen(vm: AppViewModel, onBack: () -> Unit, onPick: (ExerciseType) -> Unit, onFinger: () -> Unit) {
    BackHandler(onBack = onBack)
    val workouts by Repo.workouts.collectAsStateWithLifecycle()
    val today = LocalDate.now()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val fingerToday = history.todayReps()
    val target = settings.target
    var filter by rememberSaveable { mutableStateOf("ALL") }
    val shown = ExerciseType.values().filter { filter == "ALL" || Plans.groupOf(it).name == filter }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.statusBarsPadding()) {
        Column {
            Column(Modifier.padding(start = 22.dp, end = 22.dp, top = 16.dp)) {
                Text("Exercise", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "The camera counts every rep. Keep your whole body in view.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp,
                )
            }
            Row(
                Modifier.padding(horizontal = 22.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(selected = filter == "ALL", onClick = { filter = "ALL" }, label = { Text("All") })
                PlanGroup.values().forEach { g ->
                    FilterChip(selected = filter == g.name, onClick = { filter = g.name }, label = { Text(g.chip) })
                }
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 22.dp, end = 22.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(shown) { type ->
                    val done = workouts
                        .filter { it.type == type.name && it.t.toLocalDate() == today }
                        .sumOf { it.reps }
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth().clickable { onPick(type) },
                    ) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.fillMaxWidth().height(88.dp).background(HeroTint, RoundedCornerShape(18.dp)),
                                contentAlignment = Alignment.Center,
                            ) { Text(type.emoji, fontSize = 46.sp) }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                type.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            )
                            Text(
                                "${Plans.groupOf(type).chip} · ${type.defaultTarget} ${type.unit}",
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                            )
                            Text(
                                if (done > 0) "Today: $done ${type.unit}" else " ",
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.tertiary,
                                fontWeight = FontWeight.SemiBold, maxLines = 1,
                            )
                        }
                    }
                }
                if (filter == "ALL") {
                    item {
                        Card(
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth().clickable { onFinger() },
                        ) {
                            Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    Modifier.fillMaxWidth().height(88.dp).background(HeroTint, RoundedCornerShape(18.dp)),
                                    contentAlignment = Alignment.Center,
                                ) { Text("✋", fontSize = 46.sp) }
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    "Finger exercise", fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                )
                                Text(
                                    "Hand · $target reps",
                                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                                )
                                Text(
                                    if (fingerToday > 0) "Today: $fingerToday reps" else " ",
                                    fontSize = 12.sp, color = MaterialTheme.colorScheme.tertiary,
                                    fontWeight = FontWeight.SemiBold, maxLines = 1,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
