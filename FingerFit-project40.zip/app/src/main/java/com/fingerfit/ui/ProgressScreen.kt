package com.fingerfit.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.data.ProfileRepo
import com.fingerfit.data.Repo
import com.fingerfit.data.WeightRepo
import com.fingerfit.logic.Act
import com.fingerfit.logic.Burn
import com.fingerfit.logic.ExerciseType
import com.fingerfit.logic.Health
import com.fingerfit.logic.Nudges
import com.fingerfit.logic.Progress
import com.fingerfit.logic.WeightLog
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.util.Locale

private val PgGreen = Color(0xFF0B8A6C)
private val PgBlue = Color(0xFF2F6BFF)
private val PgAmber = Color(0xFFE8890C)
private val PgViolet = Color(0xFF7C5CE6)
private val PgInk = Color(0xFF12203F)
private val PgInkSoft = Color(0xFF3F4F70)

/** The "Progress" tab: today / week / month at a glance, charts, streak, weight, badges and favourite exercises. */
@Composable
fun ProgressScreen(vm: AppViewModel) {
    val isBn = LangState.bn
    val workouts by Repo.workouts.collectAsStateWithLifecycle()
    val walks by Repo.walks.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val profile by ProfileRepo.profile.collectAsStateWithLifecycle()
    val weights by WeightRepo.list.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf(1) } // 0 today, 1 week, 2 month
    var logWeight by remember { mutableStateOf(false) }

    val today = LocalDate.now()
    val acts = remember(workouts, walks, history) { allActs(workouts, walks, history) }
    val goal = settings.walkGoalMin
    val weightKg = weights.lastOrNull()?.kg ?: profile?.weightKg ?: 60f
    val kcalGoal = Burn.target(weightKg, goal)

    val scopeDays = when (tab) { 0 -> 1; 1 -> 7; else -> 30 }
    val chartDays = if (tab == 2) 30 else 7
    val scope = remember(acts, scopeDays) { Progress.perDay(acts, today, scopeDays) }
    val chart = remember(acts, chartDays) { Progress.perDay(acts, today, chartDays) }
    val week = remember(acts) { Progress.perDay(acts, today, 7) }
    val streak = remember(acts) { Progress.streak(acts, today) }
    val best = remember(acts) { maxOf(bestStreak(acts), Progress.streak(acts, today)) }
    val todayMin = remember(acts) { Progress.perDay(acts, today, 1).last().minutes }
    val ring = Progress.ring(todayMin, goal)

    val scopeMin = scope.sumOf { it.minutes }
    val scopeKcal = Burn.kcal(weightKg, scopeMin)
    val scopeSessions = scope.sumOf { it.sessions }
    val activeDays = scope.count { it.active }
    val scopeReps = scope.sumOf { it.reps }

    val totalReps = workouts.sumOf { it.reps } + history.sumOf { it.reps }
    val sessions = workouts.size + walks.size + history.size
    val km = walks.sumOf { it.meters.toDouble() } / 1000.0
    val topEx = remember(workouts) { workouts.groupingBy { it.type }.eachCount().entries.sortedByDescending { it.value }.take(5) }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.statusBarsPadding()) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Rise(0) {
                Column {
                    Text(pick(isBn, "Progress", "অগ্রগতি"), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    val me = profile
                    if (me != null) {
                        Text(
                            "${Nudges.firstName(me.name, isBn)}, " + pick(isBn, "here is how you are doing", "আপনি কেমন করছেন দেখুন"),
                            fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            Rise(1) {
                RangeTabs(
                    tab, listOf(pick(isBn, "Today", "আজ"), pick(isBn, "This week", "এই সপ্তাহ"), pick(isBn, "This month", "এই মাস")),
                ) { tab = it }
            }

            // ---- summary -------------------------------------------------------------------
            Rise(2) {
                Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = HeroTint)) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        val animRing by animateFloatAsState(ring, tween(900), label = "ring")
                        val track = Color.White
                        Box(Modifier.size(108.dp), contentAlignment = Alignment.Center) {
                            Canvas(Modifier.size(108.dp)) {
                                val sw = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                                val inset = 6.dp.toPx()
                                val arc = Size(size.width - 2 * inset, size.height - 2 * inset)
                                drawArc(track, -90f, 360f, false, Offset(inset, inset), arc, style = sw)
                                if (animRing > 0f) drawArc(PgGreen, -90f, 360f * animRing, false, Offset(inset, inset), arc, style = sw)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${num(isBn, (ring * 100).toInt())}%", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = PgInk)
                                Text(pick(isBn, "of today's goal", "আজকের লক্ষ্য"), fontSize = 10.sp, color = PgInkSoft, maxLines = 1)
                            }
                        }
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(
                                when (tab) {
                                    0 -> pick(isBn, "Today", "আজ")
                                    1 -> pick(isBn, "Last 7 days", "গত ৭ দিন")
                                    else -> pick(isBn, "Last 30 days", "গত ৩০ দিন")
                                },
                                fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PgInkSoft,
                            )
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(num(isBn, scopeKcal), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = PgInk)
                                Spacer(Modifier.width(4.dp))
                                Text(pick(isBn, "kcal burned", "ক্যালরি খরচ"), fontSize = 13.sp, color = PgInk, modifier = Modifier.padding(bottom = 5.dp))
                            }
                            Text(
                                num(isBn, scopeMin) + " " + pick(isBn, "min", "মিনিট") + " · " +
                                    num(isBn, scopeSessions) + " " + pick(isBn, if (scopeSessions == 1) "exercise" else "exercises", "ব্যায়াম"),
                                fontSize = 14.sp, color = PgInk,
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(KIcon.Flame, contentDescription = null, tint = PgAmber, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    num(isBn, streak) + " " + pick(isBn, if (streak == 1) "day in a row" else "days in a row", "দিন টানা"),
                                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = PgInk,
                                )
                            }
                        }
                    }
                }
            }

            Rise(3) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MiniTile(KIcon.Calendar, PgGreen, num(isBn, activeDays) + "/" + num(isBn, scopeDays), pick(isBn, "active days", "সক্রিয় দিন"), Modifier.weight(1f))
                    MiniTile(KIcon.Repeat, PgBlue, num(isBn, scopeReps), pick(isBn, "reps", "বার"), Modifier.weight(1f))
                    MiniTile(KIcon.Walk, PgViolet, String.format(Locale.US, "%.1f", km).let { if (isBn) com.fingerfit.logic.Bn.toBn(it) else it }, pick(isBn, "km walked", "কিমি হাঁটা"), Modifier.weight(1f))
                }
            }

            // ---- calories chart ----------------------------------------------------------------
            Rise(4) {
                PgCard {
                    Head(KIcon.Flame, PgAmber, pick(isBn, "Calories burned", "ক্যালরি খরচ"), num(isBn, Burn.kcal(weightKg, chart.sumOf { it.minutes })) + " " + pick(isBn, "kcal", "ক্যালরি"))
                    BarsChart(chart.map { Burn.kcal(weightKg, it.minutes) }, kcalGoal, PgAmber)
                    DayLabels(chart, isBn, tab == 2)
                    Legend(pick(isBn, "Dashed line = daily goal", "ড্যাশ রেখা = দৈনিক লক্ষ্য") + " (" + num(isBn, kcalGoal) + " " + pick(isBn, "kcal", "ক্যালরি") + ")")
                }
            }

            // ---- active time + exercise count -------------------------------------------------
            Rise(5) {
                PgCard {
                    Head(KIcon.Stopwatch, PgBlue, pick(isBn, "Active time", "সক্রিয় সময়"), num(isBn, chart.sumOf { it.minutes }) + " " + pick(isBn, "min", "মিনিট"))
                    BarsChart(chart.map { it.minutes }, goal, PgBlue)
                    DayLabels(chart, isBn, tab == 2)
                    if (tab != 2) {
                        Row(Modifier.fillMaxWidth()) {
                            chart.forEach { d ->
                                Text(
                                    num(isBn, d.sessions), fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                                    color = if (d.sessions > 0) PgBlue else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.weight(1f), maxLines = 1,
                                )
                            }
                        }
                        Legend(pick(isBn, "Numbers under the days = exercises done", "দিনের নিচের সংখ্যা = করা ব্যায়াম"))
                    } else {
                        Legend(num(isBn, chart.sumOf { it.sessions }) + " " + pick(isBn, "exercises in 30 days", "ব্যায়াম ৩০ দিনে"))
                    }
                }
            }

            // ---- streak ---------------------------------------------------------------------
            Rise(6) {
                PgCard {
                    Head(KIcon.Flame, PgAmber, pick(isBn, "Your streak", "টানা দিন"), null)
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(num(isBn, streak), fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, color = PgAmber)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            pick(isBn, if (streak == 1) "day in a row" else "days in a row", "দিন টানা"),
                            fontSize = 15.sp, modifier = Modifier.padding(bottom = 8.dp).weight(1f),
                        )
                        Text(
                            pick(isBn, "Best", "সেরা") + " " + num(isBn, best),
                            fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 8.dp),
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        week.forEach { d -> DayDot(d.active, dayShort(isBn, d.date.dayOfWeek.value)) }
                    }
                }
            }

            // ---- weight ---------------------------------------------------------------------
            val me = profile
            if (me != null) {
                Rise(7) {
                    val bmi = Health.bmi(weightKg, me.heightCm)
                    val change = WeightLog.change(weights, 30, today)
                    val range = Health.healthyRangeKg(me.heightCm)
                    PgCard {
                        Head(KIcon.Scale, PgGreen, pick(isBn, "Weight", "ওজন"), String.format(Locale.US, "%.1f", weightKg).let { if (isBn) com.fingerfit.logic.Bn.toBn(it) else it } + " " + pick(isBn, "kg", "কেজি"))
                        WeightChart(weights.takeLast(12).map { it.kg })
                        if (weights.size < 2) {
                            Legend(pick(isBn, "Add your weight each week. The chart will show your progress.", "প্রতি সপ্তাহে ওজন যোগ করুন। চার্টে আপনার অগ্রগতি দেখা যাবে।"))
                        } else if (change != null) {
                            val c = String.format(Locale.US, "%.1f", kotlin.math.abs(change)).let { if (isBn) com.fingerfit.logic.Bn.toBn(it) else it }
                            Text(
                                if (kotlin.math.abs(change) < 0.05f) pick(isBn, "No change in the last 30 days", "গত ৩০ দিনে কোনো পরিবর্তন নেই")
                                else if (change < 0) pick(isBn, "Down $c kg in the last 30 days", "গত ৩০ দিনে $c কেজি কমেছে")
                                else pick(isBn, "Up $c kg in the last 30 days", "গত ৩০ দিনে $c কেজি বেড়েছে"),
                                fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                            )
                        }
                        Legend(
                            "BMI " + String.format(Locale.US, "%.1f", bmi).let { if (isBn) com.fingerfit.logic.Bn.toBn(it) else it } + " · " + Health.bmiCategory(bmi),
                        )
                        Legend(
                            pick(isBn, "Healthy range for your height: ", "আপনার উচ্চতায় সুস্থ ওজন: ") +
                                String.format(Locale.US, "%.0f–%.0f", range.first, range.second).let { if (isBn) com.fingerfit.logic.Bn.toBn(it) else it } + " " + pick(isBn, "kg", "কেজি"),
                        )
                        OutlinedButton(onClick = { logWeight = true }, shape = RoundedCornerShape(14.dp)) {
                            Icon(KIcon.Plus, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(pick(isBn, "Add today's weight", "আজকের ওজন যোগ করুন"))
                        }
                    }
                }
            }

            // ---- badges ---------------------------------------------------------------------
            Rise(8) {
                val badges = listOf(
                    Badge(KIcon.Star, PgAmber, "First exercise", "প্রথম ব্যায়াম", sessions, 1),
                    Badge(KIcon.Flame, PgAmber, "7-day streak", "৭ দিন টানা", best, 7),
                    Badge(KIcon.Trophy, PgGreen, "30-day streak", "৩০ দিন টানা", best, 30),
                    Badge(KIcon.Repeat, PgBlue, "1000 reps", "১০০০ বার", totalReps, 1000),
                    Badge(KIcon.Medal, PgViolet, "100 exercises", "১০০ ব্যায়াম", sessions, 100),
                    Badge(KIcon.Walk, PgGreen, "50 km walked", "৫০ কিমি হাঁটা", km.toInt(), 50),
                )
                val got = badges.count { it.value >= it.goal }
                PgCard {
                    Head(KIcon.Medal, PgViolet, pick(isBn, "Achievements", "অর্জন"), num(isBn, got) + "/" + num(isBn, badges.size))
                    badges.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            pair.forEach { b -> BadgeTile(b, isBn, Modifier.weight(1f)) }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            // ---- most done exercises --------------------------------------------------------
            Rise(9) {
                PgCard {
                    Head(KIcon.Exercise, PgGreen, pick(isBn, "Most done exercises", "সবচেয়ে বেশি করা ব্যায়াম"), null)
                    if (topEx.isEmpty()) {
                        Legend(pick(isBn, "Your first workout will start this list. Open the Exercise tab and begin.", "প্রথম ব্যায়াম করলেই এই তালিকা শুরু হবে। ব্যায়াম ট্যাবে গিয়ে শুরু করুন।"))
                    } else {
                        val most = topEx.first().value.coerceAtLeast(1)
                        topEx.forEach { e ->
                            val type = runCatching { ExerciseType.valueOf(e.key) }.getOrNull()
                            TopRow(type, e.key, e.value, most, isBn)
                        }
                    }
                }
            }

            Rise(10) {
                Text(
                    pick(
                        isBn,
                        if (sessions == 0) "Your first workout will start your charts. A little each day is the best habit."
                        else if (streak >= 3) "Great! You are on a streak. Keep going."
                        else "Every session counts. A little each day is the best habit.",
                        if (sessions == 0) "প্রথম ব্যায়ামেই আপনার চার্ট শুরু হবে। প্রতিদিন একটু একটু করাই সেরা অভ্যাস।"
                        else if (streak >= 3) "দারুণ! আপনি টানা করছেন। চালিয়ে যান।"
                        else "প্রতিটি সেশনই গুরুত্বপূর্ণ। প্রতিদিন একটু একটু করাই সেরা অভ্যাস।",
                    ),
                    fontSize = 14.sp, color = PgInkSoft,
                    modifier = Modifier.fillMaxWidth().background(Color(0xFFFFF4E0), RoundedCornerShape(18.dp)).padding(16.dp),
                )
            }
            Spacer(Modifier.height(8.dp))
        }
    }
    val p = profile
    if (logWeight && p != null) {
        WeightDialog(
            initial = weightKg,
            isBn = isBn,
            onDismiss = { logWeight = false },
            onSave = { kg -> ProfileRepo.save(p.copy(weightKg = kg)); logWeight = false },
        )
    }
}

// ---------------------------------------------------------------------------------------------
// small pieces
// ---------------------------------------------------------------------------------------------

private class Badge(val icon: ImageVector, val tint: Color, val en: String, val bn: String, val value: Int, val goal: Int)

private fun bestStreak(acts: List<Act>): Int {
    val ds = acts.map { it.date }.toSortedSet().toList()
    var best = 0
    var run = 0
    var prev: LocalDate? = null
    for (d in ds) {
        val p = prev
        run = if (p != null && p.plusDays(1) == d) run + 1 else 1
        if (run > best) best = run
        prev = d
    }
    return best
}

private fun dayShort(isBn: Boolean, isoDay: Int): String = when (isoDay) {
    1 -> pick(isBn, "Mon", "সোম")
    2 -> pick(isBn, "Tue", "মঙ্গল")
    3 -> pick(isBn, "Wed", "বুধ")
    4 -> pick(isBn, "Thu", "বৃহ")
    5 -> pick(isBn, "Fri", "শুক্র")
    6 -> pick(isBn, "Sat", "শনি")
    else -> pick(isBn, "Sun", "রবি")
}

/** Fades and slides a block up shortly after the screen opens, one after another by [index]. */
@Composable
private fun Rise(index: Int, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(index * 70L)
        shown = true
    }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(450), label = "rise")
    Box(Modifier.graphicsLayer { alpha = a; translationY = (1f - a) * 30f }) { content() }
}

@Composable
private fun RangeTabs(sel: Int, labels: List<String>, onSel: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        labels.forEachIndexed { i, l ->
            val on = i == sel
            val bg by animateColorAsState(if (on) MaterialTheme.colorScheme.surface else Color.Transparent, tween(200), label = "tab")
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(bg).bounceClick { onSel(i) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    l, fontSize = 14.sp, fontWeight = if (on) FontWeight.ExtraBold else FontWeight.SemiBold, maxLines = 1,
                    color = if (on) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun PgCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() }
    }
}

@Composable
private fun Head(icon: ImageVector, tint: Color, title: String, trailing: String?) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).clip(CircleShape).background(tint.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(10.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f), maxLines = 2)
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            Text(trailing, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = tint, maxLines = 1)
        }
    }
}

@Composable
private fun Legend(text: String) {
    Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun MiniTile(icon: ImageVector, tint: Color, value: String, label: String, modifier: Modifier) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier,
    ) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
            Spacer(Modifier.height(4.dp))
            Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, maxLines = 1)
            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, maxLines = 2, minLines = 2)
        }
    }
}

@Composable
private fun DayLabels(days: List<com.fingerfit.logic.DayStat>, isBn: Boolean, month: Boolean) {
    if (month) {
        Legend(pick(isBn, "Last 30 days", "গত ৩০ দিন"))
        return
    }
    Row(Modifier.fillMaxWidth()) {
        days.forEach { d ->
            Text(
                dayShort(isBn, d.date.dayOfWeek.value), fontSize = 11.sp, textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Clip,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun DayDot(active: Boolean, label: String) {
    val bg by animateColorAsState(if (active) PgGreen else Color.Transparent, tween(400), label = "dot")
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(bg)
                .border(1.5.dp, if (active) PgGreen else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            if (active) Icon(KIcon.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun BadgeTile(b: Badge, isBn: Boolean, modifier: Modifier) {
    val got = b.value >= b.goal
    val frac = (b.value.toFloat() / b.goal).coerceIn(0f, 1f)
    val tint = if (got) b.tint else MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        modifier.clip(RoundedCornerShape(16.dp))
            .background(if (got) b.tint.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(38.dp).clip(CircleShape).background(tint.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            Icon(if (got) b.icon else KIcon.Lock, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(pick(isBn, b.en, b.bn), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 2, lineHeight = 15.sp)
            if (got) {
                Text(pick(isBn, "Unlocked", "অর্জিত"), fontSize = 11.sp, color = b.tint, fontWeight = FontWeight.SemiBold)
            } else {
                LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape), color = b.tint)
                Text(num(isBn, b.value) + " / " + num(isBn, b.goal), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}

@Composable
private fun TopRow(type: ExerciseType?, key: String, count: Int, most: Int, isBn: Boolean) {
    val photo = ExerciseImages.of(key)
    val frac = (count.toFloat() / most).coerceIn(0.05f, 1f)
    val anim by animateFloatAsState(frac, tween(700), label = "top")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(72.dp).aspectRatio(4f / 3f).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            if (photo != null) {
                Image(painter = painterResource(photo), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().aspectRatio(4f / 3f))
            } else {
                Icon(KIcon.Exercise, contentDescription = null, tint = PgGreen, modifier = Modifier.size(24.dp))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(type?.title ?: key, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(6.dp))
                Text(num(isBn, count) + "×", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = PgGreen)
            }
            Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)) {
                Box(Modifier.fillMaxWidth(anim).height(6.dp).clip(CircleShape).background(PgGreen))
            }
        }
    }
}

/** Bars per day with a dashed goal line; the bars grow in when the screen opens. */
@Composable
private fun BarsChart(values: List<Int>, goal: Int, color: Color) {
    val empty = MaterialTheme.colorScheme.surfaceVariant
    val goalColor = MaterialTheme.colorScheme.onSurfaceVariant
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { go = true }
    val grow by animateFloatAsState(if (go) 1f else 0f, tween(700), label = "grow")
    Canvas(Modifier.fillMaxWidth().height(150.dp)) {
        val n = values.size.coerceAtLeast(1)
        val top = maxOf(values.maxOrNull() ?: 0, goal, 10) * 1.15f
        val slot = size.width / n
        val w = slot * 0.6f
        val usable = size.height - 4.dp.toPx()
        val minH = 5.dp.toPx()
        values.forEachIndexed { i, v ->
            val full = if (v <= 0) minH else maxOf(minH, v / top * usable)
            val h = full * grow
            val x = i * slot + (slot - w) / 2f
            drawRoundRect(
                color = if (v <= 0) empty else if (i == values.size - 1) color else color.copy(alpha = 0.6f),
                topLeft = Offset(x, size.height - h),
                size = Size(w, h),
                cornerRadius = CornerRadius(w / 2.5f, w / 2.5f),
            )
        }
        if (goal > 0) {
            val y = size.height - goal / top * usable
            drawLine(
                goalColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1.5.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f), 0f),
            )
        }
    }
}

@Composable
private fun WeightChart(values: List<Float>) {
    val line = MaterialTheme.colorScheme.tertiary
    val dot = MaterialTheme.colorScheme.primary
    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
        if (values.size < 2) return@Canvas
        val mn = values.minOrNull() ?: 0f
        val mx = values.maxOrNull() ?: 0f
        val span = (mx - mn).coerceAtLeast(1f)
        val pad = 10.dp.toPx()
        fun px(i: Int) = pad + i * (size.width - 2 * pad) / (values.size - 1)
        fun py(v: Float) = size.height - pad - (v - mn) / span * (size.height - 2 * pad)
        for (i in 1 until values.size) {
            drawLine(line, Offset(px(i - 1), py(values[i - 1])), Offset(px(i), py(values[i])), 4.dp.toPx(), StrokeCap.Round)
        }
        values.forEachIndexed { i, v ->
            drawCircle(if (i == values.size - 1) dot else line, 5.dp.toPx(), Offset(px(i), py(v)))
        }
    }
}

@Composable
private fun WeightDialog(initial: Float, isBn: Boolean, onDismiss: () -> Unit, onSave: (Float) -> Unit) {
    var text by remember { mutableStateOf(String.format(Locale.US, "%.1f", initial)) }
    val kg = text.replace(',', '.').toFloatOrNull()
    val ok = kg != null && kg in 15f..300f
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(pick(isBn, "Add today's weight", "আজকের ওজন যোগ করুন")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    label = { Text(pick(isBn, "Weight (kg)", "ওজন (কেজি)")) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                )
                if (!ok) Text(pick(isBn, "Weight must be between 15 and 300 kg.", "ওজন ১৫ থেকে ৩০০ কেজির মধ্যে হতে হবে।"), fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { TextButton(onClick = { if (kg != null && ok) onSave(kg) }, enabled = ok) { Text(pick(isBn, "Save", "সেভ")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(pick(isBn, "Cancel", "বাতিল")) } },
    )
}
