package com.fingerfit.update

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.fingerfit.Notify
import com.fingerfit.R
import com.fingerfit.data.AppPrefs
import java.util.concurrent.TimeUnit

/** Tells the person, once per version, that a new Kinetro is ready. Tapping it opens the app, which shows the update popup. */
object UpdateNotify {
    private const val CH_UPDATE = "updates"
    private const val ID = 301

    fun notifyOnce(ctx: Context, info: UpdateInfo) {
        try {
            val sp = ctx.applicationContext.getSharedPreferences("kinetro_update", Context.MODE_PRIVATE)
            if (sp.getInt("notified_code", 0) >= info.code) return
            if (!Notify.canPost(ctx)) return
            val bn = com.fingerfit.logic.Bn.bn
            val title = if (bn) "Kinetro-র নতুন আপডেট এসেছে" else "A new Kinetro update is ready"
            val body = if (bn) "নতুন ভার্সন ${info.name}। অ্যাপ খুলে আপডেট করুন।" else "New version ${info.name}. Open the app to update."
            val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel(CH_UPDATE, if (bn) "অ্যাপ আপডেট" else "App updates", NotificationManager.IMPORTANCE_HIGH),
                )
            }
            val n = NotificationCompat.Builder(ctx, CH_UPDATE)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setContentIntent(Notify.openAppIntent(ctx))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()
            nm.notify(ID, n)
            sp.edit().putInt("notified_code", info.code).apply()
        } catch (e: Exception) {
            // a missing notification must never crash the app
        }
    }
}

/** Looks for a new version in the background, even when the app is closed, whenever there is internet. */
class UpdateCheckWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        AppPrefs.apply(applicationContext)
        val info = Updater.check(applicationContext)
        if (info != null) UpdateNotify.notifyOnce(applicationContext, info)
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<UpdateCheckWorker>(6, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx.applicationContext)
                .enqueueUniquePeriodicWork("update_check", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
