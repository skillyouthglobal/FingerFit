package com.fingerfit.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import com.fingerfit.logic.Versions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class UpdateInfo(val code: Int, val name: String, val apkUrl: String)

/**
 * Looks at the newest GitHub release. Only needs internet at that moment; the app itself stays
 * fully offline. The update is never installed silently: Android always asks the user to confirm.
 */
object Updater {
    const val REPO = "skillyouthglobal/FingerFit"

    fun installedCode(context: Context): Int = try {
        PackageInfoCompat.getLongVersionCode(context.packageManager.getPackageInfo(context.packageName, 0)).toInt()
    } catch (e: Exception) {
        0
    }

    /**
     * Where the newest version is described, as a small JSON file: {"code":41,"name":"v41","apk":"https://..."}.
     * Empty = use the GitHub release. Later this can point to the project's own website, so the app
     * keeps updating even after the GitHub repository is made private.
     */
    val FEED_URL: String = ""

    /** The newer release, or null when up to date, offline, or anything goes wrong. */
    suspend fun check(context: Context): UpdateInfo? = withContext(Dispatchers.IO) {
        val own = if (FEED_URL.isNotEmpty()) fromFeed(context) else null
        own ?: fromGithub(context)
    }

    private fun get(url: String): String? {
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("Accept", "application/json")
            try {
                if (conn.responseCode != 200) null else conn.inputStream.bufferedReader().use { it.readText() }
            } finally {
                conn.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun fromFeed(context: Context): UpdateInfo? {
        return try {
            val json = JSONObject(get(FEED_URL) ?: return null)
            val code = json.optInt("code", 0)
            val apk = json.optString("apk")
            if (apk.isEmpty() || !Versions.isNewer(code, installedCode(context))) null
            else UpdateInfo(code, json.optString("name", "v$code"), apk)
        } catch (e: Exception) {
            null
        }
    }

    private fun fromGithub(context: Context): UpdateInfo? {
        return try {
            val json = JSONObject(get("https://api.github.com/repos/$REPO/releases/latest") ?: return null)
            val tag = json.optString("tag_name")
            val code = Versions.codeFromTag(tag) ?: return null
            if (!Versions.isNewer(code, installedCode(context))) return null
            val assets = json.optJSONArray("assets") ?: return null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk", ignoreCase = true)) {
                    return UpdateInfo(code, tag, a.getString("browser_download_url"))
                }
            }
            null
        } catch (e: Exception) {
            null
        }
    }

    /** Downloads the APK into the app's cache. Returns null on failure. */
    suspend fun download(context: Context, info: UpdateInfo, onProgress: (Int) -> Unit): File? = withContext(Dispatchers.IO) {
        try {
            val dir = File(context.cacheDir, "updates").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val out = File(dir, "Kinetro.apk")
            val conn = URL(info.apkUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.instanceFollowRedirects = true
            try {
                if (conn.responseCode != 200) return@withContext null
                val total = conn.contentLength.toLong()
                var done = 0L
                conn.inputStream.use { input ->
                    out.outputStream().use { os ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            os.write(buf, 0, n)
                            done += n
                            if (total > 0) onProgress((done * 100 / total).toInt())
                        }
                    }
                }
                if (out.length() < 1_000_000L) null else out
            } finally {
                conn.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }

    /** True when the installer was opened; false when the user must first allow installs from Kinetro. */
    fun install(context: Context, apk: File): Boolean {
        if (!context.packageManager.canRequestPackageInstalls()) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            return false
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", apk)
        context.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
        )
        return true
    }
}
