package com.fingerfit.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fingerfit.AppViewModel
import com.fingerfit.R
import com.fingerfit.data.Repo
import com.fingerfit.data.Session
import com.fingerfit.data.localDate
import com.fingerfit.data.todayReps
import com.fingerfit.data.toLocalDate
import com.fingerfit.logic.Act
import com.fingerfit.logic.ExerciseType
import com.fingerfit.logic.Plans
import com.fingerfit.logic.Progress
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

internal val PRESETS = listOf(10, 20, 50)

private val BrandGreen = Color(0xFF0B8A6C)
private val BrandDeep = Color(0xFF065F46)
private val BrandBlue = Color(0xFF2F6BFF)
private val Warn = Color(0xFFD97706)

/** A quiet, bordered surface: the one card style used on Home, so nothing looks like a loose button. */
@Composable
private fun Panel(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier.clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
    ) { content() }
}

@Composable
private fun IconBadge(icon: ImageVector, tint: Color, size: Dp = 40.dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(tint.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.55f)) }
}

private class Banner(
    val res: Int, val dark: Boolean,
    val en: String, val bn: String, val subEn: String, val subBn: String,
    val ctaEn: String, val ctaBn: String, val onClick: () -> Unit,
)

@Composable
private fun BannerCard(b: Banner, isBn: Boolean, s: Float) {
    val fg = if (b.dark) Color.White else Color(0xFF0B3B2A)
    Box(Modifier.fillMaxWidth().aspectRatio(2.4f).clip(RoundedCornerShape(20.dp))) {
        Image(
            painter = painterResource(b.res), contentDescription = null,
            modifier = Modifier.matchParentSize(), contentScale = ContentScale.Crop, alignment = Alignment.CenterEnd,
        )
        Column(
            Modifier.fillMaxHeight().fillMaxWidth(0.5f).padding(start = 16.dp, top = 10.dp, bottom = 10.dp),
            verticalArrangement = Arrangement.Center,
        ) {
            Text(
                pick(isBn, b.en, b.bn), fontSize = (17 * s).sp, lineHeight = (21 * s).sp,
                fontWeight = FontWeight.ExtraBold, color = fg, maxLines = 2,
            )
            Spacer(Modifier.height(4.dp))
            Text(pick(isBn, b.subEn, b.subBn), fontSize = (11.5f * s).sp, lineHeight = (14 * s).sp, color = fg.copy(alpha = 0.88f), maxLines = 2)
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.clip(CircleShape).background(if (b.dark) Color.White else BrandGreen)
                    .clickable(onClick = b.onClick).padding(horizontal = 14.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    pick(isBn, b.ctaEn, b.ctaBn), fontSize = (12 * s).sp, fontWeight = FontWeight.Bold,
                    color = if (b.dark) BrandDeep else Color.White, maxLines = 1,
                )
                Spacer(Modifier.width(6.dp))
                Icon(KIcon.Arrow, contentDescription = null, tint = if (b.dark) BrandDeep else Color.White, modifier = Modifier.size(14.dp))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BannerPager(banners: List<Banner>, isBn: Boolean, s: Float) {
    val pager = rememberPagerState { banners.size }
    LaunchedEffect(pager) {
        while (true) {
            delay(5500)
            pager.animateScrollToPage((pager.currentPage + 1) % banners.size)
        }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        HorizontalPager(state = pager, pageSpacing = 12.dp) { i -> BannerCard(banners[i], isBn, s) }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            repeat(banners.size) { i ->
                val on = i == pager.currentPage
                Box(
                    Modifier.height(5.dp).width(if (on) 16.dp else 5.dp).clip(CircleShape)
                        .background(if (on) BrandGreen else MaterialTheme.colorScheme.outlineVariant),
                )
            }
        }
    }
}

@Composable
private fun StatLine(icon: ImageVector, value: String, label: String, s: Float) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconBadge(icon, BrandGreen, 32.dp)
        Spacer(Modifier.width(10.dp))
        Column {
            Text(value, fontWeight = FontWeight.Bold, fontSize = (15 * s).sp, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
            Text(label, fontSize = (11.5f * s).sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
private fun SectionTitle(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onBackground)
        if (action != null) {
            Row(Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onAction).padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(action, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = BrandGreen)
                Icon(KIcon.Chevron, contentDescription = null, tint = BrandGreen, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun ActionCard(
    icon: ImageVector, tint: Color, title: String, subtitle: String, action: String,
    onClick: () -> Unit, modifier: Modifier, s: Float,
) {
    Panel(modifier, onClick) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            IconBadge(icon, tint)
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = (15 * s).sp, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                Text(subtitle, fontSize = (12 * s).sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, minLines = 2)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(action, fontSize = (13 * s).sp, fontWeight = FontWeight.SemiBold, color = tint)
                Icon(KIcon.Chevron, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun MiniCard(icon: ImageVector, tint: Color, title: String, subtitle: String, onClick: () -> Unit, modifier: Modifier, s: Float) {
    Panel(modifier, onClick) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon, tint, 36.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = (14 * s).sp, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                Text(subtitle, fontSize = (11.5f * s).sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            }
        }
    }
}

/** The camera is the heart of Kinetro, so its state is always visible near the top. */
@Composable
private fun CameraPanel(linkStatus: String?, lastCamera: String?, onLink: () -> Unit, onReconnect: () -> Unit, isBn: Boolean, s: Float) {
    val on = linkStatus != null
    Panel(Modifier.fillMaxWidth(), onLink) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBadge(KIcon.Camera, if (on) BrandGreen else BrandBlue, 44.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        pick(isBn, "Camera", "ক্যামেরা"), fontWeight = FontWeight.Bold, fontSize = (15 * s).sp,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        linkStatus?.removePrefix("● ") ?: pick(
                            isBn, "Connect a Wi-Fi camera or a second phone to count your exercise hands-free.",
                            "হাত না লাগিয়ে ব্যায়াম গুনতে একটি ওয়াই-ফাই ক্যামেরা বা দ্বিতীয় ফোন যুক্ত করুন।",
                        ),
                        fontSize = (12 * s).sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3,
                    )
                }
                Spacer(Modifier.width(8.dp))
                Row(
                    Modifier.clip(CircleShape).background((if (on) BrandGreen else Warn).copy(alpha = 0.12f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(if (on) BrandGreen else Warn))
                    Spacer(Modifier.width(5.dp))
                    Text(
                        if (on) pick(isBn, "Connected", "সংযুক্ত") else pick(isBn, "Not connected", "সংযুক্ত নয়"),
                        fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = if (on) BrandGreen else Warn, maxLines = 1,
                    )
                }
            }
            if (!on) {
                Button(
                    onClick = if (lastCamera != null) onReconnect else onLink,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandGreen, contentColor = Color.White),
                ) {
                    if (lastCamera != null) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(pick(isBn, "Connect again", "আবার সংযুক্ত করুন"), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(lastCamera, fontSize = 11.sp, maxLines = 1, color = Color.White.copy(alpha = 0.85f))
                        }
                    } else {
                        Text(pick(isBn, "Connect camera", "ক্যামেরা সংযুক্ত করুন"), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

private val TIPS = listOf(
    "Even ten minutes of movement today is better than none." to "আজ মাত্র দশ মিনিট নড়াচড়াও কিছু না করার চেয়ে ভালো।",
    "Drink water before and after you exercise." to "ব্যায়ামের আগে ও পরে পানি পান করুন।",
    "Warm up for a minute so your muscles are ready." to "পেশি তৈরি রাখতে এক মিনিট গা গরম করে নিন।",
    "Slow, correct reps build more strength than fast ones." to "দ্রুত নয়, ধীরে ও সঠিক ভঙ্গিতে করলেই বেশি শক্তি বাড়ে।",
    "Sleep well. Your body grows stronger while you rest." to "ভালো ঘুমান। বিশ্রামের সময়েই শরীর শক্তিশালী হয়।",
    "Adults need about 150 minutes of moderate activity each week." to "প্রাপ্তবয়স্কদের সপ্তাহে প্রায় ১৫০ মিনিট মাঝারি ব্যায়াম দরকার।",
    "Consistency beats intensity. Show up every day." to "তীব্রতার চেয়ে নিয়মিততা বড়। প্রতিদিন চালিয়ে যান।",
)

@Composable
fun HomeScreen(
    vm: AppViewModel,
    onPlan: () -> Unit,
    onExercise: () -> Unit,
    onDiet: () -> Unit,
    onWalk: () -> Unit,
    onSleep: () -> Unit,
    onInbox: () -> Unit,
    onLink: () -> Unit,
    linkStatus: String? = null,
    lastCamera: String? = null,
    onReconnect: () -> Unit = {},
    profile: com.fingerfit.data.Profile? = null,
    updateVm: com.fingerfit.UpdateViewModel? = null,
    onProgress: () -> Unit = {},
    onProfile: () -> Unit = {},
    onOpenExercise: (ExerciseType) -> Unit = {},
) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val workouts by Repo.workouts.collectAsStateWithLifecycle()
    val walks by Repo.walks.collectAsStateWithLifecycle()
    val sleeps by Repo.sleeps.collectAsStateWithLifecycle()
    val inbox by Repo.inbox.collectAsStateWithLifecycle()
    val unread = inbox.count { !it.read }
    val today = LocalDate.now()
    val isBn = LangState.bn
    val walkMin = remember(walks) { Repo.todayWalkSeconds() / 60 }
    val lastSleep = sleeps.firstOrNull { it.date == today.toString() }

    val acts = remember(workouts, walks, history) { allActs(workouts, walks, history) }
    val todayStat = remember(acts) { Progress.perDay(acts, today, 1)[0] }
    val goal = settings.walkGoalMin
    val ring = Progress.ring(todayStat.minutes, goal)
    val doneToday = remember(workouts, history) {
        workouts.filter { it.t.toLocalDate() == today }.map { it.type }.toSet().size +
            (if (history.todayReps() > 0) 1 else 0)
    }

    val hour = java.time.LocalTime.now().hour
    val greeting = when {
        hour < 12 -> pick(isBn, "Good morning", "শুভ সকাল")
        hour < 17 -> pick(isBn, "Good afternoon", "শুভ অপরাহ্ন")
        else -> pick(isBn, "Good evening", "শুভ সন্ধ্যা")
    }
    val planCount = profile?.let { Plans.exercisePlan(it.age(today), it.bmi(), it.goal, today.dayOfYear).size }
    val kcal = profile?.let { Plans.calories(it.gender, it.weightKg, it.heightCm, it.age(today), it.goal) }
    val popular = remember { POPULAR }
    val tip = TIPS[today.dayOfYear % TIPS.size]
    val banners = listOf(
        Banner(
            R.drawable.banner_run, true, "Stay healthy, stay active", "সুস্থ থাকুন, সক্রিয় থাকুন",
            "Fitness is part of life.", "ফিটনেসই হোক জীবনের অংশ।", "Start", "শুরু করুন", onExercise,
        ),
        Banner(
            R.drawable.banner_food, false, "Eat well, move well", "ভালো খান, নিয়মিত নড়ুন",
            "Balanced food and daily exercise build lasting health.", "সুষম খাবার আর নিয়মিত ব্যায়ামেই টেকসই সুস্থতা।",
            "Today's plan", "আজকের পরিকল্পনা", onPlan,
        ),
        Banner(
            R.drawable.banner_gym, true, "Every rep counts", "প্রতিটি বার গুরুত্বপূর্ণ",
            "Small steps every day make a strong body.", "প্রতিদিনের ছোট পদক্ষেপই গড়ে শক্ত শরীর।",
            "Set up camera", "ক্যামেরা যুক্ত করুন", onLink,
        ),
    )

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.systemBarsPadding()) {
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            // Every phone is a different size: text and the ring scale with the screen width, and very wide screens stay readable.
            val s = (maxWidth.value / 392f).coerceIn(0.88f, 1.2f)
            LazyColumn(
                modifier = Modifier.widthIn(max = 600.dp).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FingerFitLogo(44.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(greeting, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                            Text(
                                profile?.name ?: "Kinetro", fontSize = (22 * s).sp, fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onBackground, maxLines = 1,
                            )
                        }
                        Box(contentAlignment = Alignment.TopEnd) {
                            IconButton(onClick = onInbox) {
                                Icon(KIcon.Bell, contentDescription = pick(isBn, "Notifications", "নোটিফিকেশন"), tint = MaterialTheme.colorScheme.onBackground)
                            }
                            if (unread > 0) {
                                Text(
                                    if (unread > 9) "9+" else "$unread", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 6.dp, end = 6.dp).clip(CircleShape)
                                        .background(Color(0xFFDC2626)).padding(horizontal = 5.dp, vertical = 1.dp),
                                )
                            }
                        }
                        IconButton(onClick = onProfile) {
                            Icon(com.fingerfit.ui.ProfileIcon, contentDescription = pick(isBn, "Profile", "প্রোফাইল"), tint = MaterialTheme.colorScheme.onBackground)
                        }
                    }
                }

                if (updateVm != null) {
                    item { UpdateCard(updateVm, always = false) }
                }

                item { BannerPager(banners, isBn, s) }

                item {
                    Panel(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            SectionTitle(pick(isBn, "Today", "আজ"), pick(isBn, "Weekly progress", "সাপ্তাহিক অগ্রগতি"), onProgress)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val ringSize = (96 * s).dp
                                Box(Modifier.size(ringSize), contentAlignment = Alignment.Center) {
                                    val track = MaterialTheme.colorScheme.outlineVariant
                                    androidx.compose.foundation.Canvas(Modifier.size(ringSize)) {
                                        val stroke = androidx.compose.ui.graphics.drawscope.Stroke(
                                            width = 10.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round,
                                        )
                                        val inset = 6.dp.toPx()
                                        val arcSize = androidx.compose.ui.geometry.Size(size.width - inset * 2, size.height - inset * 2)
                                        val topLeft = androidx.compose.ui.geometry.Offset(inset, inset)
                                        drawArc(track, 0f, 360f, false, topLeft, arcSize, style = stroke)
                                        if (ring > 0f) drawArc(BrandGreen, -90f, 360f * ring, false, topLeft, arcSize, style = stroke)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            "${num(isBn, (ring * 100).toInt())}%", fontSize = (22 * s).sp, fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                        )
                                        Text(pick(isBn, "of goal", "লক্ষ্যের"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Spacer(Modifier.width(16.dp))
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    StatLine(KIcon.Flame, num(isBn, todayStat.reps), pick(isBn, "reps today", "আজকের বার"), s)
                                    StatLine(KIcon.Clock, "${num(isBn, todayStat.minutes)} / ${num(isBn, goal)} ${pick(isBn, "min", "মিনিট")}", pick(isBn, "active time", "সক্রিয় সময়"), s)
                                    StatLine(KIcon.Medal, num(isBn, doneToday), pick(isBn, "exercises done", "ব্যায়াম সম্পন্ন"), s)
                                }
                            }
                        }
                    }
                }

                item { CameraPanel(linkStatus, lastCamera, onLink, onReconnect, isBn, s) }

                item {
                    Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        ActionCard(
                            KIcon.Clipboard, BrandGreen, pick(isBn, "Today's plan", "আজকের পরিকল্পনা"),
                            if (planCount != null) pick(isBn, "$planCount exercises picked for you", "আপনার জন্য ${num(true, planCount)}টি ব্যায়াম")
                            else pick(isBn, "Add your profile to get a plan", "পরিকল্পনা পেতে প্রোফাইল পূরণ করুন"),
                            pick(isBn, "Open", "দেখুন"), onPlan, Modifier.weight(1f).fillMaxHeight(), s,
                        )
                        ActionCard(
                            com.fingerfit.ui.DietIcon, BrandBlue, pick(isBn, "Diet", "ডায়েট"),
                            if (kcal != null) pick(isBn, "About ${kcal.kcal} kcal a day", "দিনে প্রায় ${num(true, kcal.kcal)} কিলোক্যালরি")
                            else pick(isBn, "Food and nutrition guidance", "খাবার ও পুষ্টির নির্দেশনা"),
                            pick(isBn, "Open", "দেখুন"), onDiet, Modifier.weight(1f).fillMaxHeight(), s,
                        )
                    }
                }

                item {
                    Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        MiniCard(
                            KIcon.Walk, BrandGreen, pick(isBn, "Walking", "হাঁটা"),
                            pick(isBn, "${walkMin} of ${settings.walkGoalMin} min", "${num(true, walkMin.toInt())} / ${num(true, settings.walkGoalMin)} মিনিট"),
                            onWalk, Modifier.weight(1f).fillMaxHeight(), s,
                        )
                        MiniCard(
                            KIcon.Moon, BrandBlue, pick(isBn, "Sleep", "ঘুম"),
                            lastSleep?.let { pick(isBn, "${it.minutes / 60}h ${it.minutes % 60}m last night", "গত রাতে ${num(true, it.minutes / 60)} ঘণ্টা ${num(true, it.minutes % 60)} মিনিট") }
                                ?: pick(isBn, "Tap to add", "যোগ করতে চাপুন"),
                            onSleep, Modifier.weight(1f).fillMaxHeight(), s,
                        )
                    }
                }

                item { SectionTitle(pick(isBn, "Popular exercises", "জনপ্রিয় ব্যায়াম"), pick(isBn, "See all", "সব দেখুন"), onExercise) }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(popular, key = { it.name }) { t ->
                            Panel(Modifier.width((156 * s).dp), onClick = { onOpenExercise(t) }) {
                                Column {
                                    val photo = ExerciseImages.of(t.name)
                                    if (photo != null) {
                                        Image(
                                            painter = painterResource(photo), contentDescription = t.title,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxWidth().aspectRatio(4f / 3f),
                                        )
                                    }
                                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(
                                            t.title, fontWeight = FontWeight.Bold, fontSize = (14 * s).sp, maxLines = 2, minLines = 2,
                                            color = MaterialTheme.colorScheme.onSurface,
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(KIcon.Camera, contentDescription = null, tint = BrandGreen, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(5.dp))
                                            Text("${t.defaultTarget} ${t.unit}", fontSize = (12 * s).sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Panel(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconBadge(KIcon.Bulb, Warn, 36.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(pick(isBn, tip.first, tip.second), fontSize = (13 * s).sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
        }
    }
}

/** Everything done so far as plain activities (workouts, walks, finger sessions), for the ring and the charts. */
internal fun allActs(
    workouts: List<com.fingerfit.data.WorkoutRecord>,
    walks: List<com.fingerfit.data.WalkRecord>,
    history: List<Session>,
): List<Act> =
    workouts.map { Act(it.t.toLocalDate(), it.seconds, it.reps) } +
        walks.map { Act(it.t.toLocalDate(), it.seconds, 0) } +
        history.map { Act(it.localDate(), it.durationSec, it.reps) }

@Composable
internal fun SessionRow(s: Session) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(dayLabel(s), fontWeight = FontWeight.SemiBold)
                Text(
                    "${formatDuration(s.durationSec * 1000L)}  ·  target ${s.target}",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (s.targetReached) {
                Icon(Icons.Default.Check, contentDescription = "Target reached", tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
            }
            Text("${s.reps} reps", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
internal fun CustomTargetDialog(current: Int, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    var text by remember { mutableStateOf(current.toString()) }
    val value = text.toIntOrNull()
    val valid = value != null && value in 1..1000
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom target") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter(Char::isDigit).take(4) },
                label = { Text("Repetitions (1-1000)") },
                singleLine = true,
                isError = !valid,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(value!!) }, enabled = valid) { Text("Set target") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

fun formatDuration(ms: Long): String {
    val total = (ms / 1000).toInt()
    return "%d:%02d".format(Locale.US, total / 60, total % 60)
}

private fun dayLabel(s: Session): String {
    val today = LocalDate.now()
    val d = s.localDate()
    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(s.timestamp))
    return when (d) {
        today -> "Today, $time"
        today.minusDays(1) -> "Yesterday, $time"
        else -> SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(s.timestamp))
    }
}
