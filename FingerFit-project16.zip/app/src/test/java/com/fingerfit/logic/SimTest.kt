package com.fingerfit.logic

import kotlin.math.abs
import kotlin.math.hypot
import org.junit.Assert.assertTrue
import org.junit.Test

class SimTest {
    private fun near(a: Float, b: Float, e: Float = 0.012f) = abs(a - b) <= e

    @Test fun every_exercise_has_a_demo_and_valid_numbers() {
        for (t in ExerciseType.values()) {
            val sp = Sims.of(t)
            assertTrue(t.name, sp.cycleMs in 1500..9000)
            for (i in 0 until 60) {
                val f = SimMath.frameAt(sp, sp.cycleMs.toLong() * 3 * i / 60)
                for (q in SimMath.figure(f.pose, sp.view).all()) assertTrue("${t.name} NaN", !q.x.isNaN() && !q.y.isNaN())
                assertTrue(f.step in 0..3)
            }
        }
    }

    @Test fun bones_keep_their_length_while_moving() {
        val sp = Sims.of(ExerciseType.SQUATS)
        for (i in 0 until 40) {
            val fg = SimMath.figure(SimMath.frameAt(sp, sp.cycleMs.toLong() * i / 40).pose, sp.view)
            assertTrue(near(hypot(fg.kneeNear.x - fg.hipNear.x, fg.kneeNear.y - fg.hipNear.y), SimMath.TH, 0.002f))
            assertTrue(near(hypot(fg.ankleNear.x - fg.kneeNear.x, fg.ankleNear.y - fg.kneeNear.y), SimMath.SH, 0.002f))
        }
    }

    @Test fun feet_stay_on_the_floor_when_standing() {
        for (t in listOf(ExerciseType.SQUATS, ExerciseType.JUMPING_JACKS)) {
            val sp = Sims.of(t)
            val f = SimMath.figure(sp.steps[0].pose, sp.view)
            assertTrue(t.name, near(minOf(f.toeNear.y, f.toeFar.y, f.ankleNear.y), 0f, 0.02f))
        }
    }

    @Test fun pushup_hands_and_toes_stay_planted() {
        val sp = Sims.of(ExerciseType.PUSH_UPS)
        val a = SimMath.figure(SimPoses.PU_A, sp.view); val b = SimMath.figure(SimPoses.PU_B, sp.view)
        assertTrue(near(a.wristNear.y, a.toeNear.y) && near(b.wristNear.y, b.toeNear.y))
        assertTrue(near(a.wristNear.x - a.toeNear.x, b.wristNear.x - b.toeNear.x))
        assertTrue(b.neck.y < a.neck.y - 0.08f) // chest really goes down
    }

    @Test fun jumping_jack_leaves_the_floor() {
        val sp = Sims.of(ExerciseType.JUMPING_JACKS)
        val f = SimMath.figure(SimPoses.JJ_B, sp.view)
        assertTrue(f.ankleNear.y > 0.03f)
    }

    @Test fun bridge_lifts_hips_but_shoulders_stay() {
        val sp = Sims.of(ExerciseType.GLUTE_BRIDGES)
        val a = SimMath.figure(SimPoses.GB_A, sp.view); val b = SimMath.figure(SimPoses.GB_B, sp.view)
        assertTrue(b.hip.y > a.hip.y + 0.1f)
        assertTrue(near(b.neck.y, b.toeNear.y, 0.02f))
    }
}
