package com.fingerfit.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fingerfit.logic.SimFigure
import com.fingerfit.logic.SimMath
import com.fingerfit.logic.SimPt
import com.fingerfit.logic.SimView
import com.fingerfit.logic.Sims
import com.fingerfit.logic.ExerciseType
import kotlin.math.max
import kotlin.math.min

private val BodyNear = Color(0xFF33497F)
private val BodyFar = Color(0xFF8D9CC6)
private val Hot = Color(0xFFFF7A45)
private val HotFar = Color(0xFFFFB28F)
private val Skin = Color(0xFFF7D2B0)
private val MatColor = Color(0xFF3FAE91)

/**
 * A looping demo of the exercise, drawn as a moving figure, with the written step that matches
 * what the figure is doing highlighted underneath. Works for every exercise from SimSpec data.
 */
@Composable
fun SimPlayer(type: ExerciseType, steps: List<String>, modifier: Modifier = Modifier) {
    val spec = remember(type) { Sims.of(type) }
    val bounds = remember(type) { SimMath.bounds(spec) }
    var playing by remember { mutableStateOf(true) }
    var slow by remember { mutableStateOf(false) }
    var clock by remember(type) { mutableStateOf(0f) }

    LaunchedEffect(playing, slow, type) {
        if (!playing) return@LaunchedEffect
        var last = androidx.compose.runtime.withFrameNanos { it }
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            clock += (now - last) / 1_000_000f * (if (slow) 0.5f else 1f)
            last = now
        }
    }

    val frame = SimMath.frameAt(spec, clock.toLong())
    val fig = SimMath.figure(frame.pose, spec.view)
    val step = frame.step.coerceIn(0, max(0, steps.size - 1))

    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            Modifier.fillMaxWidth().height(250.dp)
                .background(HeroTint, RoundedCornerShape(24.dp)),
        ) {
            Canvas(Modifier.fillMaxWidth().height(250.dp)) {
                val padX = 18.dp.toPx(); val floorPad = 30.dp.toPx(); val topPad = 14.dp.toPx()
                val wUnits = bounds[1] - bounds[0]
                val sc = min((size.width - 2 * padX) / wUnits, (size.height - floorPad - topPad) / bounds[2])
                val ox = size.width / 2f - (bounds[0] + bounds[1]) / 2f * sc
                val gy = size.height - floorPad
                fun o(p: SimPt) = Offset(ox + p.x * sc, gy - p.y * sc)

                if (spec.mat) {
                    drawRoundRect(MatColor, Offset(padX * 0.5f, gy - 2.dp.toPx()), Size(size.width - padX, 11.dp.toPx()), CornerRadius(6.dp.toPx()))
                } else {
                    drawLine(Color(0x33000000), Offset(padX * 0.5f, gy), Offset(size.width - padX * 0.5f, gy), 3.dp.toPx(), StrokeCap.Round)
                    // soft shadow that shrinks when the person jumps
                    val lift = (fig.ankleNear.y.coerceAtLeast(0f) * sc / 40.dp.toPx()).coerceIn(0f, 1f)
                    drawOval(Color(0x22000000), Offset(size.width / 2f - 46.dp.toPx() * (1 - 0.3f * lift), gy + 2.dp.toPx()), Size(92.dp.toPx() * (1 - 0.3f * lift), 7.dp.toPx()))
                }
                drawFigure(fig, spec.view, spec.hotArms, spec.hotLegs, spec.hotCore, ::o, sc)
            }
        }

        // the written step that matches the picture
        Column(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (i in steps.indices) {
                    Box(
                        Modifier.size(if (i == step) 12.dp else 8.dp)
                            .background(if (i == step) MaterialTheme.colorScheme.tertiary else Color(0x33000000), CircleShape),
                    )
                }
                androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
                Text("Rep ${frame.cycle + 1}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("Step ${step + 1} of ${steps.size}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
            Text(if (steps.isEmpty()) "" else steps[step], fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            FilledTonalButton(onClick = { playing = !playing }) { Text(if (playing) "⏸ Pause" else "▶ Play") }
            FilterChip(selected = slow, onClick = { slow = !slow }, label = { Text("Slow") })
            FilterChip(selected = false, onClick = { clock = 0f; playing = true }, label = { Text("Restart") })
        }
        Text(
            (if (spec.view == SimView.SIDE) "Side view" else "Front view") + "  ·  Orange shows the muscles that work.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

private fun DrawScope.drawFigure(
    f: SimFigure, view: SimView, hotArms: Boolean, hotLegs: Boolean, hotCore: Boolean,
    o: (SimPt) -> Offset, sc: Float,
) {
    val limb = 0.046f * sc
    val torso = 0.085f * sc
    fun line(a: SimPt, b: SimPt, c: Color, w: Float) = drawLine(c, o(a), o(b), w, StrokeCap.Round)
    val armFar = if (hotArms) HotFar else BodyFar
    val legFar = if (hotLegs) HotFar else BodyFar
    val armNear = if (hotArms) Hot else BodyNear
    val legNear = if (hotLegs) Hot else BodyNear
    val core = if (hotCore) Hot else BodyNear

    // far side first, so the near side overlaps it
    line(f.shoulderFar, f.elbowFar, armFar, limb); line(f.elbowFar, f.wristFar, armFar, limb * 0.9f)
    line(f.hipFar, f.kneeFar, legFar, limb * 1.1f); line(f.kneeFar, f.ankleFar, legFar, limb); line(f.ankleFar, f.toeFar, legFar, limb * 0.8f)
    if (view == SimView.FRONT) {
        line(f.shoulderNear, f.shoulderFar, core, torso * 0.6f)
        line(f.hipNear, f.hipFar, core, torso * 0.6f)
    }
    line(f.hip, f.neck, core, torso)
    line(f.hipNear, f.kneeNear, legNear, limb * 1.1f); line(f.kneeNear, f.ankleNear, legNear, limb); line(f.ankleNear, f.toeNear, legNear, limb * 0.8f)
    line(f.shoulderNear, f.elbowNear, armNear, limb); line(f.elbowNear, f.wristNear, armNear, limb * 0.9f)
    // neck and head
    line(f.neck, f.head, Skin, limb * 0.7f)
    val c = o(f.head); val r = SimMath.HEAD_R * sc
    drawCircle(Skin, r, c)
    drawCircle(BodyNear, r, c, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx()))
    // joint dots
    for (p in listOf(f.elbowNear, f.kneeNear, f.wristNear)) drawCircle(Color(0x55FFFFFF), limb * 0.32f, o(p))
}
