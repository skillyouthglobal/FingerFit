package com.fingerfit.logic

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Exercise demo engine. A person is a skeleton described by joint ANGLES (degrees), so bones never
 * stretch while moving. 0 = pointing down, 90 = pointing right, 180 = up, -90 = left.
 * FRONT view: arm/leg angles are "outward from the body" (mirrored for the left side).
 * SIDE view: the person faces right; limbs 1 = near side, limbs 2 = far side.
 * a1/a2 = upper/lower arm (near), b1/b2 = far arm, l1/l2 = thigh/shin (near), r1/r2 = far leg,
 * lf/rf = feet, lift = height above the floor (hops).
 *
 * To add an exercise later: write a few SimPose values and a SimSpec; no drawing code changes.
 */
class SimPose(
    val t: Float = 180f, val h: Float = 180f,
    val a1: Float = 8f, val a2: Float = 8f, val b1: Float = 8f, val b2: Float = 8f,
    val l1: Float = 3f, val l2: Float = 3f, val r1: Float = 3f, val r2: Float = 3f,
    val lf: Float = 90f, val rf: Float = 90f, val lift: Float = 0f,
) {
    fun mix(o: SimPose, f: Float): SimPose = SimPose(
        lerp(t, o.t, f), lerp(h, o.h, f), lerp(a1, o.a1, f), lerp(a2, o.a2, f), lerp(b1, o.b1, f), lerp(b2, o.b2, f),
        lerp(l1, o.l1, f), lerp(l2, o.l2, f), lerp(r1, o.r1, f), lerp(r2, o.r2, f), lerp(lf, o.lf, f), lerp(rf, o.rf, f),
        lerp(lift, o.lift, f),
    )
}

private fun lerp(a: Float, b: Float, f: Float) = a + (b - a) * f

enum class SimView { FRONT, SIDE }

/** Move to [pose] in [moveMs], then stay [holdMs]. [step] = which written step is being shown. */
class SimStep(val pose: SimPose, val moveMs: Int, val holdMs: Int, val step: Int)

class SimSpec(
    val view: SimView,
    val steps: List<SimStep>,
    val hotArms: Boolean = false,
    val hotLegs: Boolean = false,
    val hotCore: Boolean = false,
    val mat: Boolean = false,
) {
    val cycleMs: Int = steps.sumOf { it.moveMs + it.holdMs }
}

class SimPt(val x: Float, val y: Float)

/** Joint positions in metres-ish units, floor at y = 0, y grows upward, x = 0 at the feet. */
class SimFigure(
    val head: SimPt, val neck: SimPt, val hip: SimPt,
    val shoulderNear: SimPt, val shoulderFar: SimPt, val hipNear: SimPt, val hipFar: SimPt,
    val elbowNear: SimPt, val wristNear: SimPt, val elbowFar: SimPt, val wristFar: SimPt,
    val kneeNear: SimPt, val ankleNear: SimPt, val toeNear: SimPt,
    val kneeFar: SimPt, val ankleFar: SimPt, val toeFar: SimPt,
) {
    fun all(): List<SimPt> = listOf(
        head, neck, hip, shoulderNear, shoulderFar, hipNear, hipFar, elbowNear, wristNear, elbowFar, wristFar,
        kneeNear, ankleNear, toeNear, kneeFar, ankleFar, toeFar,
    )
}

object SimMath {
    const val TORSO = 0.30f; const val HEAD = 0.115f; const val UA = 0.17f; const val FA = 0.16f
    const val TH = 0.24f; const val SH = 0.23f; const val FT = 0.09f; const val SW = 0.095f; const val HW = 0.06f
    const val HEAD_R = 0.065f

    private fun dx(a: Float) = sin(a * PI / 180.0).toFloat()
    private fun dy(a: Float) = -cos(a * PI / 180.0).toFloat() // up is positive here

    fun figure(p: SimPose, view: SimView): SimFigure {
        val front = view == SimView.FRONT
        fun pt(x: Float, y: Float) = SimPt(x, y)
        val tx = dx(p.t); val ty = dy(p.t)
        val hipX = 0f; val hipY = 0f
        val neckX = hipX + tx * TORSO; val neckY = hipY + ty * TORSO
        val headX = neckX + dx(p.h) * HEAD; val headY = neckY + dy(p.h) * HEAD
        // "left" perpendicular of the torso for the front view
        val lx = -ty; val ly = tx
        val sNear = if (front) pt(neckX + lx * SW, neckY + ly * SW) else pt(neckX, neckY)
        val sFar = if (front) pt(neckX - lx * SW, neckY - ly * SW) else pt(neckX, neckY)
        val hNear = if (front) pt(hipX + lx * HW, hipY + ly * HW) else pt(hipX, hipY)
        val hFar = if (front) pt(hipX - lx * HW, hipY - ly * HW) else pt(hipX, hipY)
        fun ang(a: Float, near: Boolean) = if (front && near) -a else a
        fun arm(s: SimPt, u: Float, f: Float, near: Boolean): Pair<SimPt, SimPt> {
            val e = pt(s.x + dx(ang(u, near)) * UA, s.y + dy(ang(u, near)) * UA)
            return e to pt(e.x + dx(ang(f, near)) * FA, e.y + dy(ang(f, near)) * FA)
        }
        fun leg(h: SimPt, th: Float, sh: Float, ft: Float, near: Boolean): Triple<SimPt, SimPt, SimPt> {
            val k = pt(h.x + dx(ang(th, near)) * TH, h.y + dy(ang(th, near)) * TH)
            val a = pt(k.x + dx(ang(sh, near)) * SH, k.y + dy(ang(sh, near)) * SH)
            return Triple(k, a, pt(a.x + dx(ang(ft, near)) * FT, a.y + dy(ang(ft, near)) * FT))
        }
        val (eN, wN) = arm(sNear, p.a1, p.a2, true)
        val (eF, wF) = arm(sFar, p.b1, p.b2, false)
        val (kN, aN, tN) = leg(hNear, p.l1, p.l2, p.lf, true)
        val (kF, aF, tF) = leg(hFar, p.r1, p.r2, p.rf, false)
        val pts = listOf(headX to headY - HEAD_R, neckX to neckY, hipX to hipY, sNear.x to sNear.y, sFar.x to sFar.y,
            wN.x to wN.y, wF.x to wF.y, eN.x to eN.y, eF.x to eF.y, kN.x to kN.y, kF.x to kF.y,
            aN.x to aN.y, aF.x to aF.y, tN.x to tN.y, tF.x to tF.y, hipX to hipY)
        val minY = pts.minOf { it.second }
        val cx = if (front) hipX else (aN.x + aF.x) / 2f // keep planted feet in place
        val oy = -minY + max(0f, p.lift)
        fun s(q: SimPt) = SimPt(q.x - cx, q.y + oy)
        return SimFigure(
            s(pt(headX, headY)), s(pt(neckX, neckY)), s(pt(hipX, hipY)), s(sNear), s(sFar), s(hNear), s(hFar),
            s(eN), s(wN), s(eF), s(wF), s(kN), s(aN), s(tN), s(kF), s(aF), s(tF),
        )
    }

    private fun ease(f: Float): Float { val c = min(1f, max(0f, f)); return c * c * (3f - 2f * c) }

    class Frame(val pose: SimPose, val step: Int, val cycle: Int)

    /** Pose of the demo at [timeMs] since start (loops forever). */
    fun frameAt(spec: SimSpec, timeMs: Long): Frame {
        val total = spec.cycleMs.toLong()
        val cycle = (timeMs / total).toInt()
        var t = (timeMs % total).toInt()
        val n = spec.steps.size
        for (i in 0 until n) {
            val s = spec.steps[i]
            val prev = spec.steps[(i + n - 1) % n].pose
            if (t < s.moveMs) return Frame(prev.mix(s.pose, ease(t.toFloat() / s.moveMs)), s.step, cycle)
            t -= s.moveMs
            if (t < s.holdMs) return Frame(s.pose, s.step, cycle)
            t -= s.holdMs
        }
        return Frame(spec.steps.last().pose, spec.steps.last().step, cycle)
    }

    /** Fixed drawing window for a spec so the picture never changes size while playing: minX, maxX, maxY. */
    fun bounds(spec: SimSpec): FloatArray {
        var mnx = 0f; var mxx = 0f; var mxy = 0f
        val n = 48
        for (i in 0 until n) {
            val f = frameAt(spec, (spec.cycleMs.toLong() * i) / n)
            for (q in figure(f.pose, spec.view).all()) {
                mnx = min(mnx, q.x - 0.07f); mxx = max(mxx, q.x + 0.07f); mxy = max(mxy, q.y + 0.07f)
            }
        }
        return floatArrayOf(mnx, mxx, mxy)
    }
}

object Sims {
    private val P = SimPoses
    private fun s(p: SimPose, move: Int, hold: Int, step: Int) = SimStep(p, move, hold, step)

    fun of(type: ExerciseType): SimSpec = when (type) {
        ExerciseType.JUMPING_JACKS -> SimSpec(SimView.FRONT, listOf(
            s(P.JJ_A, 350, 700, 0), s(P.JJ_B, 380, 650, 1), s(P.JJ_A, 380, 300, 2),
        ), hotArms = true, hotLegs = true)
        ExerciseType.SQUATS -> SimSpec(SimView.SIDE, listOf(
            s(P.SQ_A, 400, 900, 0), s(P.SQ_A.mix(P.SQ_B, 0.55f), 700, 150, 1),
            s(P.SQ_B, 600, 900, 2), s(P.SQ_A, 1100, 500, 3),
        ), hotLegs = true)
        ExerciseType.PUSH_UPS -> SimSpec(SimView.SIDE, listOf(
            s(P.PU_A, 500, 900, 0), s(P.PU_A.mix(P.PU_B, 0.55f), 900, 100, 1),
            s(P.PU_B, 700, 700, 2), s(P.PU_A, 1100, 400, 2),
        ), hotArms = true, hotCore = true, mat = true)
        ExerciseType.LUNGES -> SimSpec(SimView.SIDE, listOf(
            s(P.LU_STAND, 500, 700, 0), s(P.LU_L, 900, 800, 1), s(P.LU_STAND, 900, 300, 2),
            s(P.LU_R, 900, 800, 3), s(P.LU_STAND, 900, 300, 2),
        ), hotLegs = true)
        ExerciseType.HIGH_KNEES -> SimSpec(SimView.SIDE, listOf(
            s(P.HK_UP, 420, 150, 0), s(P.HK_MID, 320, 10, 1), s(P.HK_UP2, 420, 150, 0), s(P.HK_MID, 320, 10, 2),
        ), hotLegs = true, hotCore = true)
        ExerciseType.CRUNCHES -> SimSpec(SimView.SIDE, listOf(
            s(P.CR_A, 500, 700, 0), s(P.CR_A, 1, 800, 1), s(P.CR_B, 1000, 600, 2), s(P.CR_A, 1500, 400, 3),
        ), hotCore = true, mat = true)
        ExerciseType.GLUTE_BRIDGES -> SimSpec(SimView.SIDE, listOf(
            s(P.GB_A, 500, 800, 0), s(P.GB_B, 1100, 200, 1), s(P.GB_B, 1, 1000, 2), s(P.GB_A, 1400, 400, 3),
        ), hotLegs = true, hotCore = true, mat = true)
        ExerciseType.PLANK -> SimSpec(SimView.SIDE, listOf(
            s(P.PL_A, 500, 900, 0), s(P.PL_A, 1, 900, 1), s(P.PL_A, 1, 900, 2),
            s(P.PL_B, 1500, 200, 3), s(P.PL_A, 1500, 200, 3),
        ), hotCore = true, hotArms = true, mat = true)
    }
}
